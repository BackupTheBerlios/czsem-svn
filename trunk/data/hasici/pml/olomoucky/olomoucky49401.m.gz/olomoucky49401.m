<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky49401.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky49401.txt-001-p1s1">
  <m id="m-olomoucky49401.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W2</w.rf>
   <form>jednom</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W3</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W4</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W5</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W8</w.rf>
   <form>Starého</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W9</w.rf>
   <form>Města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W11</w.rf>
   <form>poškozené</form>
   <lemma>poškozený_^(*4dit)</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W12</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W13</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W14</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W15</w.rf>
   <form>Starém</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W16</w.rf>
   <form>Městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p1s2">
  <m id="m-olomoucky49401.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W4</w.rf>
   <form>plechovou</form>
   <lemma>plechový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W5</w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W7</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W8</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W9</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W10</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W11</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W13</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W14</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W15</w.rf>
   <form>ohnutá</form>
   <lemma>ohnutý_^(*3out)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W16</w.rf>
   <form>napůl</form>
   <lemma>napůl</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p1s3">
  <m id="m-olomoucky49401.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s3W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s3W3</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s3W4</w.rf>
   <form>použili</form>
   <lemma>použít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s3W5</w.rf>
   <form>rozbrušovací</form>
   <lemma>rozbrušovací_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s3W6</w.rf>
   <form>pilu</form>
   <lemma>pila</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p1s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p2s1">
  <m id="m-olomoucky49401.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p2s1W1</w.rf>
   <form>OLOMOUC</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p3s1">
  <m id="m-olomoucky49401.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W2</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W3</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W7</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W9</w.rf>
   <form>52</form>
   <lemma>52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W11</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W12</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W14</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W15</w.rf>
   <form>Šternberku</form>
   <lemma>Šternberk-1_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W16</w.rf>
   <form>požádáni</form>
   <lemma>požádat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W17</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W18</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W19</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W20</w.rf>
   <form>odchytu</form>
   <lemma>odchyt</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W21</w.rf>
   <form>bobra</form>
   <lemma>bobr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W23</w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W24</w.rf>
   <form>Sitka</form>
   <lemma>Sitko_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W25</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W26</w.rf>
   <form>Šternberku</form>
   <lemma>Šternberk-2_;S</lemma>
   <tag>NNMS6-----A---1</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p3s2">
  <m id="m-olomoucky49401.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W5</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W7</w.rf>
   <form>městskou</form>
   <lemma>městský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W8</w.rf>
   <form>policií</form>
   <lemma>policie</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W10</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W11</w.rf>
   <form>dohodě</form>
   <lemma>dohoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W13</w.rf>
   <form>odborem</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W14</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W15</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W16</w.rf>
   <form>bobra</form>
   <lemma>bobr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W17</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W18</w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W19</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W20</w.rf>
   <form>sítě</form>
   <lemma>síť</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W21</w.rf>
   <form>vytáhli</form>
   <lemma>vytáhnout</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p3s3">
  <m id="m-olomoucky49401.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W1</w.rf>
   <form>Bobr</form>
   <lemma>bobr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W3</w.rf>
   <form>předán</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W4</w.rf>
   <form>městské</form>
   <lemma>městský</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W5</w.rf>
   <form>policii</form>
   <lemma>policie</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W9</w.rf>
   <form>vrátili</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W10</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W12</w.rf>
   <form>základnu</form>
   <lemma>základna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p3s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p4s1">
  <m id="m-olomoucky49401.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p4s1W1</w.rf>
   <form>PŘEROV</form>
   <lemma>Přerov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p5s1">
  <m id="m-olomoucky49401.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W2</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W3</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W6</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W8</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W9</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W10</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W12</w.rf>
   <form>nahlášeno</form>
   <lemma>nahlásit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W14</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W15</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W18</w.rf>
   <form>Přerově</form>
   <lemma>Přerov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W20</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W22</w.rf>
   <form>Oseku</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W23</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W24</w.rf>
   <form>Bečvou</form>
   <lemma>Bečva_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W25</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W26</w.rf>
   <form>sloup</form>
   <lemma>sloup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W27</w.rf>
   <form>veřejného</form>
   <lemma>veřejný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W28</w.rf>
   <form>osvětlení</form>
   <lemma>osvětlení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p5s2">
  <m id="m-olomoucky49401.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W3</w.rf>
   <form>vyrazili</form>
   <lemma>vyrazit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W4</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W7</w.rf>
   <form>Oseku</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W9</w.rf>
   <form>Bečvou</form>
   <lemma>Bečva_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W11</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W12</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W13</w.rf>
   <form>dohodě</form>
   <lemma>dohoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W14</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W15</w.rf>
   <form>starostkou</form>
   <lemma>starostka_^(^FM*2a)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W16</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W17</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W18</w.rf>
   <form>vypnutí</form>
   <lemma>vypnutí_^(*3out)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W19</w.rf>
   <form>elektrického</form>
   <lemma>elektrický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W20</w.rf>
   <form>proudu</form>
   <lemma>proud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W22</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W23</w.rf>
   <form>mohli</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W24</w.rf>
   <form>odstřihnout</form>
   <lemma>odstřihnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W25</w.rf>
   <form>dráty</form>
   <lemma>drát-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W27</w.rf>
   <form>zaizolovat</form>
   <lemma>zaizolovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W28</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W30</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W31</w.rf>
   <form>rozbrušovací</form>
   <lemma>rozbrušovací_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W32</w.rf>
   <form>pily</form>
   <lemma>pila</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W33</w.rf>
   <form>sloup</form>
   <lemma>sloup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W34</w.rf>
   <form>veřejného</form>
   <lemma>veřejný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W35</w.rf>
   <form>osvětlení</form>
   <lemma>osvětlení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W36</w.rf>
   <form>rozřezat</form>
   <lemma>rozřezat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p5s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p5s2W37</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p6s1">
  <m id="m-olomoucky49401.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p6s1W1</w.rf>
   <form>SEVER</form>
   <lemma>sever</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p7s1">
  <m id="m-olomoucky49401.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W2</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W3</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W8</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W9</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W10</w.rf>
   <form>32</form>
   <lemma>32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W12</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W14</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W15</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W18</w.rf>
   <form>Šumperku</form>
   <lemma>Šumperk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W19</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W20</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W22</w.rf>
   <form>Sobotíně</form>
   <lemma>Sobotín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p7s2">
  <m id="m-olomoucky49401.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W3</w.rf>
   <form>vyrazili</form>
   <lemma>vyrazit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W7</w.rf>
   <form>Šumperku</form>
   <lemma>Šumperk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W9</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W12</w.rf>
   <form>Sobotína</form>
   <lemma>Sobotín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p7s3">
  <m id="m-olomoucky49401.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W4</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W6</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W8</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W11</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W13</w.rf>
   <form>travnaté</form>
   <lemma>travnatý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W14</w.rf>
   <form>plochy</form>
   <lemma>plocha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W15</w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W17</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W18</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W19</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W20</w.rf>
   <form>m2</form>
   <lemma>m2-1_:B_^(metr_čtvereční)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p7s4">
  <m id="m-olomoucky49401.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W3</w.rf>
   <form>zlikvidovali</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W4</w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W5</w.rf>
   <form>proudem</form>
   <lemma>proud</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W6</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W8</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W9</w.rf>
   <form>hrábí</form>
   <lemma>hrábě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W10</w.rf>
   <form>rozhrabali</form>
   <lemma>rozhrabat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W11</w.rf>
   <form>požářiště</form>
   <lemma>požářiště</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W13</w.rf>
   <form>dokonale</form>
   <lemma>dokonale_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W14</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W15</w.rf>
   <form>prolili</form>
   <lemma>prolít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W16</w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p7s5">
  <m id="m-olomoucky49401.txt-001-p7s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s5W1</w.rf>
   <form>Místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s5W2</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s5W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s5W4</w.rf>
   <form>předáno</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s5W5</w.rf>
   <form>revírníkovi</form>
   <lemma>revírník</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49401.txt-001-p7s6">
  <m id="m-olomoucky49401.txt-001-p7s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W5</w.rf>
   <form>stanovena</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W6</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W7</w.rf>
   <form>úder</form>
   <lemma>úder</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W8</w.rf>
   <form>blesku</form>
   <lemma>blesk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49401.txt-001-p7s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49401.txt-001-p7s6W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
