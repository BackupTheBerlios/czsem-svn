<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky49557.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky49557.txt-001-p1s1">
  <m id="m-olomoucky49557.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W1</w.rf>
   <form>Podstatou</form>
   <lemma>podstata</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W2</w.rf>
   <form>výjezdu</form>
   <lemma>výjezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W5</w.rf>
   <form>provádění</form>
   <lemma>provádění_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W6</w.rf>
   <form>likvidace</form>
   <lemma>likvidace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W7</w.rf>
   <form>rojů</form>
   <lemma>roj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W8</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W9</w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W11</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W12</w.rf>
   <form>hrozí</form>
   <lemma>hrozit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W13</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W14</w.rf>
   <form>pobodání</form>
   <lemma>pobodání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W15</w.rf>
   <form>dítěte</form>
   <lemma>dítě</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W16</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W17</w.rf>
   <form>alergika</form>
   <lemma>alergik</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p1s2">
  <m id="m-olomoucky49557.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W2</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W3</w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W4</w.rf>
   <form>musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W5</w.rf>
   <form>upozornit</form>
   <lemma>upozornit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W9</w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W10</w.rf>
   <form>deratizační</form>
   <lemma>deratizační</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W11</w.rf>
   <form>firma</form>
   <lemma>firma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W13</w.rf>
   <form>nevyjedou</form>
   <lemma>vyjet</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W15</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W17</w.rf>
   <form>požádání</form>
   <lemma>požádání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W18</w.rf>
   <form>každého</form>
   <lemma>každý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p1s3">
  <m id="m-olomoucky49557.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s3W1</w.rf>
   <form>Musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s3W2</w.rf>
   <form>vyhodnotit</form>
   <lemma>vyhodnotit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s3W3</w.rf>
   <form>nebezpečnost</form>
   <lemma>nebezpečnost-2_^(jen_jako_práv._termín:_činu,_pachatele)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s3W4</w.rf>
   <form>situace</form>
   <lemma>situace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p1s4">
  <m id="m-olomoucky49557.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W1</w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W2</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W3</w.rf>
   <form>dorazí</form>
   <lemma>dorazit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W5</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W7</w.rf>
   <form>zjistí</form>
   <lemma>zjistit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W9</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W10</w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W11</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W12</w.rf>
   <form>nehrozí</form>
   <lemma>hrozit_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W14</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W15</w.rf>
   <form>neprovede</form>
   <lemma>provést</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s4W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p1s5">
  <m id="m-olomoucky49557.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W2</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W3</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W4</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W5</w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W6</w.rf>
   <form>občana</form>
   <lemma>občan</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W8</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W9</w.rf>
   <form>zneužil</form>
   <lemma>zneužít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W10</w.rf>
   <form>linku</form>
   <lemma>linka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W11</w.rf>
   <form>tísňového</form>
   <lemma>tísňový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W12</w.rf>
   <form>volání</form>
   <lemma>volání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W14</w.rf>
   <form>pokutovat</form>
   <lemma>pokutovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s5W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p1s6">
  <m id="m-olomoucky49557.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W1</w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W3</w.rf>
   <form>občan</form>
   <lemma>občan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W4</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W5</w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W6</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W7</w.rf>
   <form>svého</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W8</w.rf>
   <form>uvážení</form>
   <lemma>uvážení_,s_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W10</w.rf>
   <form>vyhodnotit</form>
   <lemma>vyhodnotit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W11</w.rf>
   <form>situaci</form>
   <lemma>situace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W13</w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W14</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W15</w.rf>
   <form>rozmyslet</form>
   <lemma>rozmyslet</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W17</w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W18</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W19</w.rf>
   <form>zavolá</form>
   <lemma>zavolat_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W20</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W21</w.rf>
   <form>ne</form>
   <lemma>ne</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s6W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p1s7">
  <m id="m-olomoucky49557.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W1</w.rf>
   <form>My</form>
   <lemma>já</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W2</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W4</w.rf>
   <form>letošním</form>
   <lemma>letošní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W5</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W6</w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W7</w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W8</w.rf>
   <form>výjezdy</form>
   <lemma>výjezd</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W9</w.rf>
   <form>omezovat</form>
   <lemma>omezovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W10</w.rf>
   <form>opravdu</form>
   <lemma>opravdu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W11</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W13</w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W14</w.rf>
   <form>nejnutnější</form>
   <lemma>nutný</lemma>
   <tag>AAIP4----3A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W15</w.rf>
   <form>případy</form>
   <lemma>případ</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p1s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p1s7W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p2s1">
  <m id="m-olomoucky49557.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p2s1W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p2s1W2</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p2s1W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p2s1W4</w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2_^(totiž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p2s1W5</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p2s1W6</w.rf>
   <form>provádí</form>
   <lemma>provádět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p2s1W7</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p3s1">
  <m id="m-olomoucky49557.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W1</w.rf>
   <form>Tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W2</w.rf>
   <form>postup</form>
   <lemma>postup</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W4</w.rf>
   <form>konzultován</form>
   <lemma>konzultovat_:T_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W5</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W6</w.rf>
   <form>včelaři</form>
   <lemma>včelař</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W8</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W10</w.rf>
   <form>něm</form>
   <lemma>on-1</lemma>
   <tag>P5ZS6--3-------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W11</w.rf>
   <form>spatřují</form>
   <lemma>spatřovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W12</w.rf>
   <form>výhodu</form>
   <lemma>výhoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W13</w.rf>
   <form>nejrychlejšího</form>
   <lemma>rychlý</lemma>
   <tag>AAIS2----3A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W15</w.rf>
   <form>nejčistšího</form>
   <lemma>čistý</lemma>
   <tag>AAIS2----3A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W17</w.rf>
   <form>nejjednoduššího</form>
   <lemma>jednoduchý</lemma>
   <tag>AAIS2----3A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W18</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p3s2">
  <m id="m-olomoucky49557.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W1</w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W2</w.rf>
   <form>včelař</form>
   <lemma>včelař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W3</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W4</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W5</w.rf>
   <form>hlídat</form>
   <lemma>hlídat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W6</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W7</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8NS4---------1</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W8</w.rf>
   <form>včelstvo</form>
   <lemma>včelstvo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W10</w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWYS1----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W12</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W13</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W14</w.rf>
   <form>nechce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W15</w.rf>
   <form>cizí</form>
   <lemma>cizí</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W16</w.rf>
   <form>nalezený</form>
   <lemma>nalezený_^(*3nout)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W17</w.rf>
   <form>roj</form>
   <lemma>roj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W18</w.rf>
   <form>vzít</form>
   <lemma>vzít_^(př._sebrat_něco;_brát_ohled,_zřetel,...)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W20</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W21</w.rf>
   <form>hrozí</form>
   <lemma>hrozit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W22</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W23</w.rf>
   <form>přenosu</form>
   <lemma>přenos</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W24</w.rf>
   <form>chorob</form>
   <lemma>choroba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p3s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p4s1">
  <m id="m-olomoucky49557.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W2</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W3</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W4</w.rf>
   <form>používají</form>
   <lemma>používat_:T_^(*3t)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W5</w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W6</w.rf>
   <form>speciální</form>
   <lemma>speciální</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W7</w.rf>
   <form>oblečení</form>
   <lemma>oblečení_^(*5éci)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W10</w.rf>
   <form>včelařská</form>
   <lemma>včelařský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W11</w.rf>
   <form>kukla</form>
   <lemma>kukla</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W13</w.rf>
   <form>nejlépe</form>
   <lemma>dobře</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W14</w.rf>
   <form>bílá</form>
   <lemma>bílý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W15</w.rf>
   <form>kombinéza</form>
   <lemma>kombinéza</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W17</w.rf>
   <form>jejíž</form>
   <lemma>jenž_^(který...[ve_vedl._větě])</lemma>
   <tag>P1FSXFS3-------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W18</w.rf>
   <form>barva</form>
   <lemma>barva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W19</w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W20</w.rf>
   <form>uklidní</form>
   <lemma>uklidnit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49557.txt-001-p4s2">
  <m id="m-olomoucky49557.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W1</w.rf>
   <form>Včely</form>
   <lemma>včela</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W2</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W3</w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W4</w.rf>
   <form>citlivé</form>
   <lemma>citlivý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W6</w.rf>
   <form>pot</form>
   <lemma>pot</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W8</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W9</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W10</w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W12</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W13</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W14</w.rf>
   <form>hasič</form>
   <lemma>hasič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W15</w.rf>
   <form>nepotil</form>
   <lemma>potit_:T</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W17</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W19</w.rf>
   <form>nesmí</form>
   <lemma>smět_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W20</w.rf>
   <form>rychle</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W21</w.rf>
   <form>hýbat</form>
   <lemma>hýbat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49557.txt-001-p4s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49557.txt-001-p4s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
