<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky50240.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky50240.txt-001-p1s1">
  <m id="m-olomoucky50240.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W2</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W3</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W7</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W9</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W12</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W14</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W15</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W18</w.rf>
   <form>Olomouci</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W19</w.rf>
   <form>zápach</form>
   <lemma>zápach</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W20</w.rf>
   <form>plynu</form>
   <lemma>plyn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W22</w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W24</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W25</w.rf>
   <form>Stiborova</form>
   <lemma>Stiborův_;S_^(*2)</lemma>
   <tag>AUIS2M---------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W26</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W27</w.rf>
   <form>Olomouci</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p1s2">
  <m id="m-olomoucky50240.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W4</w.rf>
   <form>prováděli</form>
   <lemma>provádět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W5</w.rf>
   <form>měření</form>
   <lemma>měření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W7</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W8</w.rf>
   <form>žádná</form>
   <lemma>žádný</lemma>
   <tag>PWFS1----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W9</w.rf>
   <form>zvýšená</form>
   <lemma>zvýšený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W10</w.rf>
   <form>koncentrace</form>
   <lemma>koncentrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W11</w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W12</w.rf>
   <form>naměřena</form>
   <lemma>naměřit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p1s3">
  <m id="m-olomoucky50240.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W1</w.rf>
   <form>Přesto</form>
   <lemma>přesto</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W3</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W4</w.rf>
   <form>jistotu</form>
   <lemma>jistota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W5</w.rf>
   <form>otevřeli</form>
   <lemma>otevřít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W6</w.rf>
   <form>okna</form>
   <lemma>okno</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W8</w.rf>
   <form>prostory</form>
   <lemma>prostora</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W9</w.rf>
   <form>odvětrali</form>
   <lemma>odvětrat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p1s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p2s1">
  <m id="m-olomoucky50240.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W2</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W3</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W7</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W9</w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W13</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W14</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W15</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W17</w.rf>
   <form>Šumperku</form>
   <lemma>Šumperk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W18</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W19</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W20</w.rf>
   <form>EPS</form>
   <lemma>EPS-1_:B_^(elektrická_požární_signalizace)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W21</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W22</w.rf>
   <form>elektronickou</form>
   <lemma>elektronický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W23</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W24</w.rf>
   <form>signalizaci</form>
   <lemma>signalizace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W25</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W26</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W28</w.rf>
   <form>Kauflandu</form>
   <lemma>Kaufland_;K</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p2s2">
  <m id="m-olomoucky50240.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W4</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W6</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W8</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W10</w.rf>
   <form>selhání</form>
   <lemma>selhání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W11</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W13</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W14</w.rf>
   <form>planý</form>
   <lemma>planý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W15</w.rf>
   <form>poplach</form>
   <lemma>poplach</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p2s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p3s1">
  <m id="m-olomoucky50240.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W2</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W3</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W7</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W9</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W12</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W14</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W15</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W18</w.rf>
   <form>Šumperku</form>
   <lemma>Šumperk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W19</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W21</w.rf>
   <form>sušárně</form>
   <lemma>sušárna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W22</w.rf>
   <form>dřeva</form>
   <lemma>dřevo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W24</w.rf>
   <form>Hraběšicích</form>
   <lemma>Hraběšice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p3s2">
  <m id="m-olomoucky50240.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W3</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W4</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W6</w.rf>
   <form>důkladném</form>
   <lemma>důkladný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W7</w.rf>
   <form>průzkumu</form>
   <lemma>průzkum</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W8</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W10</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W12</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W13</w.rf>
   <form>kouř</form>
   <lemma>kouř</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W14</w.rf>
   <form>vychází</form>
   <lemma>vycházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W15</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W16</w.rf>
   <form>komína</form>
   <lemma>komín</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W18</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W19</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W20</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W22</w.rf>
   <form>planý</form>
   <lemma>planý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W23</w.rf>
   <form>poplach</form>
   <lemma>poplach</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p3s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p4s1">
  <m id="m-olomoucky50240.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W2</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W3</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W7</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W9</w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W12</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W14</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W15</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W18</w.rf>
   <form>Prostějově</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W19</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W21</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W22</w.rf>
   <form>soukromé</form>
   <lemma>soukromý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W23</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W25</w.rf>
   <form>Kokorách</form>
   <lemma>Kokory_;G</lemma>
   <tag>NNIP6-----A---6</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p4s2">
  <m id="m-olomoucky50240.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W3</w.rf>
   <form>vyrazili</form>
   <lemma>vyrazit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W7</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W8</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W10</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W12</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W13</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W14</w.rf>
   <form>kontrolované</form>
   <lemma>kontrolovaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W15</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W17</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W18</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W19</w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W20</w.rf>
   <form>nahlášeno</form>
   <lemma>nahlásit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W22</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W23</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p4s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p4s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p5s1">
  <m id="m-olomoucky50240.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W2</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W3</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W7</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W9</w.rf>
   <form>56</form>
   <lemma>56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W12</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W13</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W14</w.rf>
   <form>EPS</form>
   <lemma>EPS-1_:B_^(elektrická_požární_signalizace)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W15</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W16</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W17</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W18</w.rf>
   <form>Olomouce</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W19</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W21</w.rf>
   <form>obchodním</form>
   <lemma>obchodní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W22</w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W23</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W24</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W25</w.rf>
   <form>Bystřici</form>
   <lemma>Bystřice_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p5s2">
  <m id="m-olomoucky50240.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W3</w.rf>
   <form>vyrazili</form>
   <lemma>vyrazit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W7</w.rf>
   <form>Olomouce</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W10</w.rf>
   <form>ČD</form>
   <lemma>ČD_:B_;K_^(České_dráhy)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W12</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W15</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W16</w.rf>
   <form>Bystřice</form>
   <lemma>Bystřice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W18</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W19</w.rf>
   <form>Hluboček</form>
   <lemma>Hlubočky_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p5s3">
  <m id="m-olomoucky50240.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W3</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W4</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W6</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W8</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W10</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W12</w.rf>
   <form>řezání</form>
   <lemma>řezání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W13</w.rf>
   <form>trubek</form>
   <lemma>trubka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W14</w.rf>
   <form>rozbrušovací</form>
   <lemma>rozbrušovací_^(*2t)</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W15</w.rf>
   <form>pilou</form>
   <lemma>pila</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W18</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W19</w.rf>
   <form>planý</form>
   <lemma>planý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W20</w.rf>
   <form>poplach</form>
   <lemma>poplach</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p5s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p5s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p6s1">
  <m id="m-olomoucky50240.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W2</w.rf>
   <form>poslednímu</form>
   <lemma>poslední</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W3</w.rf>
   <form>planému</form>
   <lemma>planý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W4</w.rf>
   <form>poplachu</form>
   <lemma>poplach</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W5</w.rf>
   <form>vyjeli</form>
   <lemma>vyjet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W6</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W8</w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W9</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W11</w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W12</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W14</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W16</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W17</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W18</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W19</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W20</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W21</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W22</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W23</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W24</w.rf>
   <form>Konice</form>
   <lemma>konice_^(*3ík)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W26</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W27</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W28</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W29</w.rf>
   <form>Pěnčína</form>
   <lemma>Pěnčín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p6s2">
  <m id="m-olomoucky50240.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W2</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W3</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W4</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W6</w.rf>
   <form>Prostějově</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W7</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W8</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W9</w.rf>
   <form>nahlášeno</form>
   <lemma>nahlásit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W11</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W13</w.rf>
   <form>Pěnčíně</form>
   <lemma>Pěnčín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W14</w.rf>
   <form>vybuchla</form>
   <lemma>vybuchnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W15</w.rf>
   <form>tlaková</form>
   <lemma>tlakový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W16</w.rf>
   <form>láhev</form>
   <lemma>láhev</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W18</w.rf>
   <form>hoří</form>
   <lemma>hořet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W19</w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p6s3">
  <m id="m-olomoucky50240.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s3W2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s3W3</w.rf>
   <form>průzkumu</form>
   <lemma>průzkum</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s3W4</w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWIS4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s3W5</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s3W6</w.rf>
   <form>nenašli</form>
   <lemma>najít</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p6s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p7s1">
  <m id="m-olomoucky50240.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p7s1W1</w.rf>
   <form>SEVER</form>
   <lemma>sever</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p8s1">
  <m id="m-olomoucky50240.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W2</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W3</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W6</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W8</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W9</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W10</w.rf>
   <form>56</form>
   <lemma>56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W12</w.rf>
   <form>požádáni</form>
   <lemma>požádat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W13</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W14</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W15</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W16</w.rf>
   <form>Jeseníku</form>
   <lemma>Jeseník_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W17</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W18</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W19</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W20</w.rf>
   <form>odchytu</form>
   <lemma>odchyt</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W21</w.rf>
   <form>hada</form>
   <lemma>had</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W23</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W24</w.rf>
   <form>Písečná</form>
   <lemma>písečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p8s2">
  <m id="m-olomoucky50240.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W3</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W4</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W6</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W8</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W10</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W12</w.rf>
   <form>zmiji</form>
   <lemma>zmije_,a</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W13</w.rf>
   <form>obecnou</form>
   <lemma>obecný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p8s3">
  <m id="m-olomoucky50240.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W1</w.rf>
   <form>Pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W2</w.rf>
   <form>speciálního</form>
   <lemma>speciální</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W3</w.rf>
   <form>nářadí</form>
   <lemma>nářadí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W4</w.rf>
   <form>hada</form>
   <lemma>had</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W5</w.rf>
   <form>odchytili</form>
   <lemma>odchytit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W7</w.rf>
   <form>vypustili</form>
   <lemma>vypustit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W9</w.rf>
   <form>volné</form>
   <lemma>volný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W10</w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p8s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p9s1">
  <m id="m-olomoucky50240.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W2</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W3</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W8</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W9</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W10</w.rf>
   <form>52</form>
   <lemma>52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W12</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W14</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W15</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W18</w.rf>
   <form>Šumperku</form>
   <lemma>Šumperk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W19</w.rf>
   <form>nález</form>
   <lemma>nález</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W20</w.rf>
   <form>neznámé</form>
   <lemma>známý-2_^(co_[ne]známe)</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W21</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W22</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W23</w.rf>
   <form>bílého</form>
   <lemma>bílý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W24</w.rf>
   <form>prášku</form>
   <lemma>prášek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W25</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W27</w.rf>
   <form>nástupišti</form>
   <lemma>nástupiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W28</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W29</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W30</w.rf>
   <form>kanceláří</form>
   <lemma>kancelář</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W31</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W32</w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W33</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W34</w.rf>
   <form>Javorníku</form>
   <lemma>Javorník_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s1W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p9s2">
  <m id="m-olomoucky50240.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W3</w.rf>
   <form>vyrazili</form>
   <lemma>vyrazit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W7</w.rf>
   <form>Jeseníku</form>
   <lemma>Jeseník_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W9</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W10</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W11</w.rf>
   <form>přítomnosti</form>
   <lemma>přítomnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W12</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W13</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W14</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W15</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W16</w.rf>
   <form>nálezu</form>
   <lemma>nález</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W18</w.rf>
   <form>následně</form>
   <lemma>následně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W19</w.rf>
   <form>neznámou</form>
   <lemma>známý-2_^(co_[ne]známe)</lemma>
   <tag>AAFS4----1N----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W20</w.rf>
   <form>látku</form>
   <lemma>látka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W21</w.rf>
   <form>odebrali</form>
   <lemma>odebrat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W22</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W23</w.rf>
   <form>kontejneru</form>
   <lemma>kontejner</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W25</w.rf>
   <form>kontaminované</form>
   <lemma>kontaminovaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W26</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W27</w.rf>
   <form>vydesinfikovali</form>
   <lemma>vydesinfikovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W28</w.rf>
   <form>dezinfekčním</form>
   <lemma>dezinfekční</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W29</w.rf>
   <form>roztokem</form>
   <lemma>roztok</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s2W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50240.txt-001-p9s3">
  <m id="m-olomoucky50240.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W1</w.rf>
   <form>Odebranou</form>
   <lemma>odebraný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W2</w.rf>
   <form>látku</form>
   <lemma>látka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W4</w.rf>
   <form>uložili</form>
   <lemma>uložit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W6</w.rf>
   <form>kontejneru</form>
   <lemma>kontejner</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W8</w.rf>
   <form>nebezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFP4----1N----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W9</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W11</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W12</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W14</w.rf>
   <form>převoz</form>
   <lemma>převoz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W16</w.rf>
   <form>Chemické</form>
   <lemma>chemický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W17</w.rf>
   <form>laboratoře</form>
   <lemma>laboratoř</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W18</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W19</w.rf>
   <form>Frenštátě</form>
   <lemma>Frenštát_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W20</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W21</w.rf>
   <form>Radhoštěm</form>
   <lemma>Radhošť_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W22</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W23</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W24</w.rf>
   <form>analýze</form>
   <lemma>analýza</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-olomoucky50240.txt-001-p9s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50240.txt-001-p9s3W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
