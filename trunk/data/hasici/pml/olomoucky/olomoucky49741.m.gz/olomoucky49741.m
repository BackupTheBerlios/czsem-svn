<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky49741.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky49741.txt-001-p1s1">
  <m id="m-olomoucky49741.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p1s1W1</w.rf>
   <form>OLOMOUC</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49741.txt-001-p2s1">
  <m id="m-olomoucky49741.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W1</w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W4</w.rf>
   <form>středu</form>
   <lemma>středa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W5</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W7</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W9</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W11</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W12</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W13</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W14</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W15</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W17</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W18</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W19</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W21</w.rf>
   <form>Olomouci</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W22</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W23</w.rf>
   <form>kanceláří</form>
   <lemma>kancelář</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W25</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W26</w.rf>
   <form>bývalého</form>
   <lemma>bývalý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W27</w.rf>
   <form>zemědělského</form>
   <lemma>zemědělský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W28</w.rf>
   <form>družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W29</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W30</w.rf>
   <form>Přáslavicích</form>
   <lemma>Přáslavice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49741.txt-001-p2s2">
  <m id="m-olomoucky49741.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W3</w.rf>
   <form>vyrazili</form>
   <lemma>vyrazit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W7</w.rf>
   <form>Olomouce</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W9</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W12</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W13</w.rf>
   <form>Bystřice</form>
   <lemma>Bystřice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W15</w.rf>
   <form>Přáslavic</form>
   <lemma>Přáslavice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49741.txt-001-p2s3">
  <m id="m-olomoucky49741.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W4</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W6</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W8</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W11</w.rf>
   <form>většího</form>
   <lemma>velký</lemma>
   <tag>AAIS2----2A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W12</w.rf>
   <form>rozsahu</form>
   <lemma>rozsah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49741.txt-001-p2s4">
  <m id="m-olomoucky49741.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W1</w.rf>
   <form>Požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W3</w.rf>
   <form>zasažen</form>
   <lemma>zasáhnout</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W4</w.rf>
   <form>objekt</form>
   <lemma>objekt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W5</w.rf>
   <form>bývalého</form>
   <lemma>bývalý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W6</w.rf>
   <form>kravína</form>
   <lemma>kravín</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W7</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W8</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W9</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W10</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W11</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W12</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W13</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W15</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W16</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W17</w.rf>
   <form>přestavěn</form>
   <lemma>přestavět_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W19</w.rf>
   <form>kanceláře</form>
   <lemma>kancelář</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s4W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49741.txt-001-p2s5">
  <m id="m-olomoucky49741.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W2</w.rf>
   <form>zničil</form>
   <lemma>zničit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W3</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W4</w.rf>
   <form>zasedací</form>
   <lemma>zasedací_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W5</w.rf>
   <form>místnosti</form>
   <lemma>místnost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W7</w.rf>
   <form>kanceláře</form>
   <lemma>kancelář</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W9</w.rf>
   <form>sklady</form>
   <lemma>sklad</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W11</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W12</w.rf>
   <form>kterých</form>
   <lemma>který</lemma>
   <tag>P4XP6----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W13</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W14</w.rf>
   <form>uložen</form>
   <lemma>uložit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W15</w.rf>
   <form>materiál</form>
   <lemma>materiál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s5W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49741.txt-001-p2s6">
  <m id="m-olomoucky49741.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W1</w.rf>
   <form>Požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W2</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W3</w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W4</w.rf>
   <form>zasaženy</form>
   <lemma>zasáhnout</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W6</w.rf>
   <form>stropy</form>
   <lemma>strop</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W7</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W9</w.rf>
   <form>střecha</form>
   <lemma>střecha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s6W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49741.txt-001-p2s7">
  <m id="m-olomoucky49741.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s7W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s7W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s7W3</w.rf>
   <form>uhořeli</form>
   <lemma>uhořet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s7W4</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s7W5</w.rf>
   <form>psi</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s7W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49741.txt-001-p2s8">
  <m id="m-olomoucky49741.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W1</w.rf>
   <form>Výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W2</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W4</w.rf>
   <form>příčinu</form>
   <lemma>příčina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W5</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W6</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W7</w.rf>
   <form>sdělí</form>
   <lemma>sdělit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W8</w.rf>
   <form>policejní</form>
   <lemma>policejní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W9</w.rf>
   <form>vyšetřovatel</form>
   <lemma>vyšetřovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49741.txt-001-p2s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49741.txt-001-p2s8W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
