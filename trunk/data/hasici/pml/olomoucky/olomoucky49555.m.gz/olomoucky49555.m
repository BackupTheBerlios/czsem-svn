<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky49555.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky49555.txt-001-p1s1">
  <m id="m-olomoucky49555.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p1s1W1</w.rf>
   <form>SEVER</form>
   <lemma>sever</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p2s1">
  <m id="m-olomoucky49555.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W2</w.rf>
   <form>pondělí</form>
   <lemma>pondělí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W3</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W8</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W9</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W10</w.rf>
   <form>55</form>
   <lemma>55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W12</w.rf>
   <form>nahlášen</form>
   <lemma>nahlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W14</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W15</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W18</w.rf>
   <form>Šumperku</form>
   <lemma>Šumperk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W19</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W20</w.rf>
   <form>kolového</form>
   <lemma>kolový-1_^(s_koly)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W21</w.rf>
   <form>bagru</form>
   <lemma>bagr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W23</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W24</w.rf>
   <form>Sobotín</form>
   <lemma>Sobotín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p2s2">
  <m id="m-olomoucky49555.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W3</w.rf>
   <form>vyrazili</form>
   <lemma>vyrazit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W7</w.rf>
   <form>Šumperku</form>
   <lemma>Šumperk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W9</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W12</w.rf>
   <form>Sobotína</form>
   <lemma>Sobotín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p2s3">
  <m id="m-olomoucky49555.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W2</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W3</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W5</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W8</w.rf>
   <form>bagr</form>
   <lemma>bagr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W9</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W10</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W11</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W12</w.rf>
   <form>zachvácen</form>
   <lemma>zachvácet_:T_,s</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W13</w.rf>
   <form>požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p2s4">
  <m id="m-olomoucky49555.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s4W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s4W3</w.rf>
   <form>zlikvidovali</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s4W4</w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>ClXP7----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s4W5</w.rf>
   <form>proudy</form>
   <lemma>proud</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s4W6</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p2s5">
  <m id="m-olomoucky49555.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W3</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W4</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W5</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W6</w.rf>
   <form>hydraulického</form>
   <lemma>hydraulický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W7</w.rf>
   <form>oleje</form>
   <lemma>olej</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W8</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W10</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W12</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W14</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W16</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W17</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W19</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W20</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W21</w.rf>
   <form>povolán</form>
   <lemma>povolat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W22</w.rf>
   <form>pracovník</form>
   <lemma>pracovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W23</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W24</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W26</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W27</w.rf>
   <form>vyhodnotil</form>
   <lemma>vyhodnotit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W28</w.rf>
   <form>závažnost</form>
   <lemma>závažnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W29</w.rf>
   <form>situace</form>
   <lemma>situace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s5W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p2s6">
  <m id="m-olomoucky49555.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W1</w.rf>
   <form>Olej</form>
   <lemma>olej</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W3</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W4</w.rf>
   <form>neustále</form>
   <lemma>neustále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W5</w.rf>
   <form>unikal</form>
   <lemma>unikat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W7</w.rf>
   <form>bagru</form>
   <lemma>bagr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W10</w.rf>
   <form>jímali</form>
   <lemma>jímat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W12</w.rf>
   <form>připravených</form>
   <lemma>připravený_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W13</w.rf>
   <form>nádob</form>
   <lemma>nádoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s6W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p2s7">
  <m id="m-olomoucky49555.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W2</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W3</w.rf>
   <form>spolupracovali</form>
   <lemma>spolupracovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W5</w.rf>
   <form>odbagrování</form>
   <lemma>odbagrování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W6</w.rf>
   <form>kontaminované</form>
   <lemma>kontaminovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W7</w.rf>
   <form>zeminy</form>
   <lemma>zemina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W9</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W10</w.rf>
   <form>odklízení</form>
   <lemma>odklízení_^(*2t)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W11</w.rf>
   <form>ohořelého</form>
   <lemma>ohořelý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W12</w.rf>
   <form>vraku</form>
   <lemma>vrak</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W13</w.rf>
   <form>kolového</form>
   <lemma>kolový-1_^(s_koly)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W14</w.rf>
   <form>bagru</form>
   <lemma>bagr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s7W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p2s8">
  <m id="m-olomoucky49555.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W1</w.rf>
   <form>Výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W2</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W4</w.rf>
   <form>příčinu</form>
   <lemma>příčina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W5</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W6</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W7</w.rf>
   <form>sdělí</form>
   <lemma>sdělit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W8</w.rf>
   <form>policejní</form>
   <lemma>policejní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W9</w.rf>
   <form>vyšetřovatel</form>
   <lemma>vyšetřovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p2s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p2s8W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p3s1">
  <m id="m-olomoucky49555.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W2</w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W3</w.rf>
   <form>včerejšího</form>
   <lemma>včerejší</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W4</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W5</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W6</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W9</w.rf>
   <form>Olomouckého</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W10</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W12</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W13</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W15</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W16</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W17</w.rf>
   <form>zlikvidovat</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W18</w.rf>
   <form>nebezpečný</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAIS4----1N----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W19</w.rf>
   <form>hmyz</form>
   <lemma>hmyz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p3s2">
  <m id="m-olomoucky49555.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W1</w.rf>
   <form>Tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W2</w.rf>
   <form>typ</form>
   <lemma>typ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W3</w.rf>
   <form>zásahů</form>
   <lemma>zásah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W6</w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W7</w.rf>
   <form>dnech</form>
   <lemma>dno_^(např._propasti)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W8</w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W9</w.rf>
   <form>rozšířený</form>
   <lemma>rozšířený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p3s3">
  <m id="m-olomoucky49555.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W1</w.rf>
   <form>Jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W2</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W3</w.rf>
   <form>začátku</form>
   <lemma>začátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W5</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W6</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W9</w.rf>
   <form>Olomouckého</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W10</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W11</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W12</w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W13</w.rf>
   <form>x</form>
   <lemma>x-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49555.txt-001-p3s4">
  <m id="m-olomoucky49555.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W2</w.rf>
   <form>příloze</form>
   <lemma>příloha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W3</w.rf>
   <form>posílám</form>
   <lemma>posílat_:T</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W4</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W5</w.rf>
   <form>podrobnější</form>
   <lemma>podrobný</lemma>
   <tag>AAFP4----2A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W6</w.rf>
   <form>informace</form>
   <lemma>informace</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W8</w.rf>
   <form>včelám</form>
   <lemma>včela</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W10</w.rf>
   <form>vosám</form>
   <lemma>vosa</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W12</w.rf>
   <form>sršňům</form>
   <lemma>sršeň</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-olomoucky49555.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49555.txt-001-p3s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
