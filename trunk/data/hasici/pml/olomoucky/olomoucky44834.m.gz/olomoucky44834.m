<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky44834.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky44834.txt-001-p1s1">
  <m id="m-olomoucky44834.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W1</w.rf>
   <form>Pozvánka</form>
   <lemma>pozvánka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W2</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W3</w.rf>
   <form>územního</form>
   <lemma>územní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W4</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W5</w.rf>
   <form>Prostějov</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W7</w.rf>
   <form>Den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W9</w.rf>
   <form>složkami</form>
   <lemma>složka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W10</w.rf>
   <form>integrovaného</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W11</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W12</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W14</w.rf>
   <form>340kb</form>
   <lemma>340kb</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p1s1W15</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p2s1">
  <m id="m-olomoucky44834.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W1</w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W2</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W4</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W5</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W6</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W7</w.rf>
   <form>tradicí</form>
   <lemma>tradice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W8</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W9</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W11</w.rf>
   <form>patří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W12</w.rf>
   <form>neodmyslitelně</form>
   <lemma>odmyslitelně_^(*4)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W14</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W16</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W17</w.rf>
   <form>zlomení</form>
   <lemma>zlomení_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W18</w.rf>
   <form>pověry</form>
   <lemma>pověra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W19</w.rf>
   <form>nešťastného</form>
   <lemma>šťastný</lemma>
   <tag>AAIS2----1N----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W20</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p2s2">
  <m id="m-olomoucky44834.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W1</w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W2</w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc-P---1-------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W3</w.rf>
   <form>rádi</form>
   <lemma>rád</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W4</w.rf>
   <form>pozvali</form>
   <lemma>pozvat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W5</w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W6</w.rf>
   <form>občany</form>
   <lemma>občan</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W8</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W10</w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W11</w.rf>
   <form>podívat</form>
   <lemma>podívat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W13</w.rf>
   <form>kteroukoli</form>
   <lemma>kterýkoliv</lemma>
   <tag>PZFS4---------1</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W14</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W15</w.rf>
   <form>stanici</form>
   <lemma>stanice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W17</w.rf>
   <form>celém</form>
   <lemma>celý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W18</w.rf>
   <form>Olomouckém</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W19</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W21</w.rf>
   <form>prohlédli</form>
   <lemma>prohlédnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W22</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W23</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W24</w.rf>
   <form>techniku</form>
   <lemma>technika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W26</w.rf>
   <form>seznámili</form>
   <lemma>seznámit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W27</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W28</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W29</w.rf>
   <form>prací</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W30</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s2W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p2s3">
  <m id="m-olomoucky44834.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W2</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W4</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W6</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W7</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W8</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W9</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W11</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W12</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W13</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W14</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W15</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W16</w.rf>
   <form>dopoledne</form>
   <lemma>dopoledne-2</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W17</w.rf>
   <form>probíhat</form>
   <lemma>probíhat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W19</w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W20</w.rf>
   <form>stanicích</form>
   <lemma>stanice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W21</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W22</w.rf>
   <form>Olomouckého</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W23</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W24</w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W25</w.rf>
   <form>ukázky</form>
   <lemma>ukázka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W27</w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W28</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W29</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W30</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W31</w.rf>
   <form>občané</form>
   <lemma>občan</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W32</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W33</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W34</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W35</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W36</w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W37</w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W38</w.rf>
   <form>ukázky</form>
   <lemma>ukázka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W39</w.rf>
   <form>slaňování</form>
   <lemma>slaňování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W40</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W41</w.rf>
   <form>hašení</form>
   <lemma>hašení_^(*4sit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W42</w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W43</w.rf>
   <form>typů</form>
   <lemma>typ</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W44</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W45</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W46</w.rf>
   <form>potápěčskou</form>
   <lemma>potápěčský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W47</w.rf>
   <form>výstroj</form>
   <lemma>výstroj</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W48</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W49</w.rf>
   <form>chemické</form>
   <lemma>chemický</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W50</w.rf>
   <form>obleky</form>
   <lemma>oblek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W51</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W52</w.rf>
   <form>mnoho</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W53</w.rf>
   <form>dalšího</form>
   <lemma>další</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p2s3W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p2s3W54</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p3s1">
  <m id="m-olomoucky44834.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W4</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W5</w.rf>
   <form>moci</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W6</w.rf>
   <form>vyzkoušet</form>
   <lemma>vyzkoušet_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W7</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FP4---------1</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W8</w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W10</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W11</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W12</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W14</w.rf>
   <form>zasoutěžit</form>
   <lemma>zasoutěžit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W15</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W17</w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W18</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W19</w.rf>
   <form>soutěžích</form>
   <lemma>soutěž</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p3s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p4s1">
  <m id="m-olomoucky44834.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W1</w.rf>
   <form>Rádi</form>
   <lemma>rád</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W2</w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc-P---1-------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W3</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W5</w.rf>
   <form>podvědomí</form>
   <lemma>podvědomí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W6</w.rf>
   <form>občanů</form>
   <lemma>občan</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W8</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W9</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W10</w.rf>
   <form>třináctého</form>
   <lemma>třináctý</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W11</w.rf>
   <form>znamená</form>
   <lemma>znamenat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W13</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W14</w.rf>
   <form>zlomení</form>
   <lemma>zlomení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W15</w.rf>
   <form>pověry</form>
   <lemma>pověra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W16</w.rf>
   <form>nešťastného</form>
   <lemma>šťastný</lemma>
   <tag>AAIS2----1N----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W17</w.rf>
   <form>pátku</form>
   <lemma>pátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W18</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W22</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W23</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W25</w.rf>
   <form>Vás</form>
   <lemma>ty</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W26</w.rf>
   <form>obracíme</form>
   <lemma>obracet_:T</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W27</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W28</w.rf>
   <form>prosbou</form>
   <lemma>prosba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W30</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W31</w.rf>
   <form>informování</form>
   <lemma>informování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W32</w.rf>
   <form>občanů</form>
   <lemma>občan</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W33</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W34</w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W35</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W36</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W37</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W38</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W40</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W41</w.rf>
   <form>dnem</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W42</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W43</w.rf>
   <form>bezpečnosti</form>
   <lemma>bezpečnost-1_^(*5ý-1)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s1W44</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p4s2">
  <m id="m-olomoucky44834.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s2W1</w.rf>
   <form>Tradičně</form>
   <lemma>tradičně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s2W2</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s2W3</w.rf>
   <form>vyhlašuje</form>
   <lemma>vyhlašovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s2W4</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s2W5</w.rf>
   <form>asociace</form>
   <lemma>asociace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s2W6</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s2W7</w.rf>
   <form>důstojníků</form>
   <lemma>důstojník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p4s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p5s1">
  <m id="m-olomoucky44834.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W2</w.rf>
   <form>následující</form>
   <lemma>následující_^(*5ovat)</lemma>
   <tag>AGFS6-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W3</w.rf>
   <form>tabulce</form>
   <lemma>tabulka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W4</w.rf>
   <form>uvádíme</form>
   <lemma>uvádět_:T</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W5</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W7</w.rf>
   <form>jednotlivých</form>
   <lemma>jednotlivý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W8</w.rf>
   <form>stanicích</form>
   <lemma>stanice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W10</w.rf>
   <form>Olomouckého</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W11</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W13</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W14</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W15</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W16</w.rf>
   <form>veřejnost</form>
   <lemma>veřejnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W17</w.rf>
   <form>otevřeny</form>
   <lemma>otevřít</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W18</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W19</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W20</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W21</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W22</w.rf>
   <form>hod</form>
   <lemma>hodina_:B_,x</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p5s1W24</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p6s1">
  <m id="m-olomoucky44834.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p6s1W1</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p6s1W2</w.rf>
   <form>Olomouc</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p7s1">
  <m id="m-olomoucky44834.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p7s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p7s1W2</w.rf>
   <form>Litovel</form>
   <lemma>Litovel_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p8s1">
  <m id="m-olomoucky44834.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p8s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p8s1W2</w.rf>
   <form>Uničov</form>
   <lemma>Uničov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p9s1">
  <m id="m-olomoucky44834.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p9s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p9s1W2</w.rf>
   <form>Šternberk</form>
   <lemma>Šternberk-2_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p10s1">
  <m id="m-olomoucky44834.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p10s1W1</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p10s1W2</w.rf>
   <form>Šumperk</form>
   <lemma>Šumperk_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p11s1">
  <m id="m-olomoucky44834.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p11s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p11s1W2</w.rf>
   <form>Zábřeh</form>
   <lemma>Zábřeh_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p12s1">
  <m id="m-olomoucky44834.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p12s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p12s1W2</w.rf>
   <form>Jeseník</form>
   <lemma>Jeseník_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p13s1">
  <m id="m-olomoucky44834.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p13s1W1</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p13s1W2</w.rf>
   <form>Přerov</form>
   <lemma>Přerov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p14s1">
  <m id="m-olomoucky44834.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p14s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p14s1W2</w.rf>
   <form>Lipník</form>
   <lemma>Lipník_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p14s1W3</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p14s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p14s1W4</w.rf>
   <form>Bečvou</form>
   <lemma>Bečva_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p15s1">
  <m id="m-olomoucky44834.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p15s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p15s1W2</w.rf>
   <form>Hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p16s1">
  <m id="m-olomoucky44834.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p16s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p16s1W2</w.rf>
   <form>Kojetín</form>
   <lemma>Kojetín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p17s1">
  <m id="m-olomoucky44834.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p17s1W1</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p17s1W2</w.rf>
   <form>Prostějov</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p18s1">
  <m id="m-olomoucky44834.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p18s1W1</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p18s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p18s1W2</w.rf>
   <form>Konice</form>
   <lemma>konice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky44834.txt-001-p19s1">
  <m id="m-olomoucky44834.txt-001-p19s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p19s1W1</w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p19s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p19s1W2</w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p19s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p19s1W3</w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p19s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p19s1W4</w.rf>
   <form>srdečně</form>
   <lemma>srdečně_^(př._pozdrav,_člověk)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p19s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p19s1W5</w.rf>
   <form>zváni</form>
   <lemma>zvát</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-olomoucky44834.txt-001-p19s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky44834.txt-001-p19s1W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
