<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky49861.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky49861.txt-001-p1s1">
  <m id="m-olomoucky49861.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p1s1W1</w.rf>
   <form>Program</form>
   <lemma>program-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p1s1W2</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p1s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p2s1">
  <m id="m-olomoucky49861.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W1</w.rf>
   <form>Pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W2</w.rf>
   <form>18.5</form>
   <form_change>num_normalization</form_change>
   <lemma>18.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W4</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W7</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W8</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W9</w.rf>
   <form>média10</form>
   <lemma>média10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W11</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W14</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W15</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W16</w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W17</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W20</w.rf>
   <form>prohlídka</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W21</w.rf>
   <form>skladu</form>
   <lemma>sklad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W22</w.rf>
   <form>humanitární</form>
   <lemma>humanitární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W23</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W24</w.rf>
   <form>Hamry11</form>
   <lemma>Hamry11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W25</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W26</w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W27</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W28</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W29</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W30</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W31</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W32</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W33</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W34</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W35</w.rf>
   <form>praktická</form>
   <lemma>praktický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W36</w.rf>
   <form>ukázka</form>
   <lemma>ukázka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W37</w.rf>
   <form>činností</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W38</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W39</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p2s1W40</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p3s1">
  <m id="m-olomoucky49861.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W1</w.rf>
   <form>Sobota</form>
   <lemma>sobota</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W2</w.rf>
   <form>19.5</form>
   <form_change>num_normalization</form_change>
   <lemma>19.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W4</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W7</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W8</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W9</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W10</w.rf>
   <form>SDH14</form>
   <lemma>SDH14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W11</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W12</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W14</w.rf>
   <form>zahájení</form>
   <lemma>zahájení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W15</w.rf>
   <form>soutěže15</form>
   <lemma>soutěže15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W16</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W17</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W20</w.rf>
   <form>start</form>
   <lemma>start</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W21</w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W23</w.rf>
   <form>etapy20</form>
   <lemma>etapy20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W24</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W25</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W27</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W28</w.rf>
   <form>start</form>
   <lemma>start</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W29</w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p3s1W31</w.rf>
   <form>etapy</form>
   <lemma>etapa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p4s1">
  <m id="m-olomoucky49861.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W1</w.rf>
   <form>Neděle</form>
   <lemma>neděle</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W2</w.rf>
   <form>20.5</form>
   <form_change>num_normalization</form_change>
   <lemma>20.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W4</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W7</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W8</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W9</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W10</w.rf>
   <form>SDH04</form>
   <lemma>SDH04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W11</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W12</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W15</w.rf>
   <form>start</form>
   <lemma>start</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W16</w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W18</w.rf>
   <form>etapy11</form>
   <lemma>etapy11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W19</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W20</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p4s1W22</w.rf>
   <form>vyhodnocení</form>
   <lemma>vyhodnocení_^(*4tit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p5s1">
  <m id="m-olomoucky49861.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p5s1W1</w.rf>
   <form>Základní</form>
   <lemma>základní_,s</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p5s1W2</w.rf>
   <form>informace</form>
   <lemma>informace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p5s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p5s1W4</w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p6s1">
  <m id="m-olomoucky49861.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W1</w.rf>
   <form>Soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W3</w.rf>
   <form>účastní</form>
   <lemma>účastnit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W4</w.rf>
   <form>členové</form>
   <lemma>člen</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W5</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W6</w.rf>
   <form>SDH</form>
   <lemma>Sdh</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W7</w.rf>
   <form>obcí</form>
   <lemma>obec</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W9</w.rf>
   <form>složení</form>
   <lemma>složení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W10</w.rf>
   <form>velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W12</w.rf>
   <form>strojník</form>
   <lemma>strojník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W14</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W15</w.rf>
   <form>členové</form>
   <lemma>člen</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W16</w.rf>
   <form>SDH</form>
   <lemma>SDH</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p6s2">
  <m id="m-olomoucky49861.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s2W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s2W2</w.rf>
   <form>probíhá</form>
   <lemma>probíhat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s2W3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s2W4</w.rf>
   <form>třech</form>
   <lemma>tři`3</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s2W5</w.rf>
   <form>etapách</form>
   <lemma>etapa</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s2W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p6s3">
  <m id="m-olomoucky49861.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W1</w.rf>
   <form>Posádky</form>
   <lemma>posádka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W3</w.rf>
   <form>pohybují</form>
   <lemma>pohybovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W4</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W5</w.rf>
   <form>trase</form>
   <lemma>trasa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W6</w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W8</w.rf>
   <form>dopravním</form>
   <lemma>dopravní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W9</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W11</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W13</w.rf>
   <form>cisterně</form>
   <lemma>cisterna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p6s4">
  <m id="m-olomoucky49861.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s4W2</w.rf>
   <form>trase</form>
   <lemma>trasa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s4W3</w.rf>
   <form>plní</form>
   <lemma>plnit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s4W4</w.rf>
   <form>jednotlivé</form>
   <lemma>jednotlivý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s4W5</w.rf>
   <form>úkoly</form>
   <lemma>úkol</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p6s5">
  <m id="m-olomoucky49861.txt-001-p6s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W1</w.rf>
   <form>Úkoly</form>
   <lemma>úkol</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W2</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W3</w.rf>
   <form>připraveny</form>
   <lemma>připravit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W4</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W6</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W7</w.rf>
   <form>co</form>
   <lemma>co-5_^(př._co_nejméně,_co_nevidět,_co_chvíli,_co_do_počtu,_atd.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W8</w.rf>
   <form>nejvíce</form>
   <lemma>hodně</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W9</w.rf>
   <form>simulovaly</form>
   <lemma>simulovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W10</w.rf>
   <form>reálný</form>
   <lemma>reálný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W11</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s5W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p6s6">
  <m id="m-olomoucky49861.txt-001-p6s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W1</w.rf>
   <form>Osádka</form>
   <lemma>osádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W2</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W3</w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W4</w.rf>
   <form>neví</form>
   <lemma>vědět</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W5</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W6</w.rf>
   <form>charakteru</form>
   <lemma>charakter</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W7</w.rf>
   <form>úkolu</form>
   <lemma>úkol</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W9</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W10</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W11</w.rf>
   <form>plnění</form>
   <lemma>plnění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p6s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p6s6W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p7s1">
  <m id="m-olomoucky49861.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W1</w.rf>
   <form>Celkové</form>
   <lemma>celkový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W2</w.rf>
   <form>hodnocení</form>
   <lemma>hodnocení_^(*4tit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W3</w.rf>
   <form>úkolu</form>
   <lemma>úkol</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W5</w.rf>
   <form>dáno</form>
   <lemma>dát</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W6</w.rf>
   <form>součtem</form>
   <lemma>součet</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W7</w.rf>
   <form>bodů</form>
   <lemma>bod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W9</w.rf>
   <form>jednotlivých</form>
   <lemma>jednotlivý</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W10</w.rf>
   <form>kritériích</form>
   <lemma>kritérium</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p7s2">
  <m id="m-olomoucky49861.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W1</w.rf>
   <form>Hodnocena</form>
   <lemma>hodnotit_:T</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W3</w.rf>
   <form>taktika</form>
   <lemma>taktika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W5</w.rf>
   <form>technické</form>
   <lemma>technický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W6</w.rf>
   <form>provedení</form>
   <lemma>provedení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W8</w.rf>
   <form>bezpečnost</form>
   <lemma>bezpečnost-1_^(*5ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W9</w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W11</w.rf>
   <form>plnění</form>
   <lemma>plnění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W12</w.rf>
   <form>úkolu</form>
   <lemma>úkol</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W13</w.rf>
   <form>velitele</form>
   <lemma>velitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W14</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p7s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p8s1">
  <m id="m-olomoucky49861.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W1</w.rf>
   <form>Celkové</form>
   <lemma>celkový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W2</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W3</w.rf>
   <form>umístění</form>
   <lemma>umístění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W4</w.rf>
   <form>posádek</form>
   <lemma>posádka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W6</w.rf>
   <form>stanoveno</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W8</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W9</w.rf>
   <form>součtu</form>
   <lemma>součet</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W10</w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W11</w.rf>
   <form>dosažených</form>
   <lemma>dosažený_^(*5áhnout)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W12</w.rf>
   <form>bodů</form>
   <lemma>bod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W14</w.rf>
   <form>jednotlivých</form>
   <lemma>jednotlivý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W15</w.rf>
   <form>etapách</form>
   <lemma>etapa</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49861.txt-001-p8s2">
  <m id="m-olomoucky49861.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s2W1</w.rf>
   <form>Vítězná</form>
   <lemma>vítězný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s2W2</w.rf>
   <form>posádka</form>
   <lemma>posádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s2W3</w.rf>
   <form>obdrží</form>
   <lemma>obdržet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s2W4</w.rf>
   <form>putovní</form>
   <lemma>putovní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s2W5</w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49861.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49861.txt-001-p8s2W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
