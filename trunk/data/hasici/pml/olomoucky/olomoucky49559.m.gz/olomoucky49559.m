<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky49559.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky49559.txt-001-p1s1">
  <m id="m-olomoucky49559.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W2</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W3</w.rf>
   <form>vyjížděly</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W4</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W5</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W6</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W8</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W9</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W11</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W12</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W13</w.rf>
   <form>případům</form>
   <lemma>případ</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W14</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W15</w.rf>
   <form>ohrožení</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W16</w.rf>
   <form>nebezpečným</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAIS7----1N----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W17</w.rf>
   <form>hmyzem</form>
   <lemma>hmyz</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W18</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p1s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p2s1">
  <m id="m-olomoucky49559.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W1</w.rf>
   <form>Nejčastěji</form>
   <lemma>častě_^(*1ý)</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W3</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W5</w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W7</w.rf>
   <form>vosy</form>
   <lemma>vosa</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W9</w.rf>
   <form>sršně</form>
   <lemma>sršeň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p2s2">
  <m id="m-olomoucky49559.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W1</w.rf>
   <form>Nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W2</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W3</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W4</w.rf>
   <form>spočívá</form>
   <lemma>spočívat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W6</w.rf>
   <form>bodnutí</form>
   <lemma>bodnutí_^(*3out)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W8</w.rf>
   <form>intoxikaci</form>
   <lemma>intoxikace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p2s3">
  <m id="m-olomoucky49559.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W2</w.rf>
   <form>včel</form>
   <lemma>včela</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W4</w.rf>
   <form>žihadlo</form>
   <lemma>žihadlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W5</w.rf>
   <form>opatřeno</form>
   <lemma>opatřit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W6</w.rf>
   <form>zpětnými</form>
   <lemma>zpětný</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W7</w.rf>
   <form>zahnutými</form>
   <lemma>zahnutý_^(*3out)</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W8</w.rf>
   <form>háčky</form>
   <lemma>háčko_,h</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W10</w.rf>
   <form>kterými</form>
   <lemma>který</lemma>
   <tag>P4XP7----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W12</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W13</w.rf>
   <form>bodnutí</form>
   <lemma>bodnutí_^(*3out)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W14</w.rf>
   <form>fixuje</form>
   <lemma>fixovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W15</w.rf>
   <form>žihadlo</form>
   <lemma>žihadlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W17</w.rf>
   <form>tkáně</form>
   <lemma>tkáň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p2s4">
  <m id="m-olomoucky49559.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W2</w.rf>
   <form>odletu</form>
   <lemma>odlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W4</w.rf>
   <form>včela</form>
   <lemma>včela</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W5</w.rf>
   <form>vytrhává</form>
   <lemma>vytrhávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W6</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W7</w.rf>
   <form>jedové</form>
   <lemma>jedový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W8</w.rf>
   <form>ústrojí</form>
   <lemma>ústrojí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W10</w.rf>
   <form>hyne</form>
   <lemma>hynout</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p2s5">
  <m id="m-olomoucky49559.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W1</w.rf>
   <form>Vosy</form>
   <lemma>vosa</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W3</w.rf>
   <form>sršni</form>
   <lemma>sršeň</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W4</w.rf>
   <form>zpětné</form>
   <lemma>zpětný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W5</w.rf>
   <form>háčky</form>
   <lemma>háček</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W6</w.rf>
   <form>nemají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W8</w.rf>
   <form>žihadlo</form>
   <lemma>žihadlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W9</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W10</w.rf>
   <form>použít</form>
   <lemma>použít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W11</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W12</w.rf>
   <form>několikrát</form>
   <lemma>několikrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s5W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p2s6">
  <m id="m-olomoucky49559.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W1</w.rf>
   <form>Vosí</form>
   <lemma>vosí</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W3</w.rf>
   <form>sršní</form>
   <lemma>sršní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W4</w.rf>
   <form>bodnutí</form>
   <lemma>bodnutí_^(*3out)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W6</w.rf>
   <form>bolestivější</form>
   <lemma>bolestivý</lemma>
   <tag>AAIS1----2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W7</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W8</w.rf>
   <form>včelí</form>
   <lemma>včelí</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W10</w.rf>
   <form>otoky</form>
   <lemma>otok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W11</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W12</w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAFP4----2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W14</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W15</w.rf>
   <form>svědí</form>
   <lemma>svědět</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p2s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p2s6W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s1">
  <m id="m-olomoucky49559.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s1W1</w.rf>
   <form>Tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s1W2</w.rf>
   <form>intoxikaci</form>
   <lemma>intoxikace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s1W3</w.rf>
   <form>těla</form>
   <lemma>tělo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s1W4</w.rf>
   <form>způsobuje</form>
   <lemma>způsobovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s1W5</w.rf>
   <form>jed</form>
   <lemma>jed</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s1W6</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s1W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s2">
  <m id="m-olomoucky49559.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W1</w.rf>
   <form>Literatura</form>
   <lemma>literatura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W2</w.rf>
   <form>uvádí</form>
   <lemma>uvádět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W4</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W5</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W6</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W7</w.rf>
   <form>vpíchnutých</form>
   <lemma>vpíchnutý_^(*3out)</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W8</w.rf>
   <form>žihadlech</form>
   <lemma>žihadlo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W9</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W10</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W11</w.rf>
   <form>sršňů</form>
   <lemma>sršeň</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W12</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W13</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W14</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W15</w.rf>
   <form>zdravého</form>
   <lemma>zdravý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W16</w.rf>
   <form>dospělého</form>
   <lemma>dospělý-2</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W17</w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W18</w.rf>
   <form>intoxikace</form>
   <lemma>intoxikace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W19</w.rf>
   <form>neočekává</form>
   <lemma>očekávat_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s3">
  <m id="m-olomoucky49559.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W1</w.rf>
   <form>Teprve</form>
   <lemma>teprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W3</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W4</w.rf>
   <form>stovkách</form>
   <lemma>stovka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W5</w.rf>
   <form>bodnutí</form>
   <lemma>bodnutí_^(*3out)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W7</w.rf>
   <form>pacient</form>
   <lemma>pacient</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W8</w.rf>
   <form>ohrožen</form>
   <lemma>ohrozit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s4">
  <m id="m-olomoucky49559.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W1</w.rf>
   <form>Nicméně</form>
   <lemma>nicméně</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W2</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W3</w.rf>
   <form>známy</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>ACTP------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W5</w.rf>
   <form>případy</form>
   <lemma>případ</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W6</w.rf>
   <form>úmrtí</form>
   <lemma>úmrtí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W7</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W8</w.rf>
   <form>jediném</form>
   <lemma>jediný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W9</w.rf>
   <form>včelím</form>
   <lemma>včelí</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W10</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W11</w.rf>
   <form>vosím</form>
   <lemma>vosí</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W12</w.rf>
   <form>píchnutí</form>
   <lemma>píchnutí_^(*3out)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s5">
  <m id="m-olomoucky49559.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W1</w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W2</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W3</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W4</w.rf>
   <form>příčinu</form>
   <lemma>příčina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W6</w.rf>
   <form>alergii</form>
   <lemma>alergie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W8</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W10</w.rf>
   <form>rozvíjí</form>
   <lemma>rozvíjet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W11</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W12</w.rf>
   <form>reakce</form>
   <lemma>reakce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W14</w.rf>
   <form>toxiny</form>
   <lemma>toxin</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s5W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s6">
  <m id="m-olomoucky49559.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s6W1</w.rf>
   <form>Největším</form>
   <lemma>velký</lemma>
   <tag>AANS7----3A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s6W2</w.rf>
   <form>nebezpečím</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s6W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s6W4</w.rf>
   <form>vznik</form>
   <lemma>vznik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s6W5</w.rf>
   <form>anafylaktického</form>
   <lemma>anafylaktický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s6W6</w.rf>
   <form>šoku</form>
   <lemma>šok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s6W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s7">
  <m id="m-olomoucky49559.txt-001-p3s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W1</w.rf>
   <form>Průběh</form>
   <lemma>průběh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W2</w.rf>
   <form>intoxikace</form>
   <lemma>intoxikace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W3</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W4</w.rf>
   <form>záleží</form>
   <lemma>záležet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W6</w.rf>
   <form>stupni</form>
   <lemma>stupeň</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W7</w.rf>
   <form>citlivosti</form>
   <lemma>citlivost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W8</w.rf>
   <form>postiženého</form>
   <lemma>postižený_^(*4hnout)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W9</w.rf>
   <form>jedince</form>
   <lemma>jedinec</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s7W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s8">
  <m id="m-olomoucky49559.txt-001-p3s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W2</w.rf>
   <form>lehčích</form>
   <lemma>lehký</lemma>
   <tag>AAIP6----2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W3</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W5</w.rf>
   <form>reakce</form>
   <lemma>reakce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W6</w.rf>
   <form>projevuje</form>
   <lemma>projevovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W7</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W8</w.rf>
   <form>lokálně</form>
   <lemma>lokálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W9</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W10</w.rf>
   <form>anemický</form>
   <lemma>anemický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W11</w.rf>
   <form>prstenec</form>
   <lemma>prstenec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W13</w.rf>
   <form>bolest</form>
   <lemma>bolest</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s8W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s9">
  <m id="m-olomoucky49559.txt-001-p3s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W1</w.rf>
   <form>Jedy</form>
   <lemma>jed</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W2</w.rf>
   <form>vos</form>
   <lemma>vosa</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W4</w.rf>
   <form>sršňů</form>
   <lemma>sršeň</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W5</w.rf>
   <form>způsobují</form>
   <lemma>způsobovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W6</w.rf>
   <form>silnější</form>
   <lemma>silný</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W7</w.rf>
   <form>lokální</form>
   <lemma>lokální</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W8</w.rf>
   <form>reakci</form>
   <lemma>reakce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W9</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W10</w.rf>
   <form>včelí</form>
   <lemma>včelí</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W11</w.rf>
   <form>jed</form>
   <lemma>jed</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W13</w.rf>
   <form>dochází</form>
   <lemma>docházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W14</w.rf>
   <form>častěji</form>
   <lemma>častě_^(*1ý)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W15</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W16</w.rf>
   <form>projevům</form>
   <lemma>projev</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W17</w.rf>
   <form>generalizované</form>
   <lemma>generalizovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W18</w.rf>
   <form>otravy</form>
   <lemma>otrava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s9W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s9W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s10">
  <m id="m-olomoucky49559.txt-001-p3s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W2</w.rf>
   <form>těžkých</form>
   <lemma>těžký</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W3</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W4</w.rf>
   <form>dochází</form>
   <lemma>docházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W5</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W6</w.rf>
   <form>celkovým</form>
   <lemma>celkový</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W7</w.rf>
   <form>projevům</form>
   <lemma>projev</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W9</w.rf>
   <form>tachykardii</form>
   <lemma>tachykardie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W11</w.rf>
   <form>zrychlení</form>
   <lemma>zrychlení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W12</w.rf>
   <form>dechové</form>
   <lemma>dechový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W13</w.rf>
   <form>frekvence</form>
   <lemma>frekvence</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W15</w.rf>
   <form>cyanóze</form>
   <lemma>cyanóza</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W17</w.rf>
   <form>zvracení</form>
   <lemma>zvracení_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W19</w.rf>
   <form>průjmu</form>
   <lemma>průjem</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W21</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W22</w.rf>
   <form>dojít</form>
   <lemma>dojít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W23</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W24</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W25</w.rf>
   <form>anafylaktickému</form>
   <lemma>anafylaktický</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W26</w.rf>
   <form>šoku</form>
   <lemma>šok</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s10W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s10W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p3s11">
  <m id="m-olomoucky49559.txt-001-p3s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W1</w.rf>
   <form>Nebezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W3</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W4</w.rf>
   <form>bodnutí</form>
   <lemma>bodnutí_^(*3out)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W6</w.rf>
   <form>sliznice</form>
   <lemma>sliznice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W7</w.rf>
   <form>dutiny</form>
   <lemma>dutina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W8</w.rf>
   <form>ústní</form>
   <lemma>ústní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W10</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W11</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W12</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W13</w.rf>
   <form>edém</form>
   <lemma>edém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W14</w.rf>
   <form>zpravidla</form>
   <lemma>zpravidla</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W15</w.rf>
   <form>lokalizován</form>
   <lemma>lokalizovat_:T_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W17</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W18</w.rf>
   <form>hrtanu</form>
   <lemma>hrtan</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p3s11W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p3s11W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p4s1">
  <m id="m-olomoucky49559.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W1</w.rf>
   <form>Terapie</form>
   <lemma>terapie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W2</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W3</w.rf>
   <form>včelím</form>
   <lemma>včelí</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W4</w.rf>
   <form>bodnutí</form>
   <lemma>bodnutí_^(*3out)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W5</w.rf>
   <form>spočívá</form>
   <lemma>spočívat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W7</w.rf>
   <form>opatrném</form>
   <lemma>opatrný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W8</w.rf>
   <form>vyjmutí</form>
   <lemma>vyjmutí_^(*3out)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W9</w.rf>
   <form>žihadla</form>
   <lemma>žihadlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p4s2">
  <m id="m-olomoucky49559.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W2</w.rf>
   <form>urychlení</form>
   <lemma>urychlení_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W3</w.rf>
   <form>odeznění</form>
   <lemma>odeznění_^(*3ít)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W4</w.rf>
   <form>bolesti</form>
   <lemma>bolest</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W6</w.rf>
   <form>aplikují</form>
   <lemma>aplikovat_:T_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W7</w.rf>
   <form>ledové</form>
   <lemma>ledový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W9</w.rf>
   <form>popř</form>
   <lemma>popřípadě_:B</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W11</w.rf>
   <form>octanové</form>
   <lemma>octanový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W13</w.rf>
   <form>obklady</form>
   <lemma>obklad</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p4s3">
  <m id="m-olomoucky49559.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W1</w.rf>
   <form>Lokální</form>
   <lemma>lokální</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W2</w.rf>
   <form>terapie</form>
   <lemma>terapie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W3</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W4</w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W5</w.rf>
   <form>nemá</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W6</w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W7</w.rf>
   <form>význam</form>
   <lemma>význam</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W9</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W10</w.rf>
   <form>projevy</form>
   <lemma>projev</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W11</w.rf>
   <form>odezní</form>
   <lemma>odeznít</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W12</w.rf>
   <form>samy</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W13</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W14</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W15</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p4s4">
  <m id="m-olomoucky49559.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s4W1</w.rf>
   <form>Edém</form>
   <lemma>edém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s4W2</w.rf>
   <form>hrtanu</form>
   <lemma>hrtan</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s4W3</w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s4W4</w.rf>
   <form>vyžaduje</form>
   <lemma>vyžadovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s4W5</w.rf>
   <form>urgentní</form>
   <lemma>urgentní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s4W6</w.rf>
   <form>tracheotomii</form>
   <lemma>tracheotomie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p4s5">
  <m id="m-olomoucky49559.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W1</w.rf>
   <form>Celková</form>
   <lemma>celkový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W2</w.rf>
   <form>intoxikace</form>
   <lemma>intoxikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W4</w.rf>
   <form>mnohočetných</form>
   <lemma>mnohočetný</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W5</w.rf>
   <form>bodnutích</form>
   <lemma>bodnutí_^(*3out)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W7</w.rf>
   <form>léčí</form>
   <lemma>léčit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W8</w.rf>
   <form>podobně</form>
   <lemma>podobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W9</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W10</w.rf>
   <form>anafylaktický</form>
   <lemma>anafylaktický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W11</w.rf>
   <form>šok</form>
   <lemma>šok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W13</w.rf>
   <form>tj.</form>
   <lemma>tj-1_:B_^(to_je/jest)</lemma>
   <tag>J^------------8</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W14</w.rf>
   <form>podáním</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W15</w.rf>
   <form>adrenalinu</form>
   <lemma>adrenalin</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p4s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p4s5W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p5s1">
  <m id="m-olomoucky49559.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W1</w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W2</w.rf>
   <form>nebezpečností</form>
   <lemma>nebezpečnost-2_^(jen_jako_práv._termín:_činu,_pachatele)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W3</w.rf>
   <form>blanokřídlého</form>
   <lemma>blanokřídlý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W4</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W6</w.rf>
   <form>zvláště</form>
   <lemma>zvláště</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W7</w.rf>
   <form>sršňů</form>
   <lemma>sršeň</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W9</w.rf>
   <form>nesmírně</form>
   <lemma>smírně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W10</w.rf>
   <form>přehání</form>
   <lemma>přehánět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p5s2">
  <m id="m-olomoucky49559.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W1</w.rf>
   <form>Bodají</form>
   <lemma>bodat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W2</w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W3</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W5</w.rf>
   <form>obraně</form>
   <lemma>obrana_^(proti_nepříteli)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W6</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W7</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W8</w.rf>
   <form>vydráždění</form>
   <lemma>vydráždění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p5s3">
  <m id="m-olomoucky49559.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W1</w.rf>
   <form>Rozrušený</form>
   <lemma>rozrušený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W2</w.rf>
   <form>roj</form>
   <lemma>roj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W3</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W4</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W5</w.rf>
   <form>přejde</form>
   <lemma>přejít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W7</w.rf>
   <form>útoku</form>
   <lemma>útok</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W8</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W9</w.rf>
   <form>rychle</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p5s4">
  <m id="m-olomoucky49559.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W1</w.rf>
   <form>Sršeň</form>
   <lemma>sršeň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W4</w.rf>
   <form>skutečnosti</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W5</w.rf>
   <form>bázlivé</form>
   <lemma>bázlivý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W7</w.rf>
   <form>neútočné</form>
   <lemma>útočný</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W8</w.rf>
   <form>zvíře</form>
   <lemma>zvíře</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W10</w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W12</w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W13</w.rf>
   <form>ovšem</form>
   <lemma>ovšem-1_^(avšak,_však;_odporovací_spojka)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W14</w.rf>
   <form>neohrožuje</form>
   <lemma>ohrožovat_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W15</w.rf>
   <form>hnízdo</form>
   <lemma>hnízdo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W17</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W18</w.rf>
   <form>patří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W19</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W20</w.rf>
   <form>chráněnému</form>
   <lemma>chráněný_^(*3it)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W21</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p5s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p5s4W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p6s1">
  <m id="m-olomoucky49559.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W1</w.rf>
   <form>Přesto</form>
   <lemma>přesto</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W3</w.rf>
   <form>situaci</form>
   <lemma>situace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W5</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W6</w.rf>
   <form>bezprostředně</form>
   <lemma>bezprostředně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W7</w.rf>
   <form>ohrožují</form>
   <lemma>ohrožovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W8</w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W10</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W11</w.rf>
   <form>nutná</form>
   <lemma>nutný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W12</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W13</w.rf>
   <form>likvidace</form>
   <lemma>likvidace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p6s2">
  <m id="m-olomoucky49559.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W1</w.rf>
   <form>Jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W3</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W5</w.rf>
   <form>případy</form>
   <lemma>případ</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W6</w.rf>
   <form>výskytu</form>
   <lemma>výskyt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W8</w.rf>
   <form>obydlích</form>
   <lemma>obydlí</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W9</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W11</w.rf>
   <form>jeho</form>
   <lemma>on-1_^(vidím_ho)</lemma>
   <tag>PPYS4--3-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W12</w.rf>
   <form>bezprostřední</form>
   <lemma>bezprostřední</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W13</w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W16</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W17</w.rf>
   <form>pohybujících</form>
   <lemma>pohybující_^(*5ovat)</lemma>
   <tag>AGMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W19</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W21</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W22</w.rf>
   <form>silné</form>
   <lemma>silný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W23</w.rf>
   <form>parfémy</form>
   <lemma>parfém</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W25</w.rf>
   <form>deodoranty</form>
   <lemma>deodorant</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W27</w.rf>
   <form>tělesný</form>
   <lemma>tělesný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W28</w.rf>
   <form>pach</form>
   <lemma>pach</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W29</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W30</w.rf>
   <form>pot</form>
   <lemma>pot</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W31</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W32</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W33</w.rf>
   <form>vydražďující</form>
   <lemma>vydražďující_^(*5ovat)</lemma>
   <tag>AGIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W34</w.rf>
   <form>účinky</form>
   <lemma>účinek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p6s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p6s2W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p7s1">
  <m id="m-olomoucky49559.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W1</w.rf>
   <form>Každá</form>
   <lemma>každý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W2</w.rf>
   <form>hasičská</form>
   <lemma>hasičský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W3</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W4</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W5</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W6</w.rf>
   <form>odlišné</form>
   <lemma>odlišný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W7</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W9</w.rf>
   <form>zásahy</form>
   <lemma>zásah</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W10</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W11</w.rf>
   <form>ohrožení</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W12</w.rf>
   <form>nebezpečným</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAIS7----1N----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W13</w.rf>
   <form>hmyzem</form>
   <lemma>hmyz</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W14</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p7s2">
  <m id="m-olomoucky49559.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W1</w.rf>
   <form>Někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W3</w.rf>
   <form>likviduje</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W4</w.rf>
   <form>nebezpečný</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAIS1----1N----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W5</w.rf>
   <form>hmyz</form>
   <lemma>hmyz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W7</w.rf>
   <form>speciálních</form>
   <lemma>speciální</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W8</w.rf>
   <form>oblecích</form>
   <lemma>oblek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W10</w.rf>
   <form>jinde</form>
   <lemma>jinde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W11</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W13</w.rf>
   <form>včelařské</form>
   <lemma>včelařský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W14</w.rf>
   <form>kukle</form>
   <lemma>kukla</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W16</w.rf>
   <form>ochranných</form>
   <lemma>ochranný</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W17</w.rf>
   <form>rukavicích</form>
   <lemma>rukavice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p7s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s1">
  <m id="m-olomoucky49559.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s1W1</w.rf>
   <form>Nejjednodušším</form>
   <lemma>jednoduchý</lemma>
   <tag>AAIS7----3A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s1W2</w.rf>
   <form>zásahem</form>
   <lemma>zásah</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s1W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s1W4</w.rf>
   <form>likvidace</form>
   <lemma>likvidace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s1W5</w.rf>
   <form>zdroje</form>
   <lemma>zdroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s1W6</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s1W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s2">
  <m id="m-olomoucky49559.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W1</w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W2</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W4</w.rf>
   <form>ovšem</form>
   <lemma>ovšem-1_^(avšak,_však;_odporovací_spojka)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W5</w.rf>
   <form>uvědomit</form>
   <lemma>uvědomit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W8</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W9</w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W10</w.rf>
   <form>chránit</form>
   <lemma>chránit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W11</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W12</w.rf>
   <form>přírodu</form>
   <lemma>příroda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s3">
  <m id="m-olomoucky49559.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W1</w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W2</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W4</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W5</w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W6</w.rf>
   <form>hmyz</form>
   <lemma>hmyz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W7</w.rf>
   <form>ponechat</form>
   <lemma>ponechat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W9</w.rf>
   <form>živu</form>
   <lemma>živý</lemma>
   <tag>ACFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W10</w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W11</w.rf>
   <form>vážně</form>
   <lemma>vážně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W12</w.rf>
   <form>neohrožuje</form>
   <lemma>ohrožovat_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W13</w.rf>
   <form>lidi</form>
   <lemma>člověk</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W15</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W16</w.rf>
   <form>úsilí</form>
   <lemma>úsilí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W17</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W19</w.rf>
   <form>mělo</form>
   <lemma>mít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W20</w.rf>
   <form>věnovat</form>
   <lemma>věnovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W21</w.rf>
   <form>osvětě</form>
   <lemma>osvěta</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s4">
  <m id="m-olomoucky49559.txt-001-p8s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W2</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W4</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W5</w.rf>
   <form>občan</form>
   <lemma>občan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W6</w.rf>
   <form>objeví</form>
   <lemma>objevit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W7</w.rf>
   <form>včelí</form>
   <lemma>včelí</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W8</w.rf>
   <form>roj</form>
   <lemma>roj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W9</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W10</w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W11</w.rf>
   <form>propadat</form>
   <lemma>propadat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W12</w.rf>
   <form>panice</form>
   <lemma>panic</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W14</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W15</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W17</w.rf>
   <form>chovat</form>
   <lemma>chovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W18</w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W19</w.rf>
   <form>normálně</form>
   <lemma>normálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W21</w.rf>
   <form>uvědomit</form>
   <lemma>uvědomit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W22</w.rf>
   <form>odborníka</form>
   <lemma>odborník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W25</w.rf>
   <form>včelaře</form>
   <lemma>včelař</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s4W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s5">
  <m id="m-olomoucky49559.txt-001-p8s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W2</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W3</w.rf>
   <form>vos</form>
   <lemma>vosa</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W4</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W5</w.rf>
   <form>naši</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSMP1-P1-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W6</w.rf>
   <form>předci</form>
   <lemma>předek-2_^(generačně)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W7</w.rf>
   <form>preventivně</form>
   <lemma>preventivně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W8</w.rf>
   <form>používali</form>
   <lemma>používat_:T_^(*3t)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W9</w.rf>
   <form>lapací</form>
   <lemma>lapací_^(*2t)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W10</w.rf>
   <form>lahve</form>
   <lemma>lahev</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W11</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W12</w.rf>
   <form>úzkým</form>
   <lemma>úzký</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W13</w.rf>
   <form>hrdlem</form>
   <lemma>hrdlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W14</w.rf>
   <form>naplněné</form>
   <lemma>naplněný_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W16</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W17</w.rf>
   <form>třetiny</form>
   <lemma>třetina</lemma>
   <tag>CyFS2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W18</w.rf>
   <form>vodným</form>
   <lemma>vodný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W19</w.rf>
   <form>roztokem</form>
   <lemma>roztok</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W20</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W21</w.rf>
   <form>cukru</form>
   <lemma>cukr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W23</w.rf>
   <form>trochy</form>
   <lemma>trocha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W24</w.rf>
   <form>piva</form>
   <lemma>pivo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W25</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W26</w.rf>
   <form>moštu</form>
   <lemma>mošt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s5W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s6">
  <m id="m-olomoucky49559.txt-001-p8s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W1</w.rf>
   <form>Láhev</form>
   <lemma>láhev</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W3</w.rf>
   <form>pověsila</form>
   <lemma>pověsit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W5</w.rf>
   <form>větve</form>
   <lemma>větev</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W6</w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W7</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W8</w.rf>
   <form>postavila</form>
   <lemma>postavit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W9</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W10</w.rf>
   <form>zemních</form>
   <lemma>zemní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W11</w.rf>
   <form>otvorů</form>
   <lemma>otvor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s6W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s7">
  <m id="m-olomoucky49559.txt-001-p8s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W1</w.rf>
   <form>Vosy</form>
   <lemma>vosa</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W2</w.rf>
   <form>najdou</form>
   <lemma>najít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W3</w.rf>
   <form>cestu</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W5</w.rf>
   <form>lahví</form>
   <lemma>lahev</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W6</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W7</w.rf>
   <form>rychle</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W9</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W10</w.rf>
   <form>ven</form>
   <lemma>ven</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W11</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W12</w.rf>
   <form>úzkým</form>
   <lemma>úzký</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W13</w.rf>
   <form>hrdlem</form>
   <lemma>hrdlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W14</w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W15</w.rf>
   <form>nedostanou</form>
   <lemma>dostat</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W17</w.rf>
   <form>utopí</form>
   <lemma>utopit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s7W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s8">
  <m id="m-olomoucky49559.txt-001-p8s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W1</w.rf>
   <form>Sršni</form>
   <lemma>sršeň</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W3</w.rf>
   <form>nerojí</form>
   <lemma>rojit_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W5</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W6</w.rf>
   <form>přítomnost</form>
   <lemma>přítomnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W8</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W9</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W10</w.rf>
   <form>pozorovat</form>
   <lemma>pozorovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W11</w.rf>
   <form>delší</form>
   <lemma>dlouhý-1_^(fyz._délka;_př._dlouhá_tyč)</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W12</w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s8W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s9">
  <m id="m-olomoucky49559.txt-001-p8s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W1</w.rf>
   <form>Ponechme</form>
   <lemma>ponechat</lemma>
   <tag>Vi-P---1--A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W2</w.rf>
   <form>sršně</form>
   <lemma>sršeň</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W4</w.rf>
   <form>živu</form>
   <lemma>živý</lemma>
   <tag>ACFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W6</w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W7</w.rf>
   <form>nás</form>
   <lemma>já</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W8</w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W9</w.rf>
   <form>vážně</form>
   <lemma>vážně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W10</w.rf>
   <form>neohrožují</form>
   <lemma>ohrožovat_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s9W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p8s10">
  <m id="m-olomoucky49559.txt-001-p8s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W1</w.rf>
   <form>Doporučuje</form>
   <lemma>doporučovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W3</w.rf>
   <form>zavolat</form>
   <lemma>zavolat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W4</w.rf>
   <form>odborníka</form>
   <lemma>odborník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W7</w.rf>
   <form>ochranáře</form>
   <lemma>ochranář</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W9</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W10</w.rf>
   <form>dokáže</form>
   <lemma>dokázat</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W11</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W12</w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W13</w.rf>
   <form>sršní</form>
   <lemma>sršní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W14</w.rf>
   <form>hnízdo</form>
   <lemma>hnízdo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W15</w.rf>
   <form>přestěhovat</form>
   <lemma>přestěhovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W16</w.rf>
   <form>sejmutím</form>
   <lemma>sejmutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W17</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W18</w.rf>
   <form>igelitového</form>
   <lemma>igelitový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W19</w.rf>
   <form>pytle</form>
   <lemma>pytel</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W21</w.rf>
   <form>uložením</form>
   <lemma>uložení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W22</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W23</w.rf>
   <form>papírové</form>
   <lemma>papírový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W24</w.rf>
   <form>krabice</form>
   <lemma>krabice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p8s10W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p8s10W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p9s1">
  <m id="m-olomoucky49559.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W1</w.rf>
   <form>Člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W2</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W3</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W4</w.rf>
   <form>volat</form>
   <lemma>volat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W5</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W7</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W8</w.rf>
   <form>nebezpečného</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAIS2----1N----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W9</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W10</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W12</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W14</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W15</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W16</w.rf>
   <form>bezprostředně</form>
   <lemma>bezprostředně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W17</w.rf>
   <form>ohrožen</form>
   <lemma>ohrozit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W19</w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W20</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W21</w.rf>
   <form>alergik</form>
   <lemma>alergik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W23</w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W24</w.rf>
   <form>dítě</form>
   <lemma>dítě</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W25</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W26</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W27</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W28</w.rf>
   <form>ohroženo</form>
   <lemma>ohrozit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W29</w.rf>
   <form>jeho</form>
   <lemma>on-1_^(vidím_ho)</lemma>
   <tag>PPYS4--3-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W30</w.rf>
   <form>zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W31</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W32</w.rf>
   <form>jeho</form>
   <lemma>on-1_^(vidím_ho)</lemma>
   <tag>PPYS4--3-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W33</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s1W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p9s2">
  <m id="m-olomoucky49559.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W1</w.rf>
   <form>Zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W2</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W3</w.rf>
   <form>hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W4</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W5</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W6</w.rf>
   <form>naráží</form>
   <lemma>narážet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W8</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W9</w.rf>
   <form>vratkou</form>
   <lemma>vratký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W10</w.rf>
   <form>hranu</form>
   <lemma>hrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W11</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W12</w.rf>
   <form>posouzení</form>
   <lemma>posouzení_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W13</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W15</w.rf>
   <form>prodlení</form>
   <lemma>prodlení_^(nebezpečí_z...;_zpoždění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W16</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W17</w.rf>
   <form>strany</form>
   <lemma>strana-1_^(v_prostoru)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W18</w.rf>
   <form>operačního</form>
   <lemma>operační</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W19</w.rf>
   <form>důstojníka</form>
   <lemma>důstojník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W21</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W22</w.rf>
   <form>rozhoduje</form>
   <lemma>rozhodovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W23</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W24</w.rf>
   <form>nasazení</form>
   <lemma>nasazení_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W25</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p9s3">
  <m id="m-olomoucky49559.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W2</w.rf>
   <form>telefonního</form>
   <lemma>telefonní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W3</w.rf>
   <form>hovoru</form>
   <lemma>hovor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W5</w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W6</w.rf>
   <form>posoudit</form>
   <lemma>posoudit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W8</w.rf>
   <form>zda</form>
   <lemma>zda</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W9</w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W10</w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W12</w.rf>
   <form>bezprostřední</form>
   <lemma>bezprostřední</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W13</w.rf>
   <form>ohrožení</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p9s4">
  <m id="m-olomoucky49559.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W2</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W3</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W4</w.rf>
   <form>obecně</form>
   <lemma>obecně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W5</w.rf>
   <form>zasahuje</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W6</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W7</w.rf>
   <form>případů</form>
   <lemma>případ</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W9</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W10</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W11</w.rf>
   <form>ohrožen</form>
   <lemma>ohrozit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W12</w.rf>
   <form>lidský</form>
   <lemma>lidský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W13</w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W15</w.rf>
   <form>zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W16</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W17</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W19</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W20</w.rf>
   <form>pochopitelné</form>
   <lemma>pochopitelný_^(*4)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W22</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W23</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W24</w.rf>
   <form>důstojník</form>
   <lemma>důstojník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W25</w.rf>
   <form>raději</form>
   <lemma>raději</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W26</w.rf>
   <form>jednotku</form>
   <lemma>jednotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W27</w.rf>
   <form>vyšle</form>
   <lemma>vyslat</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W29</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W30</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W31</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W32</w.rf>
   <form>určitou</form>
   <lemma>určitý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W33</w.rf>
   <form>pochybnost</form>
   <lemma>pochybnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W34</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W35</w.rf>
   <form>nutnosti</form>
   <lemma>nutnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W36</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W37</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W38</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W39</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W40</w.rf>
   <form>riskoval</form>
   <lemma>riskovat_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W41</w.rf>
   <form>následné</form>
   <lemma>následný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W42</w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p9s4W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p9s4W43</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky49559.txt-001-p10s1">
  <m id="m-olomoucky49559.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W1</w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W2</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W3</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W4</w.rf>
   <form>upozornit</form>
   <lemma>upozornit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W5</w.rf>
   <form>občany</form>
   <lemma>občan</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W8</w.rf>
   <form>zatímco</form>
   <lemma>zatímco</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W10</w.rf>
   <form>likvidují</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W11</w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W13</w.rf>
   <form>vosy</form>
   <lemma>vosa</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W14</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W15</w.rf>
   <form>sršně</form>
   <lemma>sršeň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W17</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W18</w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W19</w.rf>
   <form>hořet</form>
   <lemma>hořet</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W20</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W21</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W22</w.rf>
   <form>vážná</form>
   <lemma>vážný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W23</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W24</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W26</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W27</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W28</w.rf>
   <form>nemusí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W29</w.rf>
   <form>přijít</form>
   <lemma>přijít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W30</w.rf>
   <form>včas</form>
   <lemma>včas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky49559.txt-001-p10s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky49559.txt-001-p10s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
