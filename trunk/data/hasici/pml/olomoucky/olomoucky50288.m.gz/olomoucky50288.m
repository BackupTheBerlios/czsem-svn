<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="olomoucky50288.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-olomoucky50288.txt-001-p1s1">
  <m id="m-olomoucky50288.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W1</w.rf>
   <form>Jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W3</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W4</w.rf>
   <form>tradiční</form>
   <lemma>tradiční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W5</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W7</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W8</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W10</w.rf>
   <form>simulují</form>
   <lemma>simulovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W11</w.rf>
   <form>zásahovou</form>
   <lemma>zásahový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W12</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W14</w.rf>
   <form>převlečníku</form>
   <lemma>převlečník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W15</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W16</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W17</w.rf>
   <form>dýchacího</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W18</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p1s2">
  <m id="m-olomoucky50288.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W1</w.rf>
   <form>Pořadateli</form>
   <lemma>pořadatel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W2</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W3</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W4</w.rf>
   <form>Hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W5</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W6</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W7</w.rf>
   <form>Olomouckého</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W8</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W10</w.rf>
   <form>Sportovní</form>
   <lemma>sportovní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W11</w.rf>
   <form>klub</form>
   <lemma>klub</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W12</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W13</w.rf>
   <form>Hasičském</form>
   <lemma>hasičský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W14</w.rf>
   <form>záchranném</form>
   <lemma>záchranný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W15</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W16</w.rf>
   <form>Olomouckého</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W17</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W19</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W20</w.rf>
   <form>hasičská</form>
   <lemma>hasičský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W21</w.rf>
   <form>sportovní</form>
   <lemma>sportovní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W22</w.rf>
   <form>federace</form>
   <lemma>federace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p1s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p2s1">
  <m id="m-olomoucky50288.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W1</w.rf>
   <form>Náročný</form>
   <lemma>náročný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W2</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W3</w.rf>
   <form>začne</form>
   <lemma>začít-1</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W4</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W5</w.rf>
   <form>výškovou</form>
   <lemma>výškový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W6</w.rf>
   <form>budovou</form>
   <lemma>budova</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W8</w.rf>
   <form>soutěžní</form>
   <lemma>soutěžní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W9</w.rf>
   <form>trasa</form>
   <lemma>trasa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W10</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W11</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W12</w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W13</w.rf>
   <form>závodníky</form>
   <lemma>závodník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W14</w.rf>
   <form>stejná</form>
   <lemma>stejný</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p2s3">
  <m id="m-olomoucky50288.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W1</w.rf>
   <form>Poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W2</w.rf>
   <form>trasa</form>
   <lemma>trasa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W3</w.rf>
   <form>pokračuje</form>
   <lemma>pokračovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W5</w.rf>
   <form>výškové</form>
   <lemma>výškový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W6</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W8</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W9</w.rf>
   <form>hasič</form>
   <lemma>hasič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W10</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W12</w.rf>
   <form>plné</form>
   <lemma>plný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W13</w.rf>
   <form>výbavě</form>
   <lemma>výbava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W14</w.rf>
   <form>vyběhnout</form>
   <lemma>vyběhnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W16</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W18</w.rf>
   <form>patra</form>
   <lemma>patro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p2s3W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p3s1">
  <m id="m-olomoucky50288.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W3</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W4</w.rf>
   <form>zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W5</w.rf>
   <form>59</form>
   <lemma>59</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W6</w.rf>
   <form>soutěžících</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W8</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W9</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W10</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W12</w.rf>
   <form>řad</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W13</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W14</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W16</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W17</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W18</w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W19</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W20</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W21</w.rf>
   <form>řad</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W22</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W23</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W25</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W26</w.rf>
   <form>trať</form>
   <lemma>trať</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W27</w.rf>
   <form>postavena</form>
   <lemma>postavit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W28</w.rf>
   <form>paralelně</form>
   <lemma>paralelně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W29</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W30</w.rf>
   <form>zrcadlově</form>
   <lemma>zrcadlově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W31</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W32</w.rf>
   <form>současný</form>
   <lemma>současný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W33</w.rf>
   <form>postup</form>
   <lemma>postup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W34</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W35</w.rf>
   <form>soutěžících</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGIP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W36</w.rf>
   <form>startujících</form>
   <lemma>startující_^(*5ovat)</lemma>
   <tag>AGIP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W37</w.rf>
   <form>zároveň</form>
   <lemma>zároveň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p3s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p3s1W38</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p4s1">
  <m id="m-olomoucky50288.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W1</w.rf>
   <form>Hodnocení</form>
   <lemma>hodnocení_^(*4tit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W2</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W3</w.rf>
   <form>proběhne</form>
   <lemma>proběhnout_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W5</w.rf>
   <form>kategorii</form>
   <lemma>kategorie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W6</w.rf>
   <form>jednotlivců</form>
   <lemma>jednotlivec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W8</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W9</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W11</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W12</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W13</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W15</w.rf>
   <form>kategorii</form>
   <lemma>kategorie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W16</w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W19</w.rf>
   <form>kategorii</form>
   <lemma>kategorie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W20</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W21</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p4s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p5s1">
  <m id="m-olomoucky50288.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W2</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W3</w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W4</w.rf>
   <form>zvítězil</form>
   <lemma>zvítězit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W5</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W6</w.rf>
   <form>Teslík</form>
   <lemma>Teslík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W9</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W10</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W12</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W13</w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W14</w.rf>
   <form>soutěžní</form>
   <lemma>soutěžní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W15</w.rf>
   <form>trať</form>
   <lemma>trať</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W16</w.rf>
   <form>proběhl</form>
   <lemma>proběhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W17</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W18</w.rf>
   <form>neuvěřitelné</form>
   <lemma>uvěřitelný_^(*4)</lemma>
   <tag>AANS4----1N----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W19</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W20</w.rf>
   <form>minuty</form>
   <lemma>minuta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W22</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W23</w.rf>
   <form>sekundu</form>
   <lemma>sekunda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p5s2">
  <m id="m-olomoucky50288.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W1</w.rf>
   <form>Druhý</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W3</w.rf>
   <form>Martin</form>
   <lemma>Martin-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W4</w.rf>
   <form>Karlec</form>
   <lemma>Karlec_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W5</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W7</w.rf>
   <form>Olomouckého</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W8</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W10</w.rf>
   <form>bronzovou</form>
   <lemma>bronzový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W11</w.rf>
   <form>pozici</form>
   <lemma>pozice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W12</w.rf>
   <form>obsadil</form>
   <lemma>obsadit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W13</w.rf>
   <form>Zdeněk</form>
   <lemma>Zdeněk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W14</w.rf>
   <form>Koutník</form>
   <lemma>Koutník_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W15</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W16</w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p5s3">
  <m id="m-olomoucky50288.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W2</w.rf>
   <form>družstvech</form>
   <lemma>družstvo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W4</w.rf>
   <form>nejlépe</form>
   <lemma>dobře</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W5</w.rf>
   <form>vedli</form>
   <lemma>vést-1</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W6</w.rf>
   <form>zástupci</form>
   <lemma>zástupce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W7</w.rf>
   <form>hl.města</form>
   <lemma>hl.města</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W8</w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W9</w.rf>
   <form>následováni</form>
   <lemma>následovat_:T</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W10</w.rf>
   <form>Olomouckým</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W12</w.rf>
   <form>Moravskoslezským</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W13</w.rf>
   <form>krajem</form>
   <lemma>kraj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p5s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p6s1">
  <m id="m-olomoucky50288.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W2</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W3</w.rf>
   <form>patří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W4</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W5</w.rf>
   <form>nejatraktivnější</form>
   <lemma>atraktivní</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W7</w.rf>
   <form>nejpopulárnější</form>
   <lemma>populární</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W8</w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W10</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W11</w.rf>
   <form>historii</form>
   <lemma>historie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W12</w.rf>
   <form>nejen</form>
   <lemma>nejen</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W14</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W15</w.rf>
   <form>republice</form>
   <lemma>republika</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W17</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W18</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W20</w.rf>
   <form>mnoha</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W21</w.rf>
   <form>státech</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W22</w.rf>
   <form>Evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W23</w.rf>
   <form>unie</form>
   <lemma>unie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p6s2">
  <m id="m-olomoucky50288.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W1</w.rf>
   <form>Popularitu</form>
   <lemma>popularita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W2</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W3</w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W4</w.rf>
   <form>ukazuje</form>
   <lemma>ukazovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W5</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W6</w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W8</w.rf>
   <form>mistrovství</form>
   <lemma>mistrovství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W9</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W10</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W12</w.rf>
   <form>disciplínách</form>
   <lemma>disciplína</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W13</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W15</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W16</w.rf>
   <form>účastí</form>
   <lemma>účast</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W18</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W19</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W20</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W21</w.rf>
   <form>konat</form>
   <lemma>konat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W22</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W23</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W25</w.rf>
   <form>června</form>
   <lemma>červen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W26</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W27</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W28</w.rf>
   <form>Zlíně</form>
   <lemma>Zlín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p6s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p6s2W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-olomoucky50288.txt-001-p7s1">
  <m id="m-olomoucky50288.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W1</w.rf>
   <form>Schéma</form>
   <lemma>schéma</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W2</w.rf>
   <form>tratí</form>
   <lemma>trať</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W5</w.rf>
   <form>pdf</form>
   <lemma>pdf</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W6</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W7</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W8</w.rf>
   <form>138kb</form>
   <lemma>138kb</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-olomoucky50288.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-olomoucky50288.txt-001-p7s1W9</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
