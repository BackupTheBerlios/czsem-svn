<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky47552.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky47552.txt-001-p1s1">
  <m id="m-ustecky47552.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W3</w.rf>
   <form>najaře</form>
   <lemma>najař</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W4</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W5</w.rf>
   <form>stoupne</form>
   <lemma>stoupnout_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W6</w.rf>
   <form>počet</form>
   <lemma>počet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W7</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W8</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W9</w.rf>
   <form>způsobených</form>
   <lemma>způsobený_^(*3it)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W10</w.rf>
   <form>vypalováním</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNP3-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W11</w.rf>
   <form>porostů</form>
   <lemma>porost</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s2">
  <m id="m-ustecky47552.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W1</w.rf>
   <form>Příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W4</w.rf>
   <form>naprosté</form>
   <lemma>naprostý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W5</w.rf>
   <form>většině</form>
   <lemma>většina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W6</w.rf>
   <form>manipulace</form>
   <lemma>manipulace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W8</w.rf>
   <form>otevřeným</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W9</w.rf>
   <form>ohněm</form>
   <lemma>oheň</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W11</w.rf>
   <form>ať</form>
   <lemma>ať</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W12</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W13</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W14</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W15</w.rf>
   <form>vypalování</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W16</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W18</w.rf>
   <form>rozdělávání</form>
   <lemma>rozdělávání_^(*5at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W19</w.rf>
   <form>ohňů</form>
   <lemma>oheň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W21</w.rf>
   <form>lese</form>
   <lemma>les</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W22</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W24</w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W25</w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W27</w.rf>
   <form>kouření</form>
   <lemma>kouření_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s4">
  <m id="m-ustecky47552.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W1</w.rf>
   <form>Před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W2</w.rf>
   <form>odchodem</form>
   <lemma>odchod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W3</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W4</w.rf>
   <form>ohnište</form>
   <lemma>ohnište</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W6</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W8</w.rf>
   <form>přesvedčit</form>
   <lemma>přesvedčit</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W9</w.rf>
   <form>zda</form>
   <lemma>zda</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W10</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W11</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W12</w.rf>
   <form>opravdu</form>
   <lemma>opravdu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W13</w.rf>
   <form>důkladně</form>
   <lemma>důkladně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W14</w.rf>
   <form>uhašený</form>
   <lemma>uhašený_^(*4sit)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s5">
  <m id="m-ustecky47552.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W1</w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W2</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W3</w.rf>
   <form>malého</form>
   <lemma>malý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W4</w.rf>
   <form>doutnajícího</form>
   <lemma>doutnající_^(*4t)</lemma>
   <tag>AGIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W5</w.rf>
   <form>klacíku</form>
   <lemma>klacík</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W6</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W7</w.rf>
   <form>působením</form>
   <lemma>působení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W8</w.rf>
   <form>větru</form>
   <lemma>vítr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W9</w.rf>
   <form>vzniknou</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W10</w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W11</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s5W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s6">
  <m id="m-ustecky47552.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W1</w.rf>
   <form>Rozhodně</form>
   <lemma>rozhodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W2</w.rf>
   <form>nekouřit</form>
   <lemma>kouřit_:T</lemma>
   <tag>Vf--------N----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W4</w.rf>
   <form>lese</form>
   <lemma>les</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W7</w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W8</w.rf>
   <form>stohu</form>
   <lemma>stoh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W10</w.rf>
   <form>suché</form>
   <lemma>suchý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W11</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W12</w.rf>
   <form>atd</form>
   <lemma>atd-1_:B_,x_^(a_tak_dále)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s6W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s7">
  <m id="m-ustecky47552.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W1</w.rf>
   <form>Oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W2</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W3</w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W4</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W5</w.rf>
   <form>rozděláván</form>
   <lemma>rozdělávat_:T_^(*4at)</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W6</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W7</w.rf>
   <form>větrného</form>
   <lemma>větrný</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W9</w.rf>
   <form>dlouhodobě</form>
   <lemma>dlouhodobě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W10</w.rf>
   <form>suchého</form>
   <lemma>suchý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W11</w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W13</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W15</w.rf>
   <form>otevřeném</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W16</w.rf>
   <form>prostranství</form>
   <lemma>prostranství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W17</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W18</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W19</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W20</w.rf>
   <form>rozhodně</form>
   <lemma>rozhodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W21</w.rf>
   <form>týká</form>
   <lemma>týkat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W22</w.rf>
   <form>tzv</form>
   <lemma>takzvaný_:B_,x</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W24</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W25</w.rf>
   <form>črodějnic</form>
   <lemma>črodějnic</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W27</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W28</w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W29</w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W30</w.rf>
   <form>ohlásit</form>
   <lemma>ohlásit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W31</w.rf>
   <form>Hasičskému</form>
   <lemma>hasičský</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W32</w.rf>
   <form>záchrannému</form>
   <lemma>záchranný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W33</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s7W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s7W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s8">
  <m id="m-ustecky47552.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W1</w.rf>
   <form>Tel.</form>
   <lemma>telefon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W3</w.rf>
   <form>Krajské</form>
   <lemma>krajský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W4</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W5</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W7</w.rf>
   <form>Ústeckého</form>
   <lemma>ústecký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W8</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W9</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W10</w.rf>
   <form>950431114</form>
   <form_change>num_normalization</form_change>
   <lemma>950431114</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s8W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s9">
  <m id="m-ustecky47552.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W2</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W3</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W4</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W5</w.rf>
   <form>čarodějnic</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W6</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W7</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W8</w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W9</w.rf>
   <form>zajistit</form>
   <lemma>zajistit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W10</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W11</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W12</w.rf>
   <form>dozor</form>
   <lemma>dozor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W13</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W14</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W15</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W16</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W17</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s9W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s9W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s10">
  <m id="m-ustecky47552.txt-001-p1s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W2</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W3</w.rf>
   <form>provádět</form>
   <lemma>provádět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W5</w.rf>
   <form>místech</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W7</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4NP1----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W8</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W9</w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W10</w.rf>
   <form>přístupná</form>
   <lemma>přístupný</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W11</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W12</w.rf>
   <form>technice</form>
   <lemma>technika</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W14</w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W15</w.rf>
   <form>možno</form>
   <lemma>možný</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W17</w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W18</w.rf>
   <form>vodního</form>
   <lemma>vodní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W19</w.rf>
   <form>zdroje</form>
   <lemma>zdroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s10W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s10W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p1s11">
  <m id="m-ustecky47552.txt-001-p1s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W2</w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W3</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W5</w.rf>
   <form>nutno</form>
   <lemma>nutný</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W6</w.rf>
   <form>dbát</form>
   <lemma>dbát</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W8</w.rf>
   <form>bezpečnost</form>
   <lemma>bezpečnost-1_^(*5ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W9</w.rf>
   <form>přihlížejících</form>
   <lemma>přihlížející_^(*4t)</lemma>
   <tag>AGMP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W10</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p1s11W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p1s11W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p2s1">
  <m id="m-ustecky47552.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W2</w.rf>
   <form>současné</form>
   <lemma>současný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W3</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W5</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W6</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W7</w.rf>
   <form>čarodějnic</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W8</w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W9</w.rf>
   <form>častěji</form>
   <lemma>častě_^(*1ý)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W10</w.rf>
   <form>používá</form>
   <lemma>používat_:T_^(*3t)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W11</w.rf>
   <form>zábavná</form>
   <lemma>zábavný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W12</w.rf>
   <form>pyrotechnika</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p2s2">
  <m id="m-ustecky47552.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W2</w.rf>
   <form>jejím</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSZS6FS3-------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W3</w.rf>
   <form>používání</form>
   <lemma>používání_^(*4t)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W5</w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W6</w.rf>
   <form>dodržovat</form>
   <lemma>dodržovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W7</w.rf>
   <form>některá</form>
   <lemma>některý</lemma>
   <tag>PZNP4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W8</w.rf>
   <form>bezpečnostní</form>
   <lemma>bezpečnostní</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W9</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p2s3">
  <m id="m-ustecky47552.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W1</w.rf>
   <form>Teplota</form>
   <lemma>teplota</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W2</w.rf>
   <form>rachejtle</form>
   <lemma>rachejtle</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W3</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W4</w.rf>
   <form>dosáhnout</form>
   <lemma>dosáhnout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W5</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W6</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W7</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W8</w.rf>
   <form>stupňů</form>
   <lemma>stupeň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p2s4">
  <m id="m-ustecky47552.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W2</w.rf>
   <form>dopadu</form>
   <lemma>dopad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W3</w.rf>
   <form>nedohořelé</form>
   <lemma>dohořelý</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W4</w.rf>
   <form>rachejtle</form>
   <lemma>rachejtle</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W6</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W8</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W10</w.rf>
   <form>nachází</form>
   <lemma>nacházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W11</w.rf>
   <form>jakýkoli</form>
   <lemma>jakýkoliv</lemma>
   <tag>PZYS1---------1</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W12</w.rf>
   <form>hořlavý</form>
   <lemma>hořlavý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W13</w.rf>
   <form>materiál</form>
   <lemma>materiál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W14</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W15</w.rf>
   <form>např.</form>
   <lemma>například_:B_,x</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W16</w.rf>
   <form>suchá</form>
   <lemma>suchý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W17</w.rf>
   <form>tráva</form>
   <lemma>tráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W19</w.rf>
   <form>stoh</form>
   <lemma>stoh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W20</w.rf>
   <form>slámy</form>
   <lemma>sláma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W22</w.rf>
   <form>dřevěný</form>
   <lemma>dřevěný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W23</w.rf>
   <form>odpad</form>
   <lemma>odpad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W24</w.rf>
   <form>apod</form>
   <lemma>apod-1_:B_,x_^(a_podobně)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W28</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W29</w.rf>
   <form>dojít</form>
   <lemma>dojít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W30</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W31</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W32</w.rf>
   <form>krátké</form>
   <lemma>krátký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W33</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W34</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W35</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W36</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s4W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s4W37</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p2s5">
  <m id="m-ustecky47552.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W1</w.rf>
   <form>Nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W7</w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W8</w.rf>
   <form>domů</form>
   <lemma>dům</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W10</w.rf>
   <form>teplota</form>
   <lemma>teplota</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W11</w.rf>
   <form>rachejtle</form>
   <lemma>rachejtle</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W12</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W13</w.rf>
   <form>způsobit</form>
   <lemma>způsobit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W14</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W15</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W16</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W17</w.rf>
   <form>kryté</form>
   <lemma>krytý_^(*3ýt)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W18</w.rf>
   <form>bonským</form>
   <lemma>bonský</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W19</w.rf>
   <form>šindelem</form>
   <lemma>šindel</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s5W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p2s6">
  <m id="m-ustecky47552.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W1</w.rf>
   <form>Další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W2</w.rf>
   <form>stinnou</form>
   <lemma>stinný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W3</w.rf>
   <form>stránkou</form>
   <lemma>stránka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W4</w.rf>
   <form>používání</form>
   <lemma>používání_^(*4t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W5</w.rf>
   <form>zábavné</form>
   <lemma>zábavný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W6</w.rf>
   <form>pyrotechniky</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W7</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W8</w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W9</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W11</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W12</w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4XP3----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W13</w.rf>
   <form>každoročně</form>
   <lemma>každoročně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W14</w.rf>
   <form>dochází</form>
   <lemma>docházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s6W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p2s7">
  <m id="m-ustecky47552.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s7W1</w.rf>
   <form>Téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s7W2</w.rf>
   <form>všechna</form>
   <lemma>všechen</lemma>
   <tag>PLNP1----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s7W3</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s7W4</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s7W5</w.rf>
   <form>způsobena</form>
   <lemma>způsobit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s7W6</w.rf>
   <form>neodbornou</form>
   <lemma>odborný</lemma>
   <tag>AAFS7----1N----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s7W7</w.rf>
   <form>manipulací</form>
   <lemma>manipulace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s7W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47552.txt-001-p2s8">
  <m id="m-ustecky47552.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W1</w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W2</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W3</w.rf>
   <form>manipulaci</form>
   <lemma>manipulace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W4</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W5</w.rf>
   <form>zábavnou</form>
   <lemma>zábavný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W6</w.rf>
   <form>pyrotechnikou</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W7</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W8</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W9</w.rf>
   <form>důsledně</form>
   <lemma>důsledně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W10</w.rf>
   <form>dodržovat</form>
   <lemma>dodržovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W11</w.rf>
   <form>návod</form>
   <lemma>návod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W13</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W15</w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS4----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W16</w.rf>
   <form>důležitou</form>
   <lemma>důležitý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W17</w.rf>
   <form>zásadu</form>
   <lemma>zásada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W20</w.rf>
   <form>zábavná</form>
   <lemma>zábavný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W21</w.rf>
   <form>pyrotechnika</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W22</w.rf>
   <form>nepatří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W23</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W24</w.rf>
   <form>rukou</form>
   <lemma>ruka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W25</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky47552.txt-001-p2s8W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47552.txt-001-p2s8W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
