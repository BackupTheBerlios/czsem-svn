<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky49689.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky49689.txt-001-p1s1">
  <m id="m-ustecky49689.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p1s1W3</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p2s1">
  <m id="m-ustecky49689.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p2s1W1</w.rf>
   <form>Vadné</form>
   <lemma>vadný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p2s1W2</w.rf>
   <form>čidlo</form>
   <lemma>čidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p3s1">
  <m id="m-ustecky49689.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s1W1</w.rf>
   <form>16.5</form>
   <form_change>num_normalization</form_change>
   <lemma>16.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p3s2">
  <m id="m-ustecky49689.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W1</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W3</w.rf>
   <form>27</form>
   <lemma>27</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W7</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W8</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W10</w.rf>
   <form>obchodního</form>
   <lemma>obchodní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W11</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W12</w.rf>
   <form>Kaufland</form>
   <lemma>Kaufland_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W14</w.rf>
   <form>Českolipské</form>
   <lemma>českolipský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W15</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W17</w.rf>
   <form>Litoměřicích</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W18</w.rf>
   <form>odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W19</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W20</w.rf>
   <form>hlášena</form>
   <lemma>hlásit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W21</w.rf>
   <form>signalizace</form>
   <lemma>signalizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W22</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p3s3">
  <m id="m-ustecky49689.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W2</w.rf>
   <form>evakuovala</form>
   <lemma>evakuovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W4</w.rf>
   <form>obchodního</form>
   <lemma>obchodní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W5</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W6</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W7</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W9</w.rf>
   <form>průzkumem</form>
   <lemma>průzkum</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W10</w.rf>
   <form>zjistila</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W11</w.rf>
   <form>vadné</form>
   <lemma>vadný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W12</w.rf>
   <form>čidlo</form>
   <lemma>čidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p3s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p4s1">
  <m id="m-ustecky49689.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p4s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p4s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p5s1">
  <m id="m-ustecky49689.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s1W1</w.rf>
   <form>16.5</form>
   <form_change>num_normalization</form_change>
   <lemma>16.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p5s2">
  <m id="m-ustecky49689.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W1</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W3</w.rf>
   <form>59</form>
   <lemma>59</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W7</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W8</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W9</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W10</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W11</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W12</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W13</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W15</w.rf>
   <form>katastru</form>
   <lemma>katastr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W16</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W17</w.rf>
   <form>Brňany</form>
   <lemma>Brňan_;E</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p5s3">
  <m id="m-ustecky49689.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W2</w.rf>
   <form>vyprostila</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W4</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W5</w.rf>
   <form>zraněného</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W6</w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W8</w.rf>
   <form>předala</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W9</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W10</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W11</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W12</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p5s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p6s1">
  <m id="m-ustecky49689.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p6s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p6s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p6s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p7s1">
  <m id="m-ustecky49689.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p7s1W1</w.rf>
   <form>Olej</form>
   <lemma>olej</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p7s1W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p7s1W3</w.rf>
   <form>vozovce</form>
   <lemma>vozovka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p8s1">
  <m id="m-ustecky49689.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s1W1</w.rf>
   <form>16.5</form>
   <form_change>num_normalization</form_change>
   <lemma>16.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p8s2">
  <m id="m-ustecky49689.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W1</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W3</w.rf>
   <form>48</form>
   <lemma>48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W7</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W9</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W10</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W11</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W12</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W13</w.rf>
   <form>Pražské</form>
   <lemma>pražský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W14</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W16</w.rf>
   <form>Chomutově</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W17</w.rf>
   <form>zlikvidovat</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W18</w.rf>
   <form>30m</form>
   <lemma>30m</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W19</w.rf>
   <form>dlouhou</form>
   <lemma>dlouhý-1_^(fyz._délka;_př._dlouhá_tyč)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W20</w.rf>
   <form>olejovou</form>
   <lemma>olejový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W21</w.rf>
   <form>skvrnu</form>
   <lemma>skvrna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W23</w.rf>
   <form>táhnoucí</form>
   <lemma>táhnoucí_^(*2t)</lemma>
   <tag>AGIS4-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W24</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W25</w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W26</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W27</w.rf>
   <form>vodárně</form>
   <lemma>vodárna</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p8s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p8s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p9s1">
  <m id="m-ustecky49689.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p9s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p9s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p9s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p10s1">
  <m id="m-ustecky49689.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p10s1W1</w.rf>
   <form>Otevření</form>
   <lemma>otevření_^(*3ít)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p10s1W2</w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p11s1">
  <m id="m-ustecky49689.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s1W1</w.rf>
   <form>15.5</form>
   <form_change>num_normalization</form_change>
   <lemma>15.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49689.txt-001-p11s2">
  <m id="m-ustecky49689.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W1</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W3</w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W10</w.rf>
   <form>otevřela</form>
   <lemma>otevřít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W11</w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W12</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W13</w.rf>
   <form>zdravotnickou</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W14</w.rf>
   <form>záchrannou</form>
   <lemma>záchranný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W15</w.rf>
   <form>službu</form>
   <lemma>služba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W17</w.rf>
   <form>Nedbalově</form>
   <lemma>Nedbalův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W18</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W20</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W21</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W22</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W25</w.rf>
   <form>Bukově</form>
   <lemma>bukově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky49689.txt-001-p11s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49689.txt-001-p11s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
