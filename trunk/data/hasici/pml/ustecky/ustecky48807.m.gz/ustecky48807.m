<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky48807.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky48807.txt-001-p1s1">
  <m id="m-ustecky48807.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p1s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p2s1">
  <m id="m-ustecky48807.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p2s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p2s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p3s1">
  <m id="m-ustecky48807.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s1W1</w.rf>
   <form>9.5</form>
   <form_change>num_normalization</form_change>
   <lemma>9.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p3s2">
  <m id="m-ustecky48807.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W2</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W4</w.rf>
   <form>08</form>
   <lemma>08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W8</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W12</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W13</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W16</w.rf>
   <form>multikáry</form>
   <lemma>multikára</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W17</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W18</w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W19</w.rf>
   <form>Hrabák</form>
   <lemma>Hrabák_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W21</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W23</w.rf>
   <form>Čepirozích</form>
   <lemma>Čepirohy_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p3s3">
  <m id="m-ustecky48807.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s3W1</w.rf>
   <form>Jedn</form>
   <lemma>Jedn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s3W2</w.rf>
   <form>zraněný</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s3W3</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s3W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s3W5</w.rf>
   <form>odvezene</form>
   <lemma>odvezene</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s3W6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s3W7</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p3s4">
  <m id="m-ustecky48807.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s4W2</w.rf>
   <form>odčerpávala</form>
   <lemma>odčerpávat_:T_^(*4at)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s4W3</w.rf>
   <form>naftu</form>
   <lemma>nafta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s4W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s4W5</w.rf>
   <form>asanovala</form>
   <lemma>asanovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s4W6</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p3s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p4s1">
  <m id="m-ustecky48807.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p4s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p4s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p4s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p5s1">
  <m id="m-ustecky48807.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p5s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p5s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p6s1">
  <m id="m-ustecky48807.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s1W1</w.rf>
   <form>9.5</form>
   <form_change>num_normalization</form_change>
   <lemma>9.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p6s2">
  <m id="m-ustecky48807.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W1</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W3</w.rf>
   <form>33</form>
   <lemma>33</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W7</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W8</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W9</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W10</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W11</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W12</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W13</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W14</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W15</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W16</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W17</w.rf>
   <form>vroutek</form>
   <lemma>vroutek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p6s3">
  <m id="m-ustecky48807.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s3W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s3W3</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s3W4</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s3W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p6s4">
  <m id="m-ustecky48807.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W2</w.rf>
   <form>zajistila</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W3</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W4</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W5</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W7</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W8</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p6s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p6s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p7s1">
  <m id="m-ustecky48807.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p7s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p7s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p8s1">
  <m id="m-ustecky48807.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s1W1</w.rf>
   <form>9.5</form>
   <form_change>num_normalization</form_change>
   <lemma>9.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p8s2">
  <m id="m-ustecky48807.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W1</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W3</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W6</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W7</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W8</w.rf>
   <form>43</form>
   <lemma>43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W9</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W10</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W11</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W12</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W13</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W15</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W16</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W17</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W18</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W20</w.rf>
   <form>srny</form>
   <lemma>srna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W21</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W22</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W23</w.rf>
   <form>Očihov</form>
   <lemma>Očihov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p8s3">
  <m id="m-ustecky48807.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s3W2</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s3W3</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p8s3W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p9s1">
  <m id="m-ustecky48807.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p9s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p9s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p9s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p10s1">
  <m id="m-ustecky48807.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p10s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p11s1">
  <m id="m-ustecky48807.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s1W1</w.rf>
   <form>9.5</form>
   <form_change>num_normalization</form_change>
   <lemma>9.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p11s2">
  <m id="m-ustecky48807.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W1</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W3</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W7</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W8</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W9</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W10</w.rf>
   <form>plastové</form>
   <lemma>plastový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W11</w.rf>
   <form>popelnice</form>
   <lemma>popelnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W13</w.rf>
   <form>Scheinerově</form>
   <lemma>Scheinerův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W14</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W16</w.rf>
   <form>Teplicích</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W17</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W19</w.rf>
   <form>Trnovanech</form>
   <lemma>Trnovany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p11s3">
  <m id="m-ustecky48807.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s3W5</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s3W7</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p11s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p12s1">
  <m id="m-ustecky48807.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p12s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p12s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p12s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p13s1">
  <m id="m-ustecky48807.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p13s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p13s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p14s1">
  <m id="m-ustecky48807.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s1W1</w.rf>
   <form>8.5</form>
   <form_change>num_normalization</form_change>
   <lemma>8.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p14s2">
  <m id="m-ustecky48807.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W1</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W3</w.rf>
   <form>59</form>
   <lemma>59</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W7</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W8</w.rf>
   <form>Kamenice</form>
   <lemma>Kamenice_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W12</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W13</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W16</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W17</w.rf>
   <form>Kamenici</form>
   <lemma>Kamenica_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W20</w.rf>
   <form>Lísce</form>
   <lemma>líska</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p14s3">
  <m id="m-ustecky48807.txt-001-p14s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s3W1</w.rf>
   <form>Auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s3W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s3W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s3W4</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48807.txt-001-p14s4">
  <m id="m-ustecky48807.txt-001-p14s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W2</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W3</w.rf>
   <form>postavila</form>
   <lemma>postavit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W5</w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W7</w.rf>
   <form>provedla</form>
   <lemma>provést</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W8</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W9</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W11</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W12</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48807.txt-001-p14s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48807.txt-001-p14s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
