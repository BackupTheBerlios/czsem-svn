<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky49550.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky49550.txt-001-p1s1">
  <m id="m-ustecky49550.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p1s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p2s1">
  <m id="m-ustecky49550.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p2s1W1</w.rf>
   <form>Spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p2s1W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p3s1">
  <m id="m-ustecky49550.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s1W1</w.rf>
   <form>15.5</form>
   <form_change>num_normalization</form_change>
   <lemma>15.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p3s2">
  <m id="m-ustecky49550.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W1</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W3</w.rf>
   <form>08</form>
   <lemma>08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W5</w.rf>
   <form>HZSP</form>
   <lemma>HZSP</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W6</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W7</w.rf>
   <form>dráhy</form>
   <lemma>dráha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W8</w.rf>
   <form>odstranila</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W9</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W10</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W12</w.rf>
   <form>železniční</form>
   <lemma>železniční_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W13</w.rf>
   <form>trať</form>
   <lemma>trať</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W14</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W15</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W16</w.rf>
   <form>Bořislav</form>
   <lemma>Bořislav_;G_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p3s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p4s1">
  <m id="m-ustecky49550.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p4s1W1</w.rf>
   <form>Otevření</form>
   <lemma>otevření_^(*3ít)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p4s1W2</w.rf>
   <form>vrat</form>
   <lemma>vrata</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p5s1">
  <m id="m-ustecky49550.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s1W1</w.rf>
   <form>15.5</form>
   <form_change>num_normalization</form_change>
   <lemma>15.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p5s2">
  <m id="m-ustecky49550.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W1</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W3</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W7</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W8</w.rf>
   <form>přeštípla</form>
   <lemma>přeštípnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W9</w.rf>
   <form>zámek</form>
   <lemma>zámek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W11</w.rf>
   <form>vratech</form>
   <lemma>vrata</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W12</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W13</w.rf>
   <form>dvora</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W15</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W16</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W17</w.rf>
   <form>Pivovaru</form>
   <lemma>pivovar</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W18</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W19</w.rf>
   <form>Teplicích</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W22</w.rf>
   <form>Trnovanech</form>
   <lemma>Trnovany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p5s3">
  <m id="m-ustecky49550.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W2</w.rf>
   <form>dvoře</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W3</w.rf>
   <form>ležel</form>
   <lemma>ležet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W4</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W6</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W7</w.rf>
   <form>vypadl</form>
   <lemma>vypadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W9</w.rf>
   <form>druhého</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W10</w.rf>
   <form>patra</form>
   <lemma>patro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p5s4">
  <m id="m-ustecky49550.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s4W1</w.rf>
   <form>Odvezla</form>
   <lemma>odvézt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s4W2</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s4W3</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s4W4</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s4W5</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p5s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p6s1">
  <m id="m-ustecky49550.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p6s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p7s1">
  <m id="m-ustecky49550.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s1W1</w.rf>
   <form>14.5</form>
   <form_change>num_normalization</form_change>
   <lemma>14.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p7s2">
  <m id="m-ustecky49550.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W1</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W3</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W7</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W9</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W10</w.rf>
   <form>Dubí</form>
   <lemma>Dubí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W13</w.rf>
   <form>Mstišov</form>
   <lemma>Mstišov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W14</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W15</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W16</w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W18</w.rf>
   <form>Mírové</form>
   <lemma>mírový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W19</w.rf>
   <form>ulicí</form>
   <lemma>ulice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W21</w.rf>
   <form>Dubí</form>
   <lemma>Dubí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W24</w.rf>
   <form>Mstišově</form>
   <lemma>Mstišov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p7s3">
  <m id="m-ustecky49550.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s3W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s3W2</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s3W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s3W4</w.rf>
   <form>evakuováno</form>
   <lemma>evakuovat_:T_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s3W5</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s3W6</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p7s4">
  <m id="m-ustecky49550.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W2</w.rf>
   <form>následky</form>
   <lemma>následek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W3</w.rf>
   <form>nadýchání</form>
   <lemma>nadýchání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W5</w.rf>
   <form>splodin</form>
   <lemma>splodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W6</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W7</w.rf>
   <form>zemřela</form>
   <lemma>zemřít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W8</w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W10</w.rf>
   <form>podkroví</form>
   <lemma>podkroví</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p7s5">
  <m id="m-ustecky49550.txt-001-p7s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s5W1</w.rf>
   <form>Druhá</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s5W2</w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s5W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s5W4</w.rf>
   <form>hospitalizována</form>
   <lemma>hospitalizovat_:T_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s5W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p7s6">
  <m id="m-ustecky49550.txt-001-p7s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s6W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s6W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s6W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s6W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s6W5</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s6W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s6W7</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p7s7">
  <m id="m-ustecky49550.txt-001-p7s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s7W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s7W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s7W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s7W4</w.rf>
   <form>vyšetřuje</form>
   <lemma>vyšetřovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p7s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p7s7W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p8s1">
  <m id="m-ustecky49550.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p8s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p8s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p8s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p9s1">
  <m id="m-ustecky49550.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p9s1W1</w.rf>
   <form>Spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p9s1W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p10s1">
  <m id="m-ustecky49550.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s1W1</w.rf>
   <form>15.5</form>
   <form_change>num_normalization</form_change>
   <lemma>15.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p10s2">
  <m id="m-ustecky49550.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W1</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W3</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W7</w.rf>
   <form>Šluknov</form>
   <lemma>Šluknov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W9</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W10</w.rf>
   <form>Jiříkov</form>
   <lemma>Jiříkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W11</w.rf>
   <form>odstranily</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W12</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W13</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W15</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W17</w.rf>
   <form>dráty</form>
   <lemma>drát-1</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W18</w.rf>
   <form>elektrického</form>
   <lemma>elektrický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W19</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W21</w.rf>
   <form>Mánesově</form>
   <lemma>Mánesův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W22</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W24</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W25</w.rf>
   <form>Jiříkov</form>
   <lemma>Jiříkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p10s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p10s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p11s1">
  <m id="m-ustecky49550.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p11s1W1</w.rf>
   <form>Spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p11s1W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p12s1">
  <m id="m-ustecky49550.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s1W1</w.rf>
   <form>15.5</form>
   <form_change>num_normalization</form_change>
   <lemma>15.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p12s2">
  <m id="m-ustecky49550.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W1</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W3</w.rf>
   <form>48</form>
   <lemma>48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W7</w.rf>
   <form>Varnsdorf</form>
   <lemma>Varnsdorf_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W8</w.rf>
   <form>odstranila</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W9</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W10</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W12</w.rf>
   <form>kravína</form>
   <lemma>kravín</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W14</w.rf>
   <form>Jiřetíně</form>
   <lemma>Jiřetín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W15</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W16</w.rf>
   <form>Jedlovou</form>
   <lemma>jedlový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p12s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p13s1">
  <m id="m-ustecky49550.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p13s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p13s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p13s1W3</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p14s1">
  <m id="m-ustecky49550.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p14s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p14s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p15s1">
  <m id="m-ustecky49550.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s1W1</w.rf>
   <form>15.5</form>
   <form_change>num_normalization</form_change>
   <lemma>15.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p15s2">
  <m id="m-ustecky49550.txt-001-p15s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W1</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W3</w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W7</w.rf>
   <form>Roudnice</form>
   <lemma>Roudnice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W10</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W12</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W13</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W15</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W17</w.rf>
   <form>km</form>
   <lemma>km-1`kilometr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W18</w.rf>
   <form>dálnice</form>
   <lemma>dálnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W19</w.rf>
   <form>D8</form>
   <lemma>D8_:B_^(dálnice_v_ČR)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W20</w.rf>
   <form>směr</form>
   <lemma>směr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W21</w.rf>
   <form>TEPLICE</form>
   <lemma>teplice-1_^(termální_vody)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p15s3">
  <m id="m-ustecky49550.txt-001-p15s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s3W2</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s3W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s3W4</w.rf>
   <form>převrácený</form>
   <lemma>převrácený_^(*4tit)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s3W5</w.rf>
   <form>kamion</form>
   <lemma>kamión</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p15s4">
  <m id="m-ustecky49550.txt-001-p15s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W3</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W4</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W5</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W8</w.rf>
   <form>Mělník</form>
   <lemma>Mělník_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p15s5">
  <m id="m-ustecky49550.txt-001-p15s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W2</w.rf>
   <form>Mělník</form>
   <lemma>Mělník_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W3</w.rf>
   <form>vyprostila</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W4</w.rf>
   <form>mrtvého</form>
   <lemma>mrtvý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W5</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W7</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W9</w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W11</w.rf>
   <form>vrátila</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W13</w.rf>
   <form>základnu</form>
   <lemma>základna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s5W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p15s6">
  <m id="m-ustecky49550.txt-001-p15s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W1</w.rf>
   <form>Převrácená</form>
   <lemma>převrácený_^(*4tit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W2</w.rf>
   <form>cisterna</form>
   <lemma>cisterna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W3</w.rf>
   <form>převážela</form>
   <lemma>převážet_:T_^(něco_někam_např._autem)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W4</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W5</w.rf>
   <form>cement</form>
   <lemma>cement</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W6</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W7</w.rf>
   <form>hydroxid</form>
   <lemma>hydroxid</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W8</w.rf>
   <form>sodný</form>
   <lemma>sodný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W10</w.rf>
   <form>chybí</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W11</w.rf>
   <form>doklady</form>
   <lemma>doklad</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s6W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p15s7">
  <m id="m-ustecky49550.txt-001-p15s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W3</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W4</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W6</w.rf>
   <form>zástupci</form>
   <lemma>zástupce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W7</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W8</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p15s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p15s7W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p16s1">
  <m id="m-ustecky49550.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p16s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p16s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p16s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p16s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p17s1">
  <m id="m-ustecky49550.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p17s1W1</w.rf>
   <form>Spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p17s1W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p18s1">
  <m id="m-ustecky49550.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s1W1</w.rf>
   <form>15.5</form>
   <form_change>num_normalization</form_change>
   <lemma>15.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49550.txt-001-p18s2">
  <m id="m-ustecky49550.txt-001-p18s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W1</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W3</w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W10</w.rf>
   <form>odstranila</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W11</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W12</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W14</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W15</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W16</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W17</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W18</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W19</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W20</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W22</w.rf>
   <form>Ryjice</form>
   <lemma>Ryjice_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ustecky49550.txt-001-p18s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49550.txt-001-p18s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
