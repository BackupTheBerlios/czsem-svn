<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky45611.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky45611.txt-001-p1s1">
  <m id="m-ustecky45611.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p1s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p2s1">
  <m id="m-ustecky45611.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p2s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p2s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p3s1">
  <m id="m-ustecky45611.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s1W1</w.rf>
   <form>10.4</form>
   <form_change>num_normalization</form_change>
   <lemma>10.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p3s2">
  <m id="m-ustecky45611.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W2</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W4</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W8</w.rf>
   <form>Varnsdorf</form>
   <lemma>Varnsdorf_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W9</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W10</w.rf>
   <form>olejovou</form>
   <lemma>olejový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W11</w.rf>
   <form>skvrnu</form>
   <lemma>skvrna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W12</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W14</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W15</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W16</w.rf>
   <form>vozovky</form>
   <lemma>vozovka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W17</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W18</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W19</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W20</w.rf>
   <form>Jiřetína</form>
   <lemma>Jiřetín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W21</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W22</w.rf>
   <form>Jedlovou</form>
   <lemma>jedlový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W24</w.rf>
   <form>Šébr</form>
   <lemma>Šébr_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p3s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p4s1">
  <m id="m-ustecky45611.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p4s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p5s1">
  <m id="m-ustecky45611.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s1W1</w.rf>
   <form>10.4</form>
   <form_change>num_normalization</form_change>
   <lemma>10.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p5s2">
  <m id="m-ustecky45611.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W2</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W4</w.rf>
   <form>56</form>
   <lemma>56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W8</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W10</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W11</w.rf>
   <form>Benešov</form>
   <lemma>Benešov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W12</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W13</w.rf>
   <form>Ploučnicí</form>
   <lemma>Ploučnice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W15</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W16</w.rf>
   <form>Horní</form>
   <lemma>Horní_;G</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W17</w.rf>
   <form>Habartice</form>
   <lemma>Habartice_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W18</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W19</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W20</w.rf>
   <form>dřevěného</form>
   <lemma>dřevěný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W21</w.rf>
   <form>přístavku</form>
   <lemma>přístavek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W23</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W24</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W25</w.rf>
   <form>rodinného</form>
   <lemma>rodinný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W26</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W28</w.rf>
   <form>Benešově</form>
   <lemma>Benešův_;S_^(*2)</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W29</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W30</w.rf>
   <form>Ploučnicí</form>
   <lemma>Ploučnice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s2W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p5s3">
  <m id="m-ustecky45611.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s3W5</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s3W7</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p5s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p6s1">
  <m id="m-ustecky45611.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p6s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p7s1">
  <m id="m-ustecky45611.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s1W1</w.rf>
   <form>10.4</form>
   <form_change>num_normalization</form_change>
   <lemma>10.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p7s2">
  <m id="m-ustecky45611.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W2</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W4</w.rf>
   <form>33</form>
   <lemma>33</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W8</w.rf>
   <form>Varnsdorf</form>
   <lemma>Varnsdorf_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W10</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W11</w.rf>
   <form>Rybniště</form>
   <lemma>Rybniště_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W13</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W14</w.rf>
   <form>Krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W15</w.rf>
   <form>Lípa</form>
   <lemma>lípa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W17</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W18</w.rf>
   <form>Horní</form>
   <lemma>Horní_;G</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W19</w.rf>
   <form>Podluží</form>
   <lemma>Podluží_;G</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W20</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W21</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W22</w.rf>
   <form>lesního</form>
   <lemma>lesní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W23</w.rf>
   <form>prostu</form>
   <lemma>prostý</lemma>
   <tag>ACFS4-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W25</w.rf>
   <form>třech</form>
   <lemma>tři`3</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W26</w.rf>
   <form>ohniscích</form>
   <lemma>ohnisko</lemma>
   <tag>NNNP6-----A---1</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W27</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W28</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W29</w.rf>
   <form>Rybniště</form>
   <lemma>Rybniště_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s2W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p7s3">
  <m id="m-ustecky45611.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s3W5</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s3W7</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p7s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p8s1">
  <m id="m-ustecky45611.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p8s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p8s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p8s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p9s1">
  <m id="m-ustecky45611.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p9s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p10s1">
  <m id="m-ustecky45611.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s1W1</w.rf>
   <form>10.4</form>
   <form_change>num_normalization</form_change>
   <lemma>10.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p10s2">
  <m id="m-ustecky45611.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W2</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W4</w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W8</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W9</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W11</w.rf>
   <form>stavební</form>
   <lemma>stavební</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W12</w.rf>
   <form>buňky</form>
   <lemma>buňka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W14</w.rf>
   <form>Trnovanské</form>
   <lemma>trnovanský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W15</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W17</w.rf>
   <form>Novosdelicích</form>
   <lemma>Novosdelice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p10s3">
  <m id="m-ustecky45611.txt-001-p10s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s3W5</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s3W7</w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p10s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p10s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p11s1">
  <m id="m-ustecky45611.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p11s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p12s1">
  <m id="m-ustecky45611.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s1W1</w.rf>
   <form>10.4</form>
   <form_change>num_normalization</form_change>
   <lemma>10.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p12s2">
  <m id="m-ustecky45611.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W2</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W4</w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W8</w.rf>
   <form>Duchcov</form>
   <lemma>Duchcov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W10</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W11</w.rf>
   <form>Zabrušany</form>
   <lemma>Zabrušany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W13</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W14</w.rf>
   <form>Žalany</form>
   <lemma>Žalany</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W16</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W17</w.rf>
   <form>Dubí</form>
   <lemma>Dubí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W20</w.rf>
   <form>Mstišov</form>
   <lemma>Mstišov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W22</w.rf>
   <form>HZSP</form>
   <lemma>HZSP</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W23</w.rf>
   <form>Doly</form>
   <lemma>důl</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W24</w.rf>
   <form>Bílina</form>
   <lemma>Bílina_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W27</w.rf>
   <form>Ledvice</form>
   <lemma>Ledvice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W29</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W30</w.rf>
   <form>Lom</form>
   <lemma>Lom_;G_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W31</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W32</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W33</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W34</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W35</w.rf>
   <form>keřů</form>
   <lemma>keř</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W36</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W37</w.rf>
   <form>skládce</form>
   <lemma>skládka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W38</w.rf>
   <form>Nelson</form>
   <lemma>Nelson_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W39</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W40</w.rf>
   <form>Osecké</form>
   <lemma>osecký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W41</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W42</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W43</w.rf>
   <form>Duchcově</form>
   <lemma>Duchcov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s2W44</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45611.txt-001-p12s3">
  <m id="m-ustecky45611.txt-001-p12s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s3W5</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s3W7</w.rf>
   <form>42</form>
   <lemma>42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45611.txt-001-p12s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45611.txt-001-p12s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
