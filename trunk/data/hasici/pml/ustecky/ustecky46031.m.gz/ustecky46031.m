<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky46031.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky46031.txt-001-p1s1">
  <m id="m-ustecky46031.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p1s1W3</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p2s1">
  <m id="m-ustecky46031.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p2s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p3s1">
  <m id="m-ustecky46031.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W1</w.rf>
   <form>13.4</form>
   <form_change>num_normalization</form_change>
   <lemma>13.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W3</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W4</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W6</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W9</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W11</w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W12</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W13</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W14</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W15</w.rf>
   <form>Lovosice</form>
   <lemma>Lovosice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W17</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W18</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W19</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W20</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W21</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W22</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W23</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W24</w.rf>
   <form>nadjezdu</form>
   <lemma>nadjezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W26</w.rf>
   <form>Lovosicích</form>
   <lemma>Lovosice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W27</w.rf>
   <form>odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W28</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W29</w.rf>
   <form>hlášen</form>
   <lemma>hlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W30</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W31</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W32</w.rf>
   <form>chodbě</form>
   <lemma>chodba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W33</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s1W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p3s2">
  <m id="m-ustecky46031.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s2W1</w.rf>
   <form>Hořel</form>
   <lemma>hořet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s2W2</w.rf>
   <form>botník</form>
   <lemma>botník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s2W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p3s3">
  <m id="m-ustecky46031.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W1</w.rf>
   <form>Čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W2</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W4</w.rf>
   <form>matka</form>
   <lemma>matka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W6</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W7</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W8</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W10</w.rf>
   <form>nadýchali</form>
   <lemma>nadýchat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W11</w.rf>
   <form>kouře</form>
   <lemma>kouř</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W13</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W14</w.rf>
   <form>ošetřeni</form>
   <lemma>ošetřit</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W15</w.rf>
   <form>zdravotnickou</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W16</w.rf>
   <form>záchrannou</form>
   <lemma>záchranný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W17</w.rf>
   <form>službou</form>
   <lemma>služba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p3s4">
  <m id="m-ustecky46031.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s4W1</w.rf>
   <form>Jedno</form>
   <lemma>jeden`1</lemma>
   <tag>ClNS1----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s4W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s4W3</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s4W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s4W5</w.rf>
   <form>odvezeno</form>
   <lemma>odvézt</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s4W6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s4W7</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p3s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p4s1">
  <m id="m-ustecky46031.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p4s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p4s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p4s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p5s1">
  <m id="m-ustecky46031.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p5s1W1</w.rf>
   <form>Prášek</form>
   <lemma>prášek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p5s1W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p5s1W3</w.rf>
   <form>hasicího</form>
   <lemma>hasicí_^(^IC**hasit)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p5s1W4</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p6s1">
  <m id="m-ustecky46031.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s1W1</w.rf>
   <form>13.4</form>
   <form_change>num_normalization</form_change>
   <lemma>13.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p6s2">
  <m id="m-ustecky46031.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W4</w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W8</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W11</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W12</w.rf>
   <form>Jana</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W13</w.rf>
   <form>Kříže</form>
   <lemma>kříž</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W14</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W15</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W17</w.rf>
   <form>mateřeké</form>
   <lemma>mateřeký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W18</w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W19</w.rf>
   <form>nalezen</form>
   <lemma>naleznout</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W21</w.rf>
   <form>dveřích</form>
   <lemma>dveře</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W24</w.rf>
   <form>šatnách</form>
   <lemma>šatna</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W25</w.rf>
   <form>modrý</form>
   <lemma>modrý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W26</w.rf>
   <form>prášek</form>
   <lemma>prášek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p6s3">
  <m id="m-ustecky46031.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W1</w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W2</w.rf>
   <form>zjištěno</form>
   <lemma>zjistit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W4</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W6</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W7</w.rf>
   <form>prášek</form>
   <lemma>prášek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W9</w.rf>
   <form>hasicího</form>
   <lemma>hasicí_^(^IC**hasit)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W10</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W12</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W14</w.rf>
   <form>uklidili</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p6s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p6s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p7s1">
  <m id="m-ustecky46031.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p7s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p7s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p7s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p8s1">
  <m id="m-ustecky46031.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p8s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p9s1">
  <m id="m-ustecky46031.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s1W1</w.rf>
   <form>13.4</form>
   <form_change>num_normalization</form_change>
   <lemma>13.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p9s2">
  <m id="m-ustecky46031.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W2</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W4</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W7</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W9</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W10</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W11</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W12</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W13</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W14</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W15</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W16</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W17</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W18</w.rf>
   <form>starého</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W19</w.rf>
   <form>nábytku</form>
   <lemma>nábytek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W21</w.rf>
   <form>palet</form>
   <lemma>paleta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W23</w.rf>
   <form>opuštěné</form>
   <lemma>opuštěný_^(*5stit)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W24</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W26</w.rf>
   <form>Havířské</form>
   <lemma>havířský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W27</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W29</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W30</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W31</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p9s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p9s2W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p10s1">
  <m id="m-ustecky46031.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p10s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p10s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p10s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p11s1">
  <m id="m-ustecky46031.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p11s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p11s1W2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p11s1W3</w.rf>
   <form>úmrtí</form>
   <lemma>úmrtí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p12s1">
  <m id="m-ustecky46031.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s1W1</w.rf>
   <form>13.4</form>
   <form_change>num_normalization</form_change>
   <lemma>13.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p12s2">
  <m id="m-ustecky46031.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W2</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W4</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W7</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W9</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W10</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W11</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W12</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W13</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W15</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W16</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W17</w.rf>
   <form>Duchcov</form>
   <lemma>Duchcov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W19</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W20</w.rf>
   <form>Košťany</form>
   <lemma>Košťany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W21</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W22</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W24</w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W26</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W27</w.rf>
   <form>Sídliště</form>
   <lemma>sídliště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W29</w.rf>
   <form>Košťanech</form>
   <lemma>Košťany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W30</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W31</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W32</w.rf>
   <form>Střelné</form>
   <lemma>střelný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s2W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p12s3">
  <m id="m-ustecky46031.txt-001-p12s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W1</w.rf>
   <form>Uvnitř</form>
   <lemma>uvnitř-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W3</w.rf>
   <form>nalezen</form>
   <lemma>naleznout</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W4</w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W6</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W8</w.rf>
   <form>nadýchal</form>
   <lemma>nadýchat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W9</w.rf>
   <form>splodin</form>
   <lemma>splodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W10</w.rf>
   <form>kouře</form>
   <lemma>kouř</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W12</w.rf>
   <form>nepodařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W13</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W14</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W15</w.rf>
   <form>oživit</form>
   <lemma>oživit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W16</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W17</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W18</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W19</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W20</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p12s4">
  <m id="m-ustecky46031.txt-001-p12s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s4W2</w.rf>
   <form>vznikl</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s4W3</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s4W4</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s4W5</w.rf>
   <form>zapálené</form>
   <lemma>zapálený_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s4W6</w.rf>
   <form>svíčky</form>
   <lemma>svíčka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p12s5">
  <m id="m-ustecky46031.txt-001-p12s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s5W1</w.rf>
   <form>Hořela</form>
   <lemma>hořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s5W2</w.rf>
   <form>televize</form>
   <lemma>televize</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s5W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s5W4</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s5W5</w.rf>
   <form>kuchně</form>
   <lemma>kucheň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46031.txt-001-p12s6">
  <m id="m-ustecky46031.txt-001-p12s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W1</w.rf>
   <form>Předbežně</form>
   <lemma>Předbežně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W2</w.rf>
   <form>odhadnutá</form>
   <lemma>odhadnutý_^(*3out)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W3</w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W5</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W7</w.rf>
   <form>55</form>
   <lemma>55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W8</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W9</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky46031.txt-001-p12s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46031.txt-001-p12s6W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
