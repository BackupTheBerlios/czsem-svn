<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky46049.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky46049.txt-001-p1s1">
  <m id="m-ustecky46049.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W1</w.rf>
   <form>Úspěšným</form>
   <lemma>úspěšný</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W2</w.rf>
   <form>reprezentantům</form>
   <lemma>reprezentant</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W3</w.rf>
   <form>pogratuloval</form>
   <lemma>pogratulovat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W5</w.rf>
   <form>zastoupení</form>
   <lemma>zastoupení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W6</w.rf>
   <form>krajského</form>
   <lemma>krajský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W7</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W8</w.rf>
   <form>náměstek</form>
   <lemma>náměstek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W9</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W10</w.rf>
   <form>IZS</form>
   <lemma>Izs</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W11</w.rf>
   <form>plk</form>
   <lemma>plukovník_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46049.txt-001-p1s2">
  <m id="m-ustecky46049.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s2W1</w.rf>
   <form>Mgr</form>
   <lemma>Mgr-1_:B_,x_^(magistr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s2W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46049.txt-001-p1s3">
  <m id="m-ustecky46049.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s3W1</w.rf>
   <form>Vladimír</form>
   <lemma>Vladimír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s3W2</w.rf>
   <form>Kučera</form>
   <lemma>Kučera_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s3W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46049.txt-001-p1s4">
  <m id="m-ustecky46049.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s4W1</w.rf>
   <form>Úspěšní</form>
   <lemma>úspěšný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s4W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s4W3</w.rf>
   <form>obdrželi</form>
   <lemma>obdržet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s4W4</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s4W5</w.rf>
   <form>reprezentaci</form>
   <lemma>reprezentace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s4W6</w.rf>
   <form>kázeňskou</form>
   <lemma>kázeňský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s4W7</w.rf>
   <form>odměnu</form>
   <lemma>odměna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46049.txt-001-p1s5">
  <m id="m-ustecky46049.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W1</w.rf>
   <form>Tomáš</form>
   <lemma>Tomáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W2</w.rf>
   <form>Ringler</form>
   <lemma>Ringler_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W4</w.rf>
   <form>Vojtěch</form>
   <lemma>Vojtěch_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W5</w.rf>
   <form>Dvořák</form>
   <lemma>Dvořák_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W6</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W7</w.rf>
   <form>členy</form>
   <lemma>člen</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W8</w.rf>
   <form>družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W9</w.rf>
   <form>českých</form>
   <lemma>český</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W10</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W12</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W13</w.rf>
   <form>zvítězilo</form>
   <lemma>zvítězit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W15</w.rf>
   <form>hasičském</form>
   <lemma>hasičský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W16</w.rf>
   <form>víceboji</form>
   <lemma>víceboj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46049.txt-001-p1s6">
  <m id="m-ustecky46049.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W1</w.rf>
   <form>Tomáš</form>
   <lemma>Tomáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W2</w.rf>
   <form>Ringler</form>
   <lemma>Ringler_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W3</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W4</w.rf>
   <form>zvítězil</form>
   <lemma>zvítězit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W7</w.rf>
   <form>individuálním</form>
   <lemma>individuální</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W8</w.rf>
   <form>závodě</form>
   <lemma>závod</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W9</w.rf>
   <form>hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W10</w.rf>
   <form>víceboje</form>
   <lemma>víceboj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W12</w.rf>
   <form>získal</form>
   <lemma>získat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W13</w.rf>
   <form>stříbro</form>
   <lemma>stříbro</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W15</w.rf>
   <form>zápasu</form>
   <lemma>zápas</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W16</w.rf>
   <form>řecko-římském</form>
   <lemma>řecko-římský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky46049.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46049.txt-001-p1s6W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
