<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky48647.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky48647.txt-001-p1s1">
  <m id="m-ustecky48647.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p1s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p2s1">
  <m id="m-ustecky48647.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p2s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p3s1">
  <m id="m-ustecky48647.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s1W1</w.rf>
   <form>7.5</form>
   <form_change>num_normalization</form_change>
   <lemma>7.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p3s2">
  <m id="m-ustecky48647.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W2</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W4</w.rf>
   <form>09</form>
   <lemma>09</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W8</w.rf>
   <form>Louny</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W10</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W11</w.rf>
   <form>Cítolíby</form>
   <lemma>Cítolíby</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W13</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W14</w.rf>
   <form>Postolprty</form>
   <lemma>Postolprta</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W15</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W16</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W17</w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W18</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W19</w.rf>
   <form>tržiště</form>
   <lemma>tržiště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W21</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W22</w.rf>
   <form>Kosmonautů</form>
   <lemma>kosmonaut</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W24</w.rf>
   <form>Lounech</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p3s3">
  <m id="m-ustecky48647.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W1</w.rf>
   <form>Hořel</form>
   <lemma>hořet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W2</w.rf>
   <form>meziprostor</form>
   <lemma>meziprostor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W3</w.rf>
   <form>stropní</form>
   <lemma>stropní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W4</w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W6</w.rf>
   <form>stěny</form>
   <lemma>stěna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W7</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W8</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W9</w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p3s4">
  <m id="m-ustecky48647.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s4W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s4W5</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s4W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s4W7</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p3s5">
  <m id="m-ustecky48647.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W3</w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W4</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W5</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W6</w.rf>
   <form>Cítolíby</form>
   <lemma>Cítolíby</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W8</w.rf>
   <form>dohled</form>
   <lemma>dohled</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p3s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p4s1">
  <m id="m-ustecky48647.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p4s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p5s1">
  <m id="m-ustecky48647.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W1</w.rf>
   <form>6.5</form>
   <form_change>num_normalization</form_change>
   <lemma>6.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W4</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W6</w.rf>
   <form>05</form>
   <lemma>05</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W7</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W9</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W10</w.rf>
   <form>Louny</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W12</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W13</w.rf>
   <form>Líšťany</form>
   <lemma>Líšťany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W14</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W15</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W16</w.rf>
   <form>lesní</form>
   <lemma>lesní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W17</w.rf>
   <form>hrabanky</form>
   <lemma>hrabanka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W19</w.rf>
   <form>lese</form>
   <lemma>les</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W20</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W21</w.rf>
   <form>chatové</form>
   <lemma>chatový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W22</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W23</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W24</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W25</w.rf>
   <form>Zbrašín</form>
   <lemma>Zbrašín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p5s2">
  <m id="m-ustecky48647.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W1</w.rf>
   <form>Hořela</form>
   <lemma>hořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W2</w.rf>
   <form>hrabanka</form>
   <lemma>hrabanka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W4</w.rf>
   <form>porost</form>
   <lemma>porost</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W5</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W6</w.rf>
   <form>navážkou</form>
   <lemma>navážka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W7</w.rf>
   <form>zeminy</form>
   <lemma>zemina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W9</w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W10</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W11</w.rf>
   <form>musely</form>
   <lemma>muset</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W12</w.rf>
   <form>rozhrabávat</form>
   <lemma>rozhrabávat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p5s3">
  <m id="m-ustecky48647.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s3W5</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s3W7</w.rf>
   <form>48</form>
   <lemma>48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p5s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p6s1">
  <m id="m-ustecky48647.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p6s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p6s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p6s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p7s1">
  <m id="m-ustecky48647.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p7s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p8s1">
  <m id="m-ustecky48647.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s1W1</w.rf>
   <form>7.5</form>
   <form_change>num_normalization</form_change>
   <lemma>7.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p8s2">
  <m id="m-ustecky48647.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W1</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W3</w.rf>
   <form>32</form>
   <lemma>32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W7</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W8</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W9</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W10</w.rf>
   <form>stánku</form>
   <lemma>stánek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W12</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W13</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W15</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p8s3">
  <m id="m-ustecky48647.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s3W1</w.rf>
   <form>Požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s3W2</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s3W3</w.rf>
   <form>zasaženy</form>
   <lemma>zasáhnout</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s3W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s3W5</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s3W6</w.rf>
   <form>sousedící</form>
   <lemma>sousedící_^(*3it)</lemma>
   <tag>AGIP4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s3W7</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p8s4">
  <m id="m-ustecky48647.txt-001-p8s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s4W3</w.rf>
   <form>uhašen</form>
   <lemma>uhasit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s4W5</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s4W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s4W7</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p8s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p8s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p9s1">
  <m id="m-ustecky48647.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p9s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p10s1">
  <m id="m-ustecky48647.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s1W1</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s1W3</w.rf>
   <form>-5.5</form>
   <form_change>num_normalization</form_change>
   <lemma>-5.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p10s2">
  <m id="m-ustecky48647.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W2</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W4</w.rf>
   <form>59</form>
   <lemma>59</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W8</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W10</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W11</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W12</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W14</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W15</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W17</w.rf>
   <form>HZSP</form>
   <lemma>HZSP</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W18</w.rf>
   <form>MU</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W19</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W21</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W22</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W23</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W25</w.rf>
   <form>podkrovních</form>
   <lemma>podkrovní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W26</w.rf>
   <form>bytů</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W27</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W29</w.rf>
   <form>Jedličkově</form>
   <lemma>Jedličkův_;S_^(*2a)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W30</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W31</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W32</w.rf>
   <form>Litvínově</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s2W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p10s3">
  <m id="m-ustecky48647.txt-001-p10s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s3W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s3W2</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s3W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s3W4</w.rf>
   <form>evakuováno</form>
   <lemma>evakuovat_:T_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s3W5</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s3W6</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p10s4">
  <m id="m-ustecky48647.txt-001-p10s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s4W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s4W5</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s4W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s4W7</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p10s5">
  <m id="m-ustecky48647.txt-001-p10s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s5W1</w.rf>
   <form>Předběžnáý</form>
   <lemma>Předběžnáý</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s5W2</w.rf>
   <form>odhad</form>
   <lemma>odhad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s5W3</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s5W4</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s5W5</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s5W6</w.rf>
   <form>milóny</form>
   <lemma>milóny</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s5W7</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p10s6">
  <m id="m-ustecky48647.txt-001-p10s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s6W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s6W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s6W3</w.rf>
   <form>vyšetřuje</form>
   <lemma>vyšetřovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p10s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p10s6W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p11s1">
  <m id="m-ustecky48647.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p11s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p11s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p11s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p12s1">
  <m id="m-ustecky48647.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p12s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p13s1">
  <m id="m-ustecky48647.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s1W1</w.rf>
   <form>7.5</form>
   <form_change>num_normalization</form_change>
   <lemma>7.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p13s2">
  <m id="m-ustecky48647.txt-001-p13s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W2</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W4</w.rf>
   <form>27</form>
   <lemma>27</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W8</w.rf>
   <form>Duchcov</form>
   <lemma>Duchcov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W9</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W11</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W13</w.rf>
   <form>pilin</form>
   <lemma>pilina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W15</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W16</w.rf>
   <form>Jeníkov</form>
   <lemma>Jeníkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p13s3">
  <m id="m-ustecky48647.txt-001-p13s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W4</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W6</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W7</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W8</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p13s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p13s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p14s1">
  <m id="m-ustecky48647.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p14s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p14s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p14s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p15s1">
  <m id="m-ustecky48647.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p15s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p15s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p16s1">
  <m id="m-ustecky48647.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s1W1</w.rf>
   <form>6.5</form>
   <form_change>num_normalization</form_change>
   <lemma>6.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p16s2">
  <m id="m-ustecky48647.txt-001-p16s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W2</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W4</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W8</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W12</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W13</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W16</w.rf>
   <form>motocyklu</form>
   <lemma>motocykl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W18</w.rf>
   <form>Ústecké</form>
   <lemma>ústecký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W19</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W21</w.rf>
   <form>Děčíně</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W24</w.rf>
   <form>Chrocvicích</form>
   <lemma>Chrocvice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p16s3">
  <m id="m-ustecky48647.txt-001-p16s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s3W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s3W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s3W4</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s3W5</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s3W6</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p16s4">
  <m id="m-ustecky48647.txt-001-p16s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s4W1</w.rf>
   <form>Převzala</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s4W2</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s4W3</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s4W4</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s4W5</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s4W6</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s4W7</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48647.txt-001-p16s5">
  <m id="m-ustecky48647.txt-001-p16s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s5W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s5W2</w.rf>
   <form>provedla</form>
   <lemma>provést</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s5W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s5W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s5W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s5W6</w.rf>
   <form>asanovala</form>
   <lemma>asanovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s5W7</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48647.txt-001-p16s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48647.txt-001-p16s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
