<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky47549.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky47549.txt-001-p1s1">
  <m id="m-ustecky47549.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p1s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p2s1">
  <m id="m-ustecky47549.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p2s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p2s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p2s1W3</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p2s1W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p2s1W5</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p3s1">
  <m id="m-ustecky47549.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s1W1</w.rf>
   <form>26.4</form>
   <form_change>num_normalization</form_change>
   <lemma>26.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p3s2">
  <m id="m-ustecky47549.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W1</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W3</w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W7</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W10</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W11</w.rf>
   <form>Duchcov</form>
   <lemma>Duchcov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W12</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W14</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W15</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W16</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W17</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W18</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W20</w.rf>
   <form>Teplicích</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W23</w.rf>
   <form>Hudcově</form>
   <lemma>hudcův_^(*3ec)</lemma>
   <tag>AUNS6M---------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p3s3">
  <m id="m-ustecky47549.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s3W1</w.rf>
   <form>Jedno</form>
   <lemma>jeden`1</lemma>
   <tag>ClNS1----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s3W2</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s3W3</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s3W4</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s3W5</w.rf>
   <form>shořelo</form>
   <lemma>shořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p3s4">
  <m id="m-ustecky47549.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s4W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s4W5</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s4W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s4W7</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p3s5">
  <m id="m-ustecky47549.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s5W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s5W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s5W3</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s5W4</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s5W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p3s6">
  <m id="m-ustecky47549.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s6W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s6W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s6W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s6W4</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s6W5</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p3s6W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p4s1">
  <m id="m-ustecky47549.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p4s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p4s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p4s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p5s1">
  <m id="m-ustecky47549.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p5s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p5s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p6s1">
  <m id="m-ustecky47549.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s1W1</w.rf>
   <form>26.4</form>
   <form_change>num_normalization</form_change>
   <lemma>26.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p6s2">
  <m id="m-ustecky47549.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W2</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W4</w.rf>
   <form>09</form>
   <lemma>09</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W8</w.rf>
   <form>Louny</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W12</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W13</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W16</w.rf>
   <form>Chodce</form>
   <lemma>chodec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W18</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W19</w.rf>
   <form>Osvoboditelů</form>
   <lemma>osvoboditel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W21</w.rf>
   <form>Lounech</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p6s3">
  <m id="m-ustecky47549.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s3W2</w.rf>
   <form>nezasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p6s3W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p7s1">
  <m id="m-ustecky47549.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p7s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p7s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p7s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p8s1">
  <m id="m-ustecky47549.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p8s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p8s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p9s1">
  <m id="m-ustecky47549.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W1</w.rf>
   <form>26.4</form>
   <form_change>num_normalization</form_change>
   <lemma>26.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W4</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W6</w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W7</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W9</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W10</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W11</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W14</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W15</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W17</w.rf>
   <form>motocyklu</form>
   <lemma>motocykl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W19</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W20</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W21</w.rf>
   <form>závětří</form>
   <lemma>závětří</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W23</w.rf>
   <form>Teplicích</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p9s2">
  <m id="m-ustecky47549.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s2W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s2W2</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s2W3</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p9s2W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p10s1">
  <m id="m-ustecky47549.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p10s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p10s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p11s1">
  <m id="m-ustecky47549.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s1W1</w.rf>
   <form>25.4</form>
   <form_change>num_normalization</form_change>
   <lemma>25.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p11s2">
  <m id="m-ustecky47549.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W2</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W4</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W8</w.rf>
   <form>Duchcov</form>
   <lemma>Duchcov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W9</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W10</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W12</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W13</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W16</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W17</w.rf>
   <form>Osek</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p11s3">
  <m id="m-ustecky47549.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W4</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W5</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W6</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W8</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W9</w.rf>
   <form>převzat</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W11</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W12</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W13</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W14</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p11s4">
  <m id="m-ustecky47549.txt-001-p11s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s4W2</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s4W3</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p11s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p11s4W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p12s1">
  <m id="m-ustecky47549.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p12s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p12s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p12s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p13s1">
  <m id="m-ustecky47549.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p13s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p13s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p14s1">
  <m id="m-ustecky47549.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s1W1</w.rf>
   <form>26.4</form>
   <form_change>num_normalization</form_change>
   <lemma>26.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p14s2">
  <m id="m-ustecky47549.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W2</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W4</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W8</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W9</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W10</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W12</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W13</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W16</w.rf>
   <form>dodávky</form>
   <lemma>dodávka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W18</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W19</w.rf>
   <form>Jílové</form>
   <lemma>jílový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W22</w.rf>
   <form>Martiněves</form>
   <lemma>Martiněves_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47549.txt-001-p14s3">
  <m id="m-ustecky47549.txt-001-p14s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W2</w.rf>
   <form>provedla</form>
   <lemma>provést</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W6</w.rf>
   <form>zabránila</form>
   <lemma>zabránit_:W_^(někomu_v_něčem)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W7</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W8</w.rf>
   <form>sorbčních</form>
   <lemma>sorbční</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W9</w.rf>
   <form>deček</form>
   <lemma>dečka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W10</w.rf>
   <form>vniknutí</form>
   <lemma>vniknutí_^(*3out)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W11</w.rf>
   <form>uniklých</form>
   <lemma>uniklý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W12</w.rf>
   <form>kapalin</form>
   <lemma>kapalina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W14</w.rf>
   <form>vodního</form>
   <lemma>vodní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W15</w.rf>
   <form>toku</form>
   <lemma>tok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W17</w.rf>
   <form>asanovala</form>
   <lemma>asanovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W18</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47549.txt-001-p14s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47549.txt-001-p14s3W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
