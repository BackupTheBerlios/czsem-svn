<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky48277.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky48277.txt-001-p1s1">
  <m id="m-ustecky48277.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p1s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p2s1">
  <m id="m-ustecky48277.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p2s1W1</w.rf>
   <form>Rozlitý</form>
   <lemma>rozlitý_^(*3ít)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p2s1W2</w.rf>
   <form>brom</form>
   <lemma>bróm</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p2s1W3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p2s1W4</w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p3s1">
  <m id="m-ustecky48277.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W1</w.rf>
   <form>3.5</form>
   <form_change>num_normalization</form_change>
   <lemma>3.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W4</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W6</w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W7</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W9</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W10</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W11</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W12</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W13</w.rf>
   <form>základní</form>
   <lemma>základní_,s</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W14</w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W16</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W17</w.rf>
   <form>Petra</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W18</w.rf>
   <form>Bezruče</form>
   <lemma>Bezruč_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W20</w.rf>
   <form>Žatci</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p3s2">
  <m id="m-ustecky48277.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s2W2</w.rf>
   <form>kabinetě</form>
   <lemma>kabinet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s2W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s2W4</w.rf>
   <form>rozbila</form>
   <lemma>rozbít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s2W5</w.rf>
   <form>lahev</form>
   <lemma>lahev</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s2W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s2W7</w.rf>
   <form>bromem</form>
   <lemma>bróm</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p3s3">
  <m id="m-ustecky48277.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W1</w.rf>
   <form>Škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W3</w.rf>
   <form>evakuována</form>
   <lemma>evakuovat_:T_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W5</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W6</w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>ClXP3----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W7</w.rf>
   <form>dospělým</form>
   <lemma>dospělý-1</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W8</w.rf>
   <form>lidem</form>
   <lemma>člověk</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W9</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W11</w.rf>
   <form>nadýchali</form>
   <lemma>nadýchat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W12</w.rf>
   <form>výparů</form>
   <lemma>výpar</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W13</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W14</w.rf>
   <form>povolána</form>
   <lemma>povolat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W15</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W16</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W17</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p3s4">
  <m id="m-ustecky48277.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W2</w.rf>
   <form>asanuje</form>
   <lemma>asanovat_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W3</w.rf>
   <form>látku</form>
   <lemma>látka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W5</w.rf>
   <form>jejíž</form>
   <lemma>jenž_^(který...[ve_vedl._větě])</lemma>
   <tag>P1ZS1FS3-------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W6</w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W8</w.rf>
   <form>odhaduje</form>
   <lemma>odhadovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W10</w.rf>
   <form>2dcl</form>
   <lemma>2dcl</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W11</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W12</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W14</w.rf>
   <form>5l</form>
   <lemma>5l</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W17</w.rf>
   <form>ochraných</form>
   <lemma>ochraný</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W18</w.rf>
   <form>protichemických</form>
   <lemma>protichemický</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W19</w.rf>
   <form>oblecích</form>
   <lemma>oblek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s4W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p3s5">
  <m id="m-ustecky48277.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s5W1</w.rf>
   <form>Evakuováno</form>
   <lemma>evakuovat_:T_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s5W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s5W3</w.rf>
   <form>165</form>
   <lemma>165</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s5W4</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s5W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p3s6">
  <m id="m-ustecky48277.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W1</w.rf>
   <form>Látka</form>
   <lemma>látka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W2</w.rf>
   <form>zlikvidována</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W4</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W6</w.rf>
   <form>přepravním</form>
   <lemma>přepravní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W7</w.rf>
   <form>kontejneru</form>
   <lemma>kontejner</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W9</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W11</w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p3s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p3s6W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p4s1">
  <m id="m-ustecky48277.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p4s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p4s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p4s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p5s1">
  <m id="m-ustecky48277.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p5s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p5s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p6s1">
  <m id="m-ustecky48277.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W1</w.rf>
   <form>3.5</form>
   <form_change>num_normalization</form_change>
   <lemma>3.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W4</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W6</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W7</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W9</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W10</w.rf>
   <form>Varnsdorf</form>
   <lemma>Varnsdorf_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W11</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W14</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W15</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W16</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W17</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W19</w.rf>
   <form>Jiřetíně</form>
   <lemma>Jiřetín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W20</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W21</w.rf>
   <form>Jedlovou</form>
   <lemma>jedlový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p6s2">
  <m id="m-ustecky48277.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W2</w.rf>
   <form>provedly</form>
   <lemma>provést</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W6</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W7</w.rf>
   <form>likvidovat</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W8</w.rf>
   <form>vyteklý</form>
   <lemma>vyteklý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W9</w.rf>
   <form>olej</form>
   <lemma>olej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W11</w.rf>
   <form>chladící</form>
   <lemma>chladící_^(*3it)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W12</w.rf>
   <form>kapalinu</form>
   <lemma>kapalina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p6s3">
  <m id="m-ustecky48277.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s3W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s3W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s3W4</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s3W5</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s3W6</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p6s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p7s1">
  <m id="m-ustecky48277.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p7s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p7s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p7s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p8s1">
  <m id="m-ustecky48277.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p8s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p8s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p9s1">
  <m id="m-ustecky48277.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s1W1</w.rf>
   <form>3.5</form>
   <form_change>num_normalization</form_change>
   <lemma>3.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p9s2">
  <m id="m-ustecky48277.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W4</w.rf>
   <form>04</form>
   <lemma>04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W7</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W9</w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W10</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W11</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W12</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W13</w.rf>
   <form>Petrovice</form>
   <lemma>Petrovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W14</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W15</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W16</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W17</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W18</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W19</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W20</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W22</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W23</w.rf>
   <form>Libouchec</form>
   <lemma>Libouchec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W26</w.rf>
   <form>Žďárek</form>
   <lemma>Žďárek_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p9s3">
  <m id="m-ustecky48277.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W1</w.rf>
   <form>Řidička</form>
   <lemma>řidička_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W2</w.rf>
   <form>odvezena</form>
   <lemma>odvézt</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W4</w.rf>
   <form>poraněním</form>
   <lemma>poranění_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W5</w.rf>
   <form>hlavy</form>
   <lemma>hlava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W6</w.rf>
   <form>zdravotnickou</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W7</w.rf>
   <form>záchrannou</form>
   <lemma>záchranný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W8</w.rf>
   <form>službou</form>
   <lemma>služba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W10</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p9s4">
  <m id="m-ustecky48277.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W2</w.rf>
   <form>provedla</form>
   <lemma>provést</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W6</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W7</w.rf>
   <form>vyteklé</form>
   <lemma>vyteklý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W8</w.rf>
   <form>provozní</form>
   <lemma>provozní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W9</w.rf>
   <form>kapaliny</form>
   <lemma>kapalina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p9s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p9s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p10s1">
  <m id="m-ustecky48277.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p10s1W1</w.rf>
   <form>Vyteklý</form>
   <lemma>vyteklý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p10s1W2</w.rf>
   <form>olej</form>
   <lemma>olej</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p11s1">
  <m id="m-ustecky48277.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s1W1</w.rf>
   <form>3.5</form>
   <form_change>num_normalization</form_change>
   <lemma>3.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p11s2">
  <m id="m-ustecky48277.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W2</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W4</w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W7</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W9</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W10</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W11</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W12</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W13</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W14</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W15</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W16</w.rf>
   <form>zlikvidovala</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W17</w.rf>
   <form>olej</form>
   <lemma>olej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W18</w.rf>
   <form>vyteklý</form>
   <lemma>vyteklý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W19</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W20</w.rf>
   <form>zaparkovaného</form>
   <lemma>zaparkovaný_^(*2t)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W21</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W23</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W24</w.rf>
   <form>mělo</form>
   <lemma>mít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W25</w.rf>
   <form>proraženou</form>
   <lemma>proražený_^(*4zit)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W26</w.rf>
   <form>olejovou</form>
   <lemma>olejový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W27</w.rf>
   <form>nádrž</form>
   <lemma>nádrž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W29</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W30</w.rf>
   <form>Glenově</form>
   <lemma>Glenův_;Y_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W31</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W32</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W33</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W34</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W35</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W36</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W37</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W38</w.rf>
   <form>Severní</form>
   <lemma>severní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W39</w.rf>
   <form>Terase</form>
   <lemma>terasa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p11s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p11s2W40</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p12s1">
  <m id="m-ustecky48277.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p12s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p12s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p12s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p13s1">
  <m id="m-ustecky48277.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p13s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p14s1">
  <m id="m-ustecky48277.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W1</w.rf>
   <form>2.5</form>
   <form_change>num_normalization</form_change>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W4</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W6</w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W7</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W9</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W10</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W11</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W12</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W13</w.rf>
   <form>pneumatiky</form>
   <lemma>pneumatika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W15</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W16</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W18</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p14s2">
  <m id="m-ustecky48277.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s2W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s2W5</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s2W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s2W7</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p14s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p15s1">
  <m id="m-ustecky48277.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p15s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p15s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p15s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p15s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p16s1">
  <m id="m-ustecky48277.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p16s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p17s1">
  <m id="m-ustecky48277.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W1</w.rf>
   <form>2.5</form>
   <form_change>num_normalization</form_change>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W4</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W6</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W7</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W9</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W10</w.rf>
   <form>Varnsdorf</form>
   <lemma>Varnsdorf_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W11</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W12</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W13</w.rf>
   <form>lesní</form>
   <lemma>lesní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W14</w.rf>
   <form>hrabanky</form>
   <lemma>hrabanka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W16</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W17</w.rf>
   <form>5x3m</form>
   <lemma>5x3m</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W19</w.rf>
   <form>Mladoboleslavské</form>
   <lemma>mladoboleslavský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W20</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W21</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W22</w.rf>
   <form>Varnsdorfu</form>
   <lemma>Varnsdorf_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p17s2">
  <m id="m-ustecky48277.txt-001-p17s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s2W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s2W5</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s2W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s2W7</w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p17s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p17s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p18s1">
  <m id="m-ustecky48277.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p18s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p19s1">
  <m id="m-ustecky48277.txt-001-p19s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s1W1</w.rf>
   <form>2.5</form>
   <form_change>num_normalization</form_change>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p19s2">
  <m id="m-ustecky48277.txt-001-p19s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W2</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W4</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W8</w.rf>
   <form>Šluknov</form>
   <lemma>Šluknov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W10</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W11</w.rf>
   <form>Velký</form>
   <lemma>velký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W12</w.rf>
   <form>Šenov</form>
   <lemma>Šenov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W14</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W15</w.rf>
   <form>Mikulášovice</form>
   <lemma>Mikulášovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W16</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W17</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W18</w.rf>
   <form>lesní</form>
   <lemma>lesní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W19</w.rf>
   <form>hrabanky</form>
   <lemma>hrabanka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W21</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W22</w.rf>
   <form>60m2</form>
   <lemma>60m2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W23</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W24</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W25</w.rf>
   <form>Mikulášovice</form>
   <lemma>Mikulášovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p19s3">
  <m id="m-ustecky48277.txt-001-p19s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s3W5</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s3W7</w.rf>
   <form>42</form>
   <lemma>42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p19s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p19s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p20s1">
  <m id="m-ustecky48277.txt-001-p20s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p20s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p20s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p20s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p20s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p20s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p21s1">
  <m id="m-ustecky48277.txt-001-p21s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p21s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p22s1">
  <m id="m-ustecky48277.txt-001-p22s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s1W1</w.rf>
   <form>2.5</form>
   <form_change>num_normalization</form_change>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p22s2">
  <m id="m-ustecky48277.txt-001-p22s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W2</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W4</w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W8</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W9</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W11</w.rf>
   <form>lesní</form>
   <lemma>lesní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W12</w.rf>
   <form>hrabanky</form>
   <lemma>hrabanka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W13</w.rf>
   <form>10x10m</form>
   <lemma>10x10m</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W15</w.rf>
   <form>Svahové</form>
   <lemma>svahový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W16</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W18</w.rf>
   <form>Chomutově</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48277.txt-001-p22s3">
  <m id="m-ustecky48277.txt-001-p22s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s3W5</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s3W7</w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48277.txt-001-p22s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48277.txt-001-p22s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
