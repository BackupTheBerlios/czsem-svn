<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky49402.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky49402.txt-001-p1s1">
  <m id="m-ustecky49402.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p1s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p2s1">
  <m id="m-ustecky49402.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p2s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p2s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p3s1">
  <m id="m-ustecky49402.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s1W1</w.rf>
   <form>14.5</form>
   <form_change>num_normalization</form_change>
   <lemma>14.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p3s2">
  <m id="m-ustecky49402.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W1</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W3</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W7</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W8</w.rf>
   <form>Kamenice</form>
   <lemma>Kamenice_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W12</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W13</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W16</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W17</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W18</w.rf>
   <form>Markvartic</form>
   <lemma>Markvartic_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W19</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W21</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W23</w.rf>
   <form>Markvartic</form>
   <lemma>Markvartic_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W25</w.rf>
   <form>Českou</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W26</w.rf>
   <form>Kamenici</form>
   <lemma>Kamenice_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W27</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p3s3">
  <m id="m-ustecky49402.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W2</w.rf>
   <form>autě</form>
   <lemma>auto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W3</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W4</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W5</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W6</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W7</w.rf>
   <form>zahynul</form>
   <lemma>zahynout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W9</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W10</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W11</w.rf>
   <form>těžce</form>
   <lemma>těžce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W12</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W14</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W15</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W16</w.rf>
   <form>předali</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W17</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W18</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W19</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W22</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W23</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W24</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W25</w.rf>
   <form>lehce</form>
   <lemma>lehce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W26</w.rf>
   <form>zraněni</form>
   <lemma>zranit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W28</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W29</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W30</w.rf>
   <form>autě</form>
   <lemma>auto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W31</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W32</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W33</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W35</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W36</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W37</w.rf>
   <form>provedla</form>
   <lemma>provést</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W38</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p3s3W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p3s3W39</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p4s1">
  <m id="m-ustecky49402.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p4s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p4s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p4s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p5s1">
  <m id="m-ustecky49402.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p5s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p5s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p6s1">
  <m id="m-ustecky49402.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s1W1</w.rf>
   <form>14.5</form>
   <form_change>num_normalization</form_change>
   <lemma>14.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p6s2">
  <m id="m-ustecky49402.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W1</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W3</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W7</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W8</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W9</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W10</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W11</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W12</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W13</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W15</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W17</w.rf>
   <form>Teplic</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W18</w.rf>
   <form>směr</form>
   <lemma>směr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W19</w.rf>
   <form>Všechlapy</form>
   <lemma>Všechlapy_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p6s3">
  <m id="m-ustecky49402.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s3W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s3W2</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s3W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s3W4</w.rf>
   <form>vyproštěn</form>
   <lemma>vyprostit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s3W5</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s3W6</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p6s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p7s1">
  <m id="m-ustecky49402.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p7s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p8s1">
  <m id="m-ustecky49402.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s1W1</w.rf>
   <form>13.5</form>
   <form_change>num_normalization</form_change>
   <lemma>13.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p8s2">
  <m id="m-ustecky49402.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W1</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W3</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W7</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W8</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W9</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W10</w.rf>
   <form>suché</form>
   <lemma>suchý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W11</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W13</w.rf>
   <form>odpadků</form>
   <lemma>odpadek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W15</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W16</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W17</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W19</w.rf>
   <form>Teplicích</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W22</w.rf>
   <form>Proseticích</form>
   <lemma>Prosetice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p8s3">
  <m id="m-ustecky49402.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s3W5</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s3W7</w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p8s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p9s1">
  <m id="m-ustecky49402.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p9s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p9s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p9s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p10s1">
  <m id="m-ustecky49402.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p10s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p11s1">
  <m id="m-ustecky49402.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s1W1</w.rf>
   <form>13.5</form>
   <form_change>num_normalization</form_change>
   <lemma>13.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p11s2">
  <m id="m-ustecky49402.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W1</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W3</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W7</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W8</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W9</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W10</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W11</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W13</w.rf>
   <form>Tržní</form>
   <lemma>tržní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W14</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W16</w.rf>
   <form>Horním</form>
   <lemma>Horní_;G</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W17</w.rf>
   <form>Litvínově</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p11s3">
  <m id="m-ustecky49402.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W3</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W5</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W7</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W9</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W11</w.rf>
   <form>zasáhl</form>
   <lemma>zasáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W12</w.rf>
   <form>zadní</form>
   <lemma>zadní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W13</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p11s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p11s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p12s1">
  <m id="m-ustecky49402.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p12s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p12s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p12s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p13s1">
  <m id="m-ustecky49402.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p13s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p14s1">
  <m id="m-ustecky49402.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s1W1</w.rf>
   <form>13.5</form>
   <form_change>num_normalization</form_change>
   <lemma>13.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p14s2">
  <m id="m-ustecky49402.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W1</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W3</w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W7</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W9</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W10</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W11</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W12</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W13</w.rf>
   <form>hromady</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W14</w.rf>
   <form>odpadků</form>
   <lemma>odpadek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W16</w.rf>
   <form>dvoře</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W17</w.rf>
   <form>obytných</form>
   <lemma>obytný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W18</w.rf>
   <form>domů</form>
   <lemma>dům</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W20</w.rf>
   <form>Dělnické</form>
   <lemma>dělnický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W21</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W23</w.rf>
   <form>Podbořanech</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p14s3">
  <m id="m-ustecky49402.txt-001-p14s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s3W5</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s3W7</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p14s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p14s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p15s1">
  <m id="m-ustecky49402.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p15s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p16s1">
  <m id="m-ustecky49402.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s1W1</w.rf>
   <form>13.5</form>
   <form_change>num_normalization</form_change>
   <lemma>13.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p16s2">
  <m id="m-ustecky49402.txt-001-p16s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W1</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W3</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W7</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W9</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W10</w.rf>
   <form>Kryry</form>
   <lemma>Kryry_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W11</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W12</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W13</w.rf>
   <form>seníku</form>
   <lemma>seník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W15</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W16</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W17</w.rf>
   <form>majitel</form>
   <lemma>majitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W18</w.rf>
   <form>uskladněn</form>
   <lemma>uskladnit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W19</w.rf>
   <form>stavební</form>
   <lemma>stavební</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W20</w.rf>
   <form>materiál</form>
   <lemma>materiál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W23</w.rf>
   <form>Hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W24</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W26</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W27</w.rf>
   <form>Kryry</form>
   <lemma>Kryry_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p16s3">
  <m id="m-ustecky49402.txt-001-p16s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s3W5</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s3W7</w.rf>
   <form>42</form>
   <lemma>42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p16s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p16s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p17s1">
  <m id="m-ustecky49402.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p17s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p17s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p17s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p17s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p18s1">
  <m id="m-ustecky49402.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p18s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p19s1">
  <m id="m-ustecky49402.txt-001-p19s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s1W1</w.rf>
   <form>13.5</form>
   <form_change>num_normalization</form_change>
   <lemma>13.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p19s2">
  <m id="m-ustecky49402.txt-001-p19s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W1</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W3</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W10</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W11</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W12</w.rf>
   <form>listí</form>
   <lemma>listí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W14</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W16</w.rf>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W17</w.rf>
   <form>deky</form>
   <lemma>deka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W19</w.rf>
   <form>Masrykově</form>
   <lemma>Masrykův</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W20</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W22</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W23</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W24</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W26</w.rf>
   <form>Bukově</form>
   <lemma>bukově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49402.txt-001-p19s3">
  <m id="m-ustecky49402.txt-001-p19s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s3W5</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s3W7</w.rf>
   <form>53</form>
   <lemma>53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49402.txt-001-p19s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49402.txt-001-p19s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
