<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky48968.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky48968.txt-001-p1s1">
  <m id="m-ustecky48968.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p1s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p2s1">
  <m id="m-ustecky48968.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p2s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p2s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p3s1">
  <m id="m-ustecky48968.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s1W1</w.rf>
   <form>9.5</form>
   <form_change>num_normalization</form_change>
   <lemma>9.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p3s2">
  <m id="m-ustecky48968.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W1</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W3</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W7</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W10</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W11</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W13</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W14</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W15</w.rf>
   <form>Bílina</form>
   <lemma>Bílina_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W16</w.rf>
   <form>zasahovaly</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W17</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W18</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W19</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W20</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W21</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W22</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W23</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W24</w.rf>
   <form>Želenice</form>
   <lemma>Želenice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p3s3">
  <m id="m-ustecky48968.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W3</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W4</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W5</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP4-----A---1</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W6</w.rf>
   <form>zraněni</form>
   <lemma>zranit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W8</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W9</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W10</w.rf>
   <form>převrácené</form>
   <lemma>převrácený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W12</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p3s4">
  <m id="m-ustecky48968.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W2</w.rf>
   <form>provedla</form>
   <lemma>provést</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W6</w.rf>
   <form>asanaci</form>
   <lemma>asanace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W7</w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W8</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p3s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p4s1">
  <m id="m-ustecky48968.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p4s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p5s1">
  <m id="m-ustecky48968.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s1W1</w.rf>
   <form>9.5</form>
   <form_change>num_normalization</form_change>
   <lemma>9.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p5s2">
  <m id="m-ustecky48968.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W1</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W3</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W7</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W8</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W9</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W10</w.rf>
   <form>vraku</form>
   <lemma>vrak</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W11</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W12</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W13</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W14</w.rf>
   <form>drážní</form>
   <lemma>drážní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W15</w.rf>
   <form>měnírny</form>
   <lemma>měnírna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W17</w.rf>
   <form>bývalého</form>
   <lemma>bývalý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W18</w.rf>
   <form>statku</form>
   <lemma>statek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W20</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W22</w.rf>
   <form>Rudolicích</form>
   <lemma>Rudolice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p5s3">
  <m id="m-ustecky48968.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s3W5</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s3W7</w.rf>
   <form>53</form>
   <lemma>53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p5s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p6s1">
  <m id="m-ustecky48968.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p6s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p6s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p6s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p7s1">
  <m id="m-ustecky48968.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p7s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p8s1">
  <m id="m-ustecky48968.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s1W1</w.rf>
   <form>9.5</form>
   <form_change>num_normalization</form_change>
   <lemma>9.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p8s2">
  <m id="m-ustecky48968.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W1</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W3</w.rf>
   <form>38</form>
   <lemma>38</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W10</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W11</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W12</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W14</w.rf>
   <form>Burianovy</form>
   <lemma>Burianův_;S_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W15</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W17</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W18</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W19</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W22</w.rf>
   <form>Severní</form>
   <lemma>severní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W23</w.rf>
   <form>Terase</form>
   <lemma>terasa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p8s3">
  <m id="m-ustecky48968.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s3W1</w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s3W2</w.rf>
   <form>hlášen</form>
   <lemma>hlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s3W3</w.rf>
   <form>kouř</form>
   <lemma>kouř</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s3W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s3W5</w.rf>
   <form>okna</form>
   <lemma>okno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p8s4">
  <m id="m-ustecky48968.txt-001-p8s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s4W1</w.rf>
   <form>Hořela</form>
   <lemma>hořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s4W2</w.rf>
   <form>elektrická</form>
   <lemma>elektrický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s4W3</w.rf>
   <form>zásuvka</form>
   <lemma>zásuvka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s4W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p8s5">
  <m id="m-ustecky48968.txt-001-p8s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s5W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s5W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s5W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s5W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s5W5</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s5W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s5W7</w.rf>
   <form>57</form>
   <lemma>57</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p8s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p8s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p9s1">
  <m id="m-ustecky48968.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p9s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p9s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p9s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p10s1">
  <m id="m-ustecky48968.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p10s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p11s1">
  <m id="m-ustecky48968.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s1W1</w.rf>
   <form>9.5</form>
   <form_change>num_normalization</form_change>
   <lemma>9.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p11s2">
  <m id="m-ustecky48968.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W1</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W3</w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W7</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W9</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W10</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W13</w.rf>
   <form>Staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W14</w.rf>
   <form>Město</form>
   <lemma>město</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W16</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W17</w.rf>
   <form>Boletice</form>
   <lemma>Boletice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W18</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W19</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W21</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W22</w.rf>
   <form>Horní</form>
   <lemma>Horní_;G</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W23</w.rf>
   <form>Žleb</form>
   <lemma>žleb</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W24</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W25</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W26</w.rf>
   <form>tělocvičny</form>
   <lemma>tělocvična</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W27</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W28</w.rf>
   <form>ZŠ</form>
   <lemma>ZŠ_:B_^(základní_škola)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W29</w.rf>
   <form>Vrchlického</form>
   <lemma>Vrchlický_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W30</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W31</w.rf>
   <form>Vrchlického</form>
   <lemma>Vrchlický_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W32</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W33</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W34</w.rf>
   <form>Děčíně</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s2W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p11s3">
  <m id="m-ustecky48968.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s3W5</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s3W7</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p11s4">
  <m id="m-ustecky48968.txt-001-p11s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W3</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W4</w.rf>
   <form>odhadnuta</form>
   <lemma>odhadnout_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W6</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W7</w.rf>
   <form>milióny</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W8</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48968.txt-001-p11s5">
  <m id="m-ustecky48968.txt-001-p11s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s5W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s5W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s5W3</w.rf>
   <form>manipulace</form>
   <lemma>manipulace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s5W4</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s5W5</w.rf>
   <form>otevřeným</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s5W6</w.rf>
   <form>ohněm</form>
   <lemma>oheň</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky48968.txt-001-p11s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48968.txt-001-p11s5W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
