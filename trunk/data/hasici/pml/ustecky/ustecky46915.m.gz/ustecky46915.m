<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky46915.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky46915.txt-001-p1s1">
  <m id="m-ustecky46915.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p1s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46915.txt-001-p2s1">
  <m id="m-ustecky46915.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p2s1W1</w.rf>
   <form>Výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p2s1W2</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46915.txt-001-p3s1">
  <m id="m-ustecky46915.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W1</w.rf>
   <form>Výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W2</w.rf>
   <form>příslušníků</form>
   <lemma>příslušník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W3</w.rf>
   <form>směny</form>
   <lemma>směna-1_^(výměna_za_něco)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W4</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W6</w.rf>
   <form>Ústeckého</form>
   <lemma>ústecký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W7</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W8</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W9</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W10</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46915.txt-001-p3s2">
  <m id="m-ustecky46915.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W1</w.rf>
   <form>Výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W2</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W3</w.rf>
   <form>dýchací</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W4</w.rf>
   <form>technikou</form>
   <lemma>technika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W6</w.rf>
   <form>protiplynovém</form>
   <lemma>protiplynový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W7</w.rf>
   <form>polygonu</form>
   <lemma>polygon</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W9</w.rf>
   <form>konal</form>
   <lemma>konat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W10</w.rf>
   <form>19.4</form>
   <form_change>num_normalization</form_change>
   <lemma>19.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46915.txt-001-p3s3">
  <m id="m-ustecky46915.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W3</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W4</w.rf>
   <form>stanici</form>
   <lemma>stanice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W5</w.rf>
   <form>Teplice</form>
   <lemma>teplice-1_^(termální_vody)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W7</w.rf>
   <form>Ústeckého</form>
   <lemma>ústecký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W8</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W9</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W10</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W11</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46915.txt-001-p3s4">
  <m id="m-ustecky46915.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s4W1</w.rf>
   <form>FOTO</form>
   <lemma>foto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s4W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s4W3</w.rf>
   <form>Michal</form>
   <lemma>Michal_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s4W4</w.rf>
   <form>Hrdlička</form>
   <lemma>Hrdlička-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s4W5</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s4W6</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s4W7</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46915.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46915.txt-001-p3s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
