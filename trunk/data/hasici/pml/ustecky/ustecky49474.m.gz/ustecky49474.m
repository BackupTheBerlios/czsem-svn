<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky49474.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky49474.txt-001-p1s1">
  <m id="m-ustecky49474.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W2</w.rf>
   <form>proběhne</form>
   <lemma>proběhnout_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W3</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W4</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W6</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W8</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W9</w.rf>
   <form>známé</form>
   <lemma>známá-1_^(potkat_známého_[člověka])_(*3ý-1)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W10</w.rf>
   <form>Erbenovy</form>
   <lemma>Erbenův_;S_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W11</w.rf>
   <form>Vyhlídky</form>
   <lemma>vyhlídka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49474.txt-001-p1s2">
  <m id="m-ustecky49474.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W2</w.rf>
   <form>akci</form>
   <lemma>akce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W4</w.rf>
   <form>krom</form>
   <lemma>kromě</lemma>
   <tag>RR--2---------1</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W6</w.rf>
   <form>podílejí</form>
   <lemma>podílet_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W7</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W8</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W11</w.rf>
   <form>Městská</form>
   <lemma>městský</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W12</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W14</w.rf>
   <form>Svaz</form>
   <lemma>svaz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W15</w.rf>
   <form>CO</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W16</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W18</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W19</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W20</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W22</w.rf>
   <form>Červený</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W23</w.rf>
   <form>kříž</form>
   <lemma>kříž</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49474.txt-001-p1s3">
  <m id="m-ustecky49474.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W2</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W3</w.rf>
   <form>soutěžit</form>
   <lemma>soutěžit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W5</w.rf>
   <form>znalostech</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W7</w.rf>
   <form>dovednostech</form>
   <lemma>dovednost_^(*3ý)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W9</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W10</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W11</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W12</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W14</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W15</w.rf>
   <form>disciplínách</form>
   <lemma>disciplína</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W17</w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W18</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W19</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W20</w.rf>
   <form>Ústeckého</form>
   <lemma>ústecký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W21</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49474.txt-001-p1s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49474.txt-001-p1s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
