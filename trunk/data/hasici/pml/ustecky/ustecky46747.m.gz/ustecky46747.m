<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky46747.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky46747.txt-001-p1s1">
  <m id="m-ustecky46747.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p1s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p2s1">
  <m id="m-ustecky46747.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p2s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p3s1">
  <m id="m-ustecky46747.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s1W1</w.rf>
   <form>19.4</form>
   <form_change>num_normalization</form_change>
   <lemma>19.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p3s2">
  <m id="m-ustecky46747.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W4</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W8</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W9</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W11</w.rf>
   <form>chatky</form>
   <lemma>chatka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W13</w.rf>
   <form>Krásnostudenecké</form>
   <lemma>Krásnostudenecký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W14</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W16</w.rf>
   <form>Děčíně</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W17</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W19</w.rf>
   <form>Letné</form>
   <lemma>Letná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p3s3">
  <m id="m-ustecky46747.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W2</w.rf>
   <form>vynesla</form>
   <lemma>vynést</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W3</w.rf>
   <form>propanbutanovou</form>
   <lemma>propanbutanový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W4</w.rf>
   <form>lahev</form>
   <lemma>lahev</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W6</w.rf>
   <form>ochlazovala</form>
   <lemma>ochlazovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W7</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W9</w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W10</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p3s4">
  <m id="m-ustecky46747.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s4W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s4W5</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s4W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s4W7</w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p3s5">
  <m id="m-ustecky46747.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s5W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s5W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s5W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s5W4</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s5W5</w.rf>
   <form>vada</form>
   <lemma>vada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s5W6</w.rf>
   <form>komínu</form>
   <lemma>komín</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s5W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p3s6">
  <m id="m-ustecky46747.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s6W1</w.rf>
   <form>Předběžný</form>
   <lemma>předběžný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s6W2</w.rf>
   <form>odhad</form>
   <lemma>odhad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s6W3</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s6W4</w.rf>
   <form>200</form>
   <lemma>200</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s6W5</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s6W6</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p3s6W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p4s1">
  <m id="m-ustecky46747.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p4s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p4s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p4s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p5s1">
  <m id="m-ustecky46747.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p5s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p6s1">
  <m id="m-ustecky46747.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s1W1</w.rf>
   <form>19.4</form>
   <form_change>num_normalization</form_change>
   <lemma>19.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p6s2">
  <m id="m-ustecky46747.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W2</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W4</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W8</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W9</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W11</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W12</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W13</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W14</w.rf>
   <form>sportovní</form>
   <lemma>sportovní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W15</w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W17</w.rf>
   <form>Okružní</form>
   <lemma>okružní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W18</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W20</w.rf>
   <form>Litvínově</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W23</w.rf>
   <form>Meziboří</form>
   <lemma>Meziboří_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p6s3">
  <m id="m-ustecky46747.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s3W5</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s3W7</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p6s4">
  <m id="m-ustecky46747.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s4W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s4W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s4W3</w.rf>
   <form>příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s4W5</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p6s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p7s1">
  <m id="m-ustecky46747.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p7s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p8s1">
  <m id="m-ustecky46747.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s1W1</w.rf>
   <form>18.4</form>
   <form_change>num_normalization</form_change>
   <lemma>18.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p8s2">
  <m id="m-ustecky46747.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W2</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W4</w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W8</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W10</w.rf>
   <form>HZSP</form>
   <lemma>Hzsp</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W11</w.rf>
   <form>MU</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W12</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p8s3">
  <m id="m-ustecky46747.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W1</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W2</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W3</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W4</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W6</w.rf>
   <form>kruhového</form>
   <lemma>kruhový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W7</w.rf>
   <form>objezdu</form>
   <lemma>objezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W8</w.rf>
   <form>směr</form>
   <lemma>směr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W9</w.rf>
   <form>Čepirohy</form>
   <lemma>Čepirohy_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W10</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W11</w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W12</w.rf>
   <form>stranách</form>
   <lemma>strana-1_^(v_prostoru)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W13</w.rf>
   <form>čtyproudovky</form>
   <lemma>čtyproudovka</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p8s4">
  <m id="m-ustecky46747.txt-001-p8s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s4W1</w.rf>
   <form>Pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s4W2</w.rf>
   <form>ohnisek</form>
   <lemma>ohnisko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s4W3</w.rf>
   <form>5x5m</form>
   <lemma>5x5m</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s4W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p8s5">
  <m id="m-ustecky46747.txt-001-p8s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W3</w.rf>
   <form>stromků</form>
   <lemma>stromek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W5</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W7</w.rf>
   <form>čepirožské</form>
   <lemma>čepirožský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W8</w.rf>
   <form>výsypce</form>
   <lemma>výsypka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W11</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W12</w.rf>
   <form>ohniska</form>
   <lemma>ohnisko</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s5W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p8s6">
  <m id="m-ustecky46747.txt-001-p8s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s6W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s6W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s6W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s6W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s6W5</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s6W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p8s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p8s6W7</w.rf>
   <form>47</form>
   <lemma>47</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p9s1">
  <m id="m-ustecky46747.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p9s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p10s1">
  <m id="m-ustecky46747.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s1W1</w.rf>
   <form>18.4</form>
   <form_change>num_normalization</form_change>
   <lemma>18.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p10s2">
  <m id="m-ustecky46747.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W2</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W4</w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W8</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W10</w.rf>
   <form>HZSP</form>
   <lemma>Hzsp</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W11</w.rf>
   <form>MU</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W12</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p10s3">
  <m id="m-ustecky46747.txt-001-p10s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W1</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W2</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W3</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W4</w.rf>
   <form>garáže</form>
   <lemma>garáž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W5</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W6</w.rf>
   <form>starším</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS7----2A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W7</w.rf>
   <form>autem</form>
   <lemma>aut</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W9</w.rf>
   <form>Vartburk</form>
   <lemma>Vartburk</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W12</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W13</w.rf>
   <form>Železničářů</form>
   <lemma>železničář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W14</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W15</w.rf>
   <form>Starém</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W16</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p10s4">
  <m id="m-ustecky46747.txt-001-p10s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s4W1</w.rf>
   <form>Vartburk</form>
   <lemma>Vartburk</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s4W3</w.rf>
   <form>požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s4W4</w.rf>
   <form>zasažen</form>
   <lemma>zasáhnout</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s4W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p10s5">
  <m id="m-ustecky46747.txt-001-p10s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s5W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s5W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s5W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s5W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s5W5</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s5W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s5W7</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p10s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p10s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p11s1">
  <m id="m-ustecky46747.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p11s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p11s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p11s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p12s1">
  <m id="m-ustecky46747.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p12s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p13s1">
  <m id="m-ustecky46747.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s1W1</w.rf>
   <form>18.4</form>
   <form_change>num_normalization</form_change>
   <lemma>18.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p13s2">
  <m id="m-ustecky46747.txt-001-p13s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W2</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W4</w.rf>
   <form>08</form>
   <lemma>08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W8</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W9</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W11</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W12</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W14</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W15</w.rf>
   <form>Vikové</form>
   <lemma>Viková_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W16</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W17</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W18</w.rf>
   <form>Kunětické</form>
   <lemma>kunětický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W20</w.rf>
   <form>Chomutově</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p13s3">
  <m id="m-ustecky46747.txt-001-p13s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s3W5</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s3W7</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p13s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p13s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p14s1">
  <m id="m-ustecky46747.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p14s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p14s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p14s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p15s1">
  <m id="m-ustecky46747.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p15s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p15s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p16s1">
  <m id="m-ustecky46747.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s1W1</w.rf>
   <form>18.4</form>
   <form_change>num_normalization</form_change>
   <lemma>18.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p16s2">
  <m id="m-ustecky46747.txt-001-p16s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W2</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W4</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W7</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W9</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W10</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W11</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W12</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W13</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W14</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W15</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W16</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W17</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W18</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W19</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W20</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W21</w.rf>
   <form>dodávek</form>
   <lemma>dodávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W22</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W23</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W24</w.rf>
   <form>Olšinky</form>
   <lemma>Olšinky_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W26</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W27</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W28</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s2W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p16s3">
  <m id="m-ustecky46747.txt-001-p16s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W1</w.rf>
   <form>Řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W2</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS2----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W3</w.rf>
   <form>dodávky</form>
   <lemma>dodávka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W5</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W6</w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W8</w.rf>
   <form>druhý</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W9</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W10</w.rf>
   <form>vyproštěn</form>
   <lemma>vyprostit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W11</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W12</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W13</w.rf>
   <form>příjezdem</form>
   <lemma>příjezd</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W14</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky46747.txt-001-p16s4">
  <m id="m-ustecky46747.txt-001-p16s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W2</w.rf>
   <form>zajistila</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W3</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W4</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W6</w.rf>
   <form>vyprostila</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W7</w.rf>
   <form>mrtvé</form>
   <lemma>mrtvý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W8</w.rf>
   <form>tělo</form>
   <lemma>tělo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W10</w.rf>
   <form>asanovala</form>
   <lemma>asanovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W11</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky46747.txt-001-p16s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky46747.txt-001-p16s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
