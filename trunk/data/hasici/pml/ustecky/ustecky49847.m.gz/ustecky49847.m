<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky49847.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky49847.txt-001-p1s1">
  <m id="m-ustecky49847.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p1s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p1s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p1s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p2s1">
  <m id="m-ustecky49847.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p2s1W1</w.rf>
   <form>Rtuť</form>
   <lemma>rtuť</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p3s1">
  <m id="m-ustecky49847.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s1W1</w.rf>
   <form>17.5</form>
   <form_change>num_normalization</form_change>
   <lemma>17.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p3s2">
  <m id="m-ustecky49847.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W1</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W3</w.rf>
   <form>54</form>
   <lemma>54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W10</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W12</w.rf>
   <form>třídírny</form>
   <lemma>třídírna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W13</w.rf>
   <form>balíků</form>
   <lemma>balík-2_^(člověk)</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W14</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W15</w.rf>
   <form>pošty</form>
   <lemma>pošta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W17</w.rf>
   <form>Jateční</form>
   <lemma>jateční</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W18</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W20</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W21</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W22</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W24</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W25</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W26</w.rf>
   <form>balíku</form>
   <lemma>balík-1_^(předmět)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W27</w.rf>
   <form>unikl</form>
   <lemma>uniknout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W28</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W29</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W30</w.rf>
   <form>dcl</form>
   <lemma>dcl</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W31</w.rf>
   <form>rtuti</form>
   <lemma>rtuť</lemma>
   <tag>NNFS2-----A---1</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s2W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p3s3">
  <m id="m-ustecky49847.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W2</w.rf>
   <form>rtuť</form>
   <lemma>rtuť</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W3</w.rf>
   <form>odebrala</form>
   <lemma>odebrat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W5</w.rf>
   <form>sběrné</form>
   <lemma>sběrný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W6</w.rf>
   <form>lahve</form>
   <lemma>lahev</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W8</w.rf>
   <form>odvezla</form>
   <lemma>odvézt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p3s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p4s1">
  <m id="m-ustecky49847.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p4s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p4s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p4s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p5s1">
  <m id="m-ustecky49847.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p5s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p6s1">
  <m id="m-ustecky49847.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s1W1</w.rf>
   <form>17.5</form>
   <form_change>num_normalization</form_change>
   <lemma>17.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p6s2">
  <m id="m-ustecky49847.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W1</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W3</w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W6</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W7</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W8</w.rf>
   <form>55</form>
   <lemma>55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W9</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W10</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W11</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W12</w.rf>
   <form>Šluknov</form>
   <lemma>Šluknov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W13</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W15</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W16</w.rf>
   <form>trafostanice</form>
   <lemma>trafostanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W18</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W19</w.rf>
   <form>Šluknov</form>
   <lemma>Šluknov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W21</w.rf>
   <form>Rožany</form>
   <lemma>Rožany_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p6s3">
  <m id="m-ustecky49847.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W2</w.rf>
   <form>zjistila</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W4</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W5</w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W7</w.rf>
   <form>žhnoucí</form>
   <lemma>žhnoucí_^(*2t)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W8</w.rf>
   <form>kabel</form>
   <lemma>kabel</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W9</w.rf>
   <form>elektrického</form>
   <lemma>elektrický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W10</w.rf>
   <form>přívodu</form>
   <lemma>přívod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p6s4">
  <m id="m-ustecky49847.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W1</w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W2</w.rf>
   <form>povolán</form>
   <lemma>povolat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W3</w.rf>
   <form>pracovník</form>
   <lemma>pracovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W4</w.rf>
   <form>Energetiky</form>
   <lemma>energetika_^(věda)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W6</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W7</w.rf>
   <form>odstranil</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W8</w.rf>
   <form>závadu</form>
   <lemma>závada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p6s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p6s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p7s1">
  <m id="m-ustecky49847.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p7s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p7s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p7s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p8s1">
  <m id="m-ustecky49847.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p8s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p8s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p9s1">
  <m id="m-ustecky49847.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s1W1</w.rf>
   <form>16.5</form>
   <form_change>num_normalization</form_change>
   <lemma>16.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p9s2">
  <m id="m-ustecky49847.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W1</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W3</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W4</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W7</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W9</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W10</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W11</w.rf>
   <form>zasahovaly</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W14</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W15</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W16</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W17</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W19</w.rf>
   <form>Podkrušnohorské</form>
   <lemma>podkrušnohorský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W20</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W22</w.rf>
   <form>Litvínově</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p9s3">
  <m id="m-ustecky49847.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W1</w.rf>
   <form>Jedno</form>
   <lemma>jeden`1</lemma>
   <tag>ClNS1----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W2</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W5</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W6</w.rf>
   <form>převrátilo</form>
   <lemma>převrátit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W8</w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W10</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W11</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W12</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p9s4">
  <m id="m-ustecky49847.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s4W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s4W2</w.rf>
   <form>provedly</form>
   <lemma>provést</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s4W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s4W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s4W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s4W6</w.rf>
   <form>asanovaly</form>
   <lemma>asanovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s4W7</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p9s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p9s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p10s1">
  <m id="m-ustecky49847.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p10s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p11s1">
  <m id="m-ustecky49847.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s1W1</w.rf>
   <form>16.5</form>
   <form_change>num_normalization</form_change>
   <lemma>16.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p11s2">
  <m id="m-ustecky49847.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W1</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W3</w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W7</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W8</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W9</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W10</w.rf>
   <form>hromady</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W11</w.rf>
   <form>odpadků</form>
   <lemma>odpadek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W13</w.rf>
   <form>opuštěném</form>
   <lemma>opuštěný_^(*5stit)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W14</w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W16</w.rf>
   <form>Ukrajinské</form>
   <lemma>ukrajinský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W17</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W19</w.rf>
   <form>Litvínově</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p11s3">
  <m id="m-ustecky49847.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s3W5</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s3W7</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p11s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p12s1">
  <m id="m-ustecky49847.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p12s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p13s1">
  <m id="m-ustecky49847.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s1W1</w.rf>
   <form>16.5</form>
   <form_change>num_normalization</form_change>
   <lemma>16.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p13s2">
  <m id="m-ustecky49847.txt-001-p13s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W1</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W3</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W7</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W8</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W9</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W10</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W11</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W13</w.rf>
   <form>třídě</form>
   <lemma>třída</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W14</w.rf>
   <form>Budovatelů</form>
   <lemma>budovatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W16</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p13s3">
  <m id="m-ustecky49847.txt-001-p13s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s3W1</w.rf>
   <form>Hořela</form>
   <lemma>hořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s3W2</w.rf>
   <form>elektroinstalace</form>
   <lemma>elektroinstalace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s3W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p13s4">
  <m id="m-ustecky49847.txt-001-p13s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s4W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s4W5</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s4W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s4W7</w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p13s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p13s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p14s1">
  <m id="m-ustecky49847.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p14s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p14s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p14s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p15s1">
  <m id="m-ustecky49847.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p15s1W1</w.rf>
   <form>Otevření</form>
   <lemma>otevření_^(*3ít)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p15s1W2</w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p16s1">
  <m id="m-ustecky49847.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s1W1</w.rf>
   <form>16.5</form>
   <form_change>num_normalization</form_change>
   <lemma>16.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p16s2">
  <m id="m-ustecky49847.txt-001-p16s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W1</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W3</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W7</w.rf>
   <form>Louny</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W8</w.rf>
   <form>otevřela</form>
   <lemma>otevřít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W9</w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W11</w.rf>
   <form>Karlově</form>
   <lemma>Karlův_;Y_^(*3el)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W12</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W14</w.rf>
   <form>Lounech</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49847.txt-001-p16s3">
  <m id="m-ustecky49847.txt-001-p16s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W2</w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W4</w.rf>
   <form>nalezena</form>
   <lemma>naleznout</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W5</w.rf>
   <form>postižená</form>
   <lemma>postižený_^(*4hnout)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W6</w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W8</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W9</w.rf>
   <form>předána</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W10</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W11</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W12</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49847.txt-001-p16s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49847.txt-001-p16s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
