<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky47079.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky47079.txt-001-p1s1">
  <m id="m-ustecky47079.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p1s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p2s1">
  <m id="m-ustecky47079.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p2s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p3s1">
  <m id="m-ustecky47079.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W1</w.rf>
   <form>22.4</form>
   <form_change>num_normalization</form_change>
   <lemma>22.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W4</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W6</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W7</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W9</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W10</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W12</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W13</w.rf>
   <form>Podbožany</form>
   <lemma>Podbožany</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W14</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W15</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W16</w.rf>
   <form>lesního</form>
   <lemma>lesní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W17</w.rf>
   <form>porostu</form>
   <lemma>porost</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W19</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W20</w.rf>
   <form>20x50m</form>
   <lemma>20x50m</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W21</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W22</w.rf>
   <form>Podbořan</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p3s2">
  <m id="m-ustecky47079.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s2W3</w.rf>
   <form>zlikvidovány</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s2W5</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s2W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s2W7</w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p3s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p4s1">
  <m id="m-ustecky47079.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p4s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p4s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p5s1">
  <m id="m-ustecky47079.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W1</w.rf>
   <form>22.4</form>
   <form_change>num_normalization</form_change>
   <lemma>22.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W4</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W6</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W9</w.rf>
   <form>10-27</form>
   <lemma>10-27</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W10</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W11</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W12</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W13</w.rf>
   <form>Louny</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W14</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W15</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W16</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W17</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W18</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W19</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W20</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W22</w.rf>
   <form>Tomanově</form>
   <lemma>Tomanův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W23</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W25</w.rf>
   <form>Lounech</form>
   <lemma>Louny_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p5s2">
  <m id="m-ustecky47079.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W4</w.rf>
   <form>zraněno</form>
   <lemma>zranit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W5</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W6</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W9</w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W10</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W11</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p5s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p6s1">
  <m id="m-ustecky47079.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p6s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p6s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p6s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p7s1">
  <m id="m-ustecky47079.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p7s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p8s1">
  <m id="m-ustecky47079.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W1</w.rf>
   <form>22.4</form>
   <form_change>num_normalization</form_change>
   <lemma>22.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W4</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W6</w.rf>
   <form>46</form>
   <lemma>46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W7</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W9</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W10</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W12</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W13</w.rf>
   <form>Lom</form>
   <lemma>Lom_;G_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W14</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W15</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W16</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W18</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W19</w.rf>
   <form>40x20m</form>
   <lemma>40x20m</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W20</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W21</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W22</w.rf>
   <form>Lom</form>
   <lemma>Lom_;G_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p8s2">
  <m id="m-ustecky47079.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s2W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s2W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s2W5</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s2W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s2W7</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p8s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p9s1">
  <m id="m-ustecky47079.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p9s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p9s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p9s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p10s1">
  <m id="m-ustecky47079.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p10s1W1</w.rf>
   <form>Strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p11s1">
  <m id="m-ustecky47079.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W1</w.rf>
   <form>22.4</form>
   <form_change>num_normalization</form_change>
   <lemma>22.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W4</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W6</w.rf>
   <form>46</form>
   <lemma>46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W9</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W11</w.rf>
   <form>04</form>
   <lemma>04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W12</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W13</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W14</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W15</w.rf>
   <form>Varnsdorf</form>
   <lemma>Varnsdorf_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W16</w.rf>
   <form>odstranila</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W17</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W18</w.rf>
   <form>padlý</form>
   <lemma>padlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W20</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W22</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W23</w.rf>
   <form>Jiřetín</form>
   <lemma>Jiřetín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W24</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W25</w.rf>
   <form>Jedlovou</form>
   <lemma>jedlový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W27</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W28</w.rf>
   <form>Lesné</form>
   <lemma>Lesná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p11s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p11s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p12s1">
  <m id="m-ustecky47079.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p12s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p12s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p12s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p13s1">
  <m id="m-ustecky47079.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p13s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p14s1">
  <m id="m-ustecky47079.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s1W1</w.rf>
   <form>22.4</form>
   <form_change>num_normalization</form_change>
   <lemma>22.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p14s2">
  <m id="m-ustecky47079.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W2</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W4</w.rf>
   <form>55</form>
   <lemma>55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W8</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W9</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W12</w.rf>
   <form>lesíku</form>
   <lemma>lesík</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W14</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W15</w.rf>
   <form>20m2</form>
   <lemma>20m2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W16</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W17</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W18</w.rf>
   <form>Údlice</form>
   <lemma>Údlice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p14s3">
  <m id="m-ustecky47079.txt-001-p14s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s3W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s3W5</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p14s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p14s3W7</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p15s1">
  <m id="m-ustecky47079.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p15s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p16s1">
  <m id="m-ustecky47079.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W1</w.rf>
   <form>21.4</form>
   <form_change>num_normalization</form_change>
   <lemma>21.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W4</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W6</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W7</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W8</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W9</w.rf>
   <form>Černpvice</form>
   <lemma>Černpvice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W11</w.rf>
   <form>HZSP</form>
   <lemma>Hzsp</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W12</w.rf>
   <form>ČEZa.s</form>
   <lemma>ČEZa.</lemma>
   <tag>NNMPX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W15</w.rf>
   <form>HZSP</form>
   <lemma>HZSP</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W16</w.rf>
   <form>Severočeské</form>
   <lemma>severočeský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W17</w.rf>
   <form>doly</form>
   <lemma>důl</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W18</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W21</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W22</w.rf>
   <form>Kadaň</form>
   <lemma>Kadaň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W23</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W24</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W25</w.rf>
   <form>skládky</form>
   <lemma>skládka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W27</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W28</w.rf>
   <form>8m2</form>
   <lemma>8m2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W29</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W30</w.rf>
   <form>elektrárny</form>
   <lemma>elektrárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W31</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W32</w.rf>
   <form>Tušimicích</form>
   <lemma>Tušimice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s1W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p16s2">
  <m id="m-ustecky47079.txt-001-p16s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s2W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s2W5</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s2W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s2W7</w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p16s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p16s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p17s1">
  <m id="m-ustecky47079.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p17s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p17s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p17s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p17s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p18s1">
  <m id="m-ustecky47079.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p18s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p19s1">
  <m id="m-ustecky47079.txt-001-p19s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W1</w.rf>
   <form>22.4</form>
   <form_change>num_normalization</form_change>
   <lemma>22.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W4</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W6</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W7</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W9</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W10</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W11</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W12</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W13</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W14</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W15</w.rf>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W16</w.rf>
   <form>chatky</form>
   <lemma>chatka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W18</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W19</w.rf>
   <form>Dvojdomí</form>
   <lemma>dvojdomý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W21</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W22</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W23</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W26</w.rf>
   <form>Krásném</form>
   <lemma>krásný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W27</w.rf>
   <form>Březně</form>
   <lemma>Březno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47079.txt-001-p19s2">
  <m id="m-ustecky47079.txt-001-p19s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s2W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s2W5</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s2W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s2W7</w.rf>
   <form>57</form>
   <lemma>57</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47079.txt-001-p19s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47079.txt-001-p19s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
