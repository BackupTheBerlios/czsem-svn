<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky47692.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky47692.txt-001-p1s1">
  <m id="m-ustecky47692.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p1s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p2s1">
  <m id="m-ustecky47692.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p2s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p3s1">
  <m id="m-ustecky47692.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s1W1</w.rf>
   <form>27.4</form>
   <form_change>num_normalization</form_change>
   <lemma>27.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p3s2">
  <m id="m-ustecky47692.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W2</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W4</w.rf>
   <form>51</form>
   <lemma>51</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W8</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W9</w.rf>
   <form>Kamenice</form>
   <lemma>Kamenice_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W11</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W12</w.rf>
   <form>Chřibská</form>
   <lemma>Chřibská_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W14</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W15</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W16</w.rf>
   <form>Varnsdorf</form>
   <lemma>Varnsdorf_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W17</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W18</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W19</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W20</w.rf>
   <form>lesního</form>
   <lemma>lesní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W21</w.rf>
   <form>porostu</form>
   <lemma>porost</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W23</w.rf>
   <form>kopci</form>
   <lemma>kopec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W24</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W25</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W26</w.rf>
   <form>Chřibská</form>
   <lemma>Chřibská_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p3s3">
  <m id="m-ustecky47692.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W3</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W4</w.rf>
   <form>kilometr</form>
   <lemma>kilometr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W5</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W6</w.rf>
   <form>cesty</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W8</w.rf>
   <form>vrcholu</form>
   <lemma>vrchol</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W9</w.rf>
   <form>kopce</form>
   <lemma>kopec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p3s4">
  <m id="m-ustecky47692.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s4W1</w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s4W2</w.rf>
   <form>obtížné</form>
   <lemma>obtížný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s4W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s4W4</w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s4W5</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s4W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s4W7</w.rf>
   <form>technikou</form>
   <lemma>technika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p3s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p4s1">
  <m id="m-ustecky47692.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p4s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p4s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p4s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p5s1">
  <m id="m-ustecky47692.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p5s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p5s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p6s1">
  <m id="m-ustecky47692.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s1W1</w.rf>
   <form>27.4</form>
   <form_change>num_normalization</form_change>
   <lemma>27.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p6s2">
  <m id="m-ustecky47692.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W2</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W4</w.rf>
   <form>32</form>
   <lemma>32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W8</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W10</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W11</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W12</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W13</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W15</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W16</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W17</w.rf>
   <form>kamionu</form>
   <lemma>kamión</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W18</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W19</w.rf>
   <form>nákladem</form>
   <lemma>náklad</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W20</w.rf>
   <form>kamenů</form>
   <lemma>kámen</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W22</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W23</w.rf>
   <form>Lubenec</form>
   <lemma>Lubenec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W26</w.rf>
   <form>Drahonice</form>
   <lemma>Drahonice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p6s3">
  <m id="m-ustecky47692.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s3W1</w.rf>
   <form>Kamion</form>
   <lemma>kamión</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s3W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s3W3</w.rf>
   <form>převrácený</form>
   <lemma>převrácený_^(*4tit)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s3W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s3W5</w.rf>
   <form>bok</form>
   <lemma>bok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p6s4">
  <m id="m-ustecky47692.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s4W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s4W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s4W3</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s4W4</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s4W5</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP4-----A---1</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s4W6</w.rf>
   <form>zraněni</form>
   <lemma>zranit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p6s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p6s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p7s1">
  <m id="m-ustecky47692.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p7s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p7s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p7s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p8s1">
  <m id="m-ustecky47692.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p8s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p8s1W2</w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s1">
  <m id="m-ustecky47692.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s1W1</w.rf>
   <form>26.4</form>
   <form_change>num_normalization</form_change>
   <lemma>26.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s2">
  <m id="m-ustecky47692.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W2</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W4</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W8</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W10</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W11</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W14</w.rf>
   <form>Staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W15</w.rf>
   <form>Město</form>
   <lemma>město</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W17</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W18</w.rf>
   <form>Křešice</form>
   <lemma>Křešice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W20</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W21</w.rf>
   <form>Boletice</form>
   <lemma>Boletice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W22</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W23</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W25</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W26</w.rf>
   <form>Benešov</form>
   <lemma>Benešov_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W27</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W28</w.rf>
   <form>Ploučnicí</form>
   <lemma>Ploučnice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W30</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W31</w.rf>
   <form>Horní</form>
   <lemma>Horní_;G</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W32</w.rf>
   <form>žleb</form>
   <lemma>žleb</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W33</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W34</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W35</w.rf>
   <form>Jílové</form>
   <lemma>jílový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W36</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W37</w.rf>
   <form>Děčína</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W38</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W39</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W40</w.rf>
   <form>Modrá</form>
   <lemma>modrý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W41</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W42</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W43</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W44</w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W45</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W46</w.rf>
   <form>Děčína</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W47</w.rf>
   <form>XVII</form>
   <lemma>XVII-3`17</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W48</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W49</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W50</w.rf>
   <form>Jalůvčí</form>
   <lemma>Jalůvčí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s2W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s2W51</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s3">
  <m id="m-ustecky47692.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W3</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W4</w.rf>
   <form>půl</form>
   <lemma>půl-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W5</w.rf>
   <form>hektaru</form>
   <lemma>ha-1`hektar</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W7</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W9</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W11</w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s4">
  <m id="m-ustecky47692.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W2</w.rf>
   <form>dvacáté</form>
   <lemma>dvacátý</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W3</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W5</w.rf>
   <form>hlášen</form>
   <lemma>hlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W6</w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W7</w.rf>
   <form>kouř</form>
   <lemma>kouř</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W8</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W10</w.rf>
   <form>nevrátily</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W12</w.rf>
   <form>stejné</form>
   <lemma>stejný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W13</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W14</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W15</w.rf>
   <form>najely</form>
   <lemma>najet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W17</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W18</w.rf>
   <form>km</form>
   <lemma>km-1`kilometr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W19</w.rf>
   <form>dál</form>
   <lemma>daleko-1_^(dojít_dále_než_...)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W20</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W21</w.rf>
   <form>Maxičkám</form>
   <lemma>Maxičkám</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W23</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W24</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W25</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W26</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s4W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s5">
  <m id="m-ustecky47692.txt-001-p9s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W1</w.rf>
   <form>Hořelo</form>
   <lemma>hořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W2</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W3</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W5</w.rf>
   <form>Bělou</form>
   <lemma>Bělá-1_;S_^(*3ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W7</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W8</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W9</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W10</w.rf>
   <form>těžko</form>
   <lemma>těžko-2_^(sotva)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W11</w.rf>
   <form>přístupné</form>
   <lemma>přístupný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s5W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s6">
  <m id="m-ustecky47692.txt-001-p9s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W2</w.rf>
   <form>poradě</form>
   <lemma>porada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W4</w.rf>
   <form>místními</form>
   <lemma>místní</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W5</w.rf>
   <form>občany</form>
   <lemma>občan</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W7</w.rf>
   <form>nalezena</form>
   <lemma>naleznout</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W8</w.rf>
   <form>cesta</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W10</w.rf>
   <form>27.4</form>
   <form_change>num_normalization</form_change>
   <lemma>27.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W14</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W15</w.rf>
   <form>09</form>
   <lemma>09</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W16</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W17</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W18</w.rf>
   <form>přerušen</form>
   <lemma>přerušit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s6W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s7">
  <m id="m-ustecky47692.txt-001-p9s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W4</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W5</w.rf>
   <form>vrátily</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W6</w.rf>
   <form>27.4</form>
   <form_change>num_normalization</form_change>
   <lemma>27.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W8</w.rf>
   <form>ráno</form>
   <lemma>ráno-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W9</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W10</w.rf>
   <form>šesté</form>
   <lemma>šestý</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W11</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W13</w.rf>
   <form>pokračují</form>
   <lemma>pokračovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W15</w.rf>
   <form>hašení</form>
   <lemma>hašení_^(*4sit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s7W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s8">
  <m id="m-ustecky47692.txt-001-p9s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s8W1</w.rf>
   <form>Komunikace</form>
   <lemma>komunikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s8W2</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s8W3</w.rf>
   <form>Bělou</form>
   <lemma>Běla_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s8W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s8W5</w.rf>
   <form>Maxičkami</form>
   <lemma>Maxičkami</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s8W6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s8W7</w.rf>
   <form>uzavřena</form>
   <lemma>uzavřít</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s8W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s9">
  <m id="m-ustecky47692.txt-001-p9s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s9W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s9W2</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s9W3</w.rf>
   <form>celkovou</form>
   <lemma>celkový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s9W4</w.rf>
   <form>rozlohu</form>
   <lemma>rozloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s9W5</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s9W6</w.rf>
   <form>2ha</form>
   <lemma>2h</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s9W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s10">
  <m id="m-ustecky47692.txt-001-p9s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W1</w.rf>
   <form>N</form>
   <lemma>N-0_:B_;Y</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W5</w.rf>
   <form>současnosti</form>
   <lemma>současnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W6</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W7</w.rf>
   <form>požárních</form>
   <lemma>požární</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W8</w.rf>
   <form>vozidel.O</form>
   <lemma>vozidel.O</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W9</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W10</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W11</w.rf>
   <form>informována</form>
   <lemma>informovat_:T_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W12</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W13</w.rf>
   <form>inspekce</form>
   <lemma>inspekce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W14</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W15</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s10W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p9s11">
  <m id="m-ustecky47692.txt-001-p9s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s11W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s11W2</w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s11W3</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s11W4</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s11W5</w.rf>
   <form>ohniště</form>
   <lemma>ohniště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p9s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p9s11W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p10s1">
  <m id="m-ustecky47692.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p10s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p10s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p10s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p11s1">
  <m id="m-ustecky47692.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p11s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p11s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p12s1">
  <m id="m-ustecky47692.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s1W1</w.rf>
   <form>27.4</form>
   <form_change>num_normalization</form_change>
   <lemma>27.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p12s2">
  <m id="m-ustecky47692.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W4</w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W8</w.rf>
   <form>Duchcov</form>
   <lemma>Duchcov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W12</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W13</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W14</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W15</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W16</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W17</w.rf>
   <form>autobazaru</form>
   <lemma>autobazar</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W19</w.rf>
   <form>Duchcově</form>
   <lemma>Duchcov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W22</w.rf>
   <form>Lahošti</form>
   <lemma>Lahošť_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p12s3">
  <m id="m-ustecky47692.txt-001-p12s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s3W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s3W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s3W4</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s3W5</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s3W6</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p12s4">
  <m id="m-ustecky47692.txt-001-p12s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s4W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s4W2</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s4W3</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p12s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p12s4W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p13s1">
  <m id="m-ustecky47692.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p13s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p13s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p14s1">
  <m id="m-ustecky47692.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W1</w.rf>
   <form>27.4</form>
   <form_change>num_normalization</form_change>
   <lemma>27.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W4</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W6</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W7</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W9</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W10</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W12</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W13</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W14</w.rf>
   <form>Bílina</form>
   <lemma>Bílina_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W15</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W17</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W18</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W19</w.rf>
   <form>nákladního</form>
   <lemma>nákladní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W20</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W21</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W22</w.rf>
   <form>uhlím</form>
   <lemma>uhlí</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W24</w.rf>
   <form>dálničím</form>
   <lemma>dálničí</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W25</w.rf>
   <form>sjezdu</form>
   <lemma>sjezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W26</w.rf>
   <form>směr</form>
   <lemma>směr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W27</w.rf>
   <form>Hostomice</form>
   <lemma>Hostomice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p14s2">
  <m id="m-ustecky47692.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W1</w.rf>
   <form>Auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W3</w.rf>
   <form>převrácené</form>
   <lemma>převrácený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W5</w.rf>
   <form>boku</form>
   <lemma>bok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W7</w.rf>
   <form>vytékala</form>
   <lemma>vytékat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W9</w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>P5ZS2--3-------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W10</w.rf>
   <form>nafta</form>
   <lemma>nafta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p14s3">
  <m id="m-ustecky47692.txt-001-p14s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s3W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s3W2</w.rf>
   <form>asanovaly</form>
   <lemma>asanovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s3W3</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p14s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p14s3W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p15s1">
  <m id="m-ustecky47692.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p15s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p15s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p15s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p15s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p16s1">
  <m id="m-ustecky47692.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p16s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p16s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p17s1">
  <m id="m-ustecky47692.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W1</w.rf>
   <form>27.4</form>
   <form_change>num_normalization</form_change>
   <lemma>27.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W4</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W6</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W7</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W9</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W10</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W11</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W14</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W15</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W16</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W17</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W19</w.rf>
   <form>Pražské</form>
   <lemma>pražský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W20</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W22</w.rf>
   <form>Chomutově</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p17s2">
  <m id="m-ustecky47692.txt-001-p17s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s2W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s2W2</w.rf>
   <form>uklidila</form>
   <lemma>uklidit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s2W3</w.rf>
   <form>vyteklý</form>
   <lemma>vyteklý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s2W4</w.rf>
   <form>olej</form>
   <lemma>olej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p17s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p17s2W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p18s1">
  <m id="m-ustecky47692.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p18s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p18s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p18s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p18s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p18s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p19s1">
  <m id="m-ustecky47692.txt-001-p19s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p19s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p19s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p19s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p20s1">
  <m id="m-ustecky47692.txt-001-p20s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s1W1</w.rf>
   <form>27.4</form>
   <form_change>num_normalization</form_change>
   <lemma>27.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p20s2">
  <m id="m-ustecky47692.txt-001-p20s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W2</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W4</w.rf>
   <form>08</form>
   <lemma>08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W8</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W12</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W13</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W14</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W15</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W16</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W17</w.rf>
   <form>Podbořanami</form>
   <lemma>Podbořana</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W18</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W19</w.rf>
   <form>hřbitova</form>
   <lemma>hřbitov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p20s3">
  <m id="m-ustecky47692.txt-001-p20s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s3W2</w.rf>
   <form>pomohla</form>
   <lemma>pomoci</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s3W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s3W4</w.rf>
   <form>odstraněním</form>
   <lemma>odstranění_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s3W5</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p20s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p20s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p21s1">
  <m id="m-ustecky47692.txt-001-p21s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p21s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p21s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p21s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p21s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p21s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p22s1">
  <m id="m-ustecky47692.txt-001-p22s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p22s1W1</w.rf>
   <form>Netopýři</form>
   <lemma>netopýr</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p23s1">
  <m id="m-ustecky47692.txt-001-p23s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s1W1</w.rf>
   <form>26.4</form>
   <form_change>num_normalization</form_change>
   <lemma>26.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p23s2">
  <m id="m-ustecky47692.txt-001-p23s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W2</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W4</w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W8</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W9</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W10</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W11</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W12</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W13</w.rf>
   <form>Sibiřské</form>
   <lemma>sibiřský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W14</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W16</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W17</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W18</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W21</w.rf>
   <form>Neštěmicích</form>
   <lemma>Neštěmice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W23</w.rf>
   <form>odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W24</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W25</w.rf>
   <form>hlášen</form>
   <lemma>hlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W26</w.rf>
   <form>výskyt</form>
   <lemma>výskyt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W27</w.rf>
   <form>většího</form>
   <lemma>velký</lemma>
   <tag>AANS2----2A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W28</w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W29</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W30</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W31</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W32</w.rf>
   <form>netopýrů</form>
   <lemma>netopýr</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W33</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W34</w.rf>
   <form>panelovém</form>
   <lemma>panelový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W35</w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s2W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p23s3">
  <m id="m-ustecky47692.txt-001-p23s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W3</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W4</w.rf>
   <form>nalezla</form>
   <lemma>nalézt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W5</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W6</w.rf>
   <form>netopýrů</form>
   <lemma>netopýr</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W8</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W9</w.rf>
   <form>poradě</form>
   <lemma>porada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W10</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W11</w.rf>
   <form>zoologem</form>
   <lemma>zoolog</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W12</w.rf>
   <form>netopýry</form>
   <lemma>netopýr</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W13</w.rf>
   <form>vyhnala</form>
   <lemma>vyhnat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W14</w.rf>
   <form>otevřeným</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W15</w.rf>
   <form>oknem</form>
   <lemma>okno</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p23s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p23s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p24s1">
  <m id="m-ustecky47692.txt-001-p24s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p24s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p24s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p24s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p24s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p24s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p25s1">
  <m id="m-ustecky47692.txt-001-p25s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p25s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p26s1">
  <m id="m-ustecky47692.txt-001-p26s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s1W1</w.rf>
   <form>26.4</form>
   <form_change>num_normalization</form_change>
   <lemma>26.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p26s2">
  <m id="m-ustecky47692.txt-001-p26s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W2</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W4</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W8</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W10</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W11</w.rf>
   <form>Benešov</form>
   <lemma>Benešov_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W12</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W13</w.rf>
   <form>Ploučnicí</form>
   <lemma>Ploučnice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W14</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W15</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W16</w.rf>
   <form>starého</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W17</w.rf>
   <form>gauče</form>
   <lemma>gauč</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W19</w.rf>
   <form>utomobilových</form>
   <lemma>utomobilův</lemma>
   <tag>AUFP2M---------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W20</w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W21</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W22</w.rf>
   <form>sklepě</form>
   <lemma>sklep</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W23</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W25</w.rf>
   <form>Benešově</form>
   <lemma>Benešův_;S_^(*2)</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W26</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W27</w.rf>
   <form>Ploučnicí</form>
   <lemma>Ploučnice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p26s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p26s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p27s1">
  <m id="m-ustecky47692.txt-001-p27s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p27s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p27s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p27s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p27s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p27s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p28s1">
  <m id="m-ustecky47692.txt-001-p28s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p28s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p29s1">
  <m id="m-ustecky47692.txt-001-p29s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s1W1</w.rf>
   <form>26.4</form>
   <form_change>num_normalization</form_change>
   <lemma>26.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p29s2">
  <m id="m-ustecky47692.txt-001-p29s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W2</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W4</w.rf>
   <form>42</form>
   <lemma>42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W8</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W10</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W11</w.rf>
   <form>Lom</form>
   <lemma>Lom_;G_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W12</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W13</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W14</w.rf>
   <form>lesního</form>
   <lemma>lesní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W15</w.rf>
   <form>porostu</form>
   <lemma>porost</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W17</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W18</w.rf>
   <form>200x20m</form>
   <lemma>200x20m</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W19</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W20</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W21</w.rf>
   <form>Lom</form>
   <lemma>Lom_;G_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W22</w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W24</w.rf>
   <form>Osek</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky47692.txt-001-p29s3">
  <m id="m-ustecky47692.txt-001-p29s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s3W5</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s3W7</w.rf>
   <form>55</form>
   <lemma>55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky47692.txt-001-p29s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky47692.txt-001-p29s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
