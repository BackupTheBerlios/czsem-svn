<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky48451.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky48451.txt-001-p1s1">
  <m id="m-ustecky48451.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p1s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p2s1">
  <m id="m-ustecky48451.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p2s1W1</w.rf>
   <form>Otevření</form>
   <lemma>otevření_^(*3ít)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p2s1W2</w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p3s1">
  <m id="m-ustecky48451.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s1W1</w.rf>
   <form>4.5</form>
   <form_change>num_normalization</form_change>
   <lemma>4.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p3s2">
  <m id="m-ustecky48451.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W2</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W4</w.rf>
   <form>04</form>
   <lemma>04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W8</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W9</w.rf>
   <form>otevřela</form>
   <lemma>otevřít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W10</w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W12</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W13</w.rf>
   <form>Jana</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W14</w.rf>
   <form>Kubelíka</form>
   <lemma>Kubelík_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W16</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p3s3">
  <m id="m-ustecky48451.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W1</w.rf>
   <form>Paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W3</w.rf>
   <form>zlomil</form>
   <lemma>zlomit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W4</w.rf>
   <form>klíč</form>
   <lemma>klíč</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W6</w.rf>
   <form>zámku</form>
   <lemma>zámek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W8</w.rf>
   <form>uvnitř</form>
   <lemma>uvnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W9</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W10</w.rf>
   <form>dítě</form>
   <lemma>dítě</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p3s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p4s1">
  <m id="m-ustecky48451.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p4s1W1</w.rf>
   <form>Člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p4s1W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p4s1W3</w.rf>
   <form>parapetu</form>
   <lemma>parapet</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p5s1">
  <m id="m-ustecky48451.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s1W1</w.rf>
   <form>4.5</form>
   <form_change>num_normalization</form_change>
   <lemma>4.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p5s2">
  <m id="m-ustecky48451.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W1</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W2</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W4</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W8</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W10</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W11</w.rf>
   <form>automobilním</form>
   <lemma>automobilní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W12</w.rf>
   <form>žebříkem</form>
   <lemma>žebřík</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W14</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W15</w.rf>
   <form>Přátelství</form>
   <lemma>přátelství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W17</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W18</w.rf>
   <form>seděl</form>
   <lemma>sedět</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W19</w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W21</w.rf>
   <form>parapetu</form>
   <lemma>parapet</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p5s3">
  <m id="m-ustecky48451.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s3W1</w.rf>
   <form>Člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s3W2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s3W3</w.rf>
   <form>domluvě</form>
   <lemma>domluva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s3W4</w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s3W5</w.rf>
   <form>slezl</form>
   <lemma>slézt</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p5s4">
  <m id="m-ustecky48451.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s4W1</w.rf>
   <form>Vzala</form>
   <lemma>vzít_^(př._sebrat_něco;_brát_ohled,_zřetel,...)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s4W2</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s4W3</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s4W4</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s4W5</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s4W6</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s4W7</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p5s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p6s1">
  <m id="m-ustecky48451.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p6s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p7s1">
  <m id="m-ustecky48451.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W1</w.rf>
   <form>3.5</form>
   <form_change>num_normalization</form_change>
   <lemma>3.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W4</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W6</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W7</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W8</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W9</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W10</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W12</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W13</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W16</w.rf>
   <form>Rudolice</form>
   <lemma>Rudolice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W18</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W19</w.rf>
   <form>Braňany</form>
   <lemma>Braňany</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W21</w.rf>
   <form>SDHO</form>
   <lemma>SDHO</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W22</w.rf>
   <form>Obrnice</form>
   <lemma>Obrnice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W23</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W24</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W25</w.rf>
   <form>porostu</form>
   <lemma>porost</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W27</w.rf>
   <form>pneumatik</form>
   <lemma>pneumatika</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W28</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W29</w.rf>
   <form>pološe</form>
   <lemma>pološe</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W30</w.rf>
   <form>50m2</form>
   <lemma>50m2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W31</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W32</w.rf>
   <form>černé</form>
   <lemma>černý-1_^(barva)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W33</w.rf>
   <form>skládce</form>
   <lemma>skládka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W34</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W35</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W36</w.rf>
   <form>Patokryjích</form>
   <lemma>Patokryje_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s1W37</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p7s2">
  <m id="m-ustecky48451.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s2W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s2W5</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s2W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s2W7</w.rf>
   <form>09</form>
   <lemma>09</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p7s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p8s1">
  <m id="m-ustecky48451.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p8s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p8s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p8s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p9s1">
  <m id="m-ustecky48451.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p9s1W1</w.rf>
   <form>Dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p9s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p10s1">
  <m id="m-ustecky48451.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W1</w.rf>
   <form>3.5</form>
   <form_change>num_normalization</form_change>
   <lemma>3.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W3</w.rf>
   <form>07</form>
   <lemma>07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W4</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W6</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W9</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W11</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W12</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W13</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W14</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W15</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W16</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W17</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W18</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W19</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W20</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W21</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W22</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W23</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W24</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W26</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W27</w.rf>
   <form>Tolstého</form>
   <lemma>Tolstý_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W29</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W30</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W31</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s1W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky48451.txt-001-p10s2">
  <m id="m-ustecky48451.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s2W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s2W2</w.rf>
   <form>zlikvidovala</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s2W3</w.rf>
   <form>vyteklý</form>
   <lemma>vyteklý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s2W4</w.rf>
   <form>olej</form>
   <lemma>olej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky48451.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky48451.txt-001-p10s2W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
