<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky49231.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky49231.txt-001-p1s1">
  <m id="m-ustecky49231.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p1s1W1</w.rf>
   <form>Silný</form>
   <lemma>silný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p1s1W2</w.rf>
   <form>vítr</form>
   <lemma>vítr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p1s1W3</w.rf>
   <form>Ústecký</form>
   <lemma>ústecký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p1s1W4</w.rf>
   <form>kraj</form>
   <lemma>kraj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s1">
  <m id="m-ustecky49231.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s1W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s1W2</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s1W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s1W4</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s1W5</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s1W6</w.rf>
   <form>zasahovaly</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s1W7</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s2">
  <m id="m-ustecky49231.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W2</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W3</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W4</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W5</w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W8</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W9</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W10</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W11</w.rf>
   <form>hod</form>
   <lemma>hodina_:B_,x</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W13</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W14</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W15</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W16</w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W17</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W18</w.rf>
   <form>způsobených</form>
   <lemma>způsobený_^(*3it)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W19</w.rf>
   <form>silným</form>
   <lemma>silný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W20</w.rf>
   <form>větrem</form>
   <lemma>vítr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s3">
  <m id="m-ustecky49231.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W1</w.rf>
   <form>Nejčastěji</form>
   <lemma>častě_^(*1ý)</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W3</w.rf>
   <form>potřeba</form>
   <lemma>potřeba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W4</w.rf>
   <form>odstranit</form>
   <lemma>odstranit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W5</w.rf>
   <form>spadlé</form>
   <lemma>spadlý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W6</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W8</w.rf>
   <form>ulámané</form>
   <lemma>ulámaný_^(*2t)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W9</w.rf>
   <form>větve</form>
   <lemma>větev</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W11</w.rf>
   <form>uvolněné</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W12</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W14</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W15</w.rf>
   <form>nějakým</form>
   <lemma>nějaký</lemma>
   <tag>PZZS7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W16</w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W17</w.rf>
   <form>ohrožovaly</form>
   <lemma>ohrožovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W18</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W19</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W20</w.rf>
   <form>omezovaly</form>
   <lemma>omezovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W21</w.rf>
   <form>komunikaci</form>
   <lemma>komunikace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s4">
  <m id="m-ustecky49231.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W1</w.rf>
   <form>Nejvíce</form>
   <lemma>hodně</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W2</w.rf>
   <form>zásahů</form>
   <lemma>zásah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W5</w.rf>
   <form>Chomutovsku</form>
   <lemma>Chomutovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W7</w.rf>
   <form>Žatecku</form>
   <lemma>Žatecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W9</w.rf>
   <form>Teplicku</form>
   <lemma>Teplicko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s5">
  <m id="m-ustecky49231.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W1</w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W2</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W4</w.rf>
   <form>ostatních</form>
   <lemma>ostatní</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W5</w.rf>
   <form>okresech</form>
   <lemma>okres</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W7</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W8</w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s6">
  <m id="m-ustecky49231.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W2</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W3</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W5</w.rf>
   <form>narušeno</form>
   <lemma>narušit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W6</w.rf>
   <form>elektrické</form>
   <lemma>elektrický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W8</w.rf>
   <form>telefonní</form>
   <lemma>telefonní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W9</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s6W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s7">
  <m id="m-ustecky49231.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W1</w.rf>
   <form>Pádem</form>
   <lemma>pád</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W2</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W4</w.rf>
   <form>větve</form>
   <lemma>větev</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W5</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W6</w.rf>
   <form>poškozeny</form>
   <lemma>poškodit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W7</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W8</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s7W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s8">
  <m id="m-ustecky49231.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W1</w.rf>
   <form>Minimálně</form>
   <lemma>minimálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W2</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W3</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W4</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W5</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W6</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W8</w.rf>
   <form>železniční</form>
   <lemma>železniční_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W9</w.rf>
   <form>trať</form>
   <lemma>trať</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W12</w.rf>
   <form>jednom</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W13</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W15</w.rf>
   <form>budovu</form>
   <lemma>budova</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s8W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p2s9">
  <m id="m-ustecky49231.txt-001-p2s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W1</w.rf>
   <form>Poškozené</form>
   <lemma>poškozený_^(*4dit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W2</w.rf>
   <form>elektrické</form>
   <lemma>elektrický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W3</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W5</w.rf>
   <form>způsobilo</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W6</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W7</w.rf>
   <form>menších</form>
   <lemma>malý</lemma>
   <tag>AAIP2----2A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W8</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W9</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p2s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p2s9W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p3s1">
  <m id="m-ustecky49231.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p3s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p3s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p3s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p4s1">
  <m id="m-ustecky49231.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p4s2">
  <m id="m-ustecky49231.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W1</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W3</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W4</w.rf>
   <form>Dubí</form>
   <lemma>Dubí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W6</w.rf>
   <form>Zahradní</form>
   <lemma>zahradní_,a</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W7</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W10</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W11</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W12</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p4s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p5s1">
  <m id="m-ustecky49231.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p5s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p5s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p5s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p6s1">
  <m id="m-ustecky49231.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p6s2">
  <m id="m-ustecky49231.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W3</w.rf>
   <form>52</form>
   <lemma>52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W4</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W7</w.rf>
   <form>Jirkov</form>
   <lemma>Jirkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W9</w.rf>
   <form>zahrádkářská</form>
   <lemma>zahrádkářský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W10</w.rf>
   <form>kolonie</form>
   <lemma>kolonie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W13</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W14</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W15</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p6s2W16</w.rf>
   <form>cestu</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p7s1">
  <m id="m-ustecky49231.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p7s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p7s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p7s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p8s1">
  <m id="m-ustecky49231.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p8s2">
  <m id="m-ustecky49231.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W3</w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W4</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W6</w.rf>
   <form>Dlouhá</form>
   <lemma>Dlouhá_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W7</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W10</w.rf>
   <form>lešení</form>
   <lemma>lešení</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W11</w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W12</w.rf>
   <form>synagogy</form>
   <lemma>synagoga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W13</w.rf>
   <form>padají</form>
   <lemma>padat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W14</w.rf>
   <form>podlážky</form>
   <lemma>podlážka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p8s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p9s1">
  <m id="m-ustecky49231.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p9s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p9s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p9s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p10s1">
  <m id="m-ustecky49231.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p10s2">
  <m id="m-ustecky49231.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W3</w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W4</w.rf>
   <form>Kadaň</form>
   <lemma>Kadaň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W7</w.rf>
   <form>zlomený</form>
   <lemma>zlomený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W8</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W9</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p10s2W10</w.rf>
   <form>cestu</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p11s1">
  <m id="m-ustecky49231.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p11s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p11s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p11s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p12s1">
  <m id="m-ustecky49231.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p12s2">
  <m id="m-ustecky49231.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W3</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W4</w.rf>
   <form>Krupka</form>
   <lemma>krupka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W7</w.rf>
   <form>Vrchoslav</form>
   <lemma>Vrchoslav_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W10</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W11</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W12</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W14</w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W15</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W16</w.rf>
   <form>šroubárnou</form>
   <lemma>šroubárna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p12s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p13s1">
  <m id="m-ustecky49231.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p13s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p13s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p13s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p14s1">
  <m id="m-ustecky49231.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p14s2">
  <m id="m-ustecky49231.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W3</w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W4</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W5</w.rf>
   <form>Nové</form>
   <lemma>nový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W6</w.rf>
   <form>Město</form>
   <lemma>město</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W7</w.rf>
   <form>Kamenická</form>
   <lemma>kamenický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W8</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W11</w.rf>
   <form>spadlá</form>
   <lemma>spadlý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W12</w.rf>
   <form>větev</form>
   <lemma>větev</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W14</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p14s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p14s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p15s1">
  <m id="m-ustecky49231.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p15s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p15s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p15s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p15s1W3</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p16s1">
  <m id="m-ustecky49231.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p16s2">
  <m id="m-ustecky49231.txt-001-p16s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W3</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W4</w.rf>
   <form>Uštěk</form>
   <lemma>uštěknout_:W_,e</lemma>
   <tag>VpYS---XR-AA--6</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W7</w.rf>
   <form>Robeč</form>
   <lemma>Robeč_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W8</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W9</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W11</w.rf>
   <form>hřbitově</form>
   <lemma>hřbitov</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p16s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p16s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p17s1">
  <m id="m-ustecky49231.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p17s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p17s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p17s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p17s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p18s1">
  <m id="m-ustecky49231.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p18s2">
  <m id="m-ustecky49231.txt-001-p18s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W3</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W4</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W7</w.rf>
   <form>Křimov</form>
   <lemma>Křimov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W10</w.rf>
   <form>Krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W11</w.rf>
   <form>Lípa</form>
   <lemma>lípa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W12</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W13</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W14</w.rf>
   <form>Dominou</form>
   <lemma>domina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W15</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W16</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W18</w.rf>
   <form>vozovce</form>
   <lemma>vozovka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p18s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p18s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p19s1">
  <m id="m-ustecky49231.txt-001-p19s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p19s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p19s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p19s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p19s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p19s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p20s1">
  <m id="m-ustecky49231.txt-001-p20s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p20s2">
  <m id="m-ustecky49231.txt-001-p20s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W3</w.rf>
   <form>04</form>
   <lemma>04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W4</w.rf>
   <form>Benátky</form>
   <lemma>Benátky_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W6</w.rf>
   <form>Lounsku</form>
   <lemma>Lounsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W7</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W8</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W11</w.rf>
   <form>kaštan</form>
   <lemma>kaštan</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p20s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p20s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p21s1">
  <m id="m-ustecky49231.txt-001-p21s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W1</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W3</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W5</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W7</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W8</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W11</w.rf>
   <form>Pšov</form>
   <lemma>Pšov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W12</w.rf>
   <form>převržený</form>
   <lemma>převržený_^(*4hnout)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W13</w.rf>
   <form>kamion</form>
   <lemma>kamión</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p21s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p21s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p22s1">
  <m id="m-ustecky49231.txt-001-p22s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p22s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p22s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p22s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p22s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p22s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p23s1">
  <m id="m-ustecky49231.txt-001-p23s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p23s2">
  <m id="m-ustecky49231.txt-001-p23s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W1</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W3</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W4</w.rf>
   <form>Spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W5</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W6</w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W8</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W9</w.rf>
   <form>Kadaň</form>
   <lemma>Kadaň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W12</w.rf>
   <form>Mašťov</form>
   <lemma>Mašťov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p23s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p23s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p24s1">
  <m id="m-ustecky49231.txt-001-p24s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p24s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p24s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p24s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p24s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p24s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p25s1">
  <m id="m-ustecky49231.txt-001-p25s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p25s2">
  <m id="m-ustecky49231.txt-001-p25s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W1</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W3</w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W4</w.rf>
   <form>Spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W5</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W6</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W7</w.rf>
   <form>cestu</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W8</w.rf>
   <form>Košťany</form>
   <lemma>Košťany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W11</w.rf>
   <form>Střelná</form>
   <lemma>střelný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p25s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p25s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p26s1">
  <m id="m-ustecky49231.txt-001-p26s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p26s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p26s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p26s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p26s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p26s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p27s1">
  <m id="m-ustecky49231.txt-001-p27s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p27s2">
  <m id="m-ustecky49231.txt-001-p27s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W1</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W3</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W4</w.rf>
   <form>Strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W5</w.rf>
   <form>padlý</form>
   <lemma>padlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W7</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W9</w.rf>
   <form>Chomutově</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W10</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W11</w.rf>
   <form>Povodím</form>
   <lemma>povodí</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W12</w.rf>
   <form>ohře</form>
   <lemma>ohř</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p27s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p27s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p28s1">
  <m id="m-ustecky49231.txt-001-p28s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p28s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p28s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p28s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p28s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p28s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p29s1">
  <m id="m-ustecky49231.txt-001-p29s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p29s2">
  <m id="m-ustecky49231.txt-001-p29s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W1</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W3</w.rf>
   <form>53</form>
   <lemma>53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W4</w.rf>
   <form>Uvolněné</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W5</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W6</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W7</w.rf>
   <form>Lidovou</form>
   <lemma>lidový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W8</w.rf>
   <form>školou</form>
   <lemma>škola</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W9</w.rf>
   <form>umění</form>
   <lemma>umění_^(mít_schopnost_něco_dělat)_(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W11</w.rf>
   <form>Litvínově</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W12</w.rf>
   <form>Chudeříně</form>
   <lemma>Chudeřín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p29s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p29s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p30s1">
  <m id="m-ustecky49231.txt-001-p30s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p30s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p30s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p30s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p30s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p30s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p31s1">
  <m id="m-ustecky49231.txt-001-p31s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p31s2">
  <m id="m-ustecky49231.txt-001-p31s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W1</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W3</w.rf>
   <form>04</form>
   <lemma>04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W4</w.rf>
   <form>Polní</form>
   <lemma>polní-1</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W5</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W6</w.rf>
   <form>Vansdorf</form>
   <lemma>Vansdorf</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W7</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W9</w.rf>
   <form>kolejích</form>
   <lemma>kolej</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p31s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p31s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p32s1">
  <m id="m-ustecky49231.txt-001-p32s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p32s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p32s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p32s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p32s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p32s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p33s1">
  <m id="m-ustecky49231.txt-001-p33s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p33s2">
  <m id="m-ustecky49231.txt-001-p33s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W1</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W3</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W4</w.rf>
   <form>Podbořany</form>
   <lemma>Podbořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W6</w.rf>
   <form>Revoluční</form>
   <lemma>revoluční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W7</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W8</w.rf>
   <form>uvolněné</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W9</w.rf>
   <form>hliníkové</form>
   <lemma>hliníkový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W10</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W12</w.rf>
   <form>dvoupatrové</form>
   <lemma>dvoupatrový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W13</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p33s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p33s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p34s1">
  <m id="m-ustecky49231.txt-001-p34s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p34s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p34s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p34s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p34s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p34s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p35s1">
  <m id="m-ustecky49231.txt-001-p35s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p35s2">
  <m id="m-ustecky49231.txt-001-p35s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W1</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W3</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W4</w.rf>
   <form>Zlomená</form>
   <lemma>zlomený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W5</w.rf>
   <form>větev</form>
   <lemma>větev</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W7</w.rf>
   <form>Bethovenově</form>
   <lemma>Bethovenův</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W8</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W10</w.rf>
   <form>Chomutově</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p35s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p35s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p36s1">
  <m id="m-ustecky49231.txt-001-p36s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p36s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p36s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p36s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p36s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p36s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p37s1">
  <m id="m-ustecky49231.txt-001-p37s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p37s2">
  <m id="m-ustecky49231.txt-001-p37s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W1</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W3</w.rf>
   <form>53</form>
   <lemma>53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W7</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W8</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W10</w.rf>
   <form>Podkrušnohorské</form>
   <lemma>podkrušnohorský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W11</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W13</w.rf>
   <form>Litvínově</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W16</w.rf>
   <form>Chudeříně</form>
   <lemma>Chudeřín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W18</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W19</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W21</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W22</w.rf>
   <form>uvolnily</form>
   <lemma>uvolnit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W23</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W25</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W26</w.rf>
   <form>15m</form>
   <lemma>15m</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W27</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W28</w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p37s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p37s2W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p38s1">
  <m id="m-ustecky49231.txt-001-p38s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p38s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p38s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p38s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p38s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p38s1W3</w.rf>
   <form>Žatec</form>
   <lemma>Žatec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p39s1">
  <m id="m-ustecky49231.txt-001-p39s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p39s2">
  <m id="m-ustecky49231.txt-001-p39s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W1</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W3</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W4</w.rf>
   <form>Postoloprty</form>
   <lemma>Postoloprty_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W5</w.rf>
   <form>směr</form>
   <lemma>směr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W6</w.rf>
   <form>Lenešice</form>
   <lemma>Lenešice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W8</w.rf>
   <form>pískovnu</form>
   <lemma>pískovna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W9</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W10</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W12</w.rf>
   <form>chatek</form>
   <lemma>chatka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p39s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p39s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p40s1">
  <m id="m-ustecky49231.txt-001-p40s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p40s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p40s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p40s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p40s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p40s1W3</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p41s1">
  <m id="m-ustecky49231.txt-001-p41s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p41s1W1</w.rf>
   <form>Spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p41s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p41s1W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p42s1">
  <m id="m-ustecky49231.txt-001-p42s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p42s2">
  <m id="m-ustecky49231.txt-001-p42s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W1</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W3</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W7</w.rf>
   <form>Roudnice</form>
   <lemma>Roudnice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W10</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W11</w.rf>
   <form>odstranit</form>
   <lemma>odstranit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W12</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W13</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W14</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W15</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W16</w.rf>
   <form>Kyškovice</form>
   <lemma>Kyškovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p42s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p42s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p43s1">
  <m id="m-ustecky49231.txt-001-p43s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p43s1W1</w.rf>
   <form>Ulomená</form>
   <lemma>ulomený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p43s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p43s1W2</w.rf>
   <form>větev</form>
   <lemma>větev</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p44s1">
  <m id="m-ustecky49231.txt-001-p44s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p44s2">
  <m id="m-ustecky49231.txt-001-p44s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W1</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W3</w.rf>
   <form>56</form>
   <lemma>56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W7</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W8</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W9</w.rf>
   <form>odstranit</form>
   <lemma>odstranit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W10</w.rf>
   <form>ulomenou</form>
   <lemma>ulomený_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W11</w.rf>
   <form>větev</form>
   <lemma>větev</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W12</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W13</w.rf>
   <form>slinicí</form>
   <lemma>slinic</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W14</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W15</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W16</w.rf>
   <form>Michalovice</form>
   <lemma>Michalovic_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p44s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p44s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p45s1">
  <m id="m-ustecky49231.txt-001-p45s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p45s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p45s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p45s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p45s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p45s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p46s1">
  <m id="m-ustecky49231.txt-001-p46s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p46s2">
  <m id="m-ustecky49231.txt-001-p46s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W1</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W3</w.rf>
   <form>53</form>
   <lemma>53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W7</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W9</w.rf>
   <form>HZSP</form>
   <lemma>Hzsp</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W10</w.rf>
   <form>ČEZ</form>
   <lemma>ČEZ-1_:B_;K_^(České_energetické_závody)</lemma>
   <tag>NNIPX-----A---8</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W11</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W12</w.rf>
   <form>odstranit</form>
   <lemma>odstranit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W13</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W14</w.rf>
   <form>kabel</form>
   <lemma>kabel</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W16</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W17</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W18</w.rf>
   <form>elektrárnou</form>
   <lemma>elektrárna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W19</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W20</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W21</w.rf>
   <form>Kadaň</form>
   <lemma>Kadaň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p46s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p46s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p47s1">
  <m id="m-ustecky49231.txt-001-p47s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p47s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p47s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p47s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p47s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p47s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p48s1">
  <m id="m-ustecky49231.txt-001-p48s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p48s2">
  <m id="m-ustecky49231.txt-001-p48s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W1</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W3</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W7</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W8</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W10</w.rf>
   <form>Lidické</form>
   <lemma>lidický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W11</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W12</w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W13</w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W14</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W15</w.rf>
   <form>kovboje</form>
   <lemma>kovboj</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W17</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W18</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W19</w.rf>
   <form>uvolněná</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W20</w.rf>
   <form>plastová</form>
   <lemma>plastový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W21</w.rf>
   <form>krytina</form>
   <lemma>krytina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p48s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p48s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p49s1">
  <m id="m-ustecky49231.txt-001-p49s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p49s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p49s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p49s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p49s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p49s1W3</w.rf>
   <form>Děčín</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p50s1">
  <m id="m-ustecky49231.txt-001-p50s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p50s1W1</w.rf>
   <form>Spadlé</form>
   <lemma>spadlý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p50s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p50s1W2</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p51s1">
  <m id="m-ustecky49231.txt-001-p51s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p51s2">
  <m id="m-ustecky49231.txt-001-p51s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W1</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W3</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W7</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W8</w.rf>
   <form>Kamenice</form>
   <lemma>Kamenice_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W10</w.rf>
   <form>směr</form>
   <lemma>směr</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W11</w.rf>
   <form>obec</form>
   <lemma>obec</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W12</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W13</w.rf>
   <form>Kamenice</form>
   <lemma>Kamenice_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W15</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W16</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W18</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W19</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W20</w.rf>
   <form>Kamenice</form>
   <lemma>Kamenica_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W21</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W22</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W23</w.rf>
   <form>4km</form>
   <lemma>4km</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W24</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W25</w.rf>
   <form>Č.</form>
   <lemma>Č-0_:B_;Y</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W26</w.rf>
   <form>Kamenice</form>
   <lemma>Kamenica_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W27</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W28</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W29</w.rf>
   <form>Žandova</form>
   <lemma>Žandov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W30</w.rf>
   <form>spadlé</form>
   <lemma>spadlý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W31</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p51s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p51s2W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p52s1">
  <m id="m-ustecky49231.txt-001-p52s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p52s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p52s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p52s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p52s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p52s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p53s1">
  <m id="m-ustecky49231.txt-001-p53s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p53s1W1</w.rf>
   <form>Zlomený</form>
   <lemma>zlomený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p53s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p53s1W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p54s1">
  <m id="m-ustecky49231.txt-001-p54s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p54s2">
  <m id="m-ustecky49231.txt-001-p54s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W1</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W3</w.rf>
   <form>55</form>
   <lemma>55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W7</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W8</w.rf>
   <form>odstraňuje</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W9</w.rf>
   <form>zlomený</form>
   <lemma>zlomený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W10</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W12</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W13</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W15</w.rf>
   <form>soobní</form>
   <lemma>soobní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W16</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W17</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W18</w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W19</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W20</w.rf>
   <form>losa</form>
   <lemma>los-1_^(zvíře)</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W22</w.rf>
   <form>Chomutově</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p54s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p54s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p55s1">
  <m id="m-ustecky49231.txt-001-p55s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p55s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p55s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p55s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p55s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p55s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p56s1">
  <m id="m-ustecky49231.txt-001-p56s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p56s1W1</w.rf>
   <form>Uvolněné</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p56s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p56s1W2</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p57s1">
  <m id="m-ustecky49231.txt-001-p57s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p57s2">
  <m id="m-ustecky49231.txt-001-p57s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W1</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W3</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W10</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W12</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W13</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W14</w.rf>
   <form>jeslí</form>
   <lemma>jesle</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W16</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W17</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W18</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W21</w.rf>
   <form>centru</form>
   <lemma>centrum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W23</w.rf>
   <form>upevnit</form>
   <lemma>upevnit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W24</w.rf>
   <form>uvolněné</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W25</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W26</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W27</w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrNS6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W28</w.rf>
   <form>poschodí</form>
   <lemma>poschodí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p57s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p57s2W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p58s1">
  <m id="m-ustecky49231.txt-001-p58s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p58s1W1</w.rf>
   <form>Spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p58s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p58s1W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p59s1">
  <m id="m-ustecky49231.txt-001-p59s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p59s2">
  <m id="m-ustecky49231.txt-001-p59s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W1</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W3</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W6</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W9</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W10</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W12</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W13</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W14</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W16</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W17</w.rf>
   <form>Brné</form>
   <lemma>Brná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W19</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W21</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W22</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W23</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W25</w.rf>
   <form>Sebuzín</form>
   <lemma>Sebuzín_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W26</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W27</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p59s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p59s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p60s1">
  <m id="m-ustecky49231.txt-001-p60s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p60s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p60s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p60s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p60s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p60s1W3</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p61s1">
  <m id="m-ustecky49231.txt-001-p61s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p61s1W1</w.rf>
   <form>Uvolněné</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p61s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p61s1W2</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p62s1">
  <m id="m-ustecky49231.txt-001-p62s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W1</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W3</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W7</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W8</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W10</w.rf>
   <form>Doubravské</form>
   <lemma>doubravský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W11</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W13</w.rf>
   <form>Teplicích</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W16</w.rf>
   <form>Trnovanech</form>
   <lemma>Trnovany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W18</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W19</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W20</w.rf>
   <form>uvolnily</form>
   <lemma>uvolnit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W21</w.rf>
   <form>plech</form>
   <lemma>plech</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W23</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p62s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p62s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p63s1">
  <m id="m-ustecky49231.txt-001-p63s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p63s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p63s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p63s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p63s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p63s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p64s1">
  <m id="m-ustecky49231.txt-001-p64s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p64s1W1</w.rf>
   <form>Uvolněné</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p64s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p64s1W2</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p65s1">
  <m id="m-ustecky49231.txt-001-p65s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s1W1</w.rf>
   <form>11.5</form>
   <form_change>num_normalization</form_change>
   <lemma>11.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky49231.txt-001-p65s2">
  <m id="m-ustecky49231.txt-001-p65s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W1</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W3</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W4</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W6</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W7</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W8</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W10</w.rf>
   <form>třídu</form>
   <lemma>třída</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W11</w.rf>
   <form>Budovatelů</form>
   <lemma>budovatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W13</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W15</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W17</w.rf>
   <form>uvolnily</form>
   <lemma>uvolnit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W18</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W20</w.rf>
   <form>opravované</form>
   <lemma>opravovaný_^(*2t)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W21</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky49231.txt-001-p65s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky49231.txt-001-p65s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
