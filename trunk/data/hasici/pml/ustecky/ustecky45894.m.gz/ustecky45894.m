<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ustecky45894.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-ustecky45894.txt-001-p1s1">
  <m id="m-ustecky45894.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p1s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p1s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p1s1W3</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p2s1">
  <m id="m-ustecky45894.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p2s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p3s1">
  <m id="m-ustecky45894.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s1W1</w.rf>
   <form>12.4</form>
   <form_change>num_normalization</form_change>
   <lemma>12.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p3s2">
  <m id="m-ustecky45894.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W2</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W4</w.rf>
   <form>46</form>
   <lemma>46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W8</w.rf>
   <form>Lovosice</form>
   <lemma>Lovosice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W11</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W12</w.rf>
   <form>ořezaných</form>
   <lemma>ořezaný_^(*2t)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W13</w.rf>
   <form>větví</form>
   <lemma>větev</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W15</w.rf>
   <form>černé</form>
   <lemma>černý-1_^(barva)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W16</w.rf>
   <form>skládky</form>
   <lemma>skládka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W17</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W18</w.rf>
   <form>obcí</form>
   <lemma>obec</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W19</w.rf>
   <form>Čížkovice</form>
   <lemma>Čížkovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W20</w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W22</w.rf>
   <form>Sulejovice</form>
   <lemma>Sulejovice_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p3s3">
  <m id="m-ustecky45894.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s3W3</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s3W5</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s3W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s3W7</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p3s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p4s1">
  <m id="m-ustecky45894.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p4s1W1</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p4s1W2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p4s1W3</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p5s1">
  <m id="m-ustecky45894.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p5s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p6s1">
  <m id="m-ustecky45894.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s1W1</w.rf>
   <form>12.4</form>
   <form_change>num_normalization</form_change>
   <lemma>12.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p6s2">
  <m id="m-ustecky45894.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W2</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W4</w.rf>
   <form>42</form>
   <lemma>42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W5</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W8</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W9</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W10</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W11</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W13</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W15</w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W17</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W18</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W19</w.rf>
   <form>Drahách</form>
   <lemma>dráha</lemma>
   <tag>NNFP6-----A---1</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W21</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W22</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W23</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p6s3">
  <m id="m-ustecky45894.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W1</w.rf>
   <form>Hořela</form>
   <lemma>hořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W2</w.rf>
   <form>matrace</form>
   <lemma>matrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W4</w.rf>
   <form>deka</form>
   <lemma>deko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W6</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W8</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W9</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W10</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W11</w.rf>
   <form>příjezdem</form>
   <lemma>příjezd</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W12</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p6s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p7s1">
  <m id="m-ustecky45894.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p7s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p7s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p7s1W3</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p8s1">
  <m id="m-ustecky45894.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p8s1W1</w.rf>
   <form>Únik</form>
   <lemma>únik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p8s1W2</w.rf>
   <form>nafty</form>
   <lemma>nafta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p9s1">
  <m id="m-ustecky45894.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s1W1</w.rf>
   <form>12.4</form>
   <form_change>num_normalization</form_change>
   <lemma>12.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p9s2">
  <m id="m-ustecky45894.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W2</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W4</w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W7</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W8</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W10</w.rf>
   <form>HZSP</form>
   <lemma>Hzsp</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W11</w.rf>
   <form>MU</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W12</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p9s3">
  <m id="m-ustecky45894.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W1</w.rf>
   <form>Most</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W2</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W4</w.rf>
   <form>Kopistskou</form>
   <lemma>Kopistská</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W5</w.rf>
   <form>výsypku</form>
   <lemma>výsypka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W8</w.rf>
   <form>východ</form>
   <lemma>východ</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W10</w.rf>
   <form>Mostě</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W12</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W13</w.rf>
   <form>vyteklo</form>
   <lemma>vytéci</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W15</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W16</w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AANS4----2A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W17</w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W18</w.rf>
   <form>nafty</form>
   <lemma>nafta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W21</w.rf>
   <form>50m2</form>
   <lemma>50m2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p9s4">
  <m id="m-ustecky45894.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s4W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s4W2</w.rf>
   <form>provádějí</form>
   <lemma>provádět_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s4W3</w.rf>
   <form>zasypávání</form>
   <lemma>zasypávání_^(*5at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s4W4</w.rf>
   <form>nafty</form>
   <lemma>nafta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s4W5</w.rf>
   <form>sorbentem</form>
   <lemma>sorbent</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p9s5">
  <m id="m-ustecky45894.txt-001-p9s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W4</w.rf>
   <form>dostavila</form>
   <lemma>dostavit_:W_^(se)_(na_dané_místo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W5</w.rf>
   <form>pracovnice</form>
   <lemma>pracovnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W6</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W7</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W8</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W9</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W10</w.rf>
   <form>Litvínov</form>
   <lemma>Litvínov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p9s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p9s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p10s1">
  <m id="m-ustecky45894.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p10s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p10s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p10s1W3</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p11s1">
  <m id="m-ustecky45894.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p11s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p12s1">
  <m id="m-ustecky45894.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s1W1</w.rf>
   <form>12.4</form>
   <form_change>num_normalization</form_change>
   <lemma>12.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p12s2">
  <m id="m-ustecky45894.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W1</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W2</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W4</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W7</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W9</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W10</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W11</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W12</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W13</w.rf>
   <form>Chomutov</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W14</w.rf>
   <form>likvidovala</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W15</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W16</w.rf>
   <form>plastového</form>
   <lemma>plastový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W17</w.rf>
   <form>kontejneru</form>
   <lemma>kontejner</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W19</w.rf>
   <form>Školní</form>
   <lemma>školní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W20</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W22</w.rf>
   <form>Chomutově</form>
   <lemma>Chomutov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p12s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p12s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p13s1">
  <m id="m-ustecky45894.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p13s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p13s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p13s1W3</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p14s1">
  <m id="m-ustecky45894.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p14s1W1</w.rf>
   <form>Únik</form>
   <lemma>únik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p14s1W2</w.rf>
   <form>plynu</form>
   <lemma>plyn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p14s1W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p14s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p14s1W4</w.rf>
   <form>čpavek</form>
   <lemma>čpavek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p14s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p14s1W5</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s1">
  <m id="m-ustecky45894.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s1W1</w.rf>
   <form>11.4</form>
   <form_change>num_normalization</form_change>
   <lemma>11.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s2">
  <m id="m-ustecky45894.txt-001-p15s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s2W1</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s2W3</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s2W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s2W5</w.rf>
   <form>12.4</form>
   <form_change>num_normalization</form_change>
   <lemma>12.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s2W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s3">
  <m id="m-ustecky45894.txt-001-p15s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W1</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W3</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W4</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W5</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W7</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W8</w.rf>
   <form>Roudnice</form>
   <lemma>Roudnice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W9</w.rf>
   <form>n.L</form>
   <lemma>n.L</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W12</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W13</w.rf>
   <form>CPS</form>
   <lemma>CPS-1_:B_;R_,t_^(Central_Point_Software)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W14</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W15</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W17</w.rf>
   <form>masokombinátu</form>
   <lemma>masokombinát</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W19</w.rf>
   <form>Chelčického</form>
   <lemma>Chelčický_;S</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W20</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W22</w.rf>
   <form>Roudnici</form>
   <lemma>Roudnice_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W23</w.rf>
   <form>n.L</form>
   <lemma>n.L</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s4">
  <m id="m-ustecky45894.txt-001-p15s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s4W1</w.rf>
   <form>Unikl</form>
   <lemma>uniknout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s4W2</w.rf>
   <form>čpavek</form>
   <lemma>čpavek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s4W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s4W4</w.rf>
   <form>rozvodu</form>
   <lemma>rozvod-1_^(manželství)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s4W5</w.rf>
   <form>výměníku</form>
   <lemma>výměník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s5">
  <m id="m-ustecky45894.txt-001-p15s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W1</w.rf>
   <form>Uniklý</form>
   <lemma>uniklý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W2</w.rf>
   <form>plyn</form>
   <lemma>plyn</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W3</w.rf>
   <form>zasáhl</form>
   <lemma>zasáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W4</w.rf>
   <form>prostor</form>
   <lemma>prostor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W5</w.rf>
   <form>chladírny</form>
   <lemma>chladírna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W7</w.rf>
   <form>bourárny</form>
   <lemma>bourárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W8</w.rf>
   <form>hovězího</form>
   <lemma>hovězí</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W9</w.rf>
   <form>masa</form>
   <lemma>maso_^(jídlo_apod.)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s5W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s6">
  <m id="m-ustecky45894.txt-001-p15s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s6W1</w.rf>
   <form>Zaměstnanci</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s6W2</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s6W3</w.rf>
   <form>příjezdem</form>
   <lemma>příjezd</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s6W4</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s6W5</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s6W6</w.rf>
   <form>uzavření</form>
   <lemma>uzavření_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s6W7</w.rf>
   <form>ventilu</form>
   <lemma>ventil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s7">
  <m id="m-ustecky45894.txt-001-p15s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W2</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W3</w.rf>
   <form>zkrápěly</form>
   <lemma>zkrápět_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W4</w.rf>
   <form>čpavkový</form>
   <lemma>čpavkový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W5</w.rf>
   <form>mrak</form>
   <lemma>mrak</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W7</w.rf>
   <form>odvětraly</form>
   <lemma>odvětrat_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W8</w.rf>
   <form>prostory</form>
   <lemma>prostora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s7W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s8">
  <m id="m-ustecky45894.txt-001-p15s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W1</w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W2</w.rf>
   <form>provedeno</form>
   <lemma>provést</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W3</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W4</w.rf>
   <form>kontrolních</form>
   <lemma>kontrolní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W5</w.rf>
   <form>měření</form>
   <lemma>měření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W7</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W8</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W10</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W11</w.rf>
   <form>hranicí</form>
   <lemma>hranice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W12</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W15</w.rf>
   <form>městské</form>
   <lemma>městský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W16</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W17</w.rf>
   <form>Bezděkov</form>
   <lemma>Bezděkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s8W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s9">
  <m id="m-ustecky45894.txt-001-p15s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W1</w.rf>
   <form>Naměřené</form>
   <lemma>naměřený_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W2</w.rf>
   <form>hodnoty</form>
   <lemma>hodnota</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W4</w.rf>
   <form>podlimitní</form>
   <lemma>podlimitní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W6</w.rf>
   <form>obyvatelé</form>
   <lemma>obyvatel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W7</w.rf>
   <form>nebyli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W8</w.rf>
   <form>ohroženi</form>
   <lemma>ohrozit</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s9W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s10">
  <m id="m-ustecky45894.txt-001-p15s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W4</w.rf>
   <form>dostavil</form>
   <lemma>dostavit_:W_^(se)_(na_dané_místo)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W5</w.rf>
   <form>technický</form>
   <lemma>technický</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W6</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W7</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W9</w.rf>
   <form>zástupce</form>
   <lemma>zástupce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W10</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W11</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W13</w.rf>
   <form>starosta</form>
   <lemma>starosta</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W14</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s10W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s11">
  <m id="m-ustecky45894.txt-001-p15s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W2</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W3</w.rf>
   <form>spolupracovaly</form>
   <lemma>spolupracovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W4</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W5</w.rf>
   <form>policií</form>
   <lemma>policie</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W6</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W8</w.rf>
   <form>městskou</form>
   <lemma>městský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W9</w.rf>
   <form>policií</form>
   <lemma>policie</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s11W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s11W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ustecky45894.txt-001-p15s12">
  <m id="m-ustecky45894.txt-001-p15s12W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W1</w.rf>
   <form>Čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W2</w.rf>
   <form>zaměstnanci</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W3</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W5</w.rf>
   <form>čpavku</form>
   <lemma>čpavek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W6</w.rf>
   <form>nadýchali</form>
   <lemma>nadýchat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W8</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W10</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W11</w.rf>
   <form>zůstali</form>
   <lemma>zůstat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W13</w.rf>
   <form>péči</form>
   <lemma>péče</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W14</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W15</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W16</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ustecky45894.txt-001-p15s12W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-ustecky45894.txt-001-p15s12W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
