<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky50068.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky50068.txt-001-p1s1">
  <m id="m-plzensky50068.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W1</w.rf>
   <form>Spolupořadateli</form>
   <lemma>spolupořadatel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W2</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W3</w.rf>
   <form>pořádané</form>
   <lemma>pořádaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W4</w.rf>
   <form>Hasičským</form>
   <lemma>hasičský</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W5</w.rf>
   <form>záchranným</form>
   <lemma>záchranný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W6</w.rf>
   <form>sborem</form>
   <lemma>sbor</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W7</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W8</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W10</w.rf>
   <form>územním</form>
   <lemma>územní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W11</w.rf>
   <form>odborem</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W12</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W14</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W15</w.rf>
   <form>MěÚ</form>
   <lemma>MěÚ-1_:B_^(městský_úřad)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W16</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W18</w.rf>
   <form>okresní</form>
   <lemma>okresní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W19</w.rf>
   <form>ředitelství</form>
   <lemma>ředitelství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W20</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W21</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W22</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W24</w.rf>
   <form>ZZS</form>
   <lemma>Zzs</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W25</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W26</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W28</w.rf>
   <form>ZŠ</form>
   <lemma>ZŠ_:B_^(základní_škola)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W29</w.rf>
   <form>T.G</form>
   <lemma>T.galsko</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W31</w.rf>
   <form>Masaryka</form>
   <lemma>Masaryk_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W32</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycana_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W33</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W34</w.rf>
   <form>ČČK</form>
   <lemma>ČČK_:B_;K</lemma>
   <tag>Xx-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W35</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s1W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p1s2">
  <m id="m-plzensky50068.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W1</w.rf>
   <form>Cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W2</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W4</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W5</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W6</w.rf>
   <form>školám</form>
   <lemma>škola</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W7</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W8</w.rf>
   <form>plnění</form>
   <lemma>plnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W9</w.rf>
   <form>pokynu</form>
   <lemma>pokyn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W10</w.rf>
   <form>MŠMT</form>
   <lemma>MŠMT_:B_;K_;p_;u_;w_^(Ministerstvo_školství_mládeže_a_tělovýchovy)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W12</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W13</w.rf>
   <form>2003</form>
   <lemma>2003</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W15</w.rf>
   <form>začlenění</form>
   <lemma>začlenění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W16</w.rf>
   <form>tématiky</form>
   <lemma>tématika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W19</w.rf>
   <form>Ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W20</w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W21</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W22</w.rf>
   <form>mimořádných</form>
   <lemma>mimořádný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W23</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W24</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W25</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W26</w.rf>
   <form>vzdělávacích</form>
   <lemma>vzdělávací_^(*5at)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W27</w.rf>
   <form>programů</form>
   <lemma>program-1</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W29</w.rf>
   <form>doplnění</form>
   <lemma>doplnění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W30</w.rf>
   <form>probíhajícího</form>
   <lemma>probíhající_^(*4t)</lemma>
   <tag>AGNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W31</w.rf>
   <form>školení</form>
   <lemma>školení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W32</w.rf>
   <form>učitelů</form>
   <lemma>učitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W33</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W34</w.rf>
   <form>oslovení</form>
   <lemma>oslovení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W35</w.rf>
   <form>dětské</form>
   <lemma>dětský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W36</w.rf>
   <form>populace</form>
   <lemma>populace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W37</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W38</w.rf>
   <form>doplnění</form>
   <lemma>doplnění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W39</w.rf>
   <form>výkladu</form>
   <lemma>výklad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W40</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W41</w.rf>
   <form>uvedené</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W42</w.rf>
   <form>problematiky</form>
   <lemma>problematika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W43</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W44</w.rf>
   <form>praktickou</form>
   <lemma>praktický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W45</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p1s2W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p1s2W46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p2s1">
  <m id="m-plzensky50068.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W1</w.rf>
   <form>Klání</form>
   <lemma>klání_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W3</w.rf>
   <form>zúčastnila</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W4</w.rf>
   <form>čtyřčlenná</form>
   <lemma>čtyřčlenný</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W5</w.rf>
   <form>družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W6</w.rf>
   <form>žáků</form>
   <lemma>žák</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W7</w.rf>
   <form>šestých</form>
   <lemma>šestý</lemma>
   <tag>CrFP2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W8</w.rf>
   <form>tříd</form>
   <lemma>třída</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W11</w.rf>
   <form>jednom</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W12</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W13</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W14</w.rf>
   <form>pátých</form>
   <lemma>pátý</lemma>
   <tag>CrMP2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W15</w.rf>
   <form>tříd</form>
   <lemma>třída</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W16</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W17</w.rf>
   <form>sedmi</form>
   <lemma>sedm`7</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W18</w.rf>
   <form>základních</form>
   <lemma>základní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W19</w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W20</w.rf>
   <form>okresu</form>
   <lemma>okres</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W21</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p2s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p3s1">
  <m id="m-plzensky50068.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W1</w.rf>
   <form>Soutěžní</form>
   <lemma>soutěžní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W2</w.rf>
   <form>družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W3</w.rf>
   <form>plnila</form>
   <lemma>plnit_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W4</w.rf>
   <form>úkoly</form>
   <lemma>úkol</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W6</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W7</w.rf>
   <form>sedmi</form>
   <lemma>sedm`7</lemma>
   <tag>Cn-P6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W8</w.rf>
   <form>stanovištích</form>
   <lemma>stanoviště</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W9</w.rf>
   <form>související</form>
   <lemma>související_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W10</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W11</w.rf>
   <form>ochranou</form>
   <lemma>ochrana</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W12</w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W13</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W14</w.rf>
   <form>mimořádných</form>
   <lemma>mimořádný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W15</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p3s2">
  <m id="m-plzensky50068.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s2W2</w.rf>
   <form>prvním</form>
   <lemma>první</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s2W3</w.rf>
   <form>čekal</form>
   <lemma>čekat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s2W4</w.rf>
   <form>soutěžící</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s2W5</w.rf>
   <form>znalostní</form>
   <lemma>znalostní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s2W6</w.rf>
   <form>test</form>
   <lemma>test</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p3s3">
  <m id="m-plzensky50068.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W2</w.rf>
   <form>druhém</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W3</w.rf>
   <form>stanovišti</form>
   <lemma>stanoviště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W4</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W5</w.rf>
   <form>absolvovaly</form>
   <lemma>absolvovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W6</w.rf>
   <form>prověrku</form>
   <lemma>prověrka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W7</w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W8</w.rf>
   <form>varovného</form>
   <lemma>varovný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W9</w.rf>
   <form>signálu</form>
   <lemma>signál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W11</w.rf>
   <form>prověrku</form>
   <lemma>prověrka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W12</w.rf>
   <form>znalostí</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W13</w.rf>
   <form>chování</form>
   <lemma>chování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W14</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W15</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W17</w.rf>
   <form>prověrku</form>
   <lemma>prověrka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W18</w.rf>
   <form>znalostí</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W19</w.rf>
   <form>hasících</form>
   <lemma>hasící_^(*3it)</lemma>
   <tag>AGIP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W20</w.rf>
   <form>přístrojů</form>
   <lemma>přístroj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W22</w.rf>
   <form>hydrantů</form>
   <lemma>hydrant</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s3W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p3s4">
  <m id="m-plzensky50068.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W2</w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrNS6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W3</w.rf>
   <form>stanovišti</form>
   <lemma>stanoviště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W4</w.rf>
   <form>soutěžící</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGMP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W5</w.rf>
   <form>plnili</form>
   <lemma>plnit_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W6</w.rf>
   <form>úkoly</form>
   <lemma>úkol</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W7</w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W8</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W9</w.rf>
   <form>ochranou</form>
   <lemma>ochrana</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W10</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W11</w.rf>
   <form>následky</form>
   <lemma>následek</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W12</w.rf>
   <form>živelních</form>
   <lemma>živelní_^(pohroma,...)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W13</w.rf>
   <form>pohrom</form>
   <lemma>pohroma</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W15</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W16</w.rf>
   <form>přípravy</form>
   <lemma>příprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W17</w.rf>
   <form>evakuačního</form>
   <lemma>evakuační</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W18</w.rf>
   <form>zavazadla</form>
   <lemma>zavazadlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W20</w.rf>
   <form>dodržení</form>
   <lemma>dodržení_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W21</w.rf>
   <form>zásad</form>
   <lemma>zásada</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W22</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W23</w.rf>
   <form>opuštění</form>
   <lemma>opuštění_^(*5stit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W24</w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W26</w.rf>
   <form>ohroženého</form>
   <lemma>ohrožený_^(*4zit)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W27</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s4W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p3s5">
  <m id="m-plzensky50068.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W2</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W3</w.rf>
   <form>stanovištích</form>
   <lemma>stanoviště</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W5</w.rf>
   <form>soutěžící</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGMP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W6</w.rf>
   <form>vyzkoušeli</form>
   <lemma>vyzkoušet_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W7</w.rf>
   <form>oznámení</form>
   <lemma>oznámení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W8</w.rf>
   <form>mimořádné</form>
   <lemma>mimořádný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W9</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W11</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W12</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W13</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W15</w.rf>
   <form>případně</form>
   <lemma>případně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W16</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W17</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W19</w.rf>
   <form>ZZS</form>
   <lemma>Zzs</lemma>
   <tag>NNISX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W21</w.rf>
   <form>problematiku</form>
   <lemma>problematika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W22</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W23</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W24</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W25</w.rf>
   <form>následky</form>
   <lemma>následek</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W26</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W27</w.rf>
   <form>nebezpečných</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFP2----1N----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W28</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W29</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W30</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W31</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W32</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W33</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W34</w.rf>
   <form>prostředků</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W35</w.rf>
   <form>improvizované</form>
   <lemma>improvizovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W36</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W37</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W38</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W39</w.rf>
   <form>poskytování</form>
   <lemma>poskytování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W40</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W41</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W42</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W43</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W44</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W45</w.rf>
   <form>nálezu</form>
   <lemma>nález</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W46</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W47</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W48</w.rf>
   <form>obdržení</form>
   <lemma>obdržení_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W49</w.rf>
   <form>podezřelého</form>
   <lemma>podezřelý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W50</w.rf>
   <form>předmětu</form>
   <lemma>předmět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W51</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W52</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W53</w.rf>
   <form>anonymní</form>
   <lemma>anonymní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W54</w.rf>
   <form>hrozbě</form>
   <lemma>hrozba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W55</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W56-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W56</w.rf>
   <form>výbušniny</form>
   <lemma>výbušnina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s5W57-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s5W57</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p3s6">
  <m id="m-plzensky50068.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W1</w.rf>
   <form>Organizátoři</form>
   <lemma>organizátor</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W2</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W3</w.rf>
   <form>nezapomněli</form>
   <lemma>zapomenout</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W4</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W6</w.rf>
   <form>otázky</form>
   <lemma>otázka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W7</w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W8</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W9</w.rf>
   <form>integrovaným</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W10</w.rf>
   <form>záchranným</form>
   <lemma>záchranný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W11</w.rf>
   <form>systémem</form>
   <lemma>systém</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W13</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W14</w.rf>
   <form>fungováním</form>
   <lemma>fungování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p3s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p3s6W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p4s1">
  <m id="m-plzensky50068.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s1W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s1W2</w.rf>
   <form>prokázaly</form>
   <lemma>prokázat</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s1W3</w.rf>
   <form>kvalitní</form>
   <lemma>kvalitní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s1W4</w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p4s2">
  <m id="m-plzensky50068.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s2W1</w.rf>
   <form>Největší</form>
   <lemma>velký</lemma>
   <tag>AAIP1----3A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s2W2</w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s2W3</w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PPXP3--3-------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s2W4</w.rf>
   <form>činilo</form>
   <lemma>činit_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s2W5</w.rf>
   <form>poskytování</form>
   <lemma>poskytování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s2W6</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s2W7</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p4s3">
  <m id="m-plzensky50068.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s3W1</w.rf>
   <form>Měly</form>
   <lemma>mít</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s3W2</w.rf>
   <form>ošetřit</form>
   <lemma>ošetřit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s3W3</w.rf>
   <form>popáleninu</form>
   <lemma>popálenina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s3W4</w.rf>
   <form>ruky</form>
   <lemma>ruka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s3W5</w.rf>
   <form>horkou</form>
   <lemma>horký</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s3W6</w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p4s4">
  <m id="m-plzensky50068.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W1</w.rf>
   <form>Figurantka</form>
   <lemma>figurantka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W3</w.rf>
   <form>ČCK</form>
   <lemma>Čck</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W4</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W5</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W6</w.rf>
   <form>výborně</form>
   <lemma>výborně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W7</w.rf>
   <form>nalíčená</form>
   <lemma>nalíčený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W9</w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W10</w.rf>
   <form>skvěle</form>
   <lemma>skvěle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W11</w.rf>
   <form>sehrála</form>
   <lemma>sehrát</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W12</w.rf>
   <form>opařenou</form>
   <lemma>opařený_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W13</w.rf>
   <form>osobu</form>
   <lemma>osoba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W15</w.rf>
   <form>šoku</form>
   <lemma>šok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s4W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p4s5">
  <m id="m-plzensky50068.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s5W1</w.rf>
   <form>Body</form>
   <lemma>Body_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s5W2</w.rf>
   <form>ztrácely</form>
   <lemma>ztrácet_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s5W3</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s5W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s5W5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s5W6</w.rf>
   <form>znalostním</form>
   <lemma>znalostní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s5W7</w.rf>
   <form>testu</form>
   <lemma>test</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p4s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p5s1">
  <m id="m-plzensky50068.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s1W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s1W2</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s1W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s1W4</w.rf>
   <form>připraven</form>
   <lemma>připravit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s1W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s1W6</w.rf>
   <form>doprovodný</form>
   <lemma>doprovodný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s1W7</w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p5s2">
  <m id="m-plzensky50068.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W1</w.rf>
   <form>Účastníci</form>
   <lemma>účastník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W2</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W4</w.rf>
   <form>mohli</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W5</w.rf>
   <form>prohlédnout</form>
   <lemma>prohlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W6</w.rf>
   <form>autojeřáb</form>
   <lemma>autojeřáb</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W8</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W9</w.rf>
   <form>techniku</form>
   <lemma>technika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W10</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W11</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W13</w.rf>
   <form>někteří</form>
   <lemma>některý</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W15</w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W16</w.rf>
   <form>svezli</form>
   <lemma>svézt</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W17</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W18</w.rf>
   <form>tyči</form>
   <lemma>tyč</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W20</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W21</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W22</w.rf>
   <form>sjíždějí</form>
   <lemma>sjíždět_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W23</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W25</w.rf>
   <form>jedou-li</form>
   <lemma>jedou-li</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W26</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W27</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p5s3">
  <m id="m-plzensky50068.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W2</w.rf>
   <form>dispozici</form>
   <lemma>dispozice</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W5</w.rf>
   <form>počátku</form>
   <lemma>počátek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W7</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W8</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W9</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p5s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p6s1">
  <m id="m-plzensky50068.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W1</w.rf>
   <form>Ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W2</w.rf>
   <form>dětem</form>
   <lemma>dítě</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W3</w.rf>
   <form>předával</form>
   <lemma>předávat-1_:T_,a_^(příst)_(*6at-1)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W4</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W6</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W7</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W9</w.rf>
   <form>územního</form>
   <lemma>územní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W10</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W11</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W12</w.rf>
   <form>plk</form>
   <lemma>plukovník_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p6s2">
  <m id="m-plzensky50068.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s2W1</w.rf>
   <form>Dr.</form>
   <lemma>doktor_:B_,x_^(doktor,_akad._titul)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s2W2</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s2W3</w.rf>
   <form>Špelina</form>
   <lemma>Špelina_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s2W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s2W5</w.rf>
   <form>mjr</form>
   <lemma>major_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s2W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p6s3">
  <m id="m-plzensky50068.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s3W1</w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s3W2</w.rf>
   <form>Šnaiberk</form>
   <lemma>Šnaiberk_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s3W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p6s4">
  <m id="m-plzensky50068.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W1</w.rf>
   <form>Vítězem</form>
   <lemma>vítěz</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W2</w.rf>
   <form>okresního</form>
   <lemma>okresní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W3</w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W5</w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W6</w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W7</w.rf>
   <form>Základní</form>
   <lemma>základní_,s</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W8</w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W10</w.rf>
   <form>Mateřské</form>
   <lemma>mateřský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W11</w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W12</w.rf>
   <form>Stupno</form>
   <lemma>Stupno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W14</w.rf>
   <form>složení</form>
   <lemma>složení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W15</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W16</w.rf>
   <form>Dominik</form>
   <lemma>Dominik_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W17</w.rf>
   <form>Pastorál</form>
   <lemma>pastorála</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W19</w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W20</w.rf>
   <form>Čagánek</form>
   <lemma>Čagánek_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W22</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W23</w.rf>
   <form>Procházka</form>
   <lemma>Procházka_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W25</w.rf>
   <form>Jakub</form>
   <lemma>Jakub_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W26</w.rf>
   <form>Vais</form>
   <lemma>Vais</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s4W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p6s5">
  <m id="m-plzensky50068.txt-001-p6s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W1</w.rf>
   <form>Druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W2</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W3</w.rf>
   <form>obsadilo</form>
   <lemma>obsadit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W4</w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W5</w.rf>
   <form>ZŠ</form>
   <lemma>ZŠ_:B_^(základní_škola)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W6</w.rf>
   <form>Strašice</form>
   <lemma>Strašice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W8</w.rf>
   <form>složení</form>
   <lemma>složení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W9</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W10</w.rf>
   <form>Kamila</form>
   <lemma>Kamila_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W11</w.rf>
   <form>Dragounová</form>
   <lemma>Dragounová_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W13</w.rf>
   <form>Lucie</form>
   <lemma>Lucie-1_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W14</w.rf>
   <form>Plimlová</form>
   <lemma>Plimlová_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W16</w.rf>
   <form>Kateřina</form>
   <lemma>Kateřina_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W17</w.rf>
   <form>Sazimová</form>
   <lemma>Sazim</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W19</w.rf>
   <form>Eduard</form>
   <lemma>Eduard_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W20</w.rf>
   <form>Hubl</form>
   <lemma>hubnout_:T</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s5W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p6s6">
  <m id="m-plzensky50068.txt-001-p6s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W2</w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrNS6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W3</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W4</w.rf>
   <form>skončila</form>
   <lemma>skončit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W5</w.rf>
   <form>ZŠ</form>
   <lemma>ZŠ_:B_^(základní_škola)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W6</w.rf>
   <form>Mirošov</form>
   <lemma>Mirošov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W8</w.rf>
   <form>čtvrtá</form>
   <lemma>čtvrtý</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W9</w.rf>
   <form>ZŠ</form>
   <lemma>ZŠ_:B_^(základní_škola)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W10</w.rf>
   <form>Osek</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W12</w.rf>
   <form>pátá</form>
   <lemma>pátý</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W13</w.rf>
   <form>ZŠ</form>
   <lemma>ZŠ_:B_^(základní_škola)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W14</w.rf>
   <form>Volduchy</form>
   <lemma>Volduchy_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W16</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s6W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p6s7">
  <m id="m-plzensky50068.txt-001-p6s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W1</w.rf>
   <form>ZŠ</form>
   <lemma>ZŠ_:B_^(základní_škola)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W2</w.rf>
   <form>TGM</form>
   <lemma>TGM_:B_;S</lemma>
   <tag>Xx-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W3</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W5</w.rf>
   <form>sedmá</form>
   <lemma>sedmý</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W6</w.rf>
   <form>ZŠ</form>
   <lemma>ZŠ_:B_^(základní_škola)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W7</w.rf>
   <form>Čechova</form>
   <lemma>Čechův-1_;E_^(*4-1)</lemma>
   <tag>AUIS2M---------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W8</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycana_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s7W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p6s8">
  <m id="m-plzensky50068.txt-001-p6s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W1</w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W2</w.rf>
   <form>účastníci</form>
   <lemma>účastník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W4</w.rf>
   <form>odnesli</form>
   <lemma>odnést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W5</w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W6</w.rf>
   <form>pozornost</form>
   <lemma>pozornost-1_^(všímavý,_milý,_soustředěný)_(*5ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W8</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrIP1----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W9</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W10</w.rf>
   <form>týmy</form>
   <lemma>tým</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W11</w.rf>
   <form>získaly</form>
   <lemma>získat_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W12</w.rf>
   <form>hodnotné</form>
   <lemma>hodnotný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W13</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p6s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p6s8W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50068.txt-001-p7s1">
  <m id="m-plzensky50068.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W1</w.rf>
   <form>Dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W2</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrNP4----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W3</w.rf>
   <form>družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W5</w.rf>
   <form>zajistila</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W6</w.rf>
   <form>postup</form>
   <lemma>postup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W8</w.rf>
   <form>krajského</form>
   <lemma>krajský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W9</w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W10</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W11</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W12</w.rf>
   <form>Malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W13</w.rf>
   <form>záchranář</form>
   <lemma>záchranář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W14</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W16</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W17</w.rf>
   <form>2008</form>
   <lemma>2008</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky50068.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50068.txt-001-p7s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
