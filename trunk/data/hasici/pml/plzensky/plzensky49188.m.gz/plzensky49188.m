<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49188.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49188.txt-001-p1s1">
  <m id="m-plzensky49188.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W2</w.rf>
   <form>pořádá</form>
   <lemma>pořádat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W3</w.rf>
   <form>Hasičská</form>
   <lemma>hasičský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W4</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W5</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W6</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W7</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W8</w.rf>
   <form>dráhy</form>
   <lemma>dráha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W9</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p1s2">
  <m id="m-plzensky49188.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s2W1</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s2W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p1s3">
  <m id="m-plzensky49188.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s3W1</w.rf>
   <form>Přihlášeno</form>
   <lemma>přihlásit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s3W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s3W3</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s3W4</w.rf>
   <form>soutěžních</form>
   <lemma>soutěžní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s3W5</w.rf>
   <form>týmů</form>
   <lemma>tým</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p1s4">
  <m id="m-plzensky49188.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W2</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W3</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W6</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W7</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W8</w.rf>
   <form>zařazeno</form>
   <lemma>zařadit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W9</w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W10</w.rf>
   <form>závodů</form>
   <lemma>závod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p1s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p2s1">
  <m id="m-plzensky49188.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W1</w.rf>
   <form>Soutěžní</form>
   <lemma>soutěžní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W2</w.rf>
   <form>klání</form>
   <lemma>klání_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W4</w.rf>
   <form>fotbalovém</form>
   <lemma>fotbalový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W5</w.rf>
   <form>stadionu</form>
   <lemma>stadión</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W6</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W7</w.rf>
   <form>zahájeno</form>
   <lemma>zahájit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W8</w.rf>
   <form>nástupem</form>
   <lemma>nástup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W9</w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W10</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W11</w.rf>
   <form>13.00</form>
   <form_change>num_normalization</form_change>
   <lemma>13.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W12</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W14</w.rf>
   <form>Úkolem</form>
   <lemma>úkol</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W15</w.rf>
   <form>sedmičlenných</form>
   <lemma>sedmičlenný</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W16</w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W17</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W18</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W19</w.rf>
   <form>stručnosti</form>
   <lemma>stručnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W20</w.rf>
   <form>řečeno</form>
   <lemma>říci</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W22</w.rf>
   <form>co</form>
   <lemma>co-5_^(př._co_nejméně,_co_nevidět,_co_chvíli,_co_do_počtu,_atd.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W23</w.rf>
   <form>nejrychleji</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W24</w.rf>
   <form>natáhnout</form>
   <lemma>natáhnout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W25</w.rf>
   <form>hadicové</form>
   <lemma>hadicový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W26</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W27</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W28</w.rf>
   <form>vzdálenost</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W29</w.rf>
   <form>90</form>
   <lemma>90</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W30</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W31</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W32</w.rf>
   <form>nastříkat</form>
   <lemma>nastříkat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W33</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W34</w.rf>
   <form>elektronických</form>
   <lemma>elektronický</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W35</w.rf>
   <form>terčů</form>
   <lemma>terč</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W36</w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W37</w.rf>
   <form>litrů</form>
   <lemma>l-1`litr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W38</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W39</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W40</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W41</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W42</w.rf>
   <form>stříkačky</form>
   <lemma>stříkačka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W43</w.rf>
   <form>PS</form>
   <lemma>PS-1_:B_;K_^(Pohraniční_stráž)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W44</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s1W45</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p2s2">
  <m id="m-plzensky49188.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W2</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W3</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W5</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W6</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W7</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W9</w.rf>
   <form>Plzeňském</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W10</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W11</w.rf>
   <form>konal</form>
   <lemma>konat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W13</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W15</w.rf>
   <form>Domažlicích</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p2s3">
  <m id="m-plzensky49188.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W1</w.rf>
   <form>Vítězství</form>
   <lemma>vítězství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W3</w.rf>
   <form>Domažlic</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W4</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W5</w.rf>
   <form>obhajovat</form>
   <lemma>obhajovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W6</w.rf>
   <form>příslušníci</form>
   <lemma>příslušník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W7</w.rf>
   <form>územního</form>
   <lemma>územní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W8</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W10</w.rf>
   <form>Domažlice</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W12</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W14</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W15</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W16</w.rf>
   <form>zvítězili</form>
   <lemma>zvítězit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W18</w.rf>
   <form>časem</form>
   <lemma>čas</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W19</w.rf>
   <form>22.72</form>
   <form_change>num_normalization</form_change>
   <lemma>22.72</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W20</w.rf>
   <form>sekundy</form>
   <lemma>sekunda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p2s4">
  <m id="m-plzensky49188.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W1</w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W5</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W6</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W7</w.rf>
   <form>stali</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W8</w.rf>
   <form>celkovými</form>
   <lemma>celkový</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W9</w.rf>
   <form>vítězi</form>
   <lemma>vítěz</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W10</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W11</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W12</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W13</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W14</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W16</w.rf>
   <form>požárním</form>
   <lemma>požární</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W17</w.rf>
   <form>útoku</form>
   <lemma>útok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W18</w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W19</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W20</w.rf>
   <form>krajů</form>
   <lemma>kraj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W22</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W23</w.rf>
   <form>podniků</form>
   <lemma>podnik</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W24</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W26</w.rf>
   <form>získali</form>
   <lemma>získat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W27</w.rf>
   <form>putovní</form>
   <lemma>putovní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W28</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W29</w.rf>
   <form>generálního</form>
   <lemma>generální</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W30</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W31</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W32</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p2s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p2s4W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p3s1">
  <m id="m-plzensky49188.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W1</w.rf>
   <form>První</form>
   <lemma>první</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W2</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W3</w.rf>
   <form>započítávaný</form>
   <lemma>započítávaný_^(*5at)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W5</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W6</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W8</w.rf>
   <form>uskutečnil</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W9</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W11</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W12</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W14</w.rf>
   <form>Stochově</form>
   <lemma>Stochov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W16</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W17</w.rf>
   <form>pořadatelem</form>
   <lemma>pořadatel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W18</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W19</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W20</w.rf>
   <form>Středočeského</form>
   <lemma>středočeský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W21</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W23</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W24</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W25</w.rf>
   <form>Kladno</form>
   <lemma>Kladno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W27</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W28</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W29</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W30</w.rf>
   <form>uskuteční</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W31</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W33</w.rf>
   <form>června</form>
   <lemma>červen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W34</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W35</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W36</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W37</w.rf>
   <form>pořadatelem</form>
   <lemma>pořadatel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W38</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W39</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W40</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W41</w.rf>
   <form>AERO</form>
   <lemma>Aero-1_;K_^(letecká_továrna)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W42</w.rf>
   <form>a.s</form>
   <lemma>a.</lemma>
   <tag>NNMPX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s1W43</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p3s2">
  <m id="m-plzensky49188.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W1</w.rf>
   <form>Vodochody</form>
   <lemma>Vodochody_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W3</w.rf>
   <form>čtvrtý</form>
   <lemma>čtvrtý</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W4</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W6</w.rf>
   <form>uskuteční</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W7</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W9</w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W10</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W12</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W13</w.rf>
   <form>pořadatelem</form>
   <lemma>pořadatel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W14</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W15</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W16</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W17</w.rf>
   <form>BIOCEL</form>
   <lemma>Biocel_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W19</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p3s3">
  <m id="m-plzensky49188.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W1</w.rf>
   <form>Paskov</form>
   <lemma>Paskov_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W3</w.rf>
   <form>pátý</form>
   <lemma>pátý</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W4</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W6</w.rf>
   <form>uskuteční</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W7</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W9</w.rf>
   <form>října</form>
   <lemma>říjen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W10</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W12</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W13</w.rf>
   <form>pořadatelem</form>
   <lemma>pořadatel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W14</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W15</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W16</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W17</w.rf>
   <form>Vysočina</form>
   <lemma>vysočina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W19</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W20</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W21</w.rf>
   <form>Třebíč</form>
   <lemma>Třebíč_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p3s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p3s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p4s1">
  <m id="m-plzensky49188.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W2</w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W3</w.rf>
   <form>závodů</form>
   <lemma>závod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W4</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W5</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W7</w.rf>
   <form>družstvům</form>
   <lemma>družstvo</lemma>
   <tag>NNNP3-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W9</w.rf>
   <form>celkového</form>
   <lemma>celkový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W10</w.rf>
   <form>vyhodnocení</form>
   <lemma>vyhodnocení_^(*4tit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W11</w.rf>
   <form>započítávají</form>
   <lemma>započítávat_:T_^(*4at)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W12</w.rf>
   <form>body</form>
   <lemma>bod</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W13</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W14</w.rf>
   <form>čtyř</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W15</w.rf>
   <form>nejlepších</form>
   <lemma>dobrý</lemma>
   <tag>AAIP2----3A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W16</w.rf>
   <form>výsledků</form>
   <lemma>výsledek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p4s2">
  <m id="m-plzensky49188.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W1</w.rf>
   <form>Vítěz</form>
   <lemma>vítěz</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W2</w.rf>
   <form>převezme</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W3</w.rf>
   <form>putovní</form>
   <lemma>putovní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W4</w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W5</w.rf>
   <form>generálního</form>
   <lemma>generální</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W6</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W7</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W8</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p4s3">
  <m id="m-plzensky49188.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W1</w.rf>
   <form>Družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W3</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W5</w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W6</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W7</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W8</w.rf>
   <form>dosáhne</form>
   <lemma>dosáhnout</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W9</w.rf>
   <form>nejlepší</form>
   <lemma>dobrý</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W10</w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W12</w.rf>
   <form>obdrží</form>
   <lemma>obdržet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W13</w.rf>
   <form>cenu</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W14</w.rf>
   <form>prezidenta</form>
   <lemma>prezident</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W15</w.rf>
   <form>Asociace</form>
   <lemma>asociace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W16</w.rf>
   <form>velitelů</form>
   <lemma>velitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W17</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W18</w.rf>
   <form>podniků</form>
   <lemma>podnik</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s3W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p4s4">
  <m id="m-plzensky49188.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W2</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W3</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W4</w.rf>
   <form>12.30</form>
   <form_change>num_normalization</form_change>
   <lemma>12.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W6</w.rf>
   <form>13.00</form>
   <form_change>num_normalization</form_change>
   <lemma>13.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W9</w.rf>
   <form>představí</form>
   <lemma>představit-1_:W_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W10</w.rf>
   <form>malí</form>
   <lemma>malý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W14</w.rf>
   <form>Soptíci</form>
   <lemma>Soptíc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W15</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W17</w.rf>
   <form>Mateřské</form>
   <lemma>mateřský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W18</w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W19</w.rf>
   <form>Schwarzova</form>
   <lemma>Schwarzův_;S_^(*2)</lemma>
   <tag>AUIS2M---------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W21</w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W23</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W24</w.rf>
   <form>předvedou</form>
   <lemma>předvést</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W25</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W26</w.rf>
   <form>útok</form>
   <lemma>útok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s4W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49188.txt-001-p4s5">
  <m id="m-plzensky49188.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W1</w.rf>
   <form>Rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W3</w.rf>
   <form>přestávce</form>
   <lemma>přestávka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W4</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W5</w.rf>
   <form>prvním</form>
   <lemma>první</lemma>
   <tag>CrNS7----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W7</w.rf>
   <form>druhým</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W8</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W10</w.rf>
   <form>představí</form>
   <lemma>představit-1_:W_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W11</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W12</w.rf>
   <form>malí</form>
   <lemma>malý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W14</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W15</w.rf>
   <form>SDH</form>
   <lemma>Sdh</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W16</w.rf>
   <form>Bolevec</form>
   <lemma>Bolevec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49188.txt-001-p4s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49188.txt-001-p4s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
