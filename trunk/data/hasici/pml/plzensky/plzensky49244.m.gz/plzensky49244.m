<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49244.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49244.txt-001-p1s1">
  <m id="m-plzensky49244.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s1W1</w.rf>
   <form>Většina</form>
   <lemma>většina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s1W2</w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s1W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s1W4</w.rf>
   <form>větví</form>
   <lemma>větev</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s1W5</w.rf>
   <form>padla</form>
   <lemma>padnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s1W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s1W7</w.rf>
   <form>vozovky</form>
   <lemma>vozovka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s2">
  <m id="m-plzensky49244.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s2W1</w.rf>
   <form>Nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s2W2</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s2W3</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s2W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s3">
  <m id="m-plzensky49244.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W2</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W3</w.rf>
   <form>Petra</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W4</w.rf>
   <form>Jilemnického</form>
   <lemma>Jilemnický_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W6</w.rf>
   <form>Tachově</form>
   <lemma>Tachov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W7</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W8</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W10</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W11</w.rf>
   <form>vzrostlé</form>
   <lemma>vzrostlý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W12</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s4">
  <m id="m-plzensky49244.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W2</w.rf>
   <form>Mlýnce</form>
   <lemma>Mlýnec_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W5</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W7</w.rf>
   <form>Přimdu</form>
   <lemma>Přimda_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W8</w.rf>
   <form>padl</form>
   <lemma>padnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W9</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W10</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W11</w.rf>
   <form>dráty</form>
   <lemma>drát-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W12</w.rf>
   <form>telegrafního</form>
   <lemma>telegrafní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W13</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s4W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s5">
  <m id="m-plzensky49244.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W1</w.rf>
   <form>Strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W2</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W3</w.rf>
   <form>motorové</form>
   <lemma>motorový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W4</w.rf>
   <form>pily</form>
   <lemma>pila</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W5</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W6</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W9</w.rf>
   <form>Tachova</form>
   <lemma>Tachov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s5W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s6">
  <m id="m-plzensky49244.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W1</w.rf>
   <form>Zaznamenali</form>
   <lemma>zaznamenat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W2</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W4</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClIS4----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W5</w.rf>
   <form>případ</form>
   <lemma>případ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W7</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W8</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W9</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W10</w.rf>
   <form>pádu</form>
   <lemma>pád</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W11</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W13</w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W14</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s6W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s7">
  <m id="m-plzensky49244.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s7W1</w.rf>
   <form>Stalo</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s7W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s7W3</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s7W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s7W5</w.rf>
   <form>Kašperských</form>
   <lemma>kašperský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s7W6</w.rf>
   <form>Horách</form>
   <lemma>hora</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s7W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s8">
  <m id="m-plzensky49244.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s8W1</w.rf>
   <form>Řidička</form>
   <lemma>řidička_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s8W2</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s8W3</w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s8W4</w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s8W5</w.rf>
   <form>zraněna</form>
   <lemma>zranit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s8W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s9">
  <m id="m-plzensky49244.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s9W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s9W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s9W3</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s9W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s9W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s9W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s9W7</w.rf>
   <form>Sušice</form>
   <lemma>Sušice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s9W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s10">
  <m id="m-plzensky49244.txt-001-p1s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W2</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W3</w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W4</w.rf>
   <form>Vrchem</form>
   <lemma>vrchem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W6</w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W9</w.rf>
   <form>Lobzy</form>
   <lemma>Lobzy_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W10</w.rf>
   <form>vítr</form>
   <lemma>vítr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W11</w.rf>
   <form>utrhl</form>
   <lemma>utrhnout_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W12</w.rf>
   <form>plech</form>
   <lemma>plech</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W13</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W14</w.rf>
   <form>stříšky</form>
   <lemma>stříška</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W15</w.rf>
   <form>balkonu</form>
   <lemma>balkón_,x</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s10W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s11">
  <m id="m-plzensky49244.txt-001-p1s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s11W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s11W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s11W3</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s11W4</w.rf>
   <form>plzeňští</form>
   <lemma>plzeňský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s11W5</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s11W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s11W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49244.txt-001-p1s12">
  <m id="m-plzensky49244.txt-001-p1s12W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W2</w.rf>
   <form>Tachovsku</form>
   <lemma>Tachovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W4</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W5</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W6</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W7</w.rf>
   <form>čtyřem</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W8</w.rf>
   <form>událostem</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W11</w.rf>
   <form>Rokycansku</form>
   <lemma>Rokycansko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W12</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W13</w.rf>
   <form>třem</form>
   <lemma>tři`3</lemma>
   <tag>ClXP3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W16</w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W17</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W19</w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W20</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W21</w.rf>
   <form>třem</form>
   <lemma>tři`3</lemma>
   <tag>ClXP3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W24</w.rf>
   <form>Klatovsku</form>
   <lemma>Klatovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W25</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W26</w.rf>
   <form>třem</form>
   <lemma>tři`3</lemma>
   <tag>ClXP3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W28</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W29</w.rf>
   <form>Domažlicku</form>
   <lemma>Domažlicko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W30</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W31</w.rf>
   <form>čtyřem</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W33</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W34</w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W35</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W36</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W37</w.rf>
   <form>severu</form>
   <lemma>sever</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W38</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W39</w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>ClXP3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W40</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W41</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W42</w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W43</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W44</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W45</w.rf>
   <form>jihu</form>
   <lemma>jih</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W46</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W47</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS3----------</tag>
  </m>
  <m id="m-plzensky49244.txt-001-p1s12W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49244.txt-001-p1s12W48</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
