<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky50243.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky50243.txt-001-p1s1">
  <m id="m-plzensky50243.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s1W1</w.rf>
   <form>Kamion</form>
   <lemma>kamión</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s1W2</w.rf>
   <form>převážel</form>
   <lemma>převážet_:T_^(něco_někam_např._autem)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s1W3</w.rf>
   <form>zavařovací</form>
   <lemma>zavařovací_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s1W4</w.rf>
   <form>sklenice</form>
   <lemma>sklenice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s1W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s1W6</w.rf>
   <form>paletě</form>
   <lemma>paleta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s1W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s2">
  <m id="m-plzensky50243.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s2W1</w.rf>
   <form>Následkem</form>
   <lemma>následek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s2W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s2W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s2W4</w.rf>
   <form>tahač</form>
   <lemma>tahač</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s2W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s2W6</w.rf>
   <form>návěs</form>
   <lemma>návěs</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s2W7</w.rf>
   <form>převrátily</form>
   <lemma>převrátit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s3">
  <m id="m-plzensky50243.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W1</w.rf>
   <form>Tahač</form>
   <lemma>tahač</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W2</w.rf>
   <form>skončil</form>
   <lemma>skončit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W4</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W6</w.rf>
   <form>návěs</form>
   <lemma>návěs</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W7</w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W8</w.rf>
   <form>zasahoval</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W10</w.rf>
   <form>vozovky</form>
   <lemma>vozovka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s4">
  <m id="m-plzensky50243.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s4W1</w.rf>
   <form>Střepy</form>
   <lemma>střep</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s4W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s4W3</w.rf>
   <form>rozbitých</form>
   <lemma>rozbitý_^(*3ít)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s4W4</w.rf>
   <form>sklenic</form>
   <lemma>sklenice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s4W5</w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s4W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s4W7</w.rf>
   <form>vozovce</form>
   <lemma>vozovka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s5">
  <m id="m-plzensky50243.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W1</w.rf>
   <form>Kabina</form>
   <lemma>kabina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W3</w.rf>
   <form>vmáčklá</form>
   <lemma>vmáčklý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W5</w.rf>
   <form>straně</form>
   <lemma>strana-1_^(v_prostoru)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W6</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W8</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W10</w.rf>
   <form>zraněný</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W11</w.rf>
   <form>řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W12</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W13</w.rf>
   <form>zaklíněné</form>
   <lemma>zaklíněný_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W14</w.rf>
   <form>nohy</form>
   <lemma>noha</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W15</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W16</w.rf>
   <form>palubní</form>
   <lemma>palubní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W17</w.rf>
   <form>deskou</form>
   <lemma>deska</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s6">
  <m id="m-plzensky50243.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W5</w.rf>
   <form>ZZS</form>
   <lemma>Zzs</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W7</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W8</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s6W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s7">
  <m id="m-plzensky50243.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W2</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W3</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W4</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W6</w.rf>
   <form>odpojili</form>
   <lemma>odpojit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W7</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W8</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W9</w.rf>
   <form>akumulátor</form>
   <lemma>akumulátor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s7W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s8">
  <m id="m-plzensky50243.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W3</w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W4</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W5</w.rf>
   <form>povolán</form>
   <lemma>povolat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W6</w.rf>
   <form>autojeřáb</form>
   <lemma>autojeřáb</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W8</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W9</w.rf>
   <form>Košutka</form>
   <lemma>Košutka</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W11</w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W12</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W13</w.rf>
   <form>kabina</form>
   <lemma>kabina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W14</w.rf>
   <form>nadlehčena</form>
   <lemma>nadlehčit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W16</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W17</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W18</w.rf>
   <form>rozpínáku</form>
   <lemma>rozpínáek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W19</w.rf>
   <form>uvolnili</form>
   <lemma>uvolnit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W20</w.rf>
   <form>nohy</form>
   <lemma>noha</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W21</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W23</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W24</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W25</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W26</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W27</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W28</w.rf>
   <form>ZZS</form>
   <lemma>Zzs</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W29</w.rf>
   <form>vyndali</form>
   <lemma>vyndat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W30</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W31</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s8W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s8W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s9">
  <m id="m-plzensky50243.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W1</w.rf>
   <form>Řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W3</w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W4</w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W5</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W7</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W8</w.rf>
   <form>vědomí</form>
   <lemma>vědomí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W10</w.rf>
   <form>komunikoval</form>
   <lemma>komunikovat_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W12</w.rf>
   <form>záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s9W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s10">
  <m id="m-plzensky50243.txt-001-p1s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s10W1</w.rf>
   <form>Zraněného</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s10W2</w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s10W3</w.rf>
   <form>odvezla</form>
   <lemma>odvézt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s10W4</w.rf>
   <form>sanitka</form>
   <lemma>sanitka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s10W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s10W6</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s10W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s11">
  <m id="m-plzensky50243.txt-001-p1s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W2</w.rf>
   <form>současné</form>
   <lemma>současný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W3</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W4</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W7</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W8</w.rf>
   <form>nezasahují</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s11W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s11W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s12">
  <m id="m-plzensky50243.txt-001-p1s12W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s12W1</w.rf>
   <form>Následky</form>
   <lemma>následek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s12W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s12W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s12W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s12W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s12W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s12W4</w.rf>
   <form>odstraňovat</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s12W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s12W5</w.rf>
   <form>odtahová</form>
   <lemma>odtahový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s12W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s12W6</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s12W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s12W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s13">
  <m id="m-plzensky50243.txt-001-p1s13W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s13W1</w.rf>
   <form>Silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s13W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s13W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s13W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s13W3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s13W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s13W4</w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s13W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s13W5</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s13W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s13W6</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s13W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s13W7</w.rf>
   <form>uzavřena</form>
   <lemma>uzavřít</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s13W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s13W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50243.txt-001-p1s14">
  <m id="m-plzensky50243.txt-001-p1s14W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s14W1</w.rf>
   <form>Uvažuje</form>
   <lemma>uvažovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s14W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s14W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s14W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s14W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s14W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s14W4</w.rf>
   <form>zprůjezdnění</form>
   <lemma>zprůjezdnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s14W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s14W5</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS2----------</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s14W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s14W6</w.rf>
   <form>jízdního</form>
   <lemma>jízdní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s14W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s14W7</w.rf>
   <form>pruhu</form>
   <lemma>pruh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50243.txt-001-p1s14W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50243.txt-001-p1s14W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
