<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49036.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49036.txt-001-p1s1">
  <m id="m-plzensky49036.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W1</w.rf>
   <form>Soutěžit</form>
   <lemma>soutěžit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W5</w.rf>
   <form>výstupu</form>
   <lemma>výstup</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W7</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W9</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W10</w.rf>
   <form>cvičné</form>
   <lemma>cvičný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W11</w.rf>
   <form>věže</form>
   <lemma>věž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W14</w.rf>
   <form>běhu</form>
   <lemma>běh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W16</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W17</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W18</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W19</w.rf>
   <form>překážkami</form>
   <lemma>překážka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p1s2">
  <m id="m-plzensky49036.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W1</w.rf>
   <form>Ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W2</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W3</w.rf>
   <form>zahájením</form>
   <lemma>zahájení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W4</w.rf>
   <form>závodů</form>
   <lemma>závod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W5</w.rf>
   <form>odjede</form>
   <lemma>odjet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W7</w.rf>
   <form>8.30</form>
   <form_change>num_normalization</form_change>
   <lemma>8.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W9</w.rf>
   <form>delegace</form>
   <lemma>delegace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W10</w.rf>
   <form>účastníků</form>
   <lemma>účastník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W11</w.rf>
   <form>Memoriálu</form>
   <lemma>memoriál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W13</w.rf>
   <form>hrob</form>
   <lemma>hrob</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W14</w.rf>
   <form>Milana</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W15</w.rf>
   <form>Kružíka</form>
   <lemma>Kružík_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W17</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W18</w.rf>
   <form>položí</form>
   <lemma>položit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W19</w.rf>
   <form>kytici</form>
   <lemma>kytice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W20</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W21</w.rf>
   <form>uctění</form>
   <lemma>uctění_^(*3ít)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W22</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W23</w.rf>
   <form>památky</form>
   <lemma>památka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p1s3">
  <m id="m-plzensky49036.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W1</w.rf>
   <form>Závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W2</w.rf>
   <form>začne</form>
   <lemma>začít-1</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W4</w.rf>
   <form>8.45</form>
   <form_change>num_normalization</form_change>
   <lemma>8.45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W6</w.rf>
   <form>slavnostním</form>
   <lemma>slavnostní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W7</w.rf>
   <form>nástupem</form>
   <lemma>nástup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W8</w.rf>
   <form>závodníků</form>
   <lemma>závodník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W10</w.rf>
   <form>rozhodčích</form>
   <lemma>rozhodčí</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p1s4">
  <m id="m-plzensky49036.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W1</w.rf>
   <form>Přihlášeno</form>
   <lemma>přihlásit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W3</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W4</w.rf>
   <form>stovku</form>
   <lemma>stovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W5</w.rf>
   <form>závodníků</form>
   <lemma>závodník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W7</w.rf>
   <form>většiny</form>
   <lemma>většina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W8</w.rf>
   <form>krajů</form>
   <lemma>kraj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p1s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p2s1">
  <m id="m-plzensky49036.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W1</w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W2</w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W4</w.rf>
   <form>výstup</form>
   <lemma>výstup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W6</w.rf>
   <form>věž</form>
   <lemma>věž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W8</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W10</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W11</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClIS4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W12</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W13</w.rf>
   <form>sedmi</form>
   <lemma>sedm`7</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W14</w.rf>
   <form>závodů</form>
   <lemma>závod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W15</w.rf>
   <form>zařazených</form>
   <lemma>zařazený_^(*4dit)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W19</w.rf>
   <form>Ligy</form>
   <lemma>liga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W20</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W21</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W22</w.rf>
   <form>výstupu</form>
   <lemma>výstup</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W24</w.rf>
   <form>věž</form>
   <lemma>věž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W25</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W26</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p2s2">
  <m id="m-plzensky49036.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W1</w.rf>
   <form>Memoriál</form>
   <lemma>memoriál</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W2</w.rf>
   <form>pořádá</form>
   <lemma>pořádat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W3</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W4</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W5</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W7</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W8</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W9</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W11</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W12</w.rf>
   <form>pořadatelství</form>
   <lemma>pořadatelství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W13</w.rf>
   <form>převzal</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W14</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W15</w.rf>
   <form>Hasičském</form>
   <lemma>hasičský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W16</w.rf>
   <form>záchranném</form>
   <lemma>záchranný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W17</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W18</w.rf>
   <form>TA</form>
   <lemma>ten</lemma>
   <tag>PDNP1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W19</w.rf>
   <form>Služby</form>
   <lemma>služba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W21</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p2s3">
  <m id="m-plzensky49036.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s3W1</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s3W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p2s4">
  <m id="m-plzensky49036.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s4W1</w.rf>
   <form>Plzeňský</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s4W2</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s4W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s4W4</w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrNS7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s4W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s4W6</w.rf>
   <form>pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p2s5">
  <m id="m-plzensky49036.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W1</w.rf>
   <form>První</form>
   <lemma>první</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W2</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W4</w.rf>
   <form>uskuteční</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W5</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W7</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W9</w.rf>
   <form>Karlových</form>
   <lemma>Karlův_;Y_^(*3el)</lemma>
   <tag>AUIP6M---------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W10</w.rf>
   <form>Varech</form>
   <lemma>Vary_;G_^(Karlovy_Vary)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W12</w.rf>
   <form>druhý</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W13</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W14</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W16</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W18</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W19</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W20</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W22</w.rf>
   <form>čtvrtý</form>
   <lemma>čtvrtý</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W23</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W24</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W26</w.rf>
   <form>června</form>
   <lemma>červen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W28</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W29</w.rf>
   <form>Krchleby</form>
   <lemma>Krchleby_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W30</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W31</w.rf>
   <form>Čáslavi</form>
   <lemma>Čáslav_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W33</w.rf>
   <form>pátý</form>
   <lemma>pátý</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W34</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W36</w.rf>
   <form>června</form>
   <lemma>červen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W37</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W38</w.rf>
   <form>Českých</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W39</w.rf>
   <form>Budějovicích</form>
   <lemma>Budějovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W40</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W41</w.rf>
   <form>šestý</form>
   <lemma>šestý</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W42</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W43</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W44</w.rf>
   <form>srpna</form>
   <lemma>srpen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W45</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W46</w.rf>
   <form>Zlíně</form>
   <lemma>Zlín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W47</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W48</w.rf>
   <form>sedmý</form>
   <lemma>sedmý</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W49</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W50</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W51</w.rf>
   <form>srpna</form>
   <lemma>srpen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W52</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W53</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W54</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s5W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s5W55</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p2s6">
  <m id="m-plzensky49036.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W2</w.rf>
   <form>bodování</form>
   <lemma>bodování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W3</w.rf>
   <form>Ligy</form>
   <lemma>liga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W4</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W6</w.rf>
   <form>hodnotí</form>
   <lemma>hodnotit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W7</w.rf>
   <form>pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W8</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W9</w.rf>
   <form>prvních</form>
   <lemma>první</lemma>
   <tag>CrIP6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W10</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W11</w.rf>
   <form>pokusech</form>
   <lemma>pokus</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W13</w.rf>
   <form>výstupu</form>
   <lemma>výstup</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W15</w.rf>
   <form>cvičnou</form>
   <lemma>cvičný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W16</w.rf>
   <form>věž</form>
   <lemma>věž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W17</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W18</w.rf>
   <form>pravidel</form>
   <lemma>pravidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W19</w.rf>
   <form>požárního</form>
   <lemma>požární</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W20</w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p2s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p2s6W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p3s1">
  <m id="m-plzensky49036.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W3</w.rf>
   <form>běhu</form>
   <lemma>běh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W5</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W6</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W8</w.rf>
   <form>překážkami</form>
   <lemma>překážka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W9</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W10</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W11</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W12</w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p3s2">
  <m id="m-plzensky49036.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W1</w.rf>
   <form>Prvního</form>
   <lemma>první</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W3</w.rf>
   <form>zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W4</w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W5</w.rf>
   <form>přihlášení</form>
   <lemma>přihlášení_^(*4sit)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W7</w.rf>
   <form>druhého</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W8</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W9</w.rf>
   <form>nejrychlejších</form>
   <lemma>rychlý</lemma>
   <tag>AAMP2----3A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W10</w.rf>
   <form>závodníků</form>
   <lemma>závodník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W12</w.rf>
   <form>prvních</form>
   <lemma>první</lemma>
   <tag>CrIP2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W13</w.rf>
   <form>pokusů</form>
   <lemma>pokus</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p3s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p4s1">
  <m id="m-plzensky49036.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W1</w.rf>
   <form>Vítězství</form>
   <lemma>vítězství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W2</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W3</w.rf>
   <form>výstupu</form>
   <lemma>výstup</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W5</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W7</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W8</w.rf>
   <form>cvičné</form>
   <lemma>cvičný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W9</w.rf>
   <form>věže</form>
   <lemma>věž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W11</w.rf>
   <form>minulého</form>
   <lemma>minulý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W12</w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W13</w.rf>
   <form>Memoriálu</form>
   <lemma>memoriál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W14</w.rf>
   <form>Milana</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W15</w.rf>
   <form>Kružíka</form>
   <lemma>Kružík_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W16</w.rf>
   <form>obhajuje</form>
   <lemma>obhajovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W17</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W18</w.rf>
   <form>Neubert</form>
   <lemma>Neubert_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W20</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W21</w.rf>
   <form>Středočeského</form>
   <lemma>středočeský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W22</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W24</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W25</w.rf>
   <form>Jílové</form>
   <lemma>jílový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W26</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W27</w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W29</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W30</w.rf>
   <form>časem</form>
   <lemma>čas</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W31</w.rf>
   <form>14.17</form>
   <form_change>num_normalization</form_change>
   <lemma>14.17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W32</w.rf>
   <form>sekundy</form>
   <lemma>sekunda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s1W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p4s2">
  <m id="m-plzensky49036.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W1</w.rf>
   <form>Příslušník</form>
   <lemma>příslušník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W2</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W3</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W4</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W6</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W7</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W8</w.rf>
   <form>Domažlice</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W10</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W11</w.rf>
   <form>Hrdlička</form>
   <lemma>Hrdlička-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W13</w.rf>
   <form>časem</form>
   <lemma>čas</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W14</w.rf>
   <form>14.55</form>
   <form_change>num_normalization</form_change>
   <lemma>14.55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W15</w.rf>
   <form>sekundy</form>
   <lemma>sekunda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W16</w.rf>
   <form>skončil</form>
   <lemma>skončit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W17</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p4s3">
  <m id="m-plzensky49036.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W1</w.rf>
   <form>Stal</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W3</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W4</w.rf>
   <form>celkovým</form>
   <lemma>celkový</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W5</w.rf>
   <form>vítězem</form>
   <lemma>vítěz</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W8</w.rf>
   <form>Ligy</form>
   <lemma>liga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W9</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W10</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W11</w.rf>
   <form>výstupu</form>
   <lemma>výstup</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W13</w.rf>
   <form>věž</form>
   <lemma>věž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W14</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W15</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p4s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p5s1">
  <m id="m-plzensky49036.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W2</w.rf>
   <form>běhu</form>
   <lemma>běh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W4</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W5</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W6</w.rf>
   <form>vítězství</form>
   <lemma>vítězství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W8</w.rf>
   <form>loňského</form>
   <lemma>loňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W9</w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W10</w.rf>
   <form>Memoriálu</form>
   <lemma>memoriál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W11</w.rf>
   <form>Milana</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W12</w.rf>
   <form>Kružíka</form>
   <lemma>Kružík_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W13</w.rf>
   <form>obhajuje</form>
   <lemma>obhajovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W14</w.rf>
   <form>Milan</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W15</w.rf>
   <form>Onderka</form>
   <lemma>Onderka_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W16</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W17</w.rf>
   <form>časem</form>
   <lemma>čas</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W18</w.rf>
   <form>16.50</form>
   <form_change>num_normalization</form_change>
   <lemma>16.50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W19</w.rf>
   <form>sekundy</form>
   <lemma>sekunda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W21</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W22</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W23</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W25</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W26</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W27</w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49036.txt-001-p5s2">
  <m id="m-plzensky49036.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W1</w.rf>
   <form>Příslušník</form>
   <lemma>příslušník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W2</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W3</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W4</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W6</w.rf>
   <form>územního</form>
   <lemma>územní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W7</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W8</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W10</w.rf>
   <form>Martin</form>
   <lemma>Martin-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W11</w.rf>
   <form>Provazník</form>
   <lemma>provazník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W13</w.rf>
   <form>časem</form>
   <lemma>čas</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W14</w.rf>
   <form>16.68</form>
   <form_change>num_normalization</form_change>
   <lemma>16.68</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W15</w.rf>
   <form>sekundy</form>
   <lemma>sekunda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W16</w.rf>
   <form>obsadil</form>
   <lemma>obsadit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W18</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W19</w.rf>
   <form>závodě</form>
   <lemma>závod</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W20</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W21</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49036.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49036.txt-001-p5s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
