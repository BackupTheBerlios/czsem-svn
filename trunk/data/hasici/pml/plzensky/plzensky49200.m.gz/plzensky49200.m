<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49200.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49200.txt-001-p1s1">
  <m id="m-plzensky49200.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W1</w.rf>
   <form>Jestliže</form>
   <lemma>jestliže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W2</w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W4</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W5</w.rf>
   <form>stačí</form>
   <lemma>stačit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W7</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W8</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W10</w.rf>
   <form>června</form>
   <lemma>červen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W11</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W13</w.rf>
   <form>14.30</form>
   <form_change>num_normalization</form_change>
   <lemma>14.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W14</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W15</w.rf>
   <form>zavítat</form>
   <lemma>zavítat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W17</w.rf>
   <form>Stupna</form>
   <lemma>Stupno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W19</w.rf>
   <form>házenkářské</form>
   <lemma>házenkářský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W20</w.rf>
   <form>hřiště</form>
   <lemma>hřiště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W21</w.rf>
   <form>zdejšího</form>
   <lemma>zdejší</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W22</w.rf>
   <form>Sokola</form>
   <lemma>Sokol-2_;K_^(organizace)</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p1s2">
  <m id="m-plzensky49200.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W1</w.rf>
   <form>Právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W2</w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W3</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W4</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W5</w.rf>
   <form>přispění</form>
   <lemma>přispění_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W6</w.rf>
   <form>mnoha</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W7</w.rf>
   <form>sponzorů</form>
   <lemma>sponzor</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W8</w.rf>
   <form>začne</form>
   <lemma>začít-1</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W9</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W10</w.rf>
   <form>14.30</form>
   <form_change>num_normalization</form_change>
   <lemma>14.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W12</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W13</w.rf>
   <form>XIII</form>
   <lemma>XIII-3`13</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W15</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W16</w.rf>
   <form>Pohádkový</form>
   <lemma>pohádkový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W17</w.rf>
   <form>les</form>
   <lemma>les</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W18</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p1s3">
  <m id="m-plzensky49200.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W1</w.rf>
   <form>Stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W2</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W3</w.rf>
   <form>minulé</form>
   <lemma>minulý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W4</w.rf>
   <form>ročníky</form>
   <lemma>ročník</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W6</w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W7</w.rf>
   <form>připravilo</form>
   <lemma>připravit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W8</w.rf>
   <form>Sdružení</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W9</w.rf>
   <form>sportovních</form>
   <lemma>sportovní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W10</w.rf>
   <form>klubů</form>
   <lemma>klub</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W11</w.rf>
   <form>Stupno</form>
   <lemma>Stupno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p1s4">
  <m id="m-plzensky49200.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W1</w.rf>
   <form>Cestou</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W2</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W3</w.rf>
   <form>Pohádkovým</form>
   <lemma>pohádkový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W4</w.rf>
   <form>lesem</form>
   <lemma>les</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W5</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W6</w.rf>
   <form>potkáte</form>
   <lemma>potkat_:W</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W7</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W8</w.rf>
   <form>Křemílka</form>
   <lemma>Křemílek_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W10</w.rf>
   <form>Vochomůrkou</form>
   <lemma>Vochomůrka_;S</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W12</w.rf>
   <form>víly</form>
   <lemma>víla</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W14</w.rf>
   <form>čarodějnici</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W16</w.rf>
   <form>hejkala</form>
   <lemma>hejkal_,h</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W18</w.rf>
   <form>ježibabu</form>
   <lemma>ježibaba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W20</w.rf>
   <form>perníkovou</form>
   <lemma>perníkový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W21</w.rf>
   <form>chaloupku</form>
   <lemma>chaloupka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W23</w.rf>
   <form>červenou</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W24</w.rf>
   <form>Karkulku</form>
   <lemma>Karkulka_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W25</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W26</w.rf>
   <form>bábovkou</form>
   <lemma>bábovka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W28</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W29</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W30</w.rf>
   <form>roztomilé</form>
   <lemma>roztomilý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W31</w.rf>
   <form>postavičky</form>
   <lemma>postavička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s4W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p1s5">
  <m id="m-plzensky49200.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W1</w.rf>
   <form>Každá</form>
   <lemma>každý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W3</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W4</w.rf>
   <form>připravila</form>
   <lemma>připravit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W5</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W6</w.rf>
   <form>vás</form>
   <lemma>ty</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W7</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W8</w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W9</w.rf>
   <form>úkoly</form>
   <lemma>úkol</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p1s5W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p2s1">
  <m id="m-plzensky49200.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s1W1</w.rf>
   <form>Soutěžit</form>
   <lemma>soutěžit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s1W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s1W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s1W5</w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s1W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s1W7</w.rf>
   <form>hřišti</form>
   <lemma>hřiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p2s2">
  <m id="m-plzensky49200.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W1</w.rf>
   <form>Organizátoři</form>
   <lemma>organizátor</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W2</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W3</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W4</w.rf>
   <form>malování</form>
   <lemma>malování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W6</w.rf>
   <form>asfalt</form>
   <lemma>asfalt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W8</w.rf>
   <form>hod</form>
   <lemma>hodina_:B_,x</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W9</w.rf>
   <form>míčkem</form>
   <lemma>míček</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W11</w.rf>
   <form>úst</form>
   <lemma>ústa</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W12</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W13</w.rf>
   <form>hrozné</form>
   <lemma>hrozný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W14</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W15</w.rf>
   <form>čarodějnice</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W17</w.rf>
   <form>hod</form>
   <lemma>hodina_:B_,x</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W18</w.rf>
   <form>míčkem</form>
   <lemma>míček</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W19</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W20</w.rf>
   <form>plechovek</form>
   <lemma>plechovka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W22</w.rf>
   <form>prolézání</form>
   <lemma>prolézání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W23</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W24</w.rf>
   <form>strachovým</form>
   <lemma>strachův</lemma>
   <tag>AUIS7M---------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W25</w.rf>
   <form>pytlem</form>
   <lemma>pytel</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W26</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W28</w.rf>
   <form>hod</form>
   <lemma>hodina_:B_,x</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W29</w.rf>
   <form>šiškou</form>
   <lemma>šiška</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W30</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W31</w.rf>
   <form>chůzi</form>
   <lemma>chůze</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W32</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W33</w.rf>
   <form>chůdách</form>
   <lemma>chůdy</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W34</w.rf>
   <form>aj</form>
   <lemma>aj-1_:B_^(a_jiný/á/é)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s2W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p2s3">
  <m id="m-plzensky49200.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s3W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s3W2</w.rf>
   <form>dispozici</form>
   <lemma>dispozice</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s3W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s3W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s3W5</w.rf>
   <form>netradiční</form>
   <lemma>tradiční</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s3W6</w.rf>
   <form>cvičební</form>
   <lemma>cvičební</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s3W7</w.rf>
   <form>nářadí</form>
   <lemma>nářadí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p2s4">
  <m id="m-plzensky49200.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W2</w.rf>
   <form>zajímavém</form>
   <lemma>zajímavý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W3</w.rf>
   <form>programu</form>
   <lemma>program-1</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W5</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W6</w.rf>
   <form>moderuje</form>
   <lemma>moderovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W7</w.rf>
   <form>osvědčená</form>
   <lemma>osvědčený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W8</w.rf>
   <form>dvojice</form>
   <lemma>dvojice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W9</w.rf>
   <form>František</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W10</w.rf>
   <form>Vaško</form>
   <lemma>Vaško_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W12</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W13</w.rf>
   <form>Kuncl</form>
   <lemma>Kuncl_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W14</w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W15</w.rf>
   <form>chybět</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W16</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W17</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W18</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W19</w.rf>
   <form>zpěvu</form>
   <lemma>zpěv</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W20</w.rf>
   <form>nazvaná</form>
   <lemma>nazvaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W21</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W22</w.rf>
   <form>Stupno</form>
   <lemma>Stupno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W23</w.rf>
   <form>hledá</form>
   <lemma>hledat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W24</w.rf>
   <form>SuperStar</form>
   <lemma>superstar</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W25</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s4W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p2s5">
  <m id="m-plzensky49200.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s5W1</w.rf>
   <form>Soutěžit</form>
   <lemma>soutěžit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s5W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s5W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s5W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s5W5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s5W6</w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s5W7</w.rf>
   <form>večerníčků</form>
   <lemma>večerníček</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p2s6">
  <m id="m-plzensky49200.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W1</w.rf>
   <form>Závěr</form>
   <lemma>závěr_^(př._z_jednání,_úvah)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W2</w.rf>
   <form>tradičně</form>
   <lemma>tradičně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W3</w.rf>
   <form>patří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W4</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W5</w.rf>
   <form>losování</form>
   <lemma>losování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W6</w.rf>
   <form>cen</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W8</w.rf>
   <form>jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W9</w.rf>
   <form>startovní</form>
   <lemma>startovní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W10</w.rf>
   <form>lístky</form>
   <lemma>lístek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W12</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W13</w.rf>
   <form>obdrží</form>
   <lemma>obdržet</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W14</w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W15</w.rf>
   <form>účastník</form>
   <lemma>účastník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W16</w.rf>
   <form>cesty</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W17</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W18</w.rf>
   <form>Pohádkovým</form>
   <lemma>pohádkový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W19</w.rf>
   <form>lesem</form>
   <lemma>les</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W20</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W22</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W23</w.rf>
   <form>slosovatelné</form>
   <lemma>slosovatelný_^(*4)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s6W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p2s7">
  <m id="m-plzensky49200.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W2</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W3</w.rf>
   <form>moci</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W5</w.rf>
   <form>zhlédnout</form>
   <lemma>zhlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W6</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W7</w.rf>
   <form>taneční</form>
   <lemma>taneční-2_^(kurz)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W9</w.rf>
   <form>šermířské</form>
   <lemma>šermířský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W10</w.rf>
   <form>vystoupení</form>
   <lemma>vystoupení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p2s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p2s7W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49200.txt-001-p3s1">
  <m id="m-plzensky49200.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W1</w.rf>
   <form>Proto</form>
   <lemma>proto-2_^(dal_mu_co_proto,_tak_proto!)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W3</w.rf>
   <form>chcete-li</form>
   <lemma>chcete-li</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W4</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W5</w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W6</w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W7</w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W9</w.rf>
   <form>vyhrát</form>
   <lemma>vyhrát</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W10</w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W11</w.rf>
   <form>cenu</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W13</w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W14</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W15</w.rf>
   <form>zamlsat</form>
   <lemma>zamlsat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W17</w.rf>
   <form>neváhejte</form>
   <lemma>váhat_:T</lemma>
   <tag>Vi-P---2--N----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W19</w.rf>
   <form>přijeďte</form>
   <lemma>přijet-1_^(např._autem)</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W21</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W22</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W23</w.rf>
   <form>Stupna</form>
   <lemma>Stupno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49200.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49200.txt-001-p3s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
