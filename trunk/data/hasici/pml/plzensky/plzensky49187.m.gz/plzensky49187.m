<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49187.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49187.txt-001-p1s1">
  <m id="m-plzensky49187.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W1</w.rf>
   <form>Zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W3</w.rf>
   <form>jí</form>
   <lemma>on-1_^(ona)</lemma>
   <tag>PPFS3--3-------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W4</w.rf>
   <form>sedm</form>
   <lemma>sedm`7</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W5</w.rf>
   <form>instruktorů</form>
   <lemma>instruktor</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W7</w.rf>
   <form>řad</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W8</w.rf>
   <form>příslušníků</form>
   <lemma>příslušník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W10</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W11</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W13</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W14</w.rf>
   <form>instruktor</form>
   <lemma>instruktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W15</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W16</w.rf>
   <form>HZSP</form>
   <lemma>HZSP</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W17</w.rf>
   <form>Českých</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W18</w.rf>
   <form>drah</form>
   <lemma>dráha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49187.txt-001-p1s2">
  <m id="m-plzensky49187.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W1</w.rf>
   <form>První</form>
   <lemma>první</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W2</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W4</w.rf>
   <form>věnován</form>
   <lemma>věnovat_:T</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W5</w.rf>
   <form>teorii</form>
   <lemma>teorie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W7</w.rf>
   <form>dějištěm</form>
   <lemma>dějiště</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W8</w.rf>
   <form>konání</form>
   <lemma>konání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W9</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W10</w.rf>
   <form>rekreační</form>
   <lemma>rekreační</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W11</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W12</w.rf>
   <form>Jezná</form>
   <lemma>jezná_^(*1ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49187.txt-001-p1s3">
  <m id="m-plzensky49187.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W2</w.rf>
   <form>následujících</form>
   <lemma>následující_^(*5ovat)</lemma>
   <tag>AGIP6-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W3</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W4</w.rf>
   <form>dnech</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W5</w.rf>
   <form>instruktory</form>
   <lemma>instruktor</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W6</w.rf>
   <form>čeká</form>
   <lemma>čekat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W7</w.rf>
   <form>praktická</form>
   <lemma>praktický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W8</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W9</w.rf>
   <form>spojená</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W10</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W11</w.rf>
   <form>výcvikem</form>
   <lemma>výcvik</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W12</w.rf>
   <form>lezeckých</form>
   <lemma>lezecký</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W13</w.rf>
   <form>skupin</form>
   <lemma>skupina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W14</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W15</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W16</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W18</w.rf>
   <form>HZSP</form>
   <lemma>Hzsp</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W19</w.rf>
   <form>Českých</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W20</w.rf>
   <form>drah</form>
   <lemma>dráha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W22</w.rf>
   <form>železničním</form>
   <lemma>železniční</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W23</w.rf>
   <form>mostě</form>
   <lemma>most</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W25</w.rf>
   <form>Chrástu</form>
   <lemma>Chrást-1_;S</lemma>
   <tag>NNMS6-----A---1</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s3W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49187.txt-001-p1s4">
  <m id="m-plzensky49187.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W1</w.rf>
   <form>Nacvičovat</form>
   <lemma>nacvičovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W4</w.rf>
   <form>záchrana</form>
   <lemma>záchrana</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W5</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W7</w.rf>
   <form>mostní</form>
   <lemma>mostní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W8</w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W10</w.rf>
   <form>základní</form>
   <lemma>základní_,s</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W11</w.rf>
   <form>lanová</form>
   <lemma>lanový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W12</w.rf>
   <form>technika</form>
   <lemma>technika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49187.txt-001-p1s5">
  <m id="m-plzensky49187.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W1</w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W2</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W4</w.rf>
   <form>výcviku</form>
   <lemma>výcvik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W6</w.rf>
   <form>mostě</form>
   <lemma>most</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W7</w.rf>
   <form>zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W8</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W11</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W12</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W13</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W14</w.rf>
   <form>specializací</form>
   <lemma>specializace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W15</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W16</w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W17</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W18</w.rf>
   <form>výškách</form>
   <lemma>výška</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W20</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W21</w.rf>
   <form>volnou</form>
   <lemma>volný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W22</w.rf>
   <form>hloubkou</form>
   <lemma>hloubka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s5W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49187.txt-001-p1s6">
  <m id="m-plzensky49187.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W1</w.rf>
   <form>Výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W3</w.rf>
   <form>mostě</form>
   <lemma>most</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W4</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W5</w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W6</w.rf>
   <form>dny</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W7</w.rf>
   <form>začíná</form>
   <lemma>začínat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W9</w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W11</w.rf>
   <form>dopoledne</form>
   <lemma>dopoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49187.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49187.txt-001-p1s6W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
