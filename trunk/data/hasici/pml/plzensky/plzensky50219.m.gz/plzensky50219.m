<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky50219.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky50219.txt-001-p1s1">
  <m id="m-plzensky50219.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W1</w.rf>
   <form>Medaili</form>
   <lemma>medaile</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W2</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W3</w.rf>
   <form>věrnost</form>
   <lemma>věrnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W4</w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W6</w.rf>
   <form>stupně</form>
   <lemma>stupeň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W7</w.rf>
   <form>tu</form>
   <lemma>tady</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W9</w.rf>
   <form>rukou</form>
   <lemma>ruka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W10</w.rf>
   <form>krajského</form>
   <lemma>krajský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W11</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W12</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W13</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W14</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W15</w.rf>
   <form>plk</form>
   <lemma>plukovník_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s2">
  <m id="m-plzensky50219.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s2W1</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s2W2</w.rf>
   <form>Františka</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s2W3</w.rf>
   <form>Pavlase</form>
   <lemma>Pavlas_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s2W4</w.rf>
   <form>převzali</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s2W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s2W6</w.rf>
   <form>nprap</form>
   <lemma>nadpraporčík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s3">
  <m id="m-plzensky50219.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s3W1</w.rf>
   <form>Václav</form>
   <lemma>Václav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s3W2</w.rf>
   <form>Pintíř</form>
   <lemma>Pintíř_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s3W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s3W4</w.rf>
   <form>nstržm</form>
   <lemma>nstržm</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s4">
  <m id="m-plzensky50219.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W1</w.rf>
   <form>Vojtěch</form>
   <lemma>Vojtěch_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W2</w.rf>
   <form>Šlapák</form>
   <lemma>šlapák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W4</w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W7</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W8</w.rf>
   <form>Klatovy</form>
   <lemma>Klatovy_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W10</w.rf>
   <form>pprap</form>
   <lemma>podpraporčík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s5">
  <m id="m-plzensky50219.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s5W1</w.rf>
   <form>Václav</form>
   <lemma>Václav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s5W2</w.rf>
   <form>Zvikl</form>
   <lemma>Zvikl</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s5W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s5W4</w.rf>
   <form>pprap</form>
   <lemma>podpraporčík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s5W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s6">
  <m id="m-plzensky50219.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s6W1</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s6W2</w.rf>
   <form>Volf</form>
   <lemma>Volf_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s6W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s6W4</w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s6W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s6W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s6W7</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s7">
  <m id="m-plzensky50219.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s7W1</w.rf>
   <form>Ocenění</form>
   <lemma>ocenění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s7W2</w.rf>
   <form>obdržel</form>
   <lemma>obdržet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s7W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s7W4</w.rf>
   <form>nstržm</form>
   <lemma>nstržm</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s7W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s8">
  <m id="m-plzensky50219.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W1</w.rf>
   <form>Václav</form>
   <lemma>Václav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W2</w.rf>
   <form>Chalupný</form>
   <lemma>Chalupný_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W4</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W5</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W7</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W9</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W11</w.rf>
   <form>omluvil</form>
   <lemma>omluvit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W13</w.rf>
   <form>jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W15</w.rf>
   <form>nachází</form>
   <lemma>nacházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W17</w.rf>
   <form>lekařském</form>
   <lemma>lekařský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W18</w.rf>
   <form>ozdravném</form>
   <lemma>ozdravný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W19</w.rf>
   <form>pobytu</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W21</w.rf>
   <form>mjr</form>
   <lemma>major_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s8W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s8W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s9">
  <m id="m-plzensky50219.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W1</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W2</w.rf>
   <form>Václav</form>
   <lemma>Václav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W3</w.rf>
   <form>Petržík</form>
   <lemma>Petržík_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W7</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W8</w.rf>
   <form>Domažlice</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W10</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W11</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W13</w.rf>
   <form>zahraničí</form>
   <lemma>zahraničí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s9W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p1s10">
  <m id="m-plzensky50219.txt-001-p1s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s10W1</w.rf>
   <form>Oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s10W2</w.rf>
   <form>medaili</form>
   <lemma>medaile</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s10W3</w.rf>
   <form>převezmou</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s10W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s10W5</w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s10W6</w.rf>
   <form>příležitosti</form>
   <lemma>příležitost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p1s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p1s10W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s1">
  <m id="m-plzensky50219.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W1</w.rf>
   <form>Medaili</form>
   <lemma>medaile</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W2</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W3</w.rf>
   <form>věrnost</form>
   <lemma>věrnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W4</w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W6</w.rf>
   <form>stupně</form>
   <lemma>stupeň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W7</w.rf>
   <form>převzali</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W9</w.rf>
   <form>rukou</form>
   <lemma>ruka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W10</w.rf>
   <form>krajského</form>
   <lemma>krajský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W11</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W12</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W13</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W14</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W15</w.rf>
   <form>plk</form>
   <lemma>plukovník_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s2">
  <m id="m-plzensky50219.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s2W1</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s2W2</w.rf>
   <form>Františka</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s2W3</w.rf>
   <form>Pavlase</form>
   <lemma>Pavlas_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s2W4</w.rf>
   <form>tito</form>
   <lemma>tento</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s2W5</w.rf>
   <form>příslušníci</form>
   <lemma>příslušník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s2W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s2W7</w.rf>
   <form>nprap</form>
   <lemma>nadpraporčík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s3">
  <m id="m-plzensky50219.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W1</w.rf>
   <form>Radek</form>
   <lemma>Radek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W2</w.rf>
   <form>Snášel</form>
   <lemma>Snášel_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W4</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W5</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W7</w.rf>
   <form>Domažlice</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W9</w.rf>
   <form>pprap</form>
   <lemma>podpraporčík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s4">
  <m id="m-plzensky50219.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s4W1</w.rf>
   <form>František</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s4W2</w.rf>
   <form>Ouředník</form>
   <lemma>Ouředník_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s4W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s4W4</w.rf>
   <form>nstržm</form>
   <lemma>nstržm</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s4W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s5">
  <m id="m-plzensky50219.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W1</w.rf>
   <form>Bohumír</form>
   <lemma>Bohumír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W2</w.rf>
   <form>Skolek</form>
   <lemma>Skolek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W4</w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W7</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W8</w.rf>
   <form>Klatovy</form>
   <lemma>Klatovy_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W10</w.rf>
   <form>rtn</form>
   <lemma>rtn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s6">
  <m id="m-plzensky50219.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W1</w.rf>
   <form>Marie</form>
   <lemma>Marie-1_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W2</w.rf>
   <form>Lešetická</form>
   <lemma>lešetický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W4</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W5</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W7</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W10</w.rf>
   <form>nstržm</form>
   <lemma>nstržm</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s6W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s7">
  <m id="m-plzensky50219.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s7W1</w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s7W2</w.rf>
   <form>Veselý</form>
   <lemma>Veselý_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s7W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s7W4</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s7W5</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s7W6</w.rf>
   <form>Tachov</form>
   <lemma>Tachov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s7W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s8">
  <m id="m-plzensky50219.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s8W1</w.rf>
   <form>Omluvil</form>
   <lemma>omluvit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s8W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s8W3</w.rf>
   <form>nstržm</form>
   <lemma>nstržm</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s8W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p2s9">
  <m id="m-plzensky50219.txt-001-p2s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W1</w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W2</w.rf>
   <form>Škubal</form>
   <lemma>škubat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W4</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W5</w.rf>
   <form>medaili</form>
   <lemma>medaile</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W6</w.rf>
   <form>převezme</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W7</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W8</w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W9</w.rf>
   <form>příležitosti</form>
   <lemma>příležitost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p2s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p2s9W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50219.txt-001-p3s1">
  <m id="m-plzensky50219.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W1</w.rf>
   <form>Tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W2</w.rf>
   <form>slavnostní</form>
   <lemma>slavnostní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W3</w.rf>
   <form>akt</form>
   <lemma>akt-1_^(čin)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W5</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W6</w.rf>
   <form>oceněním</form>
   <lemma>ocenění_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W7</w.rf>
   <form>úrovně</form>
   <lemma>úroveň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W8</w.rf>
   <form>výkonu</form>
   <lemma>výkon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W9</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W10</w.rf>
   <form>dotyčných</form>
   <lemma>dotyčný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W11</w.rf>
   <form>příslušníků</form>
   <lemma>příslušník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky50219.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50219.txt-001-p3s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
