<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49288.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49288.txt-001-p1s1">
  <m id="m-plzensky49288.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W2</w.rf>
   <form>Tachovsku</form>
   <lemma>Tachovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W3</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W5</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W7</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W8</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W9</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W10</w.rf>
   <form>devíti</form>
   <lemma>devět`9</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W11</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s2">
  <m id="m-plzensky49288.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W1</w.rf>
   <form>Tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W2</w.rf>
   <form>vzrostlé</form>
   <lemma>vzrostlý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W3</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W4</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W6</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W8</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W9</w.rf>
   <form>Prokopa</form>
   <lemma>prokop</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W10</w.rf>
   <form>Velikého</form>
   <lemma>veliký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W12</w.rf>
   <form>Tachově</form>
   <lemma>Tachov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s3">
  <m id="m-plzensky49288.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W2</w.rf>
   <form>padlému</form>
   <lemma>padlý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W3</w.rf>
   <form>shnilému</form>
   <lemma>shnilý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W4</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W6</w.rf>
   <form>plot</form>
   <lemma>plot</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W7</w.rf>
   <form>kynologického</form>
   <lemma>kynologický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W8</w.rf>
   <form>cvičiště</form>
   <lemma>cvičiště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W10</w.rf>
   <form>Pobřežní</form>
   <lemma>pobřežní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W11</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W13</w.rf>
   <form>Tachově</form>
   <lemma>Tachov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W14</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W15</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W16</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W17</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s4">
  <m id="m-plzensky49288.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W1</w.rf>
   <form>Shnilý</form>
   <lemma>shnilý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W3</w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W4</w.rf>
   <form>vyvrátil</form>
   <lemma>vyvrátit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W5</w.rf>
   <form>nosný</form>
   <lemma>nosný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W6</w.rf>
   <form>sloup</form>
   <lemma>sloup</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W7</w.rf>
   <form>brány</form>
   <lemma>brána</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W8</w.rf>
   <form>cvičiště</form>
   <lemma>cvičiště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s5">
  <m id="m-plzensky49288.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W2</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W3</w.rf>
   <form>zbytek</form>
   <lemma>zbytek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W4</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W5</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W6</w.rf>
   <form>plotu</form>
   <lemma>plot</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W8</w.rf>
   <form>odřízli</form>
   <lemma>odříznout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W9</w.rf>
   <form>zbývající</form>
   <lemma>zbývající_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W10</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W11</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s5W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s6">
  <m id="m-plzensky49288.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s6W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s6W2</w.rf>
   <form>dutině</form>
   <lemma>dutina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s6W3</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s6W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s6W5</w.rf>
   <form>uvězněna</form>
   <lemma>uvěznit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s6W6</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s6W7</w.rf>
   <form>ptáčata</form>
   <lemma>ptáče</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s7">
  <m id="m-plzensky49288.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W2</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W3</w.rf>
   <form>odchytili</form>
   <lemma>odchytit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W5</w.rf>
   <form>vypustili</form>
   <lemma>vypustit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W7</w.rf>
   <form>volné</form>
   <lemma>volný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W8</w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s7W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s8">
  <m id="m-plzensky49288.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W4</w.rf>
   <form>Tachova</form>
   <lemma>Tachov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W5</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W6</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W8</w.rf>
   <form>uvolněnému</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W9</w.rf>
   <form>dřevěnému</form>
   <lemma>dřevěný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W10</w.rf>
   <form>vikýři</form>
   <lemma>vikýř</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W12</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W13</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W14</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W15</w.rf>
   <form>Starém</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W16</w.rf>
   <form>Sedlišti</form>
   <lemma>Sedliště_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s8W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s9">
  <m id="m-plzensky49288.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W2</w.rf>
   <form>vikýř</form>
   <lemma>vikýř</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W3</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W4</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W5</w.rf>
   <form>automobilní</form>
   <lemma>automobilní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W6</w.rf>
   <form>plošiny</form>
   <lemma>plošina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W7</w.rf>
   <form>provizorně</form>
   <lemma>provizorně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W8</w.rf>
   <form>opravili</form>
   <lemma>opravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s9W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s10">
  <m id="m-plzensky49288.txt-001-p1s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W2</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W3</w.rf>
   <form>Mlýnec</form>
   <lemma>Mlýnec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W4</w.rf>
   <form>padl</form>
   <lemma>padnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W5</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W7</w.rf>
   <form>telefonní</form>
   <lemma>telefonní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W8</w.rf>
   <form>kabel</form>
   <lemma>kabel</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s10W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p1s11">
  <m id="m-plzensky49288.txt-001-p1s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s11W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s11W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s11W3</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s11W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s11W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s11W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s11W7</w.rf>
   <form>Tachova</form>
   <lemma>Tachov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p1s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p1s11W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p2s1">
  <m id="m-plzensky49288.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s1W2</w.rf>
   <form>Rokycansku</form>
   <lemma>Rokycansko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s1W3</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s1W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s1W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s1W6</w.rf>
   <form>šesti</form>
   <lemma>šest`6</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s1W7</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p2s2">
  <m id="m-plzensky49288.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W1</w.rf>
   <form>Nejhorší</form>
   <lemma>špatný</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W3</w.rf>
   <form>situace</form>
   <lemma>situace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W5</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W6</w.rf>
   <form>Březina</form>
   <lemma>Březina-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W8</w.rf>
   <form>Volduchy</form>
   <lemma>Volduchy_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p2s3">
  <m id="m-plzensky49288.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s3W1</w.rf>
   <form>Sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s3W2</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s3W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s3W4</w.rf>
   <form>hned</form>
   <lemma>hned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s3W5</w.rf>
   <form>třikrát</form>
   <lemma>třikrát`3</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p2s4">
  <m id="m-plzensky49288.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W1</w.rf>
   <form>Kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W2</w.rf>
   <form>většímu</form>
   <lemma>velký</lemma>
   <tag>AANS3----2A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W3</w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W4</w.rf>
   <form>nakloněných</form>
   <lemma>nakloněný_^(*3it)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W5</w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W7</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W8</w.rf>
   <form>hrozily</form>
   <lemma>hrozit_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W9</w.rf>
   <form>pádem</form>
   <lemma>pád</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W12</w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W13</w.rf>
   <form>uvažovalo</form>
   <lemma>uvažovat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W14</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W15</w.rf>
   <form>uzavření</form>
   <lemma>uzavření_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W16</w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p2s5">
  <m id="m-plzensky49288.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W1</w.rf>
   <form>Padlý</form>
   <lemma>padlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W4</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W6</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W7</w.rf>
   <form>Nevida</form>
   <lemma>vidět_:T</lemma>
   <tag>VeYS------N----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W9</w.rf>
   <form>Mýta</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W11</w.rf>
   <form>Litohlav</form>
   <lemma>Litohlavy_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s5W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p2s6">
  <m id="m-plzensky49288.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s6W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s6W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s6W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s6W4</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s6W5</w.rf>
   <form>padlé</form>
   <lemma>padlý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s6W6</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s6W7</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p2s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s1">
  <m id="m-plzensky49288.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W2</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W3</w.rf>
   <form>okresu</form>
   <lemma>okres</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W4</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W7</w.rf>
   <form>sever</form>
   <lemma>sever</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W8</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W11</w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cn-P3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W12</w.rf>
   <form>událostem</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s2">
  <m id="m-plzensky49288.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W2</w.rf>
   <form>padlému</form>
   <lemma>padlý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W3</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W5</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W6</w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W8</w.rf>
   <form>Školní</form>
   <lemma>školní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W9</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W11</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W12</w.rf>
   <form>Plasy</form>
   <lemma>Plasy_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W13</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W14</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W15</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W16</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s3">
  <m id="m-plzensky49288.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s3W1</w.rf>
   <form>Strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s3W2</w.rf>
   <form>poškodil</form>
   <lemma>poškodit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s3W3</w.rf>
   <form>plot</form>
   <lemma>plot</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s3W4</w.rf>
   <form>sousedního</form>
   <lemma>sousední</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s3W5</w.rf>
   <form>pozemku</form>
   <lemma>pozemek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s4">
  <m id="m-plzensky49288.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s4W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s4W3</w.rf>
   <form>rozřezali</form>
   <lemma>rozřezat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s4W4</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s4W5</w.rf>
   <form>motorové</form>
   <lemma>motorový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s4W6</w.rf>
   <form>pily</form>
   <lemma>pila</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s5">
  <m id="m-plzensky49288.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W2</w.rf>
   <form>padlému</form>
   <lemma>padlý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W3</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W4</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W5</w.rf>
   <form>dráty</form>
   <lemma>drát-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W6</w.rf>
   <form>elektrického</form>
   <lemma>elektrický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W7</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W9</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W10</w.rf>
   <form>Vlkýšská</form>
   <lemma>vlkýšský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W11</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W12</w.rf>
   <form>Městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W13</w.rf>
   <form>Touškov</form>
   <lemma>Touškov_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W14</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W15</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W16</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W17</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s6">
  <m id="m-plzensky49288.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s6W1</w.rf>
   <form>Strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s6W2</w.rf>
   <form>padl</form>
   <lemma>padnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s6W3</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s6W4</w.rf>
   <form>přípojku</form>
   <lemma>přípojka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s6W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s6W6</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s6W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s7">
  <m id="m-plzensky49288.txt-001-p3s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s7W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s7W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s7W3</w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s7W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s7W5</w.rf>
   <form>pracovník</form>
   <lemma>pracovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s7W6</w.rf>
   <form>ČEZu</form>
   <lemma>ČEZu</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s7W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s8">
  <m id="m-plzensky49288.txt-001-p3s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s8W1</w.rf>
   <form>Strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s8W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s8W3</w.rf>
   <form>rozřezán</form>
   <lemma>rozřezat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s8W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s8W5</w.rf>
   <form>odstraněn</form>
   <lemma>odstranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s8W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s9">
  <m id="m-plzensky49288.txt-001-p3s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W2</w.rf>
   <form>Vlkýšské</form>
   <lemma>vlkýšský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W3</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W5</w.rf>
   <form>Městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W6</w.rf>
   <form>Touškov</form>
   <lemma>Touškov_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W7</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W9</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W10</w.rf>
   <form>jednou</form>
   <lemma>jednou</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s9W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p3s10">
  <m id="m-plzensky49288.txt-001-p3s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W4</w.rf>
   <form>Nýřan</form>
   <lemma>Nýřany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W6</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W7</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W9</w.rf>
   <form>tu</form>
   <lemma>tady</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W10</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W12</w.rf>
   <form>uvolněných</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W13</w.rf>
   <form>plechů</form>
   <lemma>plech</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W15</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W16</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p3s10W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p3s10W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p4s1">
  <m id="m-plzensky49288.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W2</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W3</w.rf>
   <form>okresu</form>
   <lemma>okres</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W4</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W7</w.rf>
   <form>město</form>
   <lemma>město</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W10</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W11</w.rf>
   <form>čtyř</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W12</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p4s2">
  <m id="m-plzensky49288.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W1</w.rf>
   <form>Uvolněný</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W2</w.rf>
   <form>plech</form>
   <lemma>plech</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W3</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W4</w.rf>
   <form>balkonem</form>
   <lemma>balkón_,x</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W6</w.rf>
   <form>čtvrtém</form>
   <lemma>čtvrtý</lemma>
   <tag>CrNS6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W7</w.rf>
   <form>nadzemním</form>
   <lemma>nadzemní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W8</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W9</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W10</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W12</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W13</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W14</w.rf>
   <form>Pobřežní</form>
   <lemma>pobřežní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p4s3">
  <m id="m-plzensky49288.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s3W2</w.rf>
   <form>uvolněný</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s3W3</w.rf>
   <form>plech</form>
   <lemma>plech</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s3W4</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p4s4">
  <m id="m-plzensky49288.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s4W2</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s4W3</w.rf>
   <form>pracovali</form>
   <lemma>pracovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s4W4</w.rf>
   <form>jištěni</form>
   <lemma>jistit</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s4W5</w.rf>
   <form>lany</form>
   <lemma>lano</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p4s5">
  <m id="m-plzensky49288.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W2</w.rf>
   <form>uvolněným</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W3</w.rf>
   <form>plechům</form>
   <lemma>plech</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W5</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W6</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W8</w.rf>
   <form>Kotíkovské</form>
   <lemma>Kotíkovský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W9</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W11</w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W14</w.rf>
   <form>Bolevci</form>
   <lemma>Bolevec_;G</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W15</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W16</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W17</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W18</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W19</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W20</w.rf>
   <form>Košutka</form>
   <lemma>Košutka</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s5W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p4s6">
  <m id="m-plzensky49288.txt-001-p4s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W2</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W3</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W4</w.rf>
   <form>autožebříku</form>
   <lemma>autožebříka</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W6</w.rf>
   <form>lezecké</form>
   <lemma>lezecký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W7</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W8</w.rf>
   <form>uvolněné</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W9</w.rf>
   <form>plechy</form>
   <lemma>plech</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W10</w.rf>
   <form>přibili</form>
   <lemma>přibít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W12</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W13</w.rf>
   <form>latěmi</form>
   <lemma>lať</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p4s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p4s6W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p5s1">
  <m id="m-plzensky49288.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W2</w.rf>
   <form>okrese</form>
   <lemma>okres</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W3</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W6</w.rf>
   <form>jih</form>
   <lemma>jih</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W8</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W9</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W10</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W11</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W12</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p5s2">
  <m id="m-plzensky49288.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W1</w.rf>
   <form>Padlý</form>
   <lemma>padlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W3</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W4</w.rf>
   <form>cestu</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W6</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W7</w.rf>
   <form>Vstiš</form>
   <lemma>Vstiš</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W8</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W9</w.rf>
   <form>motorové</form>
   <lemma>motorový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W10</w.rf>
   <form>pily</form>
   <lemma>pila</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W11</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W12</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W13</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W14</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p5s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p6s1">
  <m id="m-plzensky49288.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s1W2</w.rf>
   <form>Klatovsku</form>
   <lemma>Klatovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s1W3</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s1W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s1W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s1W6</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s1W7</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p6s2">
  <m id="m-plzensky49288.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W2</w.rf>
   <form>padlému</form>
   <lemma>padlý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W3</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W4</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W5</w.rf>
   <form>dráty</form>
   <lemma>drát-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W6</w.rf>
   <form>elektrického</form>
   <lemma>elektrický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W7</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W8</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W9</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W10</w.rf>
   <form>Švihov</form>
   <lemma>Švihov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W12</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W13</w.rf>
   <form>Kamýk</form>
   <lemma>Kamýk_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W15</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W16</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W17</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W18</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W19</w.rf>
   <form>Švihova</form>
   <lemma>Švihov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W21</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W22</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W23</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W24</w.rf>
   <form>Klatov</form>
   <lemma>Klatovy_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p6s3">
  <m id="m-plzensky49288.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W5</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W6</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W7</w.rf>
   <form>operátora</form>
   <lemma>operátor</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W8</w.rf>
   <form>O2</form>
   <lemma>O2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W10</w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W11</w.rf>
   <form>povolila</form>
   <lemma>povolit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W12</w.rf>
   <form>telefonní</form>
   <lemma>telefonní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W13</w.rf>
   <form>kabely</form>
   <lemma>kabela</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W15</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W16</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W17</w.rf>
   <form>rozřezali</form>
   <lemma>rozřezat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W19</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p6s4">
  <m id="m-plzensky49288.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W1</w.rf>
   <form>Padlé</form>
   <lemma>padlý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W2</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W3</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W4</w.rf>
   <form>Rejštejna</form>
   <lemma>Rejštejn_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W5</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W6</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W8</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W9</w.rf>
   <form>Srní</form>
   <lemma>Srní_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p6s5">
  <m id="m-plzensky49288.txt-001-p6s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W2</w.rf>
   <form>Sušické</form>
   <lemma>sušický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W3</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W5</w.rf>
   <form>Kašperských</form>
   <lemma>kašperský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W6</w.rf>
   <form>horách</form>
   <lemma>hora</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W7</w.rf>
   <form>padla</form>
   <lemma>padnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W8</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W9</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W11</w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W12</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W13</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W14</w.rf>
   <form>Felicie</form>
   <lemma>Felicia-2_;R_^(vozidlo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W15</w.rf>
   <form>Combi</form>
   <lemma>Combi_;R_,t_^(v_názvech_např._Škoda_Octavia_Combi)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s5W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p6s6">
  <m id="m-plzensky49288.txt-001-p6s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s6W1</w.rf>
   <form>Řidička</form>
   <lemma>řidička_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s6W2</w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s6W3</w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s6W4</w.rf>
   <form>zraněna</form>
   <lemma>zranit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s6W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p6s7">
  <m id="m-plzensky49288.txt-001-p6s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W3</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W4</w.rf>
   <form>Sušice</form>
   <lemma>Sušice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W5</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W7</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W8</w.rf>
   <form>odstranili.Bez</form>
   <lemma>odstranili.Bez</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W9</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W10</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W12</w.rf>
   <form>obešel</form>
   <lemma>obejít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W13</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W14</w.rf>
   <form>pád</form>
   <lemma>pád</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W15</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W17</w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W18</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W19</w.rf>
   <form>Renault</form>
   <lemma>Renault-1_;K</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W20</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W22</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W23</w.rf>
   <form>Hlavňovice</form>
   <lemma>Hlavňovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s7W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p6s8">
  <m id="m-plzensky49288.txt-001-p6s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s8W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s8W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s8W3</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s8W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s8W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s8W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s8W7</w.rf>
   <form>Sušice</form>
   <lemma>Sušice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p6s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p6s8W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p7s1">
  <m id="m-plzensky49288.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s1W2</w.rf>
   <form>Domažlicku</form>
   <lemma>Domažlicko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s1W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s1W4</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s1W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s1W6</w.rf>
   <form>sedmi</form>
   <lemma>sedm`7</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s1W7</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p7s2">
  <m id="m-plzensky49288.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W1</w.rf>
   <form>Stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W2</w.rf>
   <form>zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W3</w.rf>
   <form>padaly</form>
   <lemma>padat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W4</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W5</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W6</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W8</w.rf>
   <form>Mánesově</form>
   <lemma>Mánesův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W9</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W11</w.rf>
   <form>Domažlicích</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W13</w.rf>
   <form>Pocínovic</form>
   <lemma>Pocínovic</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W15</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W16</w.rf>
   <form>Zamělíč.V</form>
   <lemma>Zamělíč.V</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W17</w.rf>
   <form>Horšovském</form>
   <lemma>horšovský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W18</w.rf>
   <form>Týně</form>
   <lemma>týn</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W19</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W20</w.rf>
   <form>prodejnou</form>
   <lemma>prodejný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W21</w.rf>
   <form>Ford</form>
   <lemma>Ford-1_;K</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W23</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W24</w.rf>
   <form>můstku</form>
   <lemma>můstek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W25</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W26</w.rf>
   <form>řeku</form>
   <lemma>řeka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W27</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W28</w.rf>
   <form>rozlomila</form>
   <lemma>rozlomit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W29</w.rf>
   <form>vrba</form>
   <lemma>vrba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s2W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p7s3">
  <m id="m-plzensky49288.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W1</w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W2</w.rf>
   <form>větev</form>
   <lemma>větev</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W3</w.rf>
   <form>visela</form>
   <lemma>viset_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W4</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W5</w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W7</w.rf>
   <form>druhá</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W9</w.rf>
   <form>pěšinou</form>
   <lemma>pěšina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W10</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W11</w.rf>
   <form>chodce</form>
   <lemma>chodec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W13</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W14</w.rf>
   <form>ohrožovala</form>
   <lemma>ohrožovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49288.txt-001-p7s4">
  <m id="m-plzensky49288.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s4W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s4W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s4W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s4W4</w.rf>
   <form>Domažlic</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s4W5</w.rf>
   <form>větve</form>
   <lemma>větev</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s4W6</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49288.txt-001-p7s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49288.txt-001-p7s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
