<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49898.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49898.txt-001-p1s1">
  <m id="m-plzensky49898.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W1</w.rf>
   <form>Pořádají</form>
   <lemma>pořádat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W2</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W3</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W4</w.rf>
   <form>přispění</form>
   <lemma>přispění_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W5</w.rf>
   <form>mnoha</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W6</w.rf>
   <form>sponzorů</form>
   <lemma>sponzor</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W7</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W8</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W10</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W11</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W13</w.rf>
   <form>Obecním</form>
   <lemma>obecní_^(v_obci;_např._úřad)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W14</w.rf>
   <form>úřadem</form>
   <lemma>úřad</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W15</w.rf>
   <form>Osek</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p1s2">
  <m id="m-plzensky49898.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W2</w.rf>
   <form>nutno</form>
   <lemma>nutný</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W3</w.rf>
   <form>říci</form>
   <lemma>říci</lemma>
   <tag>Vf--------A---1</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W5</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W7</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W8</w.rf>
   <form>nebudou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-NA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W9</w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W10</w.rf>
   <form>nudit</form>
   <lemma>nudit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W12</w.rf>
   <form>neboť</form>
   <lemma>neboť</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W13</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W14</w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>P5XP4--3-------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W15</w.rf>
   <form>pořadatelé</form>
   <lemma>pořadatel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W16</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W17</w.rf>
   <form>atraktivní</form>
   <lemma>atraktivní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W18</w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W20</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W21</w.rf>
   <form>potrvá</form>
   <lemma>potrvat_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W22</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W23</w.rf>
   <form>14.00</form>
   <form_change>num_normalization</form_change>
   <lemma>14.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W24</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W25</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W26</w.rf>
   <form>17.00</form>
   <form_change>num_normalization</form_change>
   <lemma>17.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W27</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p1s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p1s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s1">
  <m id="m-plzensky49898.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W1</w.rf>
   <form>Zajímavá</form>
   <lemma>zajímavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W2</w.rf>
   <form>určitě</form>
   <lemma>určitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W4</w.rf>
   <form>prohlídka</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W5</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W6</w.rf>
   <form>místních</form>
   <lemma>místní</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W7</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W8</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s2">
  <m id="m-plzensky49898.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s2W1</w.rf>
   <form>Připraveny</form>
   <lemma>připravit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s2W2</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s2W3</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s2W4</w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s2W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s2W6</w.rf>
   <form>zábavné</form>
   <lemma>zábavný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s2W7</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s3">
  <m id="m-plzensky49898.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W2</w.rf>
   <form>čeká</form>
   <lemma>čekat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W3</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W4</w.rf>
   <form>házení</form>
   <lemma>házení_^(*2t)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W5</w.rf>
   <form>kroužky</form>
   <lemma>kroužek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W7</w.rf>
   <form>skákání</form>
   <lemma>skákání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W9</w.rf>
   <form>pytli</form>
   <lemma>pytel</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W11</w.rf>
   <form>přetahování</form>
   <lemma>přetahování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W12</w.rf>
   <form>lanem</form>
   <lemma>lano</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W14</w.rf>
   <form>stříkání</form>
   <lemma>stříkání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W15</w.rf>
   <form>džberovou</form>
   <lemma>džberový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W16</w.rf>
   <form>stříkačkou</form>
   <lemma>stříkačka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W18</w.rf>
   <form>cíl</form>
   <lemma>cíl</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W19</w.rf>
   <form>aj</form>
   <lemma>aj-1_:B_^(a_jiný/á/é)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s4">
  <m id="m-plzensky49898.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W1</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W2</w.rf>
   <form>účast</form>
   <lemma>účast</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W4</w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W5</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W6</w.rf>
   <form>každé</form>
   <lemma>každý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W7</w.rf>
   <form>dítě</form>
   <lemma>dítě</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W8</w.rf>
   <form>obdrží</form>
   <lemma>obdržet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W9</w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PZ--4----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W10</w.rf>
   <form>dobrého</form>
   <lemma>dobrý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W12</w.rf>
   <form>zub</form>
   <lemma>zub</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W14</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W15</w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W16</w.rf>
   <form>dárek</form>
   <lemma>dárek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s5">
  <m id="m-plzensky49898.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W1</w.rf>
   <form>Nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W2</w.rf>
   <form>chybět</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W3</w.rf>
   <form>muzika</form>
   <lemma>muzika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W4</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W5</w.rf>
   <form>tanec</form>
   <lemma>tanec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W7</w.rf>
   <form>hudební</form>
   <lemma>hudební</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W8</w.rf>
   <form>hádanky</form>
   <lemma>hádanka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W10</w.rf>
   <form>hádanky</form>
   <lemma>hádanka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W12</w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W13</w.rf>
   <form>večerníčků</form>
   <lemma>večerníček</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s5W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s6">
  <m id="m-plzensky49898.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W1</w.rf>
   <form>Programem</form>
   <lemma>program-1</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W2</w.rf>
   <form>provází</form>
   <lemma>provázet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W3</w.rf>
   <form>tradičně</form>
   <lemma>tradičně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W4</w.rf>
   <form>František</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W5</w.rf>
   <form>Vaško</form>
   <lemma>Vaško_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W7</w.rf>
   <form>František</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W8</w.rf>
   <form>Kožíšek</form>
   <lemma>Kožíšek_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s6W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s7">
  <m id="m-plzensky49898.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W1</w.rf>
   <form>Nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W2</w.rf>
   <form>chybět</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W3</w.rf>
   <form>pěvecká</form>
   <lemma>pěvecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W4</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W5</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W6</w.rf>
   <form>Osek</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W7</w.rf>
   <form>hledá</form>
   <lemma>hledat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W8</w.rf>
   <form>SuperStar</form>
   <lemma>superstar</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s7W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s8">
  <m id="m-plzensky49898.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W1</w.rf>
   <form>Bonbonkem</form>
   <lemma>bonbonek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W2</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W3</w.rf>
   <form>vystoupení</form>
   <lemma>vystoupení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W4</w.rf>
   <form>cantry</form>
   <lemma>cantry</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W5</w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W6</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W7</w.rf>
   <form>Tuláci</form>
   <lemma>tulák</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W8</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s8W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49898.txt-001-p2s9">
  <m id="m-plzensky49898.txt-001-p2s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W1</w.rf>
   <form>Zpestřením</form>
   <lemma>zpestření_,s_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W2</w.rf>
   <form>celého</form>
   <lemma>celý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W3</w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-2</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W4</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W5</w.rf>
   <form>jistě</form>
   <lemma>jistě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W7</w.rf>
   <form>táborák</form>
   <lemma>táborák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W9</w.rf>
   <form>opékané</form>
   <lemma>opékaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W10</w.rf>
   <form>klobásy</form>
   <lemma>klobása</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W12</w.rf>
   <form>nealkoholické</form>
   <lemma>alkoholický</lemma>
   <tag>AAIP1----1N----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W13</w.rf>
   <form>nápoje</form>
   <lemma>nápoj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W15</w.rf>
   <form>pivo</form>
   <lemma>pivo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W17</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W18</w.rf>
   <form>přivítají</form>
   <lemma>přivítat_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W19</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W20</w.rf>
   <form>tatínkové</form>
   <lemma>tatínek</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-plzensky49898.txt-001-p2s9W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49898.txt-001-p2s9W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
