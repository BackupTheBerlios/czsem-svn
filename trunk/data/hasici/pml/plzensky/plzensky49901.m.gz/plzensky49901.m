<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49901.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49901.txt-001-p1s1">
  <m id="m-plzensky49901.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W4</w.rf>
   <form>výskyt</form>
   <lemma>výskyt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W5</w.rf>
   <form>hada</form>
   <lemma>had</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W7</w.rf>
   <form>obýváku</form>
   <lemma>obývák</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W8</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W10</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W11</w.rf>
   <form>Částkov</form>
   <lemma>Částkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W13</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W14</w.rf>
   <form>Maršovy</form>
   <lemma>Maršův_;S_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W15</w.rf>
   <form>Chody</form>
   <lemma>chod_^(např._stroje)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s2">
  <m id="m-plzensky49901.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W1</w.rf>
   <form>Ženu</form>
   <lemma>žena</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W2</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W3</w.rf>
   <form>spánku</form>
   <lemma>spánek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W5</w.rf>
   <form>obýváku</form>
   <lemma>obývák</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W7</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W8</w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W9</w.rf>
   <form>skládací</form>
   <lemma>skládací_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W10</w.rf>
   <form>sušák</form>
   <lemma>sušák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W12</w.rf>
   <form>prádlo</form>
   <lemma>prádlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W14</w.rf>
   <form>vzbudil</form>
   <lemma>vzbudit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W15</w.rf>
   <form>šramot</form>
   <lemma>šramot</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s3">
  <m id="m-plzensky49901.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W1</w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W3</w.rf>
   <form>podívala</form>
   <lemma>podívat_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W5</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W7</w.rf>
   <form>děje</form>
   <lemma>dít_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W9</w.rf>
   <form>uviděla</form>
   <lemma>uvidět</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W10</w.rf>
   <form>údajně</form>
   <lemma>údajně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W11</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W12</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W13</w.rf>
   <form>centimetrového</form>
   <lemma>centimetrový</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W14</w.rf>
   <form>hada</form>
   <lemma>had</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s4">
  <m id="m-plzensky49901.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W2</w.rf>
   <form>strachu</form>
   <lemma>strach</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W3</w.rf>
   <form>vyběhla</form>
   <lemma>vyběhnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W5</w.rf>
   <form>místnosti</form>
   <lemma>místnost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W7</w.rf>
   <form>uzavřela</form>
   <lemma>uzavřít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W8</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W10</w.rf>
   <form>zavolal</form>
   <lemma>zavolat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W11</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s5">
  <m id="m-plzensky49901.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W3</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W4</w.rf>
   <form>povolali</form>
   <lemma>povolat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W6</w.rf>
   <form>pracovníka</form>
   <lemma>pracovník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W7</w.rf>
   <form>Záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W8</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W9</w.rf>
   <form>živočichů</form>
   <lemma>živočich</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W10</w.rf>
   <form>p</form>
   <lemma>podnik_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s6">
  <m id="m-plzensky49901.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s6W1</w.rf>
   <form>Bobála</form>
   <lemma>Bobála</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s6W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s7">
  <m id="m-plzensky49901.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W2</w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W4</w.rf>
   <form>pracovníkem</form>
   <lemma>pracovník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W5</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W6</w.rf>
   <form>důkladně</form>
   <lemma>důkladně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W7</w.rf>
   <form>prohledali</form>
   <lemma>prohledat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W8</w.rf>
   <form>místnost</form>
   <lemma>místnost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W10</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W12</w.rf>
   <form>had</form>
   <lemma>had</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W13</w.rf>
   <form>spatřen</form>
   <lemma>spatřit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s7W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s8">
  <m id="m-plzensky49901.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W1</w.rf>
   <form>Rozebrali</form>
   <lemma>rozebrat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W2</w.rf>
   <form>postel</form>
   <lemma>postel</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W4</w.rf>
   <form>odhrnuli</form>
   <lemma>odhrnout</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W5</w.rf>
   <form>koberec</form>
   <lemma>koberec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W7</w.rf>
   <form>odšoupli</form>
   <lemma>odšoupnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W8</w.rf>
   <form>televizi</form>
   <lemma>televize</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W10</w.rf>
   <form>rozebrali</form>
   <lemma>rozebrat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W11</w.rf>
   <form>skříně</form>
   <lemma>skříň</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W13</w.rf>
   <form>prohledali</form>
   <lemma>prohledat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W14</w.rf>
   <form>šuplíky</form>
   <lemma>šuplík</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W16</w.rf>
   <form>zkontrolovali</form>
   <lemma>zkontrolovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W17</w.rf>
   <form>hadici</form>
   <lemma>hadice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W18</w.rf>
   <form>vysavače</form>
   <lemma>vysavač</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W19</w.rf>
   <form>aj</form>
   <lemma>aj-1_:B_^(a_jiný/á/é)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W22</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W23</w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PW--4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W24</w.rf>
   <form>nenalezli</form>
   <lemma>nalézt</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s8W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s8W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s9">
  <m id="m-plzensky49901.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W1</w.rf>
   <form>Pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W2</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W3</w.rf>
   <form>topením</form>
   <lemma>topení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W5</w.rf>
   <form>oknem</form>
   <lemma>okno</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W6</w.rf>
   <form>nalezli</form>
   <lemma>nalézt</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W7</w.rf>
   <form>díru</form>
   <lemma>díra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W9</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W10</w.rf>
   <form>mohla</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W11</w.rf>
   <form>vést</form>
   <lemma>vést-1</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W12</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W13</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W14</w.rf>
   <form>základy</form>
   <lemma>základ</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s9W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s10">
  <m id="m-plzensky49901.txt-001-p1s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s10W1</w.rf>
   <form>Tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s10W2</w.rf>
   <form>patrně</form>
   <lemma>patrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s10W3</w.rf>
   <form>plaz</form>
   <lemma>plaz</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s10W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s10W5</w.rf>
   <form>utekl</form>
   <lemma>utéci</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s10W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s11">
  <m id="m-plzensky49901.txt-001-p1s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W2</w.rf>
   <form>popisu</form>
   <lemma>popis</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W4</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W5</w.rf>
   <form>plaz</form>
   <lemma>plaz</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W6</w.rf>
   <form>vypadal</form>
   <lemma>vypadat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W9</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W10</w.rf>
   <form>p</form>
   <lemma>podnik_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s11W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s11W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49901.txt-001-p1s12">
  <m id="m-plzensky49901.txt-001-p1s12W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s12W1</w.rf>
   <form>Bobála</form>
   <lemma>Bobála</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s12W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s12W2</w.rf>
   <form>mohlo</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s12W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s12W3</w.rf>
   <form>jednat</form>
   <lemma>jednat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s12W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s12W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s12W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s12W5</w.rf>
   <form>užovku</form>
   <lemma>užovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49901.txt-001-p1s12W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49901.txt-001-p1s12W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
