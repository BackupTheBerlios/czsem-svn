<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49294.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49294.txt-001-p1s1">
  <m id="m-plzensky49294.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W3</w.rf>
   <form>dýchacích</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W4</w.rf>
   <form>přístrojích</form>
   <lemma>přístroj</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W6</w.rf>
   <form>protichemických</form>
   <lemma>protichemický</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W7</w.rf>
   <form>oblecích</form>
   <lemma>oblek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W8</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W9</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W10</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s2">
  <m id="m-plzensky49294.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W1</w.rf>
   <form>Čekárnu</form>
   <lemma>čekárna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W3</w.rf>
   <form>nálezu</form>
   <lemma>nález</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W4</w.rf>
   <form>prášku</form>
   <lemma>prášek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W5</w.rf>
   <form>uzamkl</form>
   <lemma>uzamknout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W6</w.rf>
   <form>výpravčí</form>
   <lemma>výpravčí</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W8</w.rf>
   <form>událost</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W9</w.rf>
   <form>nahlásil</form>
   <lemma>nahlásit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s3">
  <m id="m-plzensky49294.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W3</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W4</w.rf>
   <form>povoláni</form>
   <lemma>povolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W5</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W7</w.rf>
   <form>Českých</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W8</w.rf>
   <form>drah</form>
   <lemma>dráha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W10</w.rf>
   <form>specialisté</form>
   <lemma>specialista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W12</w.rf>
   <form>Školícího</form>
   <lemma>školící_^(*3it)</lemma>
   <tag>AGNS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W13</w.rf>
   <form>střediska</form>
   <lemma>středisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W15</w.rf>
   <form>laboratoře</form>
   <lemma>laboratoř</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W16</w.rf>
   <form>Třemošná</form>
   <lemma>Třemošná_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s4">
  <m id="m-plzensky49294.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W1</w.rf>
   <form>Čekárna</form>
   <lemma>čekárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W3</w.rf>
   <form>nachází</form>
   <lemma>nacházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W4</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W5</w.rf>
   <form>pokladny</form>
   <lemma>pokladna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W8</w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W9</w.rf>
   <form>občanům</form>
   <lemma>občan</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W10</w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PW--4----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W11</w.rf>
   <form>nebránilo</form>
   <lemma>bránit_^(klást_překážky)</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W12</w.rf>
   <form>koupit</form>
   <lemma>koupit_:W_^(něco_sobě/někomu)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W13</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W14</w.rf>
   <form>jízdenku</form>
   <lemma>jízdenka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W16</w.rf>
   <form>vlak</form>
   <lemma>vlak</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s5">
  <m id="m-plzensky49294.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s5W1</w.rf>
   <form>Událost</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s5W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s5W3</w.rf>
   <form>nahlášena</form>
   <lemma>nahlásit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s5W4</w.rf>
   <form>Hygienické</form>
   <lemma>hygienický</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s5W5</w.rf>
   <form>stanici</form>
   <lemma>stanice</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s5W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s5W7</w.rf>
   <form>Klatovech</form>
   <lemma>Klatovy_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s6">
  <m id="m-plzensky49294.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W2</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W4</w.rf>
   <form>PČR</form>
   <lemma>PČR_:B_;K_^(Parlament_České_republiky)</lemma>
   <tag>Xx-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W5</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W6</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W7</w.rf>
   <form>podchyceni</form>
   <lemma>podchytit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W8</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W10</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W11</w.rf>
   <form>mohli</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W13</w.rf>
   <form>látkou</form>
   <lemma>látka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W14</w.rf>
   <form>přijít</form>
   <lemma>přijít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W16</w.rf>
   <form>styku</form>
   <lemma>styk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s6W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s7">
  <m id="m-plzensky49294.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W1</w.rf>
   <form>Specialisté</form>
   <lemma>specialista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W3</w.rf>
   <form>Třemošné</form>
   <lemma>Třemošná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W4</w.rf>
   <form>odebrali</form>
   <lemma>odebrat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W5</w.rf>
   <form>vzorky</form>
   <lemma>vzorek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W7</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W8</w.rf>
   <form>stanovili</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W10</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W12</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W13</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W14</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W15</w.rf>
   <form>prášek</form>
   <lemma>prášek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W17</w.rf>
   <form>hasícího</form>
   <lemma>hasící_^(*3it)</lemma>
   <tag>AGIS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W18</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s7W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s8">
  <m id="m-plzensky49294.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W2</w.rf>
   <form>Českých</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W3</w.rf>
   <form>drah</form>
   <lemma>dráha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W5</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W6</w.rf>
   <form>událost</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W7</w.rf>
   <form>převzali</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W8</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W9</w.rf>
   <form>horažďovických</form>
   <lemma>horažďovický</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W10</w.rf>
   <form>profesionálů</form>
   <lemma>profesionál</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W11</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W12</w.rf>
   <form>pokyn</form>
   <lemma>pokyn</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W14</w.rf>
   <form>zametení</form>
   <lemma>zametení_^(*5ést)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W15</w.rf>
   <form>prášku</form>
   <lemma>prášek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W17</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W18</w.rf>
   <form>uložení</form>
   <lemma>uložení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W19</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W20</w.rf>
   <form>kontejneru</form>
   <lemma>kontejner</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s8W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s9">
  <m id="m-plzensky49294.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W2</w.rf>
   <form>úklidu</form>
   <lemma>úklid</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W3</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W4</w.rf>
   <form>nemuseli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W5</w.rf>
   <form>použít</form>
   <lemma>použít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W6</w.rf>
   <form>dýchací</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W7</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W9</w.rf>
   <form>stačily</form>
   <lemma>stačit_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W10</w.rf>
   <form>respirátory</form>
   <lemma>respirátor</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s9W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s10">
  <m id="m-plzensky49294.txt-001-p1s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s10W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s10W2</w.rf>
   <form>zametení</form>
   <lemma>zametení_^(*5ést)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s10W3</w.rf>
   <form>prášku</form>
   <lemma>prášek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s10W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s10W5</w.rf>
   <form>čekárna</form>
   <lemma>čekárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s10W6</w.rf>
   <form>znovu</form>
   <lemma>znovu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s10W7</w.rf>
   <form>otevřena</form>
   <lemma>otevřít</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s10W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49294.txt-001-p1s11">
  <m id="m-plzensky49294.txt-001-p1s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s11W1</w.rf>
   <form>Případ</form>
   <lemma>případ</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s11W2</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s11W3</w.rf>
   <form>PČR</form>
   <lemma>PČR_:B_;K_^(Parlament_České_republiky)</lemma>
   <tag>Xx-------------</tag>
  </m>
  <m id="m-plzensky49294.txt-001-p1s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49294.txt-001-p1s11W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
