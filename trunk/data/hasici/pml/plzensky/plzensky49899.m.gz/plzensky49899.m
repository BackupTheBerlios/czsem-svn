<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49899.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49899.txt-001-p1s1">
  <m id="m-plzensky49899.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W2</w.rf>
   <form>Dětský</form>
   <lemma>dětský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W3</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W4</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W6</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W7</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W8</w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W9</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W11</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W12</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W13</w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W14</w.rf>
   <form>Dětského</form>
   <lemma>dětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W15</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W17</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W18</w.rf>
   <form>pořádá</form>
   <lemma>pořádat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W19</w.rf>
   <form>Plzeňská</form>
   <lemma>plzeňský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W20</w.rf>
   <form>teplárenská</form>
   <lemma>teplárenský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W21</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W24</w.rf>
   <form>celém</form>
   <lemma>celý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W25</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W26</w.rf>
   <form>ZOO</form>
   <lemma>ZOO_:B</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p1s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s1">
  <m id="m-plzensky49899.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W3</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W4</w.rf>
   <form>složky</form>
   <lemma>složka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W5</w.rf>
   <form>IZS</form>
   <lemma>Izs</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W6</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W7</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W8</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W9</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W10</w.rf>
   <form>opravdu</form>
   <lemma>opravdu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W11</w.rf>
   <form>atraktivní</form>
   <lemma>atraktivní</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W12</w.rf>
   <form>podívanou</form>
   <lemma>podívaný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s2">
  <m id="m-plzensky49899.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W1</w.rf>
   <form>Návštěvníci</form>
   <lemma>návštěvník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W2</w.rf>
   <form>dětského</form>
   <lemma>dětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W5</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W6</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W7</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W8</w.rf>
   <form>10.00</form>
   <form_change>num_normalization</form_change>
   <lemma>10.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W10</w.rf>
   <form>prohlížet</form>
   <lemma>prohlížet_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W11</w.rf>
   <form>cisterny</form>
   <lemma>cisterna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W13</w.rf>
   <form>výškovou</form>
   <lemma>výškový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W14</w.rf>
   <form>techniku</form>
   <lemma>technika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W16</w.rf>
   <form>kontejnery</form>
   <lemma>kontejner</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W18</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W19</w.rf>
   <form>zásahová</form>
   <lemma>zásahový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W20</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s3">
  <m id="m-plzensky49899.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W1</w.rf>
   <form>Pozornost</form>
   <lemma>pozornost-1_^(všímavý,_milý,_soustředěný)_(*5ý-1)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W2</w.rf>
   <form>návštěvníků</form>
   <lemma>návštěvník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W3</w.rf>
   <form>upoutá</form>
   <lemma>upoutat_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W5</w.rf>
   <form>historická</form>
   <lemma>historický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W6</w.rf>
   <form>technika</form>
   <lemma>technika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W7</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W8</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s4">
  <m id="m-plzensky49899.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W2</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W3</w.rf>
   <form>ukázku</form>
   <lemma>ukázka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W4</w.rf>
   <form>vyprošťovacích</form>
   <lemma>vyprošťovací_^(*2t)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W5</w.rf>
   <form>prací</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W6</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W7</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W8</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W9</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W10</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W11</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W12</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W13</w.rf>
   <form>vyprošťovací</form>
   <lemma>vyprošťovací_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W14</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s5">
  <m id="m-plzensky49899.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W1</w.rf>
   <form>Své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8NS4---------1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W2</w.rf>
   <form>umění</form>
   <lemma>umění_^(mít_schopnost_něco_dělat)_(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W3</w.rf>
   <form>předvede</form>
   <lemma>předvést</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W5</w.rf>
   <form>lezecká</form>
   <lemma>lezecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W6</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W7</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W8</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W9</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W10</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W11</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W14</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W15</w.rf>
   <form>záchranu</form>
   <lemma>záchrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W16</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W17</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W18</w.rf>
   <form>výšky</form>
   <lemma>výška</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W20</w.rf>
   <form>slanění</form>
   <lemma>slanění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W21</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W22</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W23</w.rf>
   <form>plošiny</form>
   <lemma>plošina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s5W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s6">
  <m id="m-plzensky49899.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W1</w.rf>
   <form>Lahůdkou</form>
   <lemma>lahůdka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W2</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W3</w.rf>
   <form>jistě</form>
   <lemma>jistě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W4</w.rf>
   <form>ukázka</form>
   <lemma>ukázka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W5</w.rf>
   <form>evakuace</form>
   <lemma>evakuace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W6</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W7</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W8</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W9</w.rf>
   <form>rukávu</form>
   <lemma>rukáv</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W11</w.rf>
   <form>záchrana</form>
   <lemma>záchrana</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W12</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W13</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W14</w.rf>
   <form>automobilové</form>
   <lemma>automobilový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W15</w.rf>
   <form>plošiny</form>
   <lemma>plošina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W17</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W18</w.rf>
   <form>dosáhne</form>
   <lemma>dosáhnout</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W19</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W20</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W21</w.rf>
   <form>výšky</form>
   <lemma>výška</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W22</w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W23</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s6W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s7">
  <m id="m-plzensky49899.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W2</w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W4</w.rf>
   <form>poledni</form>
   <lemma>poledne</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W6</w.rf>
   <form>připravena</form>
   <lemma>připravit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W7</w.rf>
   <form>ukázka</form>
   <lemma>ukázka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W8</w.rf>
   <form>historické</form>
   <lemma>historický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W9</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W11</w.rf>
   <form>dekontaminačních</form>
   <lemma>dekontaminační</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W12</w.rf>
   <form>stanů</form>
   <lemma>stan</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W14</w.rf>
   <form>bazénků</form>
   <lemma>bazének</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W16</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W17</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W18</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W19</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W20</w.rf>
   <form>stanic</form>
   <lemma>stanice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W21</w.rf>
   <form>územního</form>
   <lemma>územní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W22</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s7W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s8">
  <m id="m-plzensky49899.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W1</w.rf>
   <form>Milovníci</form>
   <lemma>milovník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W2</w.rf>
   <form>výšek</form>
   <lemma>výška</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W4</w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W6</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS6---------1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W8</w.rf>
   <form>odpoledních</form>
   <lemma>odpolední</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W9</w.rf>
   <form>hodinách</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W11</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W12</w.rf>
   <form>lezecká</form>
   <lemma>lezecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W13</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W14</w.rf>
   <form>předvede</form>
   <lemma>předvést</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W15</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W17</w.rf>
   <form>sebezáchranné</form>
   <lemma>sebezáchranný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W18</w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W20</w.rf>
   <form>laně</form>
   <lemma>laň</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s8W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s9">
  <m id="m-plzensky49899.txt-001-p2s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W1</w.rf>
   <form>Účastníci</form>
   <lemma>účastník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W2</w.rf>
   <form>dětského</form>
   <lemma>dětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W4</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W5</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W6</w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W7</w.rf>
   <form>obdivovat</form>
   <lemma>obdivovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W8</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W9</w.rf>
   <form>automobilový</form>
   <lemma>automobilový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W10</w.rf>
   <form>žebřík</form>
   <lemma>žebřík</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W11</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W12</w.rf>
   <form>výtahem</form>
   <lemma>výtah</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W14</w.rf>
   <form>výšky</form>
   <lemma>výška</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W15</w.rf>
   <form>52</form>
   <lemma>52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W16</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s9W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s9W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s10">
  <m id="m-plzensky49899.txt-001-p2s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W1</w.rf>
   <form>Vyvrcholením</form>
   <lemma>vyvrcholení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W2</w.rf>
   <form>ukázek</form>
   <lemma>ukázka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W4</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W5</w.rf>
   <form>ukázka</form>
   <lemma>ukázka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W6</w.rf>
   <form>vyprošťovacích</form>
   <lemma>vyprošťovací_^(*2t)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W7</w.rf>
   <form>prací</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W8</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W9</w.rf>
   <form>hromadné</form>
   <lemma>hromadný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W10</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W11</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W13</w.rf>
   <form>požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W14</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W15</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W16</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W17</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W18</w.rf>
   <form>vyprošťovací</form>
   <lemma>vyprošťovací_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W19</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s10W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s10W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p2s11">
  <m id="m-plzensky49899.txt-001-p2s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s11W1</w.rf>
   <form>Půjde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s11W2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s11W3</w.rf>
   <form>nehodu</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s11W4</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s11W5</w.rf>
   <form>zraněním</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s11W6</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s11W7</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p2s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p2s11W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p3s1">
  <m id="m-plzensky49899.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W2</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W3</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W4</w.rf>
   <form>Sborem</form>
   <lemma>sbor</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W5</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W7</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W10</w.rf>
   <form>Střed</form>
   <lemma>střed</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W12</w.rf>
   <form>sdružením</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W13</w.rf>
   <form>Český</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W14</w.rf>
   <form>hasič</form>
   <lemma>hasič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W15</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W16</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W17</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W18</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W19</w.rf>
   <form>doprovodné</form>
   <lemma>doprovodný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W20</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W22</w.rf>
   <form>drobné</form>
   <lemma>drobný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W23</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W24</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W25</w.rf>
   <form>stříkání</form>
   <lemma>stříkání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W27</w.rf>
   <form>terč</form>
   <lemma>terč</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W28</w.rf>
   <form>aj</form>
   <lemma>aj-1_:B_^(a_jiný/á/é)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p3s2">
  <m id="m-plzensky49899.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W1</w.rf>
   <form>Nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W2</w.rf>
   <form>chybět</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W3</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W4</w.rf>
   <form>pěvecká</form>
   <lemma>pěvecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W5</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W6</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W7</w.rf>
   <form>Plzeňská</form>
   <lemma>plzeňský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W8</w.rf>
   <form>ZOO</form>
   <lemma>ZOO_:B</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W9</w.rf>
   <form>hledá</form>
   <lemma>hledat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W10</w.rf>
   <form>super</form>
   <lemma>super_,h_,t</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W11</w.rf>
   <form>star</form>
   <lemma>star</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W12</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p3s3">
  <m id="m-plzensky49899.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W3</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W4</w.rf>
   <form>moci</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W6</w.rf>
   <form>prohlédnout</form>
   <lemma>prohlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W8</w.rf>
   <form>doslova</form>
   <lemma>doslova</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W10</w.rf>
   <form>osahat</form>
   <lemma>osahat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W11</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W12</w.rf>
   <form>technické</form>
   <lemma>technický</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W13</w.rf>
   <form>prostředky</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W14</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W16</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W17</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W18</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W19</w.rf>
   <form>přilby</form>
   <lemma>přilba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W21</w.rf>
   <form>ochranné</form>
   <lemma>ochranný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W22</w.rf>
   <form>obleky</form>
   <lemma>oblek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W24</w.rf>
   <form>dýchací</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W25</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W26</w.rf>
   <form>aj</form>
   <lemma>aj-1_:B_^(a_jiný/á/é)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p3s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p3s3W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p4s1">
  <m id="m-plzensky49899.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W2</w.rf>
   <form>programu</form>
   <lemma>program-1</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W3</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W4</w.rf>
   <form>Dětského</form>
   <lemma>dětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W5</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W8</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W10</w.rf>
   <form>podílejí</form>
   <lemma>podílet_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W11</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W12</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W13</w.rf>
   <form>složky</form>
   <lemma>složka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W14</w.rf>
   <form>IZS</form>
   <lemma>Izs</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p4s2">
  <m id="m-plzensky49899.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W3</w.rf>
   <form>problematiky</form>
   <lemma>problematika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W4</w.rf>
   <form>zdravovědy</form>
   <lemma>zdravověda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W5</w.rf>
   <form>připravila</form>
   <lemma>připravit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W6</w.rf>
   <form>Zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W7</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W8</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W9</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W10</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p4s3">
  <m id="m-plzensky49899.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W1</w.rf>
   <form>Účastníci</form>
   <lemma>účastník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W2</w.rf>
   <form>dětského</form>
   <lemma>dětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W5</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W6</w.rf>
   <form>moci</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W7</w.rf>
   <form>prohlédnout</form>
   <lemma>prohlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W9</w.rf>
   <form>moderní</form>
   <lemma>moderní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W10</w.rf>
   <form>sanitu</form>
   <lemma>sanita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p4s4">
  <m id="m-plzensky49899.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W1</w.rf>
   <form>Ukázku</form>
   <lemma>ukázka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W2</w.rf>
   <form>výcviku</form>
   <lemma>výcvik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W3</w.rf>
   <form>služebních</form>
   <lemma>služební_^(poměr,byt,zbraň,...)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W4</w.rf>
   <form>psů</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W6</w.rf>
   <form>ukázku</form>
   <lemma>ukázka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W7</w.rf>
   <form>prvků</form>
   <lemma>prvek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W8</w.rf>
   <form>sebeobrany</form>
   <lemma>sebeobrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W9</w.rf>
   <form>připravila</form>
   <lemma>připravit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W10</w.rf>
   <form>Městská</form>
   <lemma>městský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W11</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W12</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p4s5">
  <m id="m-plzensky49899.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s5W1</w.rf>
   <form>Strážníci</form>
   <lemma>strážník_^(kdo_stráží,_člověk)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s5W2</w.rf>
   <form>předvedou</form>
   <lemma>předvést</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s5W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s5W4</w.rf>
   <form>zákroky</form>
   <lemma>zákrok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s5W5</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s5W6</w.rf>
   <form>nebezpečnému</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAMS3----1N----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s5W7</w.rf>
   <form>pachateli</form>
   <lemma>pachatel</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p4s6">
  <m id="m-plzensky49899.txt-001-p4s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W2</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W3</w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W4</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W5</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W7</w.rf>
   <form>střelbě</form>
   <lemma>střelba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W8</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W9</w.rf>
   <form>vzduchovky</form>
   <lemma>vzduchovka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s6W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p4s7">
  <m id="m-plzensky49899.txt-001-p4s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s7W1</w.rf>
   <form>Velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s7W2</w.rf>
   <form>atraktivní</form>
   <lemma>atraktivní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s7W3</w.rf>
   <form>ukázky</form>
   <lemma>ukázka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s7W4</w.rf>
   <form>připravila</form>
   <lemma>připravit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s7W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s7W6</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s7W7</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s7W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p4s8">
  <m id="m-plzensky49899.txt-001-p4s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W1</w.rf>
   <form>Policisté</form>
   <lemma>policista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W2</w.rf>
   <form>předvedou</form>
   <lemma>předvést</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W3</w.rf>
   <form>ukázky</form>
   <lemma>ukázka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W4</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W5</w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W7</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W8</w.rf>
   <form>výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W9</w.rf>
   <form>služebních</form>
   <lemma>služební_^(poměr,byt,zbraň,...)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W10</w.rf>
   <form>psů</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p4s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p4s8W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p5s1">
  <m id="m-plzensky49899.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W3</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W5</w.rf>
   <form>zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W6</w.rf>
   <form>soutěží</form>
   <lemma>soutěž</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W8</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W9</w.rf>
   <form>odnesou</form>
   <lemma>odnést</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W10</w.rf>
   <form>drobné</form>
   <lemma>drobný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W11</w.rf>
   <form>dárky</form>
   <lemma>dárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p5s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p6s1">
  <m id="m-plzensky49899.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W1</w.rf>
   <form>Programem</form>
   <lemma>program-1</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W2</w.rf>
   <form>připraveným</form>
   <lemma>připravený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W3</w.rf>
   <form>složkami</form>
   <lemma>složka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W4</w.rf>
   <form>IZS</form>
   <lemma>Izs</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W5</w.rf>
   <form>provází</form>
   <lemma>provázet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W6</w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W7</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W9</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W10</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W11</w.rf>
   <form>tiskový</form>
   <lemma>tiskový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W12</w.rf>
   <form>mluvčí</form>
   <lemma>mluvčí</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W13</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W14</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W15</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W16</w.rf>
   <form>František</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W17</w.rf>
   <form>Vaško</form>
   <lemma>Vaško_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p6s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s1">
  <m id="m-plzensky49899.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W1</w.rf>
   <form>Komu</form>
   <lemma>kdo</lemma>
   <tag>PKM-3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W2</w.rf>
   <form>nebudou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-NA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W3</w.rf>
   <form>stačit</form>
   <lemma>stačit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W4</w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W5</w.rf>
   <form>atrakce</form>
   <lemma>atrakce</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W7</w.rf>
   <form>nemusí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W8</w.rf>
   <form>zoufat</form>
   <lemma>zoufat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W10</w.rf>
   <form>jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W11</w.rf>
   <form>Plzeňská</form>
   <lemma>plzeňský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W12</w.rf>
   <form>teplárenská</form>
   <lemma>teplárenský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W13</w.rf>
   <form>a.s</form>
   <lemma>a.s</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W15</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W16</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W18</w.rf>
   <form>agenturou</form>
   <lemma>agentura</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W19</w.rf>
   <form>EUROVERLAG</form>
   <lemma>Euroverlag</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W21</w.rf>
   <form>celém</form>
   <lemma>celý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W22</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W23</w.rf>
   <form>ZOO</form>
   <lemma>ZOO_:B</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W24</w.rf>
   <form>připravila</form>
   <lemma>připravit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W25</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W26</w.rf>
   <form>atraktivní</form>
   <lemma>atraktivní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W27</w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s2">
  <m id="m-plzensky49899.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W2</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W3</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W4</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W5</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W6</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W7</w.rf>
   <form>vstupné</form>
   <lemma>vstupné_^(poplatek)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W9</w.rf>
   <form>ZOO</form>
   <lemma>ZOO_:B</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W10</w.rf>
   <form>zdarma</form>
   <lemma>zdarma</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W11</w.rf>
   <form>výměnou</form>
   <lemma>výměna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W12</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W13</w.rf>
   <form>obrázek</form>
   <lemma>obrázek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W14</w.rf>
   <form>zvířátka</form>
   <lemma>zvířátko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s3">
  <m id="m-plzensky49899.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W1</w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PKM-1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W2</w.rf>
   <form>obrázek</form>
   <lemma>obrázek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W3</w.rf>
   <form>zapomene</form>
   <lemma>zapomenout</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W5</w.rf>
   <form>nemusí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W6</w.rf>
   <form>zoufat</form>
   <lemma>zoufat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W8</w.rf>
   <form>jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W9</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W10</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W11</w.rf>
   <form>moci</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W12</w.rf>
   <form>namalovat</form>
   <lemma>namalovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W13</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W15</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s4">
  <m id="m-plzensky49899.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W1</w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W2</w.rf>
   <form>nejmenší</form>
   <lemma>malý</lemma>
   <tag>AAFP1----3A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W4</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W5</w.rf>
   <form>moci</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W6</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W7</w.rf>
   <form>zaskákat</form>
   <lemma>zaskákat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W9</w.rf>
   <form>skákacím</form>
   <lemma>skákací_^(*2t)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W10</w.rf>
   <form>hradu</form>
   <lemma>hrad</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W11</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W12</w.rf>
   <form>tvaru</form>
   <lemma>tvar</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W13</w.rf>
   <form>kouzelníka</form>
   <lemma>kouzelník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s4W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s5">
  <m id="m-plzensky49899.txt-001-p7s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W2</w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAFP4----2A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W3</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W4</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W5</w.rf>
   <form>připraveny</form>
   <lemma>připravit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W6</w.rf>
   <form>souboje</form>
   <lemma>souboj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W8</w.rf>
   <form>kladině</form>
   <lemma>kladina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W10</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W11</w.rf>
   <form>vyhraje</form>
   <lemma>vyhrát</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W12</w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W14</w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PKM-1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W15</w.rf>
   <form>druhého</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W16</w.rf>
   <form>shodí</form>
   <lemma>shodit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s6">
  <m id="m-plzensky49899.txt-001-p7s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W1</w.rf>
   <form>Oblíbený</form>
   <lemma>oblíbený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W4</w.rf>
   <form>běh</form>
   <lemma>běh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W6</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W7</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W8</w.rf>
   <form>dítě</form>
   <lemma>dítě</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W9</w.rf>
   <form>přivázáno</form>
   <lemma>přivázat_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W11</w.rf>
   <form>gumě</form>
   <lemma>guma</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W12</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W13</w.rf>
   <form>bungee</form>
   <lemma>bungee_,t_^(bungee_jumping)</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W14</w.rf>
   <form>running</form>
   <lemma>running</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W15</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s6W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s7">
  <m id="m-plzensky49899.txt-001-p7s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W1</w.rf>
   <form>Atraktivní</form>
   <lemma>atraktivní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W2</w.rf>
   <form>jistě</form>
   <lemma>jistě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W4</w.rf>
   <form>fotbalová</form>
   <lemma>fotbalový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W5</w.rf>
   <form>branka</form>
   <lemma>branka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W7</w.rf>
   <form>radarem</form>
   <lemma>radar</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W9</w.rf>
   <form>radar</form>
   <lemma>radar</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W10</w.rf>
   <form>gate</form>
   <lemma>gate</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W11</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W13</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W16</w.rf>
   <form>mladým</form>
   <lemma>mladý</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W17</w.rf>
   <form>fotbalistům</form>
   <lemma>fotbalista</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W19</w.rf>
   <form>fotbalistkám</form>
   <lemma>fotbalistka_^(*2a)</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W20</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W21</w.rf>
   <form>změří</form>
   <lemma>změřit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W22</w.rf>
   <form>rychlost</form>
   <lemma>rychlost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W23</w.rf>
   <form>střely</form>
   <lemma>střela</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s7W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s8">
  <m id="m-plzensky49899.txt-001-p7s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W2</w.rf>
   <form>oblíbené</form>
   <lemma>oblíbený_^(*3it)</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W3</w.rf>
   <form>atrakci</form>
   <lemma>atrakce</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W4</w.rf>
   <form>patří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W6</w.rf>
   <form>malování</form>
   <lemma>malování_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W7</w.rf>
   <form>zvířecích</form>
   <lemma>zvířecí</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W9</w.rf>
   <form>pohádkových</form>
   <lemma>pohádkový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W10</w.rf>
   <form>motivů</form>
   <lemma>motiv</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W12</w.rf>
   <form>obličej</form>
   <lemma>obličej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s8W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s9">
  <m id="m-plzensky49899.txt-001-p7s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W1</w.rf>
   <form>Dětské</form>
   <lemma>dětský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W2</w.rf>
   <form>obličejíčky</form>
   <lemma>obličejíček</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W3</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W4</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W5</w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W6</w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W7</w.rf>
   <form>trvání</form>
   <lemma>trvání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W8</w.rf>
   <form>dětského</form>
   <lemma>dětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W9</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W10</w.rf>
   <form>zdobit</form>
   <lemma>zdobit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W11</w.rf>
   <form>kresbami</form>
   <lemma>kresba</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W12</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W13</w.rf>
   <form>dívky</form>
   <lemma>dívka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s9W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p7s10">
  <m id="m-plzensky49899.txt-001-p7s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W1</w.rf>
   <form>Organizátoři</form>
   <lemma>organizátor</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W3</w.rf>
   <form>ZOO</form>
   <lemma>ZOO_:B</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W4</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W5</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W6</w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W7</w.rf>
   <form>řadu</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W8</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W9</w.rf>
   <form>soutěží</form>
   <lemma>soutěž</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W10</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W11</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p7s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p7s10W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p8s1">
  <m id="m-plzensky49899.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s1W1</w.rf>
   <form>Atraktivní</form>
   <lemma>atraktivní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s1W2</w.rf>
   <form>podívanou</form>
   <lemma>podívaná_^(byla_to_pěkná_p.)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s1W3</w.rf>
   <form>připravila</form>
   <lemma>připravit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s1W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s1W5</w.rf>
   <form>samotná</form>
   <lemma>samotný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s1W6</w.rf>
   <form>ZOO</form>
   <lemma>ZOO_:B</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s1W7</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p8s2">
  <m id="m-plzensky49899.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W2</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W3</w.rf>
   <form>moci</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W4</w.rf>
   <form>zhlédnout</form>
   <lemma>zhlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W5</w.rf>
   <form>ukázku</form>
   <lemma>ukázka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W6</w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W7</w.rf>
   <form>sokolníka</form>
   <lemma>sokolník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W9</w.rf>
   <form>prohlédnout</form>
   <lemma>prohlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W10</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W11</w.rf>
   <form>plazy</form>
   <lemma>plaz</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W13</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W14</w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W16</w.rf>
   <form>vlastní</form>
   <lemma>vlastní-1_^(příslušný_k_něčemu)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W17</w.rf>
   <form>oči</form>
   <lemma>oko</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W18</w.rf>
   <form>krmení</form>
   <lemma>krmení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W19</w.rf>
   <form>nosálů</form>
   <lemma>nosál</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W21</w.rf>
   <form>lemurů</form>
   <lemma>lemur_;L</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W23</w.rf>
   <form>šimpanzů</form>
   <lemma>šimpanz</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W25</w.rf>
   <form>tučňáků</form>
   <lemma>tučňák</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p8s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p8s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p9s1">
  <m id="m-plzensky49899.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W2</w.rf>
   <form>zkušenostech</form>
   <lemma>zkušenost_^(*3ý)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W4</w.rf>
   <form>loňska</form>
   <lemma>loňsko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W5</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W6</w.rf>
   <form>voleny</form>
   <lemma>volit_:T</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W7</w.rf>
   <form>atrakce</form>
   <lemma>atrakce</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W9</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W10</w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W11</w.rf>
   <form>doprovázeny</form>
   <lemma>doprovázet_:T</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W12</w.rf>
   <form>hlukem</form>
   <lemma>hluk</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49899.txt-001-p9s2">
  <m id="m-plzensky49899.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s2W1</w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s2W2</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s2W3</w.rf>
   <form>zvířátkům</form>
   <lemma>zvířátko</lemma>
   <tag>NNNP3-----A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s2W4</w.rf>
   <form>nedělá</form>
   <lemma>dělat_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s2W5</w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49899.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49899.txt-001-p9s2W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
