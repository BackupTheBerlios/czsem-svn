<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky49032.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky49032.txt-001-p1s1">
  <m id="m-plzensky49032.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W1</w.rf>
   <form>Druhý</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W2</w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W3</w.rf>
   <form>Memoriálu</form>
   <lemma>memoriál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W4</w.rf>
   <form>pořádá</form>
   <lemma>pořádat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W5</w.rf>
   <form>Hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W6</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W7</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W8</w.rf>
   <form>Plzeňského</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W9</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W11</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W12</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W13</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W15</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W16</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W18</w.rf>
   <form>Plzeňským</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W19</w.rf>
   <form>krajem</form>
   <lemma>kraj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W21</w.rf>
   <form>městem</form>
   <lemma>město</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W22</w.rf>
   <form>Rokycany</form>
   <lemma>Rokycana_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W23</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W24</w.rf>
   <form>přispění</form>
   <lemma>přispění_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W25</w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W26</w.rf>
   <form>Ambulance</form>
   <lemma>ambulance</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W27</w.rf>
   <form>Mediatrans</form>
   <lemma>Mediatrans</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W28</w.rf>
   <form>s.r.o</form>
   <lemma>s.r.o</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W30</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W31</w.rf>
   <form>otevřenou</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W32</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W33</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W34</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W35</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W36</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W37</w.rf>
   <form>zdravotnických</form>
   <lemma>zdravotnický</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W38</w.rf>
   <form>sil</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W39</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W40</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W41</w.rf>
   <form>zraněných</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W42</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W43</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W44</w.rf>
   <form>havarovaných</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W45</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W46</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W47</w.rf>
   <form>zaměřenou</form>
   <lemma>zaměřený_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W48</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W49</w.rf>
   <form>vzájemnou</form>
   <lemma>vzájemný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W50</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W51</w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W52</w.rf>
   <form>složek</form>
   <lemma>složka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s1W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s1W53</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p1s2">
  <m id="m-plzensky49032.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W1</w.rf>
   <form>Připomínám</form>
   <lemma>připomínat_:T</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W3</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W5</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W6</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W8</w.rf>
   <form>Memoriál</form>
   <lemma>memoriál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W9</w.rf>
   <form>současně</form>
   <lemma>současně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W10</w.rf>
   <form>krajským</form>
   <lemma>krajský</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W11</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W13</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W14</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W15</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W16</w.rf>
   <form>havarovaných</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W17</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W19</w.rf>
   <form>tudíž</form>
   <lemma>tudíž</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W20</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W21</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W22</w.rf>
   <form>nemohla</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W23</w.rf>
   <form>ZZS</form>
   <lemma>Zzs</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W24</w.rf>
   <form>zúčastnit</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p1s3">
  <m id="m-plzensky49032.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W1</w.rf>
   <form>Jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W2</w.rf>
   <form>otevřená</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W3</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W4</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W5</w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>ClHP4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W6</w.rf>
   <form>složky</form>
   <lemma>složka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W7</w.rf>
   <form>IZS</form>
   <lemma>Izs</lemma>
   <tag>NNISX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W8</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W9</w.rf>
   <form>Memoriál</form>
   <lemma>memoriál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W10</w.rf>
   <form>pořádán</form>
   <lemma>pořádat_:T</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W11</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W12</w.rf>
   <form>ob</form>
   <lemma>ob-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W13</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClIS4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W14</w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p1s4">
  <m id="m-plzensky49032.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W1</w.rf>
   <form>Soutěžní</form>
   <lemma>soutěžní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W2</w.rf>
   <form>klání</form>
   <lemma>klání_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W4</w.rf>
   <form>slavnostně</form>
   <lemma>slavnostně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W5</w.rf>
   <form>zahájeno</form>
   <lemma>zahájit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W6</w.rf>
   <form>nástupem</form>
   <lemma>nástup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W7</w.rf>
   <form>soutěžních</form>
   <lemma>soutěžní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W8</w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W10</w.rf>
   <form>rozhodčích</form>
   <lemma>rozhodčí</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W12</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W13</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W14</w.rf>
   <form>10.30</form>
   <form_change>num_normalization</form_change>
   <lemma>10.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W16</w.rf>
   <form>11.00</form>
   <form_change>num_normalization</form_change>
   <lemma>11.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W17</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s4W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p1s5">
  <m id="m-plzensky49032.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W1</w.rf>
   <form>Samotná</form>
   <lemma>samotný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W2</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W4</w.rf>
   <form>naplánována</form>
   <lemma>naplánovat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W6</w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W7</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W8</w.rf>
   <form>11.00</form>
   <form_change>num_normalization</form_change>
   <lemma>11.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W10</w.rf>
   <form>14.30</form>
   <form_change>num_normalization</form_change>
   <lemma>14.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s5W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p1s6">
  <m id="m-plzensky49032.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W1</w.rf>
   <form>Slavnostní</form>
   <lemma>slavnostní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W2</w.rf>
   <form>vyhodnocení</form>
   <lemma>vyhodnocení_^(*4tit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W4</w.rf>
   <form>naplánováno</form>
   <lemma>naplánovat_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W6</w.rf>
   <form>15.15</form>
   <form_change>num_normalization</form_change>
   <lemma>15.15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W9</w.rf>
   <form>restauračním</form>
   <lemma>restaurační</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W10</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W11</w.rf>
   <form>Střelnice</form>
   <lemma>střelnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W13</w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W14</w.rf>
   <form>chybět</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W15</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W16</w.rf>
   <form>muzika</form>
   <lemma>muzika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p1s6W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p2s1">
  <m id="m-plzensky49032.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W2</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W3</w.rf>
   <form>uskutečněna</form>
   <lemma>uskutečnit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W4</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W5</w.rf>
   <form>pravidel</form>
   <lemma>pravidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W6</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W8</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W9</w.rf>
   <form>zraněných</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W10</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W12</w.rf>
   <form>havarovaných</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W13</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W14</w.rf>
   <form>vydaných</form>
   <lemma>vydaný-1_^(emitovat:_cenné_papíry,_knihu,_zvuk,...)_(*4t-1)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W15</w.rf>
   <form>Pokynem</form>
   <lemma>pokyn</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W16</w.rf>
   <form>generálního</form>
   <lemma>generální</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W17</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W18</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W19</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W20</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W21</w.rf>
   <form>46</form>
   <lemma>46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W22</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W23</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W24</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W25</w.rf>
   <form>některými</form>
   <lemma>některý</lemma>
   <tag>PZXP7----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W26</w.rf>
   <form>úpravami</form>
   <lemma>úprava</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p2s2">
  <m id="m-plzensky49032.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W1</w.rf>
   <form>Soutěžit</form>
   <lemma>soutěžit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W2</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W3</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W4</w.rf>
   <form>čtyřčlenné</form>
   <lemma>čtyřčlenný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W5</w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W8</w.rf>
   <form>tříčlenné</form>
   <lemma>tříčlenný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W9</w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W10</w.rf>
   <form>zdravotníků</form>
   <lemma>zdravotník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p2s3">
  <m id="m-plzensky49032.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W2</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W3</w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W4</w.rf>
   <form>nastoupí</form>
   <lemma>nastoupit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W6</w.rf>
   <form>ochranném</form>
   <lemma>ochranný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W7</w.rf>
   <form>oděvu</form>
   <lemma>oděv</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W8</w.rf>
   <form>složeném</form>
   <lemma>složený_^(*3it)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W10</w.rf>
   <form>kabátu</form>
   <lemma>kabát</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W12</w.rf>
   <form>kalhot</form>
   <lemma>kalhoty_^(pomn.)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W14</w.rf>
   <form>zásahové</form>
   <lemma>zásahový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W15</w.rf>
   <form>obuvi</form>
   <lemma>obuv</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W17</w.rf>
   <form>zásahových</form>
   <lemma>zásahový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W18</w.rf>
   <form>rukavic</form>
   <lemma>rukavice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W20</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W21</w.rf>
   <form>přilby</form>
   <lemma>přilba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W22</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W23</w.rf>
   <form>obličejovým</form>
   <lemma>obličejový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W24</w.rf>
   <form>štítem</form>
   <lemma>štít</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W25</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W26</w.rf>
   <form>brýlemi</form>
   <lemma>brýle</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W28</w.rf>
   <form>chirurgickými</form>
   <lemma>chirurgický</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W29</w.rf>
   <form>rukavicemi</form>
   <lemma>rukavice</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W31</w.rf>
   <form>rychlým</form>
   <lemma>rychlý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W32</w.rf>
   <form>zásahovým</form>
   <lemma>zásahový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W33</w.rf>
   <form>automobilem</form>
   <lemma>automobil</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W34</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W35</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W36</w.rf>
   <form>vozidlem</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W37</w.rf>
   <form>CAS</form>
   <lemma>Casa_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W38</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W39</w.rf>
   <form>výbavou</form>
   <lemma>výbava</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s3W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s3W40</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p2s4">
  <m id="m-plzensky49032.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W1</w.rf>
   <form>Zdravotníci</form>
   <lemma>zdravotník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W2</w.rf>
   <form>nastoupí</form>
   <lemma>nastoupit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W4</w.rf>
   <form>ochranných</form>
   <lemma>ochranný</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W5</w.rf>
   <form>pracovních</form>
   <lemma>pracovní</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W6</w.rf>
   <form>prostředcích</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W8</w.rf>
   <form>vlastních</form>
   <lemma>vlastní-1_^(příslušný_k_něčemu)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W9</w.rf>
   <form>právních</form>
   <lemma>právní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W10</w.rf>
   <form>předpisů</form>
   <lemma>předpis</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W13</w.rf>
   <form>vozidlem</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W14</w.rf>
   <form>rychlé</form>
   <lemma>rychlý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W15</w.rf>
   <form>lékařské</form>
   <lemma>lékařský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W16</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p2s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p3s1">
  <m id="m-plzensky49032.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W2</w.rf>
   <form>havarovaném</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W3</w.rf>
   <form>vozidle</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W5</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W6</w.rf>
   <form>nacházet</form>
   <lemma>nacházet_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W7</w.rf>
   <form>zaklíněný</form>
   <lemma>zaklíněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W8</w.rf>
   <form>řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W10</w.rf>
   <form>připraveného</form>
   <lemma>připravený_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W11</w.rf>
   <form>scénáře</form>
   <lemma>scénář</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W13</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W14</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W15</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W16</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W17</w.rf>
   <form>jednotlivé</form>
   <lemma>jednotlivý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W18</w.rf>
   <form>soutěžící</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGNS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W19</w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W20</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W21</w.rf>
   <form>připraveno</form>
   <lemma>připravit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W22</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W23</w.rf>
   <form>vylosovaného</form>
   <lemma>vylosovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W24</w.rf>
   <form>scénáře</form>
   <lemma>scénář</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p3s2">
  <m id="m-plzensky49032.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W1</w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W2</w.rf>
   <form>scénář</form>
   <lemma>scénář</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W4</w.rf>
   <form>obsahovat</form>
   <lemma>obsahovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W5</w.rf>
   <form>minimálně</form>
   <lemma>minimálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W6</w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>ClNS1----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W7</w.rf>
   <form>havarované</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W8</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W10</w.rf>
   <form>případně</form>
   <lemma>případně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W11</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W12</w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W13</w.rf>
   <form>komplikace</form>
   <lemma>komplikace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W14</w.rf>
   <form>simulované</form>
   <lemma>simulovaný_^(*2t)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W15</w.rf>
   <form>prostředky</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W17</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W19</w.rf>
   <form>vyskytují</form>
   <lemma>vyskytovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W21</w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W22</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W23</w.rf>
   <form>provozem</form>
   <lemma>provoz</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W25</w.rf>
   <form>pozemních</form>
   <lemma>pozemní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W26</w.rf>
   <form>komunikacích</form>
   <lemma>komunikace</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p3s3">
  <m id="m-plzensky49032.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W1</w.rf>
   <form>Typ</form>
   <lemma>typ</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W3</w.rf>
   <form>rozsah</form>
   <lemma>rozsah</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W4</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W5</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W6</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W7</w.rf>
   <form>figurant</form>
   <lemma>figurant</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W9</w.rf>
   <form>písemné</form>
   <lemma>písemný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W10</w.rf>
   <form>formě</form>
   <lemma>forma</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W11</w.rf>
   <form>viditelně</form>
   <lemma>viditelně_^(*6ět)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W12</w.rf>
   <form>umístěn</form>
   <lemma>umístit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W14</w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6-X6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p3s4">
  <m id="m-plzensky49032.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W1</w.rf>
   <form>Start</form>
   <lemma>start</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W2</w.rf>
   <form>družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W4</w.rf>
   <form>proveden</form>
   <lemma>provést</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W5</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W6</w.rf>
   <form>píšťalky</form>
   <lemma>píšťalka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W7</w.rf>
   <form>hlavním</form>
   <lemma>hlavní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W8</w.rf>
   <form>rozhodčím</form>
   <lemma>rozhodčí</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W10</w.rf>
   <form>pokus</form>
   <lemma>pokus</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W11</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W12</w.rf>
   <form>ukončen</form>
   <lemma>ukončit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W13</w.rf>
   <form>zvednutím</form>
   <lemma>zvednutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W14</w.rf>
   <form>paže</form>
   <lemma>paže</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W15</w.rf>
   <form>velitelem</form>
   <lemma>velitel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W16</w.rf>
   <form>soutěžního</form>
   <lemma>soutěžní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W17</w.rf>
   <form>družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W18</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W19</w.rf>
   <form>předání</form>
   <lemma>předání-1_,a_^(příst)_(*5at-1)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W20</w.rf>
   <form>zraněného</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W21</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W22</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W23</w.rf>
   <form>vymezeného</form>
   <lemma>vymezený_^(*3it)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W24</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s4W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p3s5">
  <m id="m-plzensky49032.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W1</w.rf>
   <form>Výkony</form>
   <lemma>výkon</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W2</w.rf>
   <form>soutěžních</form>
   <lemma>soutěžní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W3</w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W4</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W5</w.rf>
   <form>hodnotit</form>
   <lemma>hodnotit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W6</w.rf>
   <form>rozhodčí</form>
   <lemma>rozhodčí</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W8</w.rf>
   <form>řad</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-1_:B_;K_^(Hasičský_záchranný_sbor)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W11</w.rf>
   <form>ZZS</form>
   <lemma>Zz</lemma>
   <tag>NNNPX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p3s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p3s5W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p4s1">
  <m id="m-plzensky49032.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s1W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s1W2</w.rf>
   <form>vítěze</form>
   <lemma>vítěz</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s1W3</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s1W4</w.rf>
   <form>připraveny</form>
   <lemma>připravit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s1W5</w.rf>
   <form>poháry</form>
   <lemma>pohár</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s1W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p4s2">
  <m id="m-plzensky49032.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W1</w.rf>
   <form>Putovní</form>
   <lemma>putovní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W2</w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W4</w.rf>
   <form>hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W5</w.rf>
   <form>cenu</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W6</w.rf>
   <form>získá</form>
   <lemma>získat_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W7</w.rf>
   <form>nejlepší</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----3A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W8</w.rf>
   <form>společné</form>
   <lemma>společný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W9</w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W10</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W12</w.rf>
   <form>ZZS</form>
   <lemma>Zzs</lemma>
   <tag>NNISX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W14</w.rf>
   <form>druhý</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W15</w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W16</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W17</w.rf>
   <form>připraven</form>
   <lemma>připravit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W18</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W19</w.rf>
   <form>nejlepší</form>
   <lemma>dobrý</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W20</w.rf>
   <form>tým</form>
   <lemma>tým</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W22</w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W23</w.rf>
   <form>ZZS</form>
   <lemma>Zzs</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W25</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W26</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W27</w.rf>
   <form>nejlepší</form>
   <lemma>dobrý</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W28</w.rf>
   <form>tým</form>
   <lemma>tým</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W29</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W30</w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W31</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s2W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky49032.txt-001-p4s3">
  <m id="m-plzensky49032.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W2</w.rf>
   <form>všechna</form>
   <lemma>všechen</lemma>
   <tag>PLNP4----------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W3</w.rf>
   <form>zúčastněná</form>
   <lemma>zúčastněný_^(*3it)</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W4</w.rf>
   <form>družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W5</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W6</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W7</w.rf>
   <form>připraveny</form>
   <lemma>připravit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W8</w.rf>
   <form>diplomy</form>
   <lemma>diplom</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W10</w.rf>
   <form>věcné</form>
   <lemma>věcný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W11</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky49032.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky49032.txt-001-p4s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
