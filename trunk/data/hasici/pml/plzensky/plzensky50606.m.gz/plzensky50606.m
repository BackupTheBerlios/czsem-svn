<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky50606.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky50606.txt-001-p1s1">
  <m id="m-plzensky50606.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W1</w.rf>
   <form>Tým</form>
   <lemma>tým</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W2</w.rf>
   <form>Terénní</form>
   <lemma>terénní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W3</w.rf>
   <form>krizové</form>
   <lemma>krizový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W4</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W5</w.rf>
   <form>plzeňské</form>
   <lemma>plzeňský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W6</w.rf>
   <form>diecézní</form>
   <lemma>diecézní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W7</w.rf>
   <form>charity</form>
   <lemma>charita</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W9</w.rf>
   <form>nejprve</form>
   <lemma>nejprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W10</w.rf>
   <form>telefonicky</form>
   <lemma>telefonicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W11</w.rf>
   <form>spojil</form>
   <lemma>spojit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W12</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W13</w.rf>
   <form>starosty</form>
   <lemma>starosta</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W14</w.rf>
   <form>postižených</form>
   <lemma>postižený_^(*4hnout)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W15</w.rf>
   <form>obcí</form>
   <lemma>obec</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50606.txt-001-p1s2">
  <m id="m-plzensky50606.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W1</w.rf>
   <form>Následně</form>
   <lemma>následně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W2</w.rf>
   <form>vyrazil</form>
   <lemma>vyrazit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W3</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W4</w.rf>
   <form>Kozojed</form>
   <lemma>Kozojedy_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W6</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W7</w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W8</w.rf>
   <form>napáchala</form>
   <lemma>napáchat_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W9</w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W10</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p1s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50606.txt-001-p2s1">
  <m id="m-plzensky50606.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W1</w.rf>
   <form>Pracovníci</form>
   <lemma>pracovník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W2</w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W4</w.rf>
   <form>dohodě</form>
   <lemma>dohoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W5</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W6</w.rf>
   <form>starostou</form>
   <lemma>starosta</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W7</w.rf>
   <form>navštívili</form>
   <lemma>navštívit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W8</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W9</w.rf>
   <form>nejvíce</form>
   <lemma>hodně</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W10</w.rf>
   <form>zasažené</form>
   <lemma>zasažený_^(*5áhnout)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W11</w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50606.txt-001-p2s2">
  <m id="m-plzensky50606.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W2</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W3</w.rf>
   <form>domech</form>
   <lemma>dům</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W4</w.rf>
   <form>sice</form>
   <lemma>sice_^(spojka/příslovce;_připouští_se_určitá_fakta)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W5</w.rf>
   <form>bahno</form>
   <lemma>bahno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W6</w.rf>
   <form>neproniko</form>
   <lemma>neproniko</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W8</w.rf>
   <form>obytných</form>
   <lemma>obytný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W9</w.rf>
   <form>prostor</form>
   <lemma>prostora</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W11</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W12</w.rf>
   <form>ničilo</form>
   <lemma>ničit_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W13</w.rf>
   <form>kotle</form>
   <lemma>kotel</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W15</w.rf>
   <form>spotřebiče</form>
   <lemma>spotřebič</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W17</w.rf>
   <form>nábytek</form>
   <lemma>nábytek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W19</w.rf>
   <form>suterénu</form>
   <lemma>suterén</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W21</w.rf>
   <form>zahrádky</form>
   <lemma>zahrádka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W23</w.rf>
   <form>dvorky</form>
   <lemma>dvorek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50606.txt-001-p2s3">
  <m id="m-plzensky50606.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s3W1</w.rf>
   <form>Přivezli</form>
   <lemma>přivézt_^(něco/někoho_autem,_vlakem,...)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s3W2</w.rf>
   <form>obyvatelům</form>
   <lemma>obyvatel</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s3W3</w.rf>
   <form>desinfekce</form>
   <lemma>desinfekce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s3W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s3W5</w.rf>
   <form>pracovní</form>
   <lemma>pracovní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s3W6</w.rf>
   <form>pomůcky</form>
   <lemma>pomůcka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50606.txt-001-p2s4">
  <m id="m-plzensky50606.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s4W1</w.rf>
   <form>Poradili</form>
   <lemma>poradit_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s4W2</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s4W3</w.rf>
   <form>vysoušením</form>
   <lemma>vysoušení_^(*2t)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p2s4W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50606.txt-001-p3s1">
  <m id="m-plzensky50606.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W1</w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W2</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W3</w.rf>
   <form>nejvíce</form>
   <lemma>hodně</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W4</w.rf>
   <form>zasaženého</form>
   <lemma>zasažený_^(*5áhnout)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W5</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W6</w.rf>
   <form>přivezou</form>
   <lemma>přivézt_^(něco/někoho_autem,_vlakem,...)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W7</w.rf>
   <form>dobrovolníci</form>
   <lemma>dobrovolník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W8</w.rf>
   <form>krizového</form>
   <lemma>krizový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W9</w.rf>
   <form>týmu</form>
   <lemma>tým</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W10</w.rf>
   <form>vysokotlaký</form>
   <lemma>vysokotlaký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W11</w.rf>
   <form>čistič</form>
   <lemma>čistič</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W13</w.rf>
   <form>průmyslový</form>
   <lemma>průmyslový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W14</w.rf>
   <form>vysavač</form>
   <lemma>vysavač</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W16</w.rf>
   <form>pomohou</form>
   <lemma>pomoci</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W18</w.rf>
   <form>očistou</form>
   <lemma>očista</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W19</w.rf>
   <form>poničených</form>
   <lemma>poničený_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W20</w.rf>
   <form>zdí</form>
   <lemma>zeď</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W22</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50606.txt-001-p3s2">
  <m id="m-plzensky50606.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s2W1</w.rf>
   <form>Zapůjčí</form>
   <lemma>zapůjčit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s2W2</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s2W3</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s2W4</w.rf>
   <form>vysoušečů</form>
   <lemma>vysoušeč</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p3s2W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky50606.txt-001-p4s1">
  <m id="m-plzensky50606.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W1</w.rf>
   <form>Fotografie</form>
   <lemma>Fotografia_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W4</w.rf>
   <form>http</form>
   <lemma>HTTP-1_:B_,t_,x_^(Hypertext_transfer_protocol)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W5</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W6</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W7</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W8</w.rf>
   <form>charita.fotopic.net</form>
   <lemma>charita.fotopic.net</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W9</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky50606.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky50606.txt-001-p4s1W10</w.rf>
   <form>c1285311.html</form>
   <lemma>c1285311.html</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
 </s>
</mdata>
