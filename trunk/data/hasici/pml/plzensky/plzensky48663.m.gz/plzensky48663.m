<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="plzensky48663.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-plzensky48663.txt-001-p1s1">
  <m id="m-plzensky48663.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W2</w.rf>
   <form>celkového</form>
   <lemma>celkový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W3</w.rf>
   <form>počtu</form>
   <lemma>počet</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W4</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W7</w.rf>
   <form>477</form>
   <lemma>477</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W8</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W9</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W10</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W11</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W14</w.rf>
   <form>453</form>
   <lemma>453</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W15</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W17</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W18</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W21</w.rf>
   <form>774</form>
   <lemma>774</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W22</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W23</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W24</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W25</w.rf>
   <form>živelní</form>
   <lemma>živelní_^(pohroma,...)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W26</w.rf>
   <form>pohromy</form>
   <lemma>pohroma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W28</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W29</w.rf>
   <form>126</form>
   <lemma>126</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W30</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W31</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W32</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W33</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W34</w.rf>
   <form>nebezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W35</w.rf>
   <form>chemické</form>
   <lemma>chemický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W36</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W37</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W38</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W39</w.rf>
   <form>562</form>
   <lemma>562</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W40</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W41</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W42</w.rf>
   <form>technické</form>
   <lemma>technický</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W43</w.rf>
   <form>zásahy</form>
   <lemma>zásah</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s1W44</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p1s2">
  <m id="m-plzensky48663.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s2W1</w.rf>
   <form>Rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s2W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s2W3</w.rf>
   <form>zaznamenáno</form>
   <lemma>zaznamenat_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s2W4</w.rf>
   <form>144</form>
   <lemma>144</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s2W5</w.rf>
   <form>planých</form>
   <lemma>planý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s2W6</w.rf>
   <form>poplachů</form>
   <lemma>poplach</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p1s3">
  <m id="m-plzensky48663.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W2</w.rf>
   <form>srovnání</form>
   <lemma>srovnání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W3</w.rf>
   <form>uvádím</form>
   <lemma>uvádět_:T</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W5</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W7</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W8</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W9</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W10</w.rf>
   <form>stejné</form>
   <lemma>stejný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W11</w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W12</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W14</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W15</w.rf>
   <form>326</form>
   <lemma>326</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W16</w.rf>
   <form>požárům</form>
   <lemma>požár</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W17</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W18</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W19</w.rf>
   <form>vyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W20</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W21</w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W22</w.rf>
   <form>milionů</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W23</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p1s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p1s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p2s1">
  <m id="m-plzensky48663.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W2</w.rf>
   <form>způsobená</form>
   <lemma>způsobený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W3</w.rf>
   <form>477</form>
   <lemma>477</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W4</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W5</w.rf>
   <form>dosáhla</form>
   <lemma>dosáhnout</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W6</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W7</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W8</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W9</w.rf>
   <form>27</form>
   <lemma>27</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W10</w.rf>
   <form>milionů</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W11</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p2s2">
  <m id="m-plzensky48663.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W2</w.rf>
   <form>požárech</form>
   <lemma>požár</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W3</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W4</w.rf>
   <form>počátku</form>
   <lemma>počátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W5</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W6</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W7</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W8</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W9</w.rf>
   <form>usmrceny</form>
   <lemma>usmrtit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W11</w.rf>
   <form>šestnáct</form>
   <lemma>šestnáct`16</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W12</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W13</w.rf>
   <form>zraněno</form>
   <lemma>zranit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p2s3">
  <m id="m-plzensky48663.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W1</w.rf>
   <form>Mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W2</w.rf>
   <form>zraněnými</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W5</w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W6</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W8</w.rf>
   <form>věku</form>
   <lemma>věk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W10</w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W11</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p2s4">
  <m id="m-plzensky48663.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W2</w.rf>
   <form>zásazích</form>
   <lemma>zásah</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W3</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W4</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W5</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W6</w.rf>
   <form>zraněno</form>
   <lemma>zranit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W7</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W8</w.rf>
   <form>třináct</form>
   <lemma>třináct`13</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W9</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W12</w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W13</w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W14</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p2s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p3s1">
  <m id="m-plzensky48663.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W2</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W3</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W5</w.rf>
   <form>zaznamenáno</form>
   <lemma>zaznamenat_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W6</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W7</w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W8</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W10</w.rf>
   <form>rodinných</form>
   <lemma>rodinný</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W11</w.rf>
   <form>domcích</form>
   <lemma>domek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W13</w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W14</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W15</w.rf>
   <form>dopravních</form>
   <lemma>dopravní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W16</w.rf>
   <form>prostředků</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W18</w.rf>
   <form>pracovních</form>
   <lemma>pracovní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W19</w.rf>
   <form>strojů</form>
   <lemma>stroj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W21</w.rf>
   <form>47</form>
   <lemma>47</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W22</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W23</w.rf>
   <form>lesů</form>
   <lemma>les</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W25</w.rf>
   <form>32</form>
   <lemma>32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W26</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W27</w.rf>
   <form>bytového</form>
   <lemma>bytový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W28</w.rf>
   <form>fondu</form>
   <lemma>fond</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W30</w.rf>
   <form>78</form>
   <lemma>78</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W31</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W32</w.rf>
   <form>odpadů</form>
   <lemma>odpad</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W33</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W34</w.rf>
   <form>odpadních</form>
   <lemma>odpadní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W35</w.rf>
   <form>produktů</form>
   <lemma>produkt</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W37</w.rf>
   <form>87</form>
   <lemma>87</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W38</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W39</w.rf>
   <form>volných</form>
   <lemma>volný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W40</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W41</w.rf>
   <form>skladovacích</form>
   <lemma>skladovací_^(*2t)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W42</w.rf>
   <form>ploch</form>
   <lemma>plocha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W43</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W44</w.rf>
   <form>budovu</form>
   <lemma>budova</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W45</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W46</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W47</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W48</w.rf>
   <form>budov</form>
   <lemma>budova</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W49</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W50</w.rf>
   <form>hal</form>
   <lemma>hala</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W51</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W52</w.rf>
   <form>výrobu</form>
   <lemma>výroba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W53</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W54</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W55</w.rf>
   <form>aj</form>
   <lemma>aj-1_:B_^(a_jiný/á/é)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s1W56-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s1W56</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p3s2">
  <m id="m-plzensky48663.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W1</w.rf>
   <form>Nejvyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAFS4----3A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W2</w.rf>
   <form>škodu</form>
   <lemma>škoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W4</w.rf>
   <form>5115</form>
   <form_change>num_normalization</form_change>
   <lemma>5115</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W5</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W6</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W7</w.rf>
   <form>právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W8</w.rf>
   <form>způsobily</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W9</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W10</w.rf>
   <form>budov</form>
   <lemma>budova</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W12</w.rf>
   <form>hal</form>
   <lemma>hala</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W13</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W14</w.rf>
   <form>výrobu</form>
   <lemma>výroba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p3s3">
  <m id="m-plzensky48663.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W2</w.rf>
   <form>druhém</form>
   <lemma>druhý-2</lemma>
   <tag>CrNS6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W3</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W4</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W5</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W6</w.rf>
   <form>hlediska</form>
   <lemma>hledisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W7</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W8</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W9</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W10</w.rf>
   <form>rodinných</form>
   <lemma>rodinný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W11</w.rf>
   <form>domků</form>
   <lemma>domek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W12</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W13</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W14</w.rf>
   <form>2944</form>
   <form_change>num_normalization</form_change>
   <lemma>2944</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W15</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W16</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W19</w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W20</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W21</w.rf>
   <form>dopravních</form>
   <lemma>dopravní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W22</w.rf>
   <form>prostředků</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W24</w.rf>
   <form>pracovních</form>
   <lemma>pracovní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W25</w.rf>
   <form>strojů</form>
   <lemma>stroj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W26</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W27</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W28</w.rf>
   <form>vyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAFS2----2A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W29</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W30</w.rf>
   <form>2918</form>
   <form_change>num_normalization</form_change>
   <lemma>2918</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W31</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W32</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W33</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W34</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W35</w.rf>
   <form>čtvrtém</form>
   <lemma>čtvrtý</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W36</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W37</w.rf>
   <form>budov</form>
   <lemma>budova</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W38</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W39</w.rf>
   <form>společné</form>
   <lemma>společný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W40</w.rf>
   <form>ubytování</form>
   <lemma>ubytování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W41</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W42</w.rf>
   <form>rekreaci</form>
   <lemma>rekreace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W43</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W44</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W45</w.rf>
   <form>2858</form>
   <form_change>num_normalization</form_change>
   <lemma>2858</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W46</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W47</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p3s3W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p3s3W48</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p4s1">
  <m id="m-plzensky48663.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W1</w.rf>
   <form>Nejvíce</form>
   <lemma>hodně</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W2</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W4</w.rf>
   <form>366</form>
   <lemma>366</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W6</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W7</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W8</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W10</w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W11</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W12</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p4s2">
  <m id="m-plzensky48663.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W2</w.rf>
   <form>88</form>
   <lemma>88</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W3</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W5</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W7</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W8</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W9</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W10</w.rf>
   <form>10000</form>
   <form_change>num_normalization</form_change>
   <lemma>10000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W13</w.rf>
   <form>250</form>
   <lemma>250</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W14</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W15</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W18</w.rf>
   <form>jedenácti</form>
   <lemma>jedenáct`11</lemma>
   <tag>Cn-P6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W19</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W20</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W21</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W22</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W23</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W24</w.rf>
   <form>250</form>
   <lemma>250</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W25</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W26</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W27</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W28</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W30</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W31</w.rf>
   <form>dvanácti</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cn-P6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W32</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W33</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W34</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W35</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W36</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W37</w.rf>
   <form>vyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W38</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W39</w.rf>
   <form>milion</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W40</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p4s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p4s2W41</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p5s1">
  <m id="m-plzensky48663.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W2</w.rf>
   <form>38</form>
   <lemma>38</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W3</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W6</w.rf>
   <form>vině</form>
   <lemma>vina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W7</w.rf>
   <form>úmysl</form>
   <lemma>úmysl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W8</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W9</w.rf>
   <form>hra</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W10</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W13</w.rf>
   <form>96</form>
   <lemma>96</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W14</w.rf>
   <form>nedbalost</form>
   <lemma>nedbalost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W17</w.rf>
   <form>jedenácti</form>
   <lemma>jedenáct`11</lemma>
   <tag>Cn-P6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W18</w.rf>
   <form>komíny</form>
   <lemma>komín</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W20</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W21</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W22</w.rf>
   <form>topidla</form>
   <lemma>topidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W25</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W26</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W27</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W28</w.rf>
   <form>závada</form>
   <lemma>závada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W29</w.rf>
   <form>atd</form>
   <lemma>atd-1_:B_,x_^(a_tak_dále)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p5s2">
  <m id="m-plzensky48663.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W2</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W3</w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W5</w.rf>
   <form>zaznamenáno</form>
   <lemma>zaznamenat_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W6</w.rf>
   <form>32</form>
   <lemma>32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W7</w.rf>
   <form>úmyslně</form>
   <lemma>úmyslně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W8</w.rf>
   <form>založených</form>
   <lemma>založený_^(*3it)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W9</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W11</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W12</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W13</w.rf>
   <form>zjištění</form>
   <lemma>zjištění_^(*5stit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W14</w.rf>
   <form>pachatele</form>
   <lemma>pachatel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W16</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W18</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W19</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W20</w.rf>
   <form>pachatel</form>
   <lemma>pachatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W21</w.rf>
   <form>zjištěn</form>
   <lemma>zjistit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p5s3">
  <m id="m-plzensky48663.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W1</w.rf>
   <form>Pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W2</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W3</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W4</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W6</w.rf>
   <form>svědomí</form>
   <lemma>svědomí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W7</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W9</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W10</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p5s4">
  <m id="m-plzensky48663.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W1</w.rf>
   <form>Kouření</form>
   <lemma>kouření_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W4</w.rf>
   <form>vině</form>
   <lemma>vina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W6</w.rf>
   <form>33</form>
   <lemma>33</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W7</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W9</w.rf>
   <form>rozdělávání</form>
   <lemma>rozdělávání_^(*5at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W10</w.rf>
   <form>ohňů</form>
   <lemma>oheň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W12</w.rf>
   <form>přírodě</form>
   <lemma>příroda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W15</w.rf>
   <form>skládkách</form>
   <lemma>skládka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W17</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W18</w.rf>
   <form>vypalování</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W19</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W20</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W21</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W22</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p5s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p5s4W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s1">
  <m id="m-plzensky48663.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W1</w.rf>
   <form>Škodu</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W2</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W3</w.rf>
   <form>miliony</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W4</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W5</w.rf>
   <form>způsobil</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W6</w.rf>
   <form>lednový</form>
   <lemma>lednový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W7</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W8</w.rf>
   <form>stáje</form>
   <lemma>stáj</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W10</w.rf>
   <form>dobytkem</form>
   <lemma>dobytek</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W12</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W13</w.rf>
   <form>Miřkov</form>
   <lemma>Miřkov</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W15</w.rf>
   <form>Domažlicku</form>
   <lemma>Domažlicko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s2">
  <m id="m-plzensky48663.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s2W1</w.rf>
   <form>Příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s2W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s2W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s2W4</w.rf>
   <form>úmysl</form>
   <lemma>úmysl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s2W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s3">
  <m id="m-plzensky48663.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W1</w.rf>
   <form>Škodu</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W2</w.rf>
   <form>1.9</form>
   <form_change>num_normalization</form_change>
   <lemma>1.9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W3</w.rf>
   <form>milionů</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W4</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W5</w.rf>
   <form>způsobil</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W6</w.rf>
   <form>únorový</form>
   <lemma>únorový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W7</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W8</w.rf>
   <form>skladu</form>
   <lemma>sklad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W9</w.rf>
   <form>sena</form>
   <lemma>seno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W11</w.rf>
   <form>slámy</form>
   <lemma>sláma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W13</w.rf>
   <form>Sedlišti</form>
   <lemma>Sedliště_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s4">
  <m id="m-plzensky48663.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s4W1</w.rf>
   <form>Také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s4W2</w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s4W3</w.rf>
   <form>sklad</form>
   <lemma>sklad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s4W4</w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PZM-1----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s4W5</w.rf>
   <form>zapálil</form>
   <lemma>zapálit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s4W6</w.rf>
   <form>úmyslně</form>
   <lemma>úmyslně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s5">
  <m id="m-plzensky48663.txt-001-p6s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W1</w.rf>
   <form>Únorový</form>
   <lemma>únorový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W4</w.rf>
   <form>Železárnách</form>
   <lemma>železárna</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W5</w.rf>
   <form>Hrádek</form>
   <lemma>hrádek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W6</w.rf>
   <form>způsobil</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W7</w.rf>
   <form>škodu</form>
   <lemma>škoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W8</w.rf>
   <form>1.5</form>
   <form_change>num_normalization</form_change>
   <lemma>1.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W9</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W10</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s6">
  <m id="m-plzensky48663.txt-001-p6s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s6W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s6W2</w.rf>
   <form>vině</form>
   <lemma>vina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s6W3</w.rf>
   <form>tu</form>
   <lemma>tady</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s6W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s6W5</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s6W6</w.rf>
   <form>závada</form>
   <lemma>závada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s6W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s7">
  <m id="m-plzensky48663.txt-001-p6s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W1</w.rf>
   <form>Technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W2</w.rf>
   <form>závada</form>
   <lemma>závada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W4</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W5</w.rf>
   <form>příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W6</w.rf>
   <form>únorového</form>
   <lemma>únorový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W7</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W8</w.rf>
   <form>kolového</form>
   <lemma>kolový-1_^(s_koly)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W9</w.rf>
   <form>lesního</form>
   <lemma>lesní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W10</w.rf>
   <form>traktoru</form>
   <lemma>traktor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W12</w.rf>
   <form>katastrálním</form>
   <lemma>katastrální</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W13</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W14</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W15</w.rf>
   <form>Kvasetice</form>
   <lemma>Kvasetica</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W16</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W17</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W18</w.rf>
   <form>1.7</form>
   <form_change>num_normalization</form_change>
   <lemma>1.7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W19</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W20</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W22</w.rf>
   <form>únorového</form>
   <lemma>únorový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W23</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W24</w.rf>
   <form>pily</form>
   <lemma>pila</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W26</w.rf>
   <form>Nalžovských</form>
   <lemma>nalžovský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W27</w.rf>
   <form>Horách</form>
   <lemma>hora</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W28</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W29</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W30</w.rf>
   <form>1.5</form>
   <form_change>num_normalization</form_change>
   <lemma>1.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W31</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W32</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W33</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W34</w.rf>
   <form>dubnového</form>
   <lemma>dubnový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W35</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W36</w.rf>
   <form>lakovny</form>
   <lemma>lakovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W37</w.rf>
   <form>dřeva</form>
   <lemma>dřevo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W38</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W39</w.rf>
   <form>Malém</form>
   <lemma>malý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W40</w.rf>
   <form>Boru</form>
   <lemma>Boro_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W41</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W42</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W43</w.rf>
   <form>1.5</form>
   <form_change>num_normalization</form_change>
   <lemma>1.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W44</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W45</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s7W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s7W46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s8">
  <m id="m-plzensky48663.txt-001-p6s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W1</w.rf>
   <form>Stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W3</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W4</w.rf>
   <form>příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W5</w.rf>
   <form>únorového</form>
   <lemma>únorový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W6</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W7</w.rf>
   <form>stodoly</form>
   <lemma>stodola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W8</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W9</w.rf>
   <form>rodinného</form>
   <lemma>rodinný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W10</w.rf>
   <form>domku</form>
   <lemma>domek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W12</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W13</w.rf>
   <form>Dýšina</form>
   <lemma>Dýšina_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W14</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W15</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W16</w.rf>
   <form>1.5</form>
   <form_change>num_normalization</form_change>
   <lemma>1.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W17</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W18</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s8W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-plzensky48663.txt-001-p6s9">
  <m id="m-plzensky48663.txt-001-p6s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W2</w.rf>
   <form>úvahu</form>
   <lemma>úvaha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W3</w.rf>
   <form>připadá</form>
   <lemma>připadat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W4</w.rf>
   <form>úmysl</form>
   <lemma>úmysl</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W6</w.rf>
   <form>kouření</form>
   <lemma>kouření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W8</w.rf>
   <form>nedbalost</form>
   <lemma>nedbalost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W10</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W11</w.rf>
   <form>závada</form>
   <lemma>závada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-plzensky48663.txt-001-p6s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-plzensky48663.txt-001-p6s9W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
