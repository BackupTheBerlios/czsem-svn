<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky48187.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky48187.txt-001-p1s1">
  <m id="m-jihomoravsky48187.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W1</w.rf>
   <form>Čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W2</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W3</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W5</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W8</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W10</w.rf>
   <form>podvečer</form>
   <lemma>podvečer</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W11</w.rf>
   <form>likvidovaly</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W12</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W13</w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W14</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W15</w.rf>
   <form>Vracova</form>
   <lemma>Vracov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W17</w.rf>
   <form>Hodonínsku</form>
   <lemma>Hodonínsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p1s2">
  <m id="m-jihomoravsky48187.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W3</w.rf>
   <form>operačnímu</form>
   <lemma>operační</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W4</w.rf>
   <form>středisku</form>
   <lemma>středisko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-1_:B_;K_^(Hasičský_záchranný_sbor)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W6</w.rf>
   <form>ohlášen</form>
   <lemma>ohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W8</w.rf>
   <form>18.26</form>
   <form_change>num_normalization</form_change>
   <lemma>18.26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W11</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W12</w.rf>
   <form>zasáhl</form>
   <lemma>zasáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W13</w.rf>
   <form>lesní</form>
   <lemma>lesní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W14</w.rf>
   <form>hrabanku</form>
   <lemma>hrabanka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W16</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W17</w.rf>
   <form>cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W18</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W19</w.rf>
   <form>krát</form>
   <lemma>krát_^(mat._operace;_2_krát_3)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W20</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W21</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p1s3">
  <m id="m-jihomoravsky48187.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W1</w.rf>
   <form>Včasným</form>
   <lemma>včasný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W2</w.rf>
   <form>zásahem</form>
   <lemma>zásah</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W5</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W6</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W7</w.rf>
   <form>rychle</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W8</w.rf>
   <form>uhasit</form>
   <lemma>uhasit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W11</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W12</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W13</w.rf>
   <form>likvidován</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W15</w.rf>
   <form>18.46</form>
   <form_change>num_normalization</form_change>
   <lemma>18.46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W16</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p1s4">
  <m id="m-jihomoravsky48187.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W2</w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W3</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W5</w.rf>
   <form>hodnotu</form>
   <lemma>hodnota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W6</w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W7</w.rf>
   <form>uchráněného</form>
   <lemma>uchráněný_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W8</w.rf>
   <form>zásahem</form>
   <lemma>zásah</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W9</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W10</w.rf>
   <form>vyšetřovatel</form>
   <lemma>vyšetřovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W11</w.rf>
   <form>vyčíslil</form>
   <lemma>vyčíslit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W13</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W14</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W15</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p1s4W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p2s1">
  <m id="m-jihomoravsky48187.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W1</w.rf>
   <form>Bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W2</w.rf>
   <form>vyčíslené</form>
   <lemma>vyčíslený_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W3</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W6</w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W7</w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W8</w.rf>
   <form>zlikvidovali</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W9</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W11</w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W13</w.rf>
   <form>Blanska</form>
   <lemma>Blansko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p2s2">
  <m id="m-jihomoravsky48187.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W3</w.rf>
   <form>operačnímu</form>
   <lemma>operační</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W4</w.rf>
   <form>středisku</form>
   <lemma>středisko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-1_:B_;K_^(Hasičský_záchranný_sbor)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W6</w.rf>
   <form>ohlášen</form>
   <lemma>ohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W8</w.rf>
   <form>16.06</form>
   <form_change>num_normalization</form_change>
   <lemma>16.06</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W12</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W13</w.rf>
   <form>zasahovaly</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W14</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W15</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W16</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W18</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W19</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p2s3">
  <m id="m-jihomoravsky48187.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W1</w.rf>
   <form>Oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W2</w.rf>
   <form>zasáhl</form>
   <lemma>zasáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W3</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W4</w.rf>
   <form>dřevěný</form>
   <lemma>dřevěný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W5</w.rf>
   <form>přístřešek</form>
   <lemma>přístřešek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W7</w.rf>
   <form>rozměru</form>
   <lemma>rozměr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W8</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W9</w.rf>
   <form>krát</form>
   <lemma>krát_^(mat._operace;_2_krát_3)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W10</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W11</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p2s4">
  <m id="m-jihomoravsky48187.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W2</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W3</w.rf>
   <form>lokalizovali</form>
   <lemma>lokalizovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W5</w.rf>
   <form>16.34</form>
   <form_change>num_normalization</form_change>
   <lemma>16.34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W6</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W8</w.rf>
   <form>dohasili</form>
   <lemma>dohasit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W10</w.rf>
   <form>17.57</form>
   <form_change>num_normalization</form_change>
   <lemma>17.57</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p2s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p3s1">
  <m id="m-jihomoravsky48187.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W1</w.rf>
   <form>Škodu</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W2</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W3</w.rf>
   <form>odhadnutou</form>
   <lemma>odhadnutý_^(*3out)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W5</w.rf>
   <form>160</form>
   <lemma>160</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W6</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W7</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W8</w.rf>
   <form>způsobil</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W10</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W11</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W13</w.rf>
   <form>porodně</form>
   <lemma>porodna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W14</w.rf>
   <form>selat</form>
   <lemma>sele</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W16</w.rf>
   <form>Zelené</form>
   <lemma>zelený</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W17</w.rf>
   <form>Hoře</form>
   <lemma>hora</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W19</w.rf>
   <form>Vyškovsku</form>
   <lemma>Vyškovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p3s2">
  <m id="m-jihomoravsky48187.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W3</w.rf>
   <form>operačnímu</form>
   <lemma>operační</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W4</w.rf>
   <form>středisku</form>
   <lemma>středisko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-1_:B_;K_^(Hasičský_záchranný_sbor)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W6</w.rf>
   <form>ohlášen</form>
   <lemma>ohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W8</w.rf>
   <form>8.51</form>
   <form_change>num_normalization</form_change>
   <lemma>8.51</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W12</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W13</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W14</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W15</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W16</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W18</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W19</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p3s3">
  <m id="m-jihomoravsky48187.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W1</w.rf>
   <form>Oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W2</w.rf>
   <form>zasáhl</form>
   <lemma>zasáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W3</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W4</w.rf>
   <form>porodní</form>
   <lemma>porodní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W5</w.rf>
   <form>plastové</form>
   <lemma>plastový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W6</w.rf>
   <form>boxy</form>
   <lemma>box</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W9</w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W11</w.rf>
   <form>silnému</form>
   <lemma>silný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W12</w.rf>
   <form>zakouření</form>
   <lemma>zakouření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W13</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W15</w.rf>
   <form>dýchacích</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W16</w.rf>
   <form>přístrojích</form>
   <lemma>přístroj</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W18</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W19</w.rf>
   <form>odvětrávání</form>
   <lemma>odvětrávání_^(*5at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W20</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W21</w.rf>
   <form>nasadili</form>
   <lemma>nasadit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W22</w.rf>
   <form>přetlakové</form>
   <lemma>přetlakový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W23</w.rf>
   <form>ventilátory</form>
   <lemma>ventilátor</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p3s4">
  <m id="m-jihomoravsky48187.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W1</w.rf>
   <form>Oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W2</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W3</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W4</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W6</w.rf>
   <form>9.18</form>
   <form_change>num_normalization</form_change>
   <lemma>9.18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W9</w.rf>
   <form>likvidace</form>
   <lemma>likvidace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W10</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W11</w.rf>
   <form>ukončena</form>
   <lemma>ukončit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W13</w.rf>
   <form>12.40</form>
   <form_change>num_normalization</form_change>
   <lemma>12.40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W14</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p3s5">
  <m id="m-jihomoravsky48187.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W2</w.rf>
   <form>hustém</form>
   <lemma>hustý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W3</w.rf>
   <form>kouři</form>
   <lemma>kouř</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W5</w.rf>
   <form>žáru</form>
   <lemma>žár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W6</w.rf>
   <form>uhynuly</form>
   <lemma>uhynout</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W7</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W8</w.rf>
   <form>prasnice</form>
   <lemma>prasnice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W10</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W11</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W12</w.rf>
   <form>selat</form>
   <lemma>sele</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W14</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W15</w.rf>
   <form>desítky</form>
   <lemma>desítka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W16</w.rf>
   <form>zvířat</form>
   <lemma>zvíře</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W17</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W18</w.rf>
   <form>vyvedením</form>
   <lemma>vyvedení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W19</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W20</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W22</w.rf>
   <form>ventilací</form>
   <lemma>ventilace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W23</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W24</w.rf>
   <form>zachránit</form>
   <lemma>zachránit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s5W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p3s6">
  <m id="m-jihomoravsky48187.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s6W1</w.rf>
   <form>Příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s6W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s6W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s6W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s6W5</w.rf>
   <form>závada</form>
   <lemma>závada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s6W6</w.rf>
   <form>elektroinstalace</form>
   <lemma>elektroinstalace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s6W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p3s7">
  <m id="m-jihomoravsky48187.txt-001-p3s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W1</w.rf>
   <form>Hodnotu</form>
   <lemma>hodnota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W2</w.rf>
   <form>majetku</form>
   <lemma>majetek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W3</w.rf>
   <form>uchráněného</form>
   <lemma>uchráněný_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W4</w.rf>
   <form>zásahem</form>
   <lemma>zásah</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W5</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W6</w.rf>
   <form>vyšetřovatel</form>
   <lemma>vyšetřovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W7</w.rf>
   <form>vyčíslil</form>
   <lemma>vyčíslit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W9</w.rf>
   <form>milion</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W10</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p3s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p3s7W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p4s1">
  <m id="m-jihomoravsky48187.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W1</w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W3</w.rf>
   <form>pondělí</form>
   <lemma>pondělí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W4</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W6</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W7</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W9</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W11</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W12</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W14</w.rf>
   <form>devíti</form>
   <lemma>devět`9</lemma>
   <tag>Cn-P3----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W15</w.rf>
   <form>požárům</form>
   <lemma>požár</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W16</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W17</w.rf>
   <form>celkovou</form>
   <lemma>celkový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W18</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W19</w.rf>
   <form>150</form>
   <lemma>150</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W20</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W21</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p4s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p5s1">
  <m id="m-jihomoravsky48187.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W3</w.rf>
   <form>chaty</form>
   <lemma>chata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W5</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W6</w.rf>
   <form>cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W7</w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W8</w.rf>
   <form>krát</form>
   <lemma>krát_^(mat._operace;_2_krát_3)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W9</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W10</w.rf>
   <form>metry</form>
   <lemma>metrum</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W11</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W12</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W13</w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W14</w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W15</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W16</w.rf>
   <form>půlnoci</form>
   <lemma>půlnoc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W17</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W18</w.rf>
   <form>rekreační</form>
   <lemma>rekreační</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W19</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W21</w.rf>
   <form>okraji</form>
   <lemma>okraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W22</w.rf>
   <form>Blanska</form>
   <lemma>Blansko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p5s2">
  <m id="m-jihomoravsky48187.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W3</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W4</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W5</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W6</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W8</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W9</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W11</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W12</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W13</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W14</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W15</w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W16</w.rf>
   <form>chata</form>
   <lemma>chata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W18</w.rf>
   <form>plamenech</form>
   <lemma>plamen</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p5s3">
  <m id="m-jihomoravsky48187.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W2</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W3</w.rf>
   <form>odostali</form>
   <lemma>odostali</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W4</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W5</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W6</w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W7</w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W8</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W9</w.rf>
   <form>půlnoci</form>
   <lemma>půlnoc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W11</w.rf>
   <form>dohašování</form>
   <lemma>dohašování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W13</w.rf>
   <form>rozebírání</form>
   <lemma>rozebírání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W14</w.rf>
   <form>konstrukcí</form>
   <lemma>konstrukce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W15</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W16</w.rf>
   <form>ukončeno</form>
   <lemma>ukončit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W17</w.rf>
   <form>krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W18</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W19</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W21</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p5s4">
  <m id="m-jihomoravsky48187.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W2</w.rf>
   <form>chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W3</w.rf>
   <form>zničil</form>
   <lemma>zničit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W5</w.rf>
   <form>škodu</form>
   <lemma>škoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W6</w.rf>
   <form>vyšetřovatel</form>
   <lemma>vyšetřovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W7</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W8</w.rf>
   <form>vyčíslil</form>
   <lemma>vyčíslit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W10</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W11</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W12</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p5s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p5s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p6s1">
  <m id="m-jihomoravsky48187.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W2</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W4</w.rf>
   <form>lesní</form>
   <lemma>lesní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W5</w.rf>
   <form>hrabanky</form>
   <lemma>hrabanka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W7</w.rf>
   <form>likvidova</form>
   <lemma>likvidova</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W9</w.rf>
   <form>li</form>
   <lemma>li</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W10</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W11</w.rf>
   <form>Kubíkovy</form>
   <lemma>Kubíkův_;S_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W12</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W14</w.rf>
   <form>Brně-Líšni</form>
   <lemma>Brně-Líšeň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W16</w.rf>
   <form>trávu</form>
   <lemma>tráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W18</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W19</w.rf>
   <form>cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W20</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W21</w.rf>
   <form>krát</form>
   <lemma>krát_^(mat._operace;_2_krát_3)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W22</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W23</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W24</w.rf>
   <form>hasili</form>
   <lemma>hasit_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W25</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W26</w.rf>
   <form>Říkonína</form>
   <lemma>Říkoníňa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W27</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W28</w.rf>
   <form>Brněnsku</form>
   <lemma>Brněnsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p6s2">
  <m id="m-jihomoravsky48187.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W3</w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W5</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W7</w.rf>
   <form>Uhřicích</form>
   <lemma>Uhřice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W9</w.rf>
   <form>Hodonínsku</form>
   <lemma>Hodonínsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W11</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W12</w.rf>
   <form>hořící</form>
   <lemma>hořící_^(*3et)</lemma>
   <tag>AGFS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W13</w.rf>
   <form>maringotce</form>
   <lemma>maringotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W14</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W16</w.rf>
   <form>Vřesovic</form>
   <lemma>Vřesovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W18</w.rf>
   <form>Hodonínsku</form>
   <lemma>Hodonínsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p6s3">
  <m id="m-jihomoravsky48187.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W2</w.rf>
   <form>stroje</form>
   <lemma>stroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W4</w.rf>
   <form>hale</form>
   <lemma>hala</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W5</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W7</w.rf>
   <form>Kobylí</form>
   <lemma>kobylí</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W9</w.rf>
   <form>Břeclavsku</form>
   <lemma>Břeclavsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W11</w.rf>
   <form>hořící</form>
   <lemma>hořící_^(*3et)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W12</w.rf>
   <form>zářivkové</form>
   <lemma>zářivkový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W13</w.rf>
   <form>tělesu</form>
   <lemma>těleso</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W14</w.rf>
   <form>uhasili</form>
   <lemma>uhasit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W16</w.rf>
   <form>jednom</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W17</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W18</w.rf>
   <form>pavilonů</form>
   <lemma>pavilon</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W19</w.rf>
   <form>brněnského</form>
   <lemma>brněnský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W20</w.rf>
   <form>výstaviště</form>
   <lemma>výstaviště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48187.txt-001-p6s4">
  <m id="m-jihomoravsky48187.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W1</w.rf>
   <form>Tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W2</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W3</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W5</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W7</w.rf>
   <form>krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W8</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W9</w.rf>
   <form>15.30</form>
   <form_change>num_normalization</form_change>
   <lemma>15.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W11</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W13</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W14</w.rf>
   <form>půdního</form>
   <lemma>půdní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W15</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W16</w.rf>
   <form>rodinného</form>
   <lemma>rodinný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W17</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W19</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W20</w.rf>
   <form>Studnice</form>
   <lemma>studnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W22</w.rf>
   <form>Vyškovsku</form>
   <lemma>Vyškovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48187.txt-001-p6s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48187.txt-001-p6s4W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
