<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky49640.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky49640.txt-001-p1s1">
  <m id="m-jihomoravsky49640.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W1</w.rf>
   <form>Nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W3</w.rf>
   <form>operačnímu</form>
   <lemma>operační</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W4</w.rf>
   <form>středisku</form>
   <lemma>středisko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W6</w.rf>
   <form>ohlášena</form>
   <lemma>ohlásit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W8</w.rf>
   <form>13.13</form>
   <form_change>num_normalization</form_change>
   <lemma>13.13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W12</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W13</w.rf>
   <form>zasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W14</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W15</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W17</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W18</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W20</w.rf>
   <form>Tišnově</form>
   <lemma>Tišnov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p1s2">
  <m id="m-jihomoravsky49640.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W4</w.rf>
   <form>čelní</form>
   <lemma>čelní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W5</w.rf>
   <form>srážku</form>
   <lemma>srážka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W6</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W7</w.rf>
   <form>Karosa</form>
   <lemma>Karosa-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W8</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W9</w.rf>
   <form>vozidlem</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W10</w.rf>
   <form>Trabant</form>
   <lemma>Trabant-2_;R_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W11</w.rf>
   <form>601</form>
   <lemma>601</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p1s3">
  <m id="m-jihomoravsky49640.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W2</w.rf>
   <form>dostupných</form>
   <lemma>dostupný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W3</w.rf>
   <form>informací</form>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W4</w.rf>
   <form>trabant</form>
   <lemma>Trabant-2_;R_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W5</w.rf>
   <form>jedoucí</form>
   <lemma>jedoucí_^(konzumovat_jídlo;_přech.)_(*6íst)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W8</w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W10</w.rf>
   <form>Kuřimi</form>
   <lemma>Kuřim_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W11</w.rf>
   <form>zřejmě</form>
   <lemma>zřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W12</w.rf>
   <form>vyjel</form>
   <lemma>vyjet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W14</w.rf>
   <form>protisměru</form>
   <lemma>protisměr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W16</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W17</w.rf>
   <form>narazil</form>
   <lemma>narazit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W19</w.rf>
   <form>linkového</form>
   <lemma>linkový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W20</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W21</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W22</w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W23</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W24</w.rf>
   <form>Žďáru</form>
   <lemma>Žďár_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W25</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W26</w.rf>
   <form>Sázavou</form>
   <lemma>Sázava_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s3W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p1s4">
  <m id="m-jihomoravsky49640.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W2</w.rf>
   <form>zdemolovaném</form>
   <lemma>zdemolovaný_^(*2t)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W3</w.rf>
   <form>trabantu</form>
   <lemma>Trabant-2_;R_^(vozidlo)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W5</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W6</w.rf>
   <form>zemřeli</form>
   <lemma>zemřít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W7</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W8</w.rf>
   <form>muži</form>
   <lemma>muž</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W11</w.rf>
   <form>82letý</form>
   <lemma>82letý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W12</w.rf>
   <form>senior</form>
   <lemma>senior</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W14</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W15</w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W17</w.rf>
   <form>jehož</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P1XXXZS3-------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W18</w.rf>
   <form>totožnost</form>
   <lemma>totožnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W19</w.rf>
   <form>zjišťují</form>
   <lemma>zjišťovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W20</w.rf>
   <form>policisté</form>
   <lemma>policista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p1s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p1s4W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p2s1">
  <m id="m-jihomoravsky49640.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W2</w.rf>
   <form>udělali</form>
   <lemma>udělat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W4</w.rf>
   <form>vozidle</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W5</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W6</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W8</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W9</w.rf>
   <form>vyšetření</form>
   <lemma>vyšetření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W11</w.rf>
   <form>zadokumentování</form>
   <lemma>zadokumentování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W12</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W14</w.rf>
   <form>policií</form>
   <lemma>policie</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W15</w.rf>
   <form>vrak</form>
   <lemma>vrak</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W16</w.rf>
   <form>trabantu</form>
   <lemma>Trabant-2_;R_^(vozidlo)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W17</w.rf>
   <form>zaklesnutý</form>
   <lemma>zaklesnutý_^(*3out)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W18</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W19</w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W20</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W21</w.rf>
   <form>lana</form>
   <lemma>lano</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W22</w.rf>
   <form>odtrhli</form>
   <lemma>odtrhnout_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p2s2">
  <m id="m-jihomoravsky49640.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W2</w.rf>
   <form>odstranění</form>
   <lemma>odstranění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W3</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W4</w.rf>
   <form>trabantu</form>
   <lemma>Trabant-2_;R_^(vozidlo)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W5</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W7</w.rf>
   <form>kabiny</form>
   <lemma>kabina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W8</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W9</w.rf>
   <form>těla</form>
   <lemma>tělo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W10</w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W11</w.rf>
   <form>mužů</form>
   <lemma>muž</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p2s3">
  <m id="m-jihomoravsky49640.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W1</w.rf>
   <form>Obě</form>
   <lemma>oba`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W2</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W3</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W5</w.rf>
   <form>trabant</form>
   <lemma>Trabant-2_;R_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W7</w.rf>
   <form>autobus</form>
   <lemma>autobus</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W9</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W10</w.rf>
   <form>postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W11</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W13</w.rf>
   <form>kraj</form>
   <lemma>kraj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W14</w.rf>
   <form>vozovky</form>
   <lemma>vozovka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W16</w.rf>
   <form>uvolnili</form>
   <lemma>uvolnit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W17</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W18</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClIS4----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W19</w.rf>
   <form>jízdní</form>
   <lemma>jízdní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W20</w.rf>
   <form>pruh</form>
   <lemma>pruh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p2s4">
  <m id="m-jihomoravsky49640.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s4W1</w.rf>
   <form>Únik</form>
   <lemma>únik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s4W2</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s4W3</w.rf>
   <form>kapalin</form>
   <lemma>kapalina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s4W4</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s4W5</w.rf>
   <form>zjištěn</form>
   <lemma>zjistit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p2s5">
  <m id="m-jihomoravsky49640.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W2</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W4</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W5</w.rf>
   <form>pomohli</form>
   <lemma>pomoci</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W6</w.rf>
   <form>vrak</form>
   <lemma>vrak</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W7</w.rf>
   <form>trabantu</form>
   <lemma>Trabant-2_;R_^(vozidlo)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W8</w.rf>
   <form>naložit</form>
   <lemma>naložit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W9</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W10</w.rf>
   <form>odtahu</form>
   <lemma>odtah</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W12</w.rf>
   <form>asistovali</form>
   <lemma>asistovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W13</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W14</w.rf>
   <form>odtažení</form>
   <lemma>odtažení_^(*5áhnout)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W15</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s5W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49640.txt-001-p2s6">
  <m id="m-jihomoravsky49640.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W2</w.rf>
   <form>úklidu</form>
   <lemma>úklid</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W3</w.rf>
   <form>vozovky</form>
   <lemma>vozovka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W4</w.rf>
   <form>krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W5</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W6</w.rf>
   <form>16.30</form>
   <form_change>num_normalization</form_change>
   <lemma>16.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W7</w.rf>
   <form>hod</form>
   <lemma>hodina_:B_,x</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W9</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W10</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W11</w.rf>
   <form>předali</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W12</w.rf>
   <form>policistům</form>
   <lemma>policista</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W14</w.rf>
   <form>ukončili</form>
   <lemma>ukončit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W15</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49640.txt-001-p2s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49640.txt-001-p2s6W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
