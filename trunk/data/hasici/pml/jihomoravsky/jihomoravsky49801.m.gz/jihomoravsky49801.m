<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky49801.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky49801.txt-001-p1s1">
  <m id="m-jihomoravsky49801.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W2</w.rf>
   <form>silné</form>
   <lemma>silný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W3</w.rf>
   <form>konkurenci</form>
   <lemma>konkurence</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W4</w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W5</w.rf>
   <form>desítek</form>
   <lemma>desítka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W8</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W9</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W10</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W11</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W13</w.rf>
   <form>studentů</form>
   <lemma>student</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W14</w.rf>
   <form>VŠB</form>
   <lemma>VŠB-1_:B_;K_^(Vysoká_škola_báňská)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W16</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W17</w.rf>
   <form>TU</form>
   <lemma>tady</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W18</w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W19</w.rf>
   <form>Radim</form>
   <lemma>Radim_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W20</w.rf>
   <form>Vacula</form>
   <lemma>Vacula_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W21</w.rf>
   <form>získal</form>
   <lemma>získat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W22</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W23</w.rf>
   <form>časem</form>
   <lemma>čas</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W24</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W25</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W26</w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W27</w.rf>
   <form>druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W28</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W29</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W30</w.rf>
   <form>kategorii</form>
   <lemma>kategorie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W31</w.rf>
   <form>jednotlivců</form>
   <lemma>jednotlivec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W32</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W33</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W34</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p1s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p1s1W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49801.txt-001-p2s1">
  <m id="m-jihomoravsky49801.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W1</w.rf>
   <form>Závod</form>
   <lemma>závod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W2</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W4</w.rf>
   <form>Toughest</form>
   <lemma>Toughest</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W5</w.rf>
   <form>Firefighter</form>
   <lemma>Firefighter</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W6</w.rf>
   <form>Alive</form>
   <lemma>Alive</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W9</w.rf>
   <form>nejtvrdší</form>
   <lemma>tvrdý</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W10</w.rf>
   <form>hasič</form>
   <lemma>hasič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W11</w.rf>
   <form>přežije</form>
   <lemma>přežít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W12</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W14</w.rf>
   <form>jehož</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P1XXXZS3-------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W15</w.rf>
   <form>discipliny</form>
   <lemma>disciplína</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W16</w.rf>
   <form>navozují</form>
   <lemma>navozovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W17</w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W18</w.rf>
   <form>skutečného</form>
   <lemma>skutečný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W19</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W20</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W22</w.rf>
   <form>extrémních</form>
   <lemma>extrémní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W23</w.rf>
   <form>podmínkách</form>
   <lemma>podmínka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W25</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W26</w.rf>
   <form>uskutečnil</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W28</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W29</w.rf>
   <form>silových</form>
   <lemma>silový</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W30</w.rf>
   <form>disciplinách</form>
   <lemma>disciplína</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W31</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W32</w.rf>
   <form>finálovým</form>
   <lemma>finálový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W33</w.rf>
   <form>výběhem</form>
   <lemma>výběh</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W34</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W35</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W36</w.rf>
   <form>plné</form>
   <lemma>plný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W37</w.rf>
   <form>zásahové</form>
   <lemma>zásahový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W38</w.rf>
   <form>výstroji</form>
   <lemma>výstroj</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W39</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W40</w.rf>
   <form>520</form>
   <lemma>520</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W41</w.rf>
   <form>schodů</form>
   <lemma>schod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W42</w.rf>
   <form>věže</form>
   <lemma>věž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W43</w.rf>
   <form>ostravské</form>
   <lemma>ostravský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W44</w.rf>
   <form>Nové</form>
   <lemma>nový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W45</w.rf>
   <form>radnice</form>
   <lemma>radnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s1W46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49801.txt-001-p2s2">
  <m id="m-jihomoravsky49801.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W1</w.rf>
   <form>Kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W2</w.rf>
   <form>běhu</form>
   <lemma>běh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W3</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W4</w.rf>
   <form>schodů</form>
   <lemma>schod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W5</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W6</w.rf>
   <form>závodníci</form>
   <lemma>závodník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W7</w.rf>
   <form>mj.</form>
   <lemma>mj-1_:B_,x_^(mimo_jiné)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W8</w.rf>
   <form>roztáhnout</form>
   <lemma>roztáhnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W9</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP4----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W10</w.rf>
   <form>hadice</form>
   <lemma>hadice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W11</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W12</w.rf>
   <form>proudnicemi</form>
   <lemma>proudnice</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W14</w.rf>
   <form>vzdálenosti</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W15</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W16</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W18</w.rf>
   <form>šedesátkrát</form>
   <lemma>šedesátkrát`60_^(*7`60)</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W19</w.rf>
   <form>udeřit</form>
   <lemma>udeřit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W20</w.rf>
   <form>železnou</form>
   <lemma>železný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W21</w.rf>
   <form>palicí</form>
   <lemma>palice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W23</w.rf>
   <form>trenažeru</form>
   <lemma>trenažer</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W25</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W26</w.rf>
   <form>překonat</form>
   <lemma>překonat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W27</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W28</w.rf>
   <form>metry</form>
   <lemma>metr</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W29</w.rf>
   <form>vysokou</form>
   <lemma>vysoký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W30</w.rf>
   <form>bariéru</form>
   <lemma>bariéra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W32</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W33</w.rf>
   <form>transportovat</form>
   <lemma>transportovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W34</w.rf>
   <form>figurínu</form>
   <lemma>figurína</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W35</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W36</w.rf>
   <form>hmotnosti</form>
   <lemma>hmotnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W37</w.rf>
   <form>80</form>
   <lemma>80</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W38</w.rf>
   <form>kilogramů</form>
   <lemma>kilogram</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s2W39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49801.txt-001-p2s3">
  <m id="m-jihomoravsky49801.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W1</w.rf>
   <form>Všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W2</w.rf>
   <form>discipliny</form>
   <lemma>disciplína</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W3</w.rf>
   <form>závodu</form>
   <lemma>závod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W5</w.rf>
   <form>absolvovali</form>
   <lemma>absolvovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W7</w.rf>
   <form>zapnutým</form>
   <lemma>zapnutý_^(*3out)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W8</w.rf>
   <form>dýchacím</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W9</w.rf>
   <form>přístrojem</form>
   <lemma>přístroj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W11</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W12</w.rf>
   <form>výstrojí</form>
   <lemma>výstroj</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W14</w.rf>
   <form>výzbrojí</form>
   <lemma>výzbroj</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W15</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W16</w.rf>
   <form>hmotnosti</form>
   <lemma>hmotnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W17</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W18</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W19</w.rf>
   <form>kilogramů</form>
   <lemma>kilogram</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49801.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49801.txt-001-p2s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
