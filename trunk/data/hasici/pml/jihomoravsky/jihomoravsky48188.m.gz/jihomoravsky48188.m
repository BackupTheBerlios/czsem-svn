<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky48188.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky48188.txt-001-p1s1">
  <m id="m-jihomoravsky48188.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W1</w.rf>
   <form>Svátek</form>
   <lemma>svátek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W3</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W4</w.rf>
   <form>připadá</form>
   <lemma>připadat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W6</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W7</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W9</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W12</w.rf>
   <form>připomenou</form>
   <lemma>připomenout</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W13</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W14</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W15</w.rf>
   <form>dříve</form>
   <lemma>brzy</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W17</w.rf>
   <form>přehlídku</form>
   <lemma>přehlídka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W18</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W19</w.rf>
   <form>dechovek</form>
   <lemma>dechovka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W20</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W21</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W23</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W24</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W26</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W28</w.rf>
   <form>centru</form>
   <lemma>centrum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W29</w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p1s2">
  <m id="m-jihomoravsky48188.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W2</w.rf>
   <form>centrálním</form>
   <lemma>centrální</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W3</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W4</w.rf>
   <form>Svobody</form>
   <lemma>svoboda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W5</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W7</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W8</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W10</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W11</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W12</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W14</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W15</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W16</w.rf>
   <form>vyhrávat</form>
   <lemma>vyhrávat_:T_^(*3t)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W17</w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W18</w.rf>
   <form>dechová</form>
   <lemma>dechový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W19</w.rf>
   <form>kapela</form>
   <lemma>kapela</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W20</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W21</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W22</w.rf>
   <form>Olomouckého</form>
   <lemma>olomoucký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W23</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p1s3">
  <m id="m-jihomoravsky48188.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W1</w.rf>
   <form>Řízné</form>
   <lemma>řízný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W2</w.rf>
   <form>tóny</form>
   <lemma>tón</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W3</w.rf>
   <form>třicetičlenného</form>
   <lemma>třicetičlenný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W4</w.rf>
   <form>tělesa</form>
   <lemma>těleso</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W6</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W7</w.rf>
   <form>doprovodí</form>
   <lemma>doprovodit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W8</w.rf>
   <form>expozice</form>
   <lemma>expozice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W9</w.rf>
   <form>historických</form>
   <lemma>historický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W10</w.rf>
   <form>požárních</form>
   <lemma>požární</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W11</w.rf>
   <form>stříkaček</form>
   <lemma>stříkačka_^(*2)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p1s4">
  <m id="m-jihomoravsky48188.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W2</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W3</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W4</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W6</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W8</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W9</w.rf>
   <form>centrem</form>
   <lemma>centrum</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W10</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W12</w.rf>
   <form>historických</form>
   <lemma>historický</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W13</w.rf>
   <form>požárních</form>
   <lemma>požární</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W14</w.rf>
   <form>vozidlech</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W15</w.rf>
   <form>projíždět</form>
   <lemma>projíždět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W17</w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W18</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W19</w.rf>
   <form>hasičská</form>
   <lemma>hasičský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W20</w.rf>
   <form>dechovka</form>
   <lemma>dechovka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W21</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W22</w.rf>
   <form>Skutče</form>
   <lemma>Skuteč_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s4W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p1s5">
  <m id="m-jihomoravsky48188.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W1</w.rf>
   <form>Trasa</form>
   <lemma>trasa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W2</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W3</w.rf>
   <form>hudební</form>
   <lemma>hudební</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W4</w.rf>
   <form>projíždky</form>
   <lemma>projíždka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W6</w.rf>
   <form>historických</form>
   <lemma>historický</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W7</w.rf>
   <form>vozidlech</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W8</w.rf>
   <form>povede</form>
   <lemma>povést</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W10</w.rf>
   <form>Moravského</form>
   <lemma>moravský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W11</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W13</w.rf>
   <form>Joštovu</form>
   <lemma>Joštův_;S_^(*2)</lemma>
   <tag>AUFS4M---------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W14</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W16</w.rf>
   <form>odtud</form>
   <lemma>odtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W17</w.rf>
   <form>Husovou</form>
   <lemma>Husův_;S_^(*2)</lemma>
   <tag>AUFS7M---------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W18</w.rf>
   <form>ulicí</form>
   <lemma>ulice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W19</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W20</w.rf>
   <form>hlavního</form>
   <lemma>hlavní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W21</w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W22</w.rf>
   <form>ČD</form>
   <lemma>ČD_:B_;K_^(České_dráhy)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W23</w.rf>
   <form>Benešovou</form>
   <lemma>Benešův_;S_^(*2)</lemma>
   <tag>AUFS7M---------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W24</w.rf>
   <form>ulicí</form>
   <lemma>ulice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W25</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W27</w.rf>
   <form>Moravské</form>
   <lemma>moravský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W28</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s5W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p1s6">
  <m id="m-jihomoravsky48188.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W2</w.rf>
   <form>trase</form>
   <lemma>trasa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W3</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W4</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W7</w.rf>
   <form>muzikanti</form>
   <lemma>muzikant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W9</w.rf>
   <form>historických</form>
   <lemma>historický</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W10</w.rf>
   <form>uniformách</form>
   <lemma>uniforma</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W11</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W12</w.rf>
   <form>zastávek</form>
   <lemma>zastávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W13</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W14</w.rf>
   <form>krátkým</form>
   <lemma>krátký</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W15</w.rf>
   <form>hudebním</form>
   <lemma>hudební</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W16</w.rf>
   <form>produkcím</form>
   <lemma>produkce</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s6W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p1s7">
  <m id="m-jihomoravsky48188.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W1</w.rf>
   <form>Chodcům</form>
   <lemma>chodec</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W2</w.rf>
   <form>zahrají</form>
   <lemma>zahrát</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W4</w.rf>
   <form>ústí</form>
   <lemma>ústí_^(řeky,_potrubí,...)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W5</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W6</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W8</w.rf>
   <form>Joštovu</form>
   <lemma>Joštův_;S_^(*2)</lemma>
   <tag>AUFS4M---------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W10</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W12</w.rf>
   <form>hlavního</form>
   <lemma>hlavní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W13</w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W16</w.rf>
   <form>Malinovského</form>
   <lemma>Malinovský_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W17</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s7W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p1s8">
  <m id="m-jihomoravsky48188.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W1</w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W2</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W3</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W4</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W7</w.rf>
   <form>muzikanti</form>
   <lemma>muzikant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W8</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W9</w.rf>
   <form>Skutče</form>
   <lemma>Skuteč_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W10</w.rf>
   <form>Brňanům</form>
   <lemma>Brňan_;E</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W11</w.rf>
   <form>představí</form>
   <lemma>představit-1_:W_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W12</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W14</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W15</w.rf>
   <form>Svobody</form>
   <lemma>svoboda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p1s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p1s8W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p2s1">
  <m id="m-jihomoravsky48188.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s1W1</w.rf>
   <form>Vystoupení</form>
   <lemma>vystoupení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s1W2</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s1W3</w.rf>
   <form>dechovek</form>
   <lemma>dechovka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s1W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s1W5</w.rf>
   <form>příležitosti</form>
   <lemma>příležitost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s1W6</w.rf>
   <form>svátku</form>
   <lemma>svátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s1W7</w.rf>
   <form>sv</form>
   <lemma>svatý_:B</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p2s2">
  <m id="m-jihomoravsky48188.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W1</w.rf>
   <form>Floriána</form>
   <lemma>Florian_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W4</w.rf>
   <form>centru</form>
   <lemma>centrum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W5</w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W6</w.rf>
   <form>uskutečnilo</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W7</w.rf>
   <form>loni</form>
   <lemma>vloni_,h</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W9</w.rf>
   <form>květnu</form>
   <lemma>květen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W10</w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W12</w.rf>
   <form>mělo</form>
   <lemma>mít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W13</w.rf>
   <form>mimořádný</form>
   <lemma>mimořádný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W14</w.rf>
   <form>ohlas</form>
   <lemma>ohlas</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p2s3">
  <m id="m-jihomoravsky48188.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W1</w.rf>
   <form>Brňanům</form>
   <lemma>Brňan_;E</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W2</w.rf>
   <form>zahráli</form>
   <lemma>zahrát</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W3</w.rf>
   <form>právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W4</w.rf>
   <form>muzikanti</form>
   <lemma>muzikant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W5</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W6</w.rf>
   <form>Skutče</form>
   <lemma>Skuteč_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W8</w.rf>
   <form>Olomouce</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p2s4">
  <m id="m-jihomoravsky48188.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W1</w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W2</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W3</w.rf>
   <form>obyvatelé</form>
   <lemma>obyvatel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W4</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W5</w.rf>
   <form>znovu</form>
   <lemma>znovu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W6</w.rf>
   <form>uvidí</form>
   <lemma>uvidět</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W8</w.rf>
   <form>uslyší</form>
   <lemma>uslyšet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W9</w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W10</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP4----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W11</w.rf>
   <form>kapely</form>
   <lemma>kapela</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p2s5">
  <m id="m-jihomoravsky48188.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W1</w.rf>
   <form>Jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W2</w.rf>
   <form>vystoupení</form>
   <lemma>vystoupení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W3</w.rf>
   <form>předznamenává</form>
   <lemma>předznamenávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W4</w.rf>
   <form>tradiční</form>
   <lemma>tradiční</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W5</w.rf>
   <form>festival</form>
   <lemma>festival</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W6</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W7</w.rf>
   <form>dechovek</form>
   <lemma>dechovka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W9</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W10</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W12</w.rf>
   <form>srpnu</form>
   <lemma>srpen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W14</w.rf>
   <form>Pelhřimově</form>
   <lemma>Pelhřimov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s5W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p2s6">
  <m id="m-jihomoravsky48188.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W1</w.rf>
   <form>Pořadatelé</form>
   <lemma>pořadatel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W2</w.rf>
   <form>brněnské</form>
   <lemma>brněnský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W3</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W5</w.rf>
   <form>krajského</form>
   <lemma>krajský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W6</w.rf>
   <form>ředitelství</form>
   <lemma>ředitelství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W7</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W8</w.rf>
   <form>Jihomoravského</form>
   <lemma>jihomoravský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W9</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W10</w.rf>
   <form>věří</form>
   <lemma>věřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W12</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W13</w.rf>
   <form>koncerty</form>
   <lemma>koncert</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W14</w.rf>
   <form>dechových</form>
   <lemma>dechový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W15</w.rf>
   <form>kapel</form>
   <lemma>kapela</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W16</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W17</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W18</w.rf>
   <form>svátku</form>
   <lemma>svátek</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W19</w.rf>
   <form>sv</form>
   <lemma>svatý_:B</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s6W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48188.txt-001-p2s7">
  <m id="m-jihomoravsky48188.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W1</w.rf>
   <form>Floriána</form>
   <lemma>Florian_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W2</w.rf>
   <form>vytvoří</form>
   <lemma>vytvořit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W3</w.rf>
   <form>novou</form>
   <lemma>nový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W4</w.rf>
   <form>tradici</form>
   <lemma>tradice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W6</w.rf>
   <form>obohatí</form>
   <lemma>obohatit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W7</w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W8</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48188.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48188.txt-001-p2s7W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
