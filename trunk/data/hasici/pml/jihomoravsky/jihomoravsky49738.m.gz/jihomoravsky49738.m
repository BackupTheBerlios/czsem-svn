<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky49738.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky49738.txt-001-p1s1">
  <m id="m-jihomoravsky49738.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W1</w.rf>
   <form>Tyto</form>
   <lemma>tento</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W3</w.rf>
   <form>řadu</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W4</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W5</w.rf>
   <form>důležitých</form>
   <lemma>důležitý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W6</w.rf>
   <form>informací</form>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W8</w.rf>
   <form>poznatků</form>
   <lemma>poznatek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W9</w.rf>
   <form>předávali</form>
   <lemma>předávat-1_:T_,a_^(příst)_(*6at-1)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W10</w.rf>
   <form>příslušníci</form>
   <lemma>příslušník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W11</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W12</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W13</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W14</w.rf>
   <form>Jihomoravského</form>
   <lemma>jihomoravský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W15</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W16</w.rf>
   <form>žákům</form>
   <lemma>žák</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W17</w.rf>
   <form>základní</form>
   <lemma>základní_,s</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W18</w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W20</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W21</w.rf>
   <form>Pastviny</form>
   <lemma>pastvina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W23</w.rf>
   <form>Brně-Komíně</form>
   <lemma>Brně-Komína</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49738.txt-001-p1s2">
  <m id="m-jihomoravsky49738.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W1</w.rf>
   <form>Základům</form>
   <lemma>základ</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W2</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W3</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W5</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W6</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W7</w.rf>
   <form>mimořádnými</form>
   <lemma>mimořádný</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W8</w.rf>
   <form>událostmi</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W9</w.rf>
   <form>učili</form>
   <lemma>učít_,a</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W10</w.rf>
   <form>školáky</form>
   <lemma>školák</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W12</w.rf>
   <form>druhých</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W14</w.rf>
   <form>šestých</form>
   <lemma>šestý</lemma>
   <tag>CrFP2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W15</w.rf>
   <form>tříd</form>
   <lemma>třída</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49738.txt-001-p1s3">
  <m id="m-jihomoravsky49738.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W1</w.rf>
   <form>Vyučovací</form>
   <lemma>vyučovací_^(*2t)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W2</w.rf>
   <form>hodiny</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W4</w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W5</w.rf>
   <form>cyklu</form>
   <lemma>cykl_,a</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W6</w.rf>
   <form>přednášek</form>
   <lemma>přednáška</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W8</w.rf>
   <form>besed</form>
   <lemma>beseda</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W10</w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W11</w.rf>
   <form>programu</form>
   <lemma>program-1</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W12</w.rf>
   <form>Výchova</form>
   <lemma>výchova</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W13</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W15</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W16</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W17</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W19</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W20</w.rf>
   <form>obyvatelstva</form>
   <lemma>obyvatelstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49738.txt-001-p1s4">
  <m id="m-jihomoravsky49738.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W1</w.rf>
   <form>Projekt</form>
   <lemma>projekt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W3</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W4</w.rf>
   <form>připravil</form>
   <lemma>připravit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W5</w.rf>
   <form>Hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W6</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W7</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W8</w.rf>
   <form>Jihomoravského</form>
   <lemma>jihomoravský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W9</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W11</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W12</w.rf>
   <form>určen</form>
   <lemma>určit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W13</w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>ClXP3----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W14</w.rf>
   <form>věkovým</form>
   <lemma>věkový</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W15</w.rf>
   <form>skupinám</form>
   <lemma>skupina</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W16</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W17</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W18</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W19</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W20</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W21</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W23</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W24</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W25</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W26</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W27</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s4W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49738.txt-001-p1s5">
  <m id="m-jihomoravsky49738.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W1</w.rf>
   <form>Cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W3</w.rf>
   <form>hravou</form>
   <lemma>hravý</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W5</w.rf>
   <form>přitažlivou</form>
   <lemma>přitažlivý</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W6</w.rf>
   <form>formou</form>
   <lemma>forma</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W7</w.rf>
   <form>předat</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W8</w.rf>
   <form>dětem</form>
   <lemma>dítě</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W9</w.rf>
   <form>důležité</form>
   <lemma>důležitý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W10</w.rf>
   <form>informace</form>
   <lemma>informace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W12</w.rf>
   <form>návyky</form>
   <lemma>návyk</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W14</w.rf>
   <form>prevenci</form>
   <lemma>prevence</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W15</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W16</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W18</w.rf>
   <form>mimořádnými</form>
   <lemma>mimořádný</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W19</w.rf>
   <form>událostmi</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s5W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49738.txt-001-p1s6">
  <m id="m-jihomoravsky49738.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W1</w.rf>
   <form>Výuku</form>
   <lemma>výuka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W3</w.rf>
   <form>délce</form>
   <lemma>délka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W4</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W6</w.rf>
   <form>doplňuje</form>
   <lemma>doplňovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W7</w.rf>
   <form>prohlídka</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W8</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W9</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s6W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49738.txt-001-p1s7">
  <m id="m-jihomoravsky49738.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W1</w.rf>
   <form>Projekt</form>
   <lemma>projekt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W2</w.rf>
   <form>vznikl</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W4</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W5</w.rf>
   <form>1996</form>
   <lemma>1996</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W7</w.rf>
   <form>severomoravském</form>
   <lemma>severomoravský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W8</w.rf>
   <form>Bruntálu</form>
   <lemma>Bruntál_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W10</w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W11</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W12</w.rf>
   <form>využitím</form>
   <lemma>využití_^(*3ít)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W13</w.rf>
   <form>poznatků</form>
   <lemma>poznatek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W15</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W16</w.rf>
   <form>prevence</form>
   <lemma>prevence</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W18</w.rf>
   <form>Kanadě</form>
   <lemma>Kanada_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W19</w.rf>
   <form>zpracovali</form>
   <lemma>zpracovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W20</w.rf>
   <form>příslušníci</form>
   <lemma>příslušník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W21</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W22</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W23</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W24</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W25</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W26</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W27</w.rf>
   <form>občanským</form>
   <lemma>občanský</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W28</w.rf>
   <form>družením</form>
   <lemma>družení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W29</w.rf>
   <form>Citadela</form>
   <lemma>citadela</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W30</w.rf>
   <form>Bruntál</form>
   <lemma>Bruntál_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s7W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s7W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49738.txt-001-p1s8">
  <m id="m-jihomoravsky49738.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W2</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W3</w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W4</w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W5</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W6</w.rf>
   <form>jediná</form>
   <lemma>jediný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W7</w.rf>
   <form>dvojice</form>
   <lemma>dvojice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W8</w.rf>
   <form>odborně</form>
   <lemma>odborně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W9</w.rf>
   <form>vyškolených</form>
   <lemma>vyškolený_^(*3it)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W10</w.rf>
   <form>aktivistů</form>
   <lemma>aktivista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W11</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W12</w.rf>
   <form>letošního</form>
   <lemma>letošní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W13</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W14</w.rf>
   <form>realizuje</form>
   <lemma>realizovat_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W16</w.rf>
   <form>základních</form>
   <lemma>základní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W17</w.rf>
   <form>školách</form>
   <lemma>škola</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W18</w.rf>
   <form>Hamry</form>
   <lemma>Hamra_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W20</w.rf>
   <form>Hudcova</form>
   <lemma>hudcův_^(*3ec)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W22</w.rf>
   <form>Pastviny</form>
   <lemma>pastvina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s8W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s8W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49738.txt-001-p1s9">
  <m id="m-jihomoravsky49738.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W2</w.rf>
   <form>vyškolení</form>
   <lemma>vyškolení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W3</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W4</w.rf>
   <form>dvojic</form>
   <lemma>dvojice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W5</w.rf>
   <form>aktivistů</form>
   <lemma>aktivista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W6</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W8</w.rf>
   <form>projekt</form>
   <lemma>projekt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W9</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W10</w.rf>
   <form>rozšířit</form>
   <lemma>rozšířit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W12</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W13</w.rf>
   <form>základní</form>
   <lemma>základní_,s</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W14</w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W16</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W17</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W19</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49738.txt-001-p1s9W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49738.txt-001-p1s9W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
