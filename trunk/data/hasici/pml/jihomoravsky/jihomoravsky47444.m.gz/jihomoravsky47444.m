<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky47444.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky47444.txt-001-p1s1">
  <m id="m-jihomoravsky47444.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W2</w.rf>
   <form>14.42</form>
   <form_change>num_normalization</form_change>
   <lemma>14.42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W3</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W4</w.rf>
   <form>převzalo</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W5</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W6</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W7</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W8</w.rf>
   <form>hlášení</form>
   <lemma>hlášení_^(*4sit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W10</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W12</w.rf>
   <form>garáže</form>
   <lemma>garáž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W13</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W15</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W16</w.rf>
   <form>Křiby</form>
   <lemma>Křiby_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W18</w.rf>
   <form>Tetčicích</form>
   <lemma>Tetčice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W19</w.rf>
   <form>šlehají</form>
   <lemma>šlehat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W20</w.rf>
   <form>plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47444.txt-001-p1s2">
  <m id="m-jihomoravsky47444.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W3</w.rf>
   <form>vyjely</form>
   <lemma>vyjet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W4</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W5</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W9</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W10</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W12</w.rf>
   <form>stanic</form>
   <lemma>stanice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W14</w.rf>
   <form>Rosicích</form>
   <lemma>Rosice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W17</w.rf>
   <form>Brně-Starém</form>
   <lemma>Brně-Starém</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W18</w.rf>
   <form>Lískovci</form>
   <lemma>Lískovec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W21</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W22</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W23</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W24</w.rf>
   <form>Rosic</form>
   <lemma>Rosice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W26</w.rf>
   <form>Zastávky</form>
   <lemma>zastávka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47444.txt-001-p1s3">
  <m id="m-jihomoravsky47444.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W3</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W5</w.rf>
   <form>Brně-Starém</form>
   <lemma>Brně-Starém</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W6</w.rf>
   <form>Lískovci</form>
   <lemma>Lískovec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W7</w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W9</w.rf>
   <form>záloze</form>
   <lemma>záloha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W11</w.rf>
   <form>nezasahovala</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47444.txt-001-p1s4">
  <m id="m-jihomoravsky47444.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W2</w.rf>
   <form>vypnuli</form>
   <lemma>vypnout</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W3</w.rf>
   <form>přívod</form>
   <lemma>přívod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W4</w.rf>
   <form>plynu</form>
   <lemma>plyn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W6</w.rf>
   <form>el</form>
   <lemma>elektrický_:B</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W8</w.rf>
   <form>proudu</form>
   <lemma>proud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W10</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W11</w.rf>
   <form>plamenům</form>
   <lemma>plamen</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W12</w.rf>
   <form>nasadili</form>
   <lemma>nasadit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W13</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W14</w.rf>
   <form>vodní</form>
   <lemma>vodní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W15</w.rf>
   <form>proudy</form>
   <lemma>proud</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W16</w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W17</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W18</w.rf>
   <form>silnému</form>
   <lemma>silný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W19</w.rf>
   <form>zakouření</form>
   <lemma>zakouření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W20</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W22</w.rf>
   <form>dýchacích</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W23</w.rf>
   <form>přístrojích</form>
   <lemma>přístroj</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s4W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47444.txt-001-p1s5">
  <m id="m-jihomoravsky47444.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W3</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W4</w.rf>
   <form>lokalizovat</form>
   <lemma>lokalizovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W6</w.rf>
   <form>15.08</form>
   <form_change>num_normalization</form_change>
   <lemma>15.08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W9</w.rf>
   <form>zlikvidovat</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W11</w.rf>
   <form>16.10</form>
   <form_change>num_normalization</form_change>
   <lemma>16.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W12</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s5W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47444.txt-001-p1s6">
  <m id="m-jihomoravsky47444.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W2</w.rf>
   <form>průzkumu</form>
   <lemma>průzkum</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W3</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W5</w.rf>
   <form>jehož</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJZS2----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W6</w.rf>
   <form>majitelé</form>
   <lemma>majitel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W8</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W9</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W10</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W11</w.rf>
   <form>nebyli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W12</w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W14</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W15</w.rf>
   <form>našli</form>
   <lemma>najít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W16</w.rf>
   <form>udušeného</form>
   <lemma>udušený_^(*4sit)</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W17</w.rf>
   <form>psa</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s6W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47444.txt-001-p1s7">
  <m id="m-jihomoravsky47444.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W2</w.rf>
   <form>garáže</form>
   <lemma>garáž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W3</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W4</w.rf>
   <form>plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W5</w.rf>
   <form>vynesli</form>
   <lemma>vynést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W7</w.rf>
   <form>ochladili</form>
   <lemma>ochladit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W8</w.rf>
   <form>kanystry</form>
   <lemma>kanystr</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W10</w.rf>
   <form>benzínem</form>
   <lemma>benzín</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s7W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47444.txt-001-p1s8">
  <m id="m-jihomoravsky47444.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W2</w.rf>
   <form>odvětrání</form>
   <lemma>odvětrání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W3</w.rf>
   <form>zakouřených</form>
   <lemma>zakouřený_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W4</w.rf>
   <form>prostor</form>
   <lemma>prostora</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W5</w.rf>
   <form>nasadili</form>
   <lemma>nasadit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W6</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W7</w.rf>
   <form>přetlakové</form>
   <lemma>přetlakový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W8</w.rf>
   <form>ventilátory</form>
   <lemma>ventilátor</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s8W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47444.txt-001-p1s9">
  <m id="m-jihomoravsky47444.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W6</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W8</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W9</w.rf>
   <form>zjištěných</form>
   <lemma>zjištěný_^(*5stit)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W10</w.rf>
   <form>poznatků</form>
   <lemma>poznatek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W11</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W12</w.rf>
   <form>mohl</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W13</w.rf>
   <form>vypuknout</form>
   <lemma>vypuknout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W14</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W15</w.rf>
   <form>zapnutého</form>
   <lemma>zapnutý_^(*3out)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W16</w.rf>
   <form>elektrického</form>
   <lemma>elektrický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W17</w.rf>
   <form>topidla</form>
   <lemma>topidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47444.txt-001-p1s9W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47444.txt-001-p1s9W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
