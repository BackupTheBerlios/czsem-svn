<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky48462.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky48462.txt-001-p1s1">
  <m id="m-jihomoravsky48462.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W1</w.rf>
   <form>Zatímco</form>
   <lemma>zatímco</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W2</w.rf>
   <form>muzikanti</form>
   <lemma>muzikant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W4</w.rf>
   <form>Olomouce</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W5</w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W7</w.rf>
   <form>zpívali</form>
   <lemma>zpívat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W9</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W10</w.rf>
   <form>Svobody</form>
   <lemma>svoboda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W12</w.rf>
   <form>dechovka</form>
   <lemma>dechovka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W13</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W14</w.rf>
   <form>Skutče</form>
   <lemma>Skuteč_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W16</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W17</w.rf>
   <form>historických</form>
   <lemma>historický</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W18</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W19</w.rf>
   <form>stříkačkách</form>
   <lemma>stříkačka_^(*2)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W20</w.rf>
   <form>projížděla</form>
   <lemma>projíždět_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W21</w.rf>
   <form>centrem</form>
   <lemma>centrum</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W22</w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W24</w.rf>
   <form>vyhrávala</form>
   <lemma>vyhrávat_:T_^(*3t)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W25</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W26</w.rf>
   <form>jízdy</form>
   <lemma>jízda</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W27</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W28</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W29</w.rf>
   <form>třech</form>
   <lemma>tři`3</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W30</w.rf>
   <form>zastávkách</form>
   <lemma>zastávka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48462.txt-001-p1s2">
  <m id="m-jihomoravsky48462.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W1</w.rf>
   <form>Řízné</form>
   <lemma>řízný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W2</w.rf>
   <form>tóny</form>
   <lemma>tón</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W3</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W4</w.rf>
   <form>dechovek</form>
   <lemma>dechovka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W5</w.rf>
   <form>doprovodila</form>
   <lemma>doprovodit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W6</w.rf>
   <form>předváděcí</form>
   <lemma>předváděcí_^(^IC**předvádět)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W7</w.rf>
   <form>jízda</form>
   <lemma>jízda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W9</w.rf>
   <form>výstavka</form>
   <lemma>výstavka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W10</w.rf>
   <form>čtyř</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W11</w.rf>
   <form>historických</form>
   <lemma>historický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W12</w.rf>
   <form>stříkaček</form>
   <lemma>stříkačka_^(*2)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W13</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W14</w.rf>
   <form>Olešnice</form>
   <lemma>Olešnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W16</w.rf>
   <form>Blanensku</form>
   <lemma>Blanensko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W18</w.rf>
   <form>Pozořic</form>
   <lemma>Pozořice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W20</w.rf>
   <form>Hrušovan</form>
   <lemma>Hrušovany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W22</w.rf>
   <form>Brněnsku</form>
   <lemma>Brněnsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W24</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W25</w.rf>
   <form>Brna-Komína</form>
   <lemma>Brna-Komín</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48462.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48462.txt-001-p1s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
