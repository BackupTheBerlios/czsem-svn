<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky48752.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky48752.txt-001-p1s1">
  <m id="m-jihomoravsky48752.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s1W1</w.rf>
   <form>Hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s1W2</w.rf>
   <form>zavolali</form>
   <lemma>zavolat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s1W3</w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s1W4</w.rf>
   <form>dítěte</form>
   <lemma>dítě</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p1s2">
  <m id="m-jihomoravsky48752.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W2</w.rf>
   <form>vystupování</form>
   <lemma>vystupování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W4</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W5</w.rf>
   <form>Audi</form>
   <lemma>Audi-1_;K</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W6</w.rf>
   <form>A6</form>
   <lemma>A6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W8</w.rf>
   <form>chvíli</form>
   <lemma>chvíle</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W9</w.rf>
   <form>položili</form>
   <lemma>položit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W10</w.rf>
   <form>klíče</form>
   <lemma>klíč</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W11</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W12</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W14</w.rf>
   <form>sedadlo</form>
   <lemma>sedadlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p1s3">
  <m id="m-jihomoravsky48752.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W1</w.rf>
   <form>Vítr</form>
   <lemma>vítr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W2</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W3</w.rf>
   <form>zabouchl</form>
   <lemma>zabouchnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W4</w.rf>
   <form>dveře</form>
   <lemma>dveře</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W5</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W7</w.rf>
   <form>uvnitř</form>
   <lemma>uvnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W8</w.rf>
   <form>zůstalo</form>
   <lemma>zůstat</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W9</w.rf>
   <form>zamčené</form>
   <lemma>zamčený_^(*4knout)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W10</w.rf>
   <form>čtrnáctidenní</form>
   <lemma>čtrnáctidenní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W11</w.rf>
   <form>dítě</form>
   <lemma>dítě</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p2s1">
  <m id="m-jihomoravsky48752.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W2</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W4</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W5</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W7</w.rf>
   <form>Lidické</form>
   <lemma>lidický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W8</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W9</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W11</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W12</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W13</w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W14</w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W15</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W16</w.rf>
   <form>ohlášení</form>
   <lemma>ohlášení_^(*4sit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W17</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W19</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W20</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W21</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p2s2">
  <m id="m-jihomoravsky48752.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W1</w.rf>
   <form>Dvoutýdenní</form>
   <lemma>dvoutýdenní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W2</w.rf>
   <form>dcerka</form>
   <lemma>dcerka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W3</w.rf>
   <form>majitelů</form>
   <lemma>majitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W4</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W5</w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W6</w.rf>
   <form>spala</form>
   <lemma>spát</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W8</w.rf>
   <form>nejevila</form>
   <lemma>jevit_:T</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W9</w.rf>
   <form>známky</form>
   <lemma>známka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W10</w.rf>
   <form>zdravotních</form>
   <lemma>zdravotní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W11</w.rf>
   <form>komplikací</form>
   <lemma>komplikace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p2s3">
  <m id="m-jihomoravsky48752.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W2</w.rf>
   <form>zabezpečovací</form>
   <lemma>zabezpečovací_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W3</w.rf>
   <form>systém</form>
   <lemma>systém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W4</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W5</w.rf>
   <form>znemožnil</form>
   <lemma>znemožnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W6</w.rf>
   <form>otevření</form>
   <lemma>otevření_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W7</w.rf>
   <form>dveří</form>
   <lemma>dveře</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W8</w.rf>
   <form>klasickým</form>
   <lemma>klasický</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W9</w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W13</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W14</w.rf>
   <form>dohodě</form>
   <lemma>dohoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W16</w.rf>
   <form>majiteli</form>
   <lemma>majitel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W17</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W18</w.rf>
   <form>rozhodli</form>
   <lemma>rozhodnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W19</w.rf>
   <form>vniknout</form>
   <lemma>vniknout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W20</w.rf>
   <form>dovnitř</form>
   <lemma>dovnitř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W21</w.rf>
   <form>násilím</form>
   <lemma>násilí</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p2s4">
  <m id="m-jihomoravsky48752.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s4W1</w.rf>
   <form>Přípravkem</form>
   <lemma>přípravek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s4W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s4W3</w.rf>
   <form>rozbíjení</form>
   <lemma>rozbíjení_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s4W4</w.rf>
   <form>skel</form>
   <lemma>sklo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s4W5</w.rf>
   <form>rozrazili</form>
   <lemma>rozrazit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s4W6</w.rf>
   <form>boční</form>
   <lemma>boční</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s4W7</w.rf>
   <form>okénko</form>
   <lemma>okénko_,e</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p2s5">
  <m id="m-jihomoravsky48752.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W1</w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W4</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W5</w.rf>
   <form>vlezl</form>
   <lemma>vlézt</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W6</w.rf>
   <form>dovnitř</form>
   <lemma>dovnitř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W8</w.rf>
   <form>podal</form>
   <lemma>podat_:W_^(něco_[někomu]_[někam])</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W9</w.rf>
   <form>otci</form>
   <lemma>otec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W10</w.rf>
   <form>dítěte</form>
   <lemma>dítě</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W11</w.rf>
   <form>zabouchnuté</form>
   <lemma>zabouchnutý_^(*3out)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W12</w.rf>
   <form>klíče</form>
   <lemma>klíč</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W14</w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W15</w.rf>
   <form>otevřel</form>
   <lemma>otevřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W16</w.rf>
   <form>dveře</form>
   <lemma>dveře</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p2s6">
  <m id="m-jihomoravsky48752.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W1</w.rf>
   <form>Necelých</form>
   <lemma>celý</lemma>
   <tag>AANP2----1N----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W2</w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W3</w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W4</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W5</w.rf>
   <form>zahájení</form>
   <lemma>zahájení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W6</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W7</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W8</w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W9</w.rf>
   <form>dcerku</form>
   <lemma>dcerka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W10</w.rf>
   <form>mladá</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W11</w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W12</w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W14</w.rf>
   <form>náruči</form>
   <lemma>náruč</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s6W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky48752.txt-001-p2s7">
  <m id="m-jihomoravsky48752.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W2</w.rf>
   <form>úklidu</form>
   <lemma>úklid</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W3</w.rf>
   <form>střepů</form>
   <lemma>střep</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W5</w.rf>
   <form>rozbitého</form>
   <lemma>rozbitý_^(*3ít)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W6</w.rf>
   <form>okénka</form>
   <lemma>okénko_,e</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W8</w.rf>
   <form>ukončili</form>
   <lemma>ukončit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W9</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W11</w.rf>
   <form>odjeli</form>
   <lemma>odjet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W13</w.rf>
   <form>základnu</form>
   <lemma>základna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky48752.txt-001-p2s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky48752.txt-001-p2s7W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
