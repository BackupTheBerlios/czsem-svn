<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky49735.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky49735.txt-001-p1s1">
  <m id="m-jihomoravsky49735.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W2</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W4</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W5</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W6</w.rf>
   <form>Baťovka</form>
   <lemma>baťovka_,h</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W8</w.rf>
   <form>operačnímu</form>
   <lemma>operační</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W9</w.rf>
   <form>středisku</form>
   <lemma>středisko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W10</w.rf>
   <form>HZS</form>
   <lemma>HZS-1_:B_;K_^(Hasičský_záchranný_sbor)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W11</w.rf>
   <form>ohlášen</form>
   <lemma>ohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W13</w.rf>
   <form>11.11</form>
   <form_change>num_normalization</form_change>
   <lemma>11.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W14</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W17</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W18</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W19</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W20</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W21</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W22</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W23</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W25</w.rf>
   <form>Hodoníně</form>
   <lemma>Hodonín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p1s2">
  <m id="m-jihomoravsky49735.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W2</w.rf>
   <form>autě</form>
   <lemma>auto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W3</w.rf>
   <form>zahořelo</form>
   <lemma>zahořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W5</w.rf>
   <form>motorovém</form>
   <lemma>motorový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W6</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W8</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W10</w.rf>
   <form>osádce</form>
   <lemma>osádka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W11</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W12</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W13</w.rf>
   <form>příjezdem</form>
   <lemma>příjezd</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W14</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W15</w.rf>
   <form>zlikvidovat</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W16</w.rf>
   <form>ručním</form>
   <lemma>ruční</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W17</w.rf>
   <form>hasícím</form>
   <lemma>hasící_^(*3it)</lemma>
   <tag>AGIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W18</w.rf>
   <form>přístrojem</form>
   <lemma>přístroj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p1s3">
  <m id="m-jihomoravsky49735.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W2</w.rf>
   <form>dohasili</form>
   <lemma>dohasit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W3</w.rf>
   <form>doutnající</form>
   <lemma>doutnající_^(*4t)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W4</w.rf>
   <form>protihlukové</form>
   <lemma>protihlukový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W5</w.rf>
   <form>obložené</form>
   <lemma>obložený_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W6</w.rf>
   <form>kapoty</form>
   <lemma>kapota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W7</w.rf>
   <form>motoru</form>
   <lemma>motor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W9</w.rf>
   <form>bezkontaktním</form>
   <lemma>bezkontaktní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W10</w.rf>
   <form>teploměrem</form>
   <lemma>teploměr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W11</w.rf>
   <form>změřili</form>
   <lemma>změřit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W12</w.rf>
   <form>teplotu</form>
   <lemma>teplota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W14</w.rf>
   <form>motoru</form>
   <lemma>motor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W15</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W17</w.rf>
   <form>interiéru</form>
   <lemma>interiér</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W18</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W19</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W20</w.rf>
   <form>případ</form>
   <lemma>případ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W21</w.rf>
   <form>žhnutí</form>
   <lemma>žhnutí_^(*3out)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W23</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W24</w.rf>
   <form>místech</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s3W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p1s4">
  <m id="m-jihomoravsky49735.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W1</w.rf>
   <form>Příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W5</w.rf>
   <form>zřejmě</form>
   <lemma>zřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W6</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W7</w.rf>
   <form>závada</form>
   <lemma>závada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W9</w.rf>
   <form>hodnotu</form>
   <lemma>hodnota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W10</w.rf>
   <form>uchráněné</form>
   <lemma>uchráněný_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W11</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W12</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W13</w.rf>
   <form>vyšetřovatel</form>
   <lemma>vyšetřovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W14</w.rf>
   <form>vyčíslil</form>
   <lemma>vyčíslit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W16</w.rf>
   <form>70</form>
   <lemma>70</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W17</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W18</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p1s4W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p2s1">
  <m id="m-jihomoravsky49735.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W1</w.rf>
   <form>Tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W2</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W3</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W5</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W8</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W10</w.rf>
   <form>Židlochovicích</form>
   <lemma>Židlochovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W12</w.rf>
   <form>Brněnsku</form>
   <lemma>Brněnsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W14</w.rf>
   <form>dobrovolné</form>
   <lemma>dobrovolný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W15</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W17</w.rf>
   <form>Židlochovic</form>
   <lemma>Židlochovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W19</w.rf>
   <form>Hrušovan</form>
   <lemma>Hrušovany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W20</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W21</w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W24</w.rf>
   <form>zaměstnal</form>
   <lemma>zaměstnat-1_:W_^(všeob._význam:_činnost,_zaměstnání)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W26</w.rf>
   <form>úterý</form>
   <lemma>úterý</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W28</w.rf>
   <form>podvečer</form>
   <lemma>podvečer</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W29</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W30</w.rf>
   <form>zahradní</form>
   <lemma>zahradní_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W31</w.rf>
   <form>chatky</form>
   <lemma>chatka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W32</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W33</w.rf>
   <form>kopci</form>
   <lemma>kopec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W34</w.rf>
   <form>Výhon</form>
   <lemma>výhon</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W35</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W36</w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W37</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W38</w.rf>
   <form>Židlochovic</form>
   <lemma>Židlochovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W39</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W40</w.rf>
   <form>Blučinu</form>
   <lemma>Blučina_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s1W41</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p2s2">
  <m id="m-jihomoravsky49735.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W3</w.rf>
   <form>operačnímu</form>
   <lemma>operační</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W4</w.rf>
   <form>středisku</form>
   <lemma>středisko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-1_:B_;K_^(Hasičský_záchranný_sbor)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W6</w.rf>
   <form>ohlášen</form>
   <lemma>ohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W8</w.rf>
   <form>18.48</form>
   <form_change>num_normalization</form_change>
   <lemma>18.48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p2s3">
  <m id="m-jihomoravsky49735.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W4</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W5</w.rf>
   <form>zděné</form>
   <lemma>zděný_^(*3ít)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W6</w.rf>
   <form>dvoupodlažní</form>
   <lemma>dvoupodlažní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W7</w.rf>
   <form>chatky</form>
   <lemma>chatka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W8</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W9</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W10</w.rf>
   <form>cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W11</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W12</w.rf>
   <form>krát</form>
   <lemma>krát_^(mat._operace;_2_krát_3)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W13</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W14</w.rf>
   <form>metry</form>
   <lemma>metr</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p2s4">
  <m id="m-jihomoravsky49735.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s4W1</w.rf>
   <form>Hořelo</form>
   <lemma>hořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s4W2</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s4W3</w.rf>
   <form>druhém</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s4W4</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s4W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p2s5">
  <m id="m-jihomoravsky49735.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s5W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s5W2</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s5W3</w.rf>
   <form>lokalizovali</form>
   <lemma>lokalizovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s5W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s5W5</w.rf>
   <form>18.58</form>
   <form_change>num_normalization</form_change>
   <lemma>18.58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s5W6</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s5W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p2s6">
  <m id="m-jihomoravsky49735.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W2</w.rf>
   <form>rozebírání</form>
   <lemma>rozebírání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W3</w.rf>
   <form>zbytků</form>
   <lemma>zbytek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W4</w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W6</w.rf>
   <form>dohašování</form>
   <lemma>dohašování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W7</w.rf>
   <form>lokálních</form>
   <lemma>lokální</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W8</w.rf>
   <form>ohnisek</form>
   <lemma>ohnisko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W9</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W11</w.rf>
   <form>zlikvidovali</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W13</w.rf>
   <form>19.23</form>
   <form_change>num_normalization</form_change>
   <lemma>19.23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W14</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s6W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p2s7">
  <m id="m-jihomoravsky49735.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W2</w.rf>
   <form>horní</form>
   <lemma>horní-1_^(vrchní)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W3</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W4</w.rf>
   <form>chatky</form>
   <lemma>chatka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W5</w.rf>
   <form>hrozila</form>
   <lemma>hrozit_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W6</w.rf>
   <form>zřícením</form>
   <lemma>zřícení_^(*4tit)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W8</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W9</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W10</w.rf>
   <form>zdi</form>
   <lemma>zeď</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W11</w.rf>
   <form>strhnout</form>
   <lemma>strhnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s7W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49735.txt-001-p2s8">
  <m id="m-jihomoravsky49735.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W5</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W7</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W9</w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W10</w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W11</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky49735.txt-001-p2s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49735.txt-001-p2s8W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
