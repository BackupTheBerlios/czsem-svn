<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky49245.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky49245.txt-001-p1s1">
  <m id="m-jihomoravsky49245.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W1</w.rf>
   <form>Vyplynulo</form>
   <lemma>vyplynout_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W3</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W4</w.rf>
   <form>shromáždění</form>
   <lemma>shromáždění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W5</w.rf>
   <form>Sborů</form>
   <lemma>sbor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W6</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W7</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W9</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W11</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W12</w.rf>
   <form>hodnotilo</form>
   <lemma>hodnotit_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W13</w.rf>
   <form>uplynulé</form>
   <lemma>uplynulý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W14</w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W16</w.rf>
   <form>zvolilo</form>
   <lemma>zvolit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W17</w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W18</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p1s2">
  <m id="m-jihomoravsky49245.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W2</w.rf>
   <form>krajském</form>
   <lemma>krajský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W3</w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W6</w.rf>
   <form>současné</form>
   <lemma>současný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W7</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W8</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W9</w.rf>
   <form>sborů</form>
   <lemma>sbor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W10</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W11</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W13</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W14</w.rf>
   <form>nichž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9XP2----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W15</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W16</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W17</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W18</w.rf>
   <form>členem</form>
   <lemma>člen</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W19</w.rf>
   <form>Moravské</form>
   <lemma>moravský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W20</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W21</w.rf>
   <form>jednoty</form>
   <lemma>jednota</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W23</w.rf>
   <form>ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W24</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W25</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W26</w.rf>
   <form>sdružení</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p1s3">
  <m id="m-jihomoravsky49245.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W1</w.rf>
   <form>Nejnovějším</form>
   <lemma>nový</lemma>
   <tag>AAIS7----3A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W3</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W4</w.rf>
   <form>aktivním</form>
   <lemma>aktivní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W5</w.rf>
   <form>sborem</form>
   <lemma>sbor</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W7</w.rf>
   <form>SDH</form>
   <lemma>Sdh</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W8</w.rf>
   <form>městské</form>
   <lemma>městský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W9</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W10</w.rf>
   <form>Brno-Vinohrady</form>
   <lemma>Brno-Vinohrada</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p1s4">
  <m id="m-jihomoravsky49245.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W1</w.rf>
   <form>Sbory</form>
   <lemma>sbor</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W2</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W3</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W4</w.rf>
   <form>zásahových</form>
   <lemma>zásahový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W5</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W7</w.rf>
   <form>jejichž</form>
   <lemma>jenž_^(který...[ve_vedl._větě])</lemma>
   <tag>P1XXXXP3-------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W8</w.rf>
   <form>základní</form>
   <lemma>základní_,s</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W9</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W11</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W12</w.rf>
   <form>starosty</form>
   <lemma>starosta</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W13</w.rf>
   <form>sdružení</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W14</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W15</w.rf>
   <form>Jaroslava</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W16</w.rf>
   <form>Schulze</form>
   <lemma>Schulz_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W18</w.rf>
   <form>CSc</form>
   <lemma>CSc-1_:B_,x_^(kandidát_věd)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W21</w.rf>
   <form>blíží</form>
   <lemma>blížit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W22</w.rf>
   <form>jednotkám</form>
   <lemma>jednotka</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W23</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W24</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s4W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p1s5">
  <m id="m-jihomoravsky49245.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W1</w.rf>
   <form>Jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W2</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W4</w.rf>
   <form>loni</form>
   <lemma>vloni_,h</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W6</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W7</w.rf>
   <form>zasahovaly</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W8</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W9</w.rf>
   <form>232</form>
   <lemma>232</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W10</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p1s6">
  <m id="m-jihomoravsky49245.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W1</w.rf>
   <form>Ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W2</w.rf>
   <form>zvyšování</form>
   <lemma>zvyšování_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W3</w.rf>
   <form>odborné</form>
   <lemma>odborný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W5</w.rf>
   <form>fyzické</form>
   <lemma>fyzický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W6</w.rf>
   <form>připravenosti</form>
   <lemma>připravenost_^(*5it)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W8</w.rf>
   <form>sbory</form>
   <lemma>sbor</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W9</w.rf>
   <form>účastní</form>
   <lemma>účastný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W10</w.rf>
   <form>klání</form>
   <lemma>klání_^(*2t)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W12</w.rf>
   <form>požárním</form>
   <lemma>požární</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W13</w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W15</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W16</w.rf>
   <form>soutěží</form>
   <lemma>soutěž</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s6W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p1s7">
  <m id="m-jihomoravsky49245.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W1</w.rf>
   <form>Tradiční</form>
   <lemma>tradiční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W2</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W3</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W4</w.rf>
   <form>dovednosti</form>
   <lemma>dovednost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W5</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W6</w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W7</w.rf>
   <form>starosty</form>
   <lemma>starosta</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W8</w.rf>
   <form>okresního</form>
   <lemma>okresní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W9</w.rf>
   <form>Sdružení</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W10</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W11</w.rf>
   <form>Čech</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W13</w.rf>
   <form>Moravy</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W15</w.rf>
   <form>Slezska</form>
   <lemma>Slezsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W16</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W17</w.rf>
   <form>Vranově</form>
   <lemma>Vranov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W18</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W19</w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W20</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W21</w.rf>
   <form>loni</form>
   <lemma>vloni_,h</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W22</w.rf>
   <form>zúčastnilo</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W23</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W24</w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W25</w.rf>
   <form>mužů</form>
   <lemma>muž</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W27</w.rf>
   <form>žen</form>
   <lemma>žena</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p1s7W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p1s7W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p2s1">
  <m id="m-jihomoravsky49245.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W3</w.rf>
   <form>věnují</form>
   <lemma>věnovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W4</w.rf>
   <form>velkou</form>
   <lemma>velký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W5</w.rf>
   <form>pozornost</form>
   <lemma>pozornost-1_^(všímavý,_milý,_soustředěný)_(*5ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W6</w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W8</w.rf>
   <form>mládeží</form>
   <lemma>mládež</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p2s2">
  <m id="m-jihomoravsky49245.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s2W1</w.rf>
   <form>Tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s2W2</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s2W3</w.rf>
   <form>loni</form>
   <lemma>vloni_,h</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s2W4</w.rf>
   <form>rozvíjelo</form>
   <lemma>rozvíjet_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s2W5</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s2W6</w.rf>
   <form>sborů</form>
   <lemma>sbor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p2s3">
  <m id="m-jihomoravsky49245.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W1</w.rf>
   <form>Kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W2</w.rf>
   <form>tradičních</form>
   <lemma>tradiční</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W3</w.rf>
   <form>jarních</form>
   <lemma>jarní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W5</w.rf>
   <form>podzimních</form>
   <lemma>podzimní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W6</w.rf>
   <form>soutěží</form>
   <lemma>soutěž</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W7</w.rf>
   <form>mladých</form>
   <lemma>mladý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W8</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W10</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W11</w.rf>
   <form>soutěží</form>
   <lemma>soutěž</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W13</w.rf>
   <form>akcí</form>
   <lemma>akce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W15</w.rf>
   <form>sdružení</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W16</w.rf>
   <form>zapojilo</form>
   <lemma>zapojit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W17</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W19</w.rf>
   <form>programu</form>
   <lemma>program-1</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W20</w.rf>
   <form>Bambiriáda</form>
   <lemma>Bambiriád</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W22</w.rf>
   <form>Centru</form>
   <lemma>centrum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W23</w.rf>
   <form>volného</form>
   <lemma>volný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W24</w.rf>
   <form>času</form>
   <lemma>čas</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W25</w.rf>
   <form>Lužánky</form>
   <lemma>Lužánky_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s3W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p2s4">
  <m id="m-jihomoravsky49245.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W2</w.rf>
   <form>odborné</form>
   <lemma>odborný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W3</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W4</w.rf>
   <form>dětských</form>
   <lemma>dětský</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W6</w.rf>
   <form>mládežnických</form>
   <lemma>mládežnický</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W7</w.rf>
   <form>kolektivů</form>
   <lemma>kolektiv</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W8</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W9</w.rf>
   <form>proškoleno</form>
   <lemma>proškolit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W10</w.rf>
   <form>54</form>
   <lemma>54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W11</w.rf>
   <form>vedoucích</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p2s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p3s1">
  <m id="m-jihomoravsky49245.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W1</w.rf>
   <form>Starostou</form>
   <lemma>starosta</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W2</w.rf>
   <form>sdružení</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W4</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W5</w.rf>
   <form>zůstává</form>
   <lemma>zůstávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W6</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W7</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W8</w.rf>
   <form>Schulz</form>
   <lemma>Schulz_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W10</w.rf>
   <form>CSc</form>
   <lemma>CSc-1_:B_,x_^(kandidát_věd)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p3s2">
  <m id="m-jihomoravsky49245.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W1</w.rf>
   <form>Mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W2</w.rf>
   <form>třemi</form>
   <lemma>tři`3</lemma>
   <tag>ClXP7----------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W3</w.rf>
   <form>místopředsedy</form>
   <lemma>místopředseda</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W6</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W7</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W8</w.rf>
   <form>prevence</form>
   <lemma>prevence</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W10</w.rf>
   <form>Jihomoravského</form>
   <lemma>jihomoravský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W11</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W12</w.rf>
   <form>plk</form>
   <lemma>plukovník_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49245.txt-001-p3s3">
  <m id="m-jihomoravsky49245.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s3W1</w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s3W2</w.rf>
   <form>Sláma</form>
   <lemma>Sláma-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49245.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49245.txt-001-p3s3W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
