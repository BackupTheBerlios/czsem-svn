<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky50262.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky50262.txt-001-p1s1">
  <m id="m-jihomoravsky50262.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W2</w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W3</w.rf>
   <form>nejvíc</form>
   <lemma>hodně</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W6</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W7</w.rf>
   <form>výjezdů</form>
   <lemma>výjezd</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W10</w.rf>
   <form>patřilo</form>
   <lemma>patřit_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W11</w.rf>
   <form>technickým</form>
   <lemma>technický</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W12</w.rf>
   <form>zásahům</form>
   <lemma>zásah</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p1s2">
  <m id="m-jihomoravsky50262.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W2</w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W4</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W6</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W7</w.rf>
   <form>nebezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAIP4----1N----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W8</w.rf>
   <form>roje</form>
   <lemma>roj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W9</w.rf>
   <form>včel</form>
   <lemma>včela</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W11</w.rf>
   <form>vos</form>
   <lemma>vosa</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W13</w.rf>
   <form>dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W15</w.rf>
   <form>komunikací</form>
   <lemma>komunikace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W16</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W17</w.rf>
   <form>vyvrácené</form>
   <lemma>vyvrácený_^(*4tit)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W18</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p1s3">
  <m id="m-jihomoravsky50262.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W3</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W4</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W5</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W6</w.rf>
   <form>požárům</form>
   <lemma>požár</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W8</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W9</w.rf>
   <form>nichž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9XP6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W10</w.rf>
   <form>nejčastěji</form>
   <lemma>častě_^(*1ý)</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W11</w.rf>
   <form>hořela</form>
   <lemma>hořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W12</w.rf>
   <form>tráva</form>
   <lemma>tráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W14</w.rf>
   <form>zemědělské</form>
   <lemma>zemědělský</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W15</w.rf>
   <form>porosty</form>
   <lemma>porost</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p1s4">
  <m id="m-jihomoravsky50262.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W1</w.rf>
   <form>Pětkrát</form>
   <lemma>pětkrát`5</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W3</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W5</w.rf>
   <form>záchraně</form>
   <lemma>záchrana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W6</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W8</w.rf>
   <form>zvířat</form>
   <lemma>zvíře</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p1s5">
  <m id="m-jihomoravsky50262.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W2</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W3</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W5</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W7</w.rf>
   <form>planý</form>
   <lemma>planý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W8</w.rf>
   <form>poplach</form>
   <lemma>poplach</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p1s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p2s1">
  <m id="m-jihomoravsky50262.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W2</w.rf>
   <form>záchraně</form>
   <lemma>záchrana</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W3</w.rf>
   <form>malého</form>
   <lemma>malý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W4</w.rf>
   <form>dítěte</form>
   <lemma>dítě</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W6</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W7</w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W8</w.rf>
   <form>nemohli</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W9</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W11</w.rf>
   <form>uzamčeného</form>
   <lemma>uzamčený_^(*4knout)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W12</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W13</w.rf>
   <form>Volkswagen</form>
   <lemma>Volkswagen-1_;K_,x</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W14</w.rf>
   <form>Golf</form>
   <lemma>Golf-2_;R_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W16</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W17</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W19</w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W20</w.rf>
   <form>krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W21</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W22</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W24</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W25</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W26</w.rf>
   <form>Hybešovy</form>
   <lemma>Hybešův_;S_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W27</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W28</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W29</w.rf>
   <form>Vyškově-Předměstí</form>
   <lemma>Vyškově-Předměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p2s2">
  <m id="m-jihomoravsky50262.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W2</w.rf>
   <form>centrální</form>
   <lemma>centrální</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W3</w.rf>
   <form>zamykání</form>
   <lemma>zamykání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W4</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W6</w.rf>
   <form>nepodařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W7</w.rf>
   <form>uvolnit</form>
   <lemma>uvolnit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W10</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W11</w.rf>
   <form>dohodě</form>
   <lemma>dohoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W13</w.rf>
   <form>majitelem</form>
   <lemma>majitel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W14</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W15</w.rf>
   <form>přípravkem</form>
   <lemma>přípravek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W17</w.rf>
   <form>rozbíjení</form>
   <lemma>rozbíjení_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W18</w.rf>
   <form>skla</form>
   <lemma>sklo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W19</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W20</w.rf>
   <form>boční</form>
   <lemma>boční</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W21</w.rf>
   <form>okénko</form>
   <lemma>okénko_,e</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W22</w.rf>
   <form>dveří</form>
   <lemma>dveře</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W24</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W25</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W26</w.rf>
   <form>vnikli</form>
   <lemma>vniknout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W27</w.rf>
   <form>násilím</form>
   <lemma>násilí</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p2s3">
  <m id="m-jihomoravsky50262.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W1</w.rf>
   <form>Chlapečka</form>
   <lemma>chlapeček</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W2</w.rf>
   <form>narozeného</form>
   <lemma>narozený_^(*4dit)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W4</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W5</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W7</w.rf>
   <form>pořádku</form>
   <lemma>pořádek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W8</w.rf>
   <form>předali</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W9</w.rf>
   <form>rodičům</form>
   <lemma>rodič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p2s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p3s1">
  <m id="m-jihomoravsky50262.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W2</w.rf>
   <form>Oslavan</form>
   <lemma>Oslavany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W4</w.rf>
   <form>Brněnsku</form>
   <lemma>Brněnsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W7</w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W8</w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W9</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W11</w.rf>
   <form>záchraně</form>
   <lemma>záchrana</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W12</w.rf>
   <form>srny</form>
   <lemma>srna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W14</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W15</w.rf>
   <form>spadla</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W17</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p3s2">
  <m id="m-jihomoravsky50262.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W3</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W5</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W6</w.rf>
   <form>značně</form>
   <lemma>značně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W7</w.rf>
   <form>vyčerpané</form>
   <lemma>vyčerpaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W8</w.rf>
   <form>zvíře</form>
   <lemma>zvíře</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W9</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W11</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W12</w.rf>
   <form>nádrži</form>
   <lemma>nádrž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W13</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W14</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W15</w.rf>
   <form>cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W16</w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W17</w.rf>
   <form>krát</form>
   <lemma>krát_^(mat._operace;_2_krát_3)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W18</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W19</w.rf>
   <form>metry</form>
   <lemma>metr</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W21</w.rf>
   <form>snaží</form>
   <lemma>snažit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W22</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W23</w.rf>
   <form>plavat</form>
   <lemma>plavat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W25</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W26</w.rf>
   <form>nemůže</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W27</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W28</w.rf>
   <form>vlastními</form>
   <lemma>vlastní-1_^(příslušný_k_něčemu)</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W29</w.rf>
   <form>silami</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W30</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W31</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W32</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s2W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p3s3">
  <m id="m-jihomoravsky50262.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W1</w.rf>
   <form>Hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W3</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W4</w.rf>
   <form>lana</form>
   <lemma>lano</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W5</w.rf>
   <form>srnu</form>
   <lemma>srna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W6</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W7</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W8</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W9</w.rf>
   <form>břehu</form>
   <lemma>břeh</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W10</w.rf>
   <form>nádrže</form>
   <lemma>nádrž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p3s4">
  <m id="m-jihomoravsky50262.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s4W1</w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s4W2</w.rf>
   <form>zvíře</form>
   <lemma>zvíře</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s4W3</w.rf>
   <form>chytili</form>
   <lemma>chytit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s4W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s4W5</w.rf>
   <form>vytáhli</form>
   <lemma>vytáhnout</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p3s5">
  <m id="m-jihomoravsky50262.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W1</w.rf>
   <form>Srnu</form>
   <lemma>srna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W2</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W3</w.rf>
   <form>známek</form>
   <lemma>známka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W4</w.rf>
   <form>poranění</form>
   <lemma>poranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W5</w.rf>
   <form>vypustili</form>
   <lemma>vypustit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W6</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W8</w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p3s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p4s1">
  <m id="m-jihomoravsky50262.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W2</w.rf>
   <form>Ivančicích</form>
   <lemma>Ivančice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W5</w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W6</w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W7</w.rf>
   <form>zachraňovali</form>
   <lemma>zachraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W8</w.rf>
   <form>mláďata</form>
   <lemma>mládě</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W9</w.rf>
   <form>labutí</form>
   <lemma>labutí</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p4s2">
  <m id="m-jihomoravsky50262.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W1</w.rf>
   <form>Dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W2</w.rf>
   <form>mláďata</form>
   <lemma>mládě</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W4</w.rf>
   <form>řece</form>
   <lemma>řeka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W5</w.rf>
   <form>Jihlavě</form>
   <lemma>Jihlava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W7</w.rf>
   <form>rekreační</form>
   <lemma>rekreační</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W8</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W9</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W10</w.rf>
   <form>Réně</form>
   <lemma>Réna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W11</w.rf>
   <form>uvěznil</form>
   <lemma>uvěznit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W12</w.rf>
   <form>prudký</form>
   <lemma>prudký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W13</w.rf>
   <form>proud</form>
   <lemma>proud</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W14</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W15</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W16</w.rf>
   <form>splavem</form>
   <lemma>splav</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p4s3">
  <m id="m-jihomoravsky50262.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W3</w.rf>
   <form>řece</form>
   <lemma>řeka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W5</w.rf>
   <form>nízký</form>
   <lemma>nízký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W6</w.rf>
   <form>stav</form>
   <lemma>stav</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W7</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W10</w.rf>
   <form>vstoupili</form>
   <lemma>vstoupit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W12</w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W14</w.rf>
   <form>labutě</form>
   <lemma>labuť</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W15</w.rf>
   <form>odchytili</form>
   <lemma>odchytit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W17</w.rf>
   <form>sítě</form>
   <lemma>síť</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W19</w.rf>
   <form>předali</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W20</w.rf>
   <form>rodičům</form>
   <lemma>rodič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p4s4">
  <m id="m-jihomoravsky50262.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W1</w.rf>
   <form>Další</form>
   <lemma>další</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W2</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W3</w.rf>
   <form>mláďata</form>
   <lemma>mládě</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W4</w.rf>
   <form>labutí</form>
   <lemma>labutí</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W5</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W6</w.rf>
   <form>vysvobodili</form>
   <lemma>vysvobodit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W8</w.rf>
   <form>přečerpávací</form>
   <lemma>přečerpávací_^(*5at)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W9</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p4s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p5s1">
  <m id="m-jihomoravsky50262.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W1</w.rf>
   <form>Osobní</form>
   <lemma>osobní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W2</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W3</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W4</w.rf>
   <form>utopené</form>
   <lemma>utopený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W5</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W7</w.rf>
   <form>řece</form>
   <lemma>řeka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W10</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W12</w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W13</w.rf>
   <form>vytahovali</form>
   <lemma>vytahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W15</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W16</w.rf>
   <form>Svitávka</form>
   <lemma>Svitávka_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W18</w.rf>
   <form>Blanensku</form>
   <lemma>Blanensko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p5s2">
  <m id="m-jihomoravsky50262.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W1</w.rf>
   <form>Událost</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W3</w.rf>
   <form>operačnímu</form>
   <lemma>operační</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W4</w.rf>
   <form>středisku</form>
   <lemma>středisko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W6</w.rf>
   <form>ohlášena</form>
   <lemma>ohlásit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W8</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W12</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W13</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W14</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W15</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W17</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W18</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W20</w.rf>
   <form>Boskovicích</form>
   <lemma>Boskovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p5s3">
  <m id="m-jihomoravsky50262.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W1</w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W3</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W4</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W6</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W7</w.rf>
   <form>majitel</form>
   <lemma>majitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W8</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W9</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W10</w.rf>
   <form>120</form>
   <lemma>120</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W11</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W13</w.rf>
   <form>břehu</form>
   <lemma>břeh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W14</w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W15</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W16</w.rf>
   <form>nezabrzdil</form>
   <lemma>zabrzdit_:W</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W18</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W19</w.rf>
   <form>sjelo</form>
   <lemma>sjet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W20</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W21</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W23</w.rf>
   <form>skončilo</form>
   <lemma>skončit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W24</w.rf>
   <form>potopené</form>
   <lemma>potopený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W25</w.rf>
   <form>přední</form>
   <lemma>přední</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W26</w.rf>
   <form>částí</form>
   <lemma>část</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W27</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W28</w.rf>
   <form>téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W29</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W30</w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s3W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p5s4">
  <m id="m-jihomoravsky50262.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W1</w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W2</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W4</w.rf>
   <form>zjištěn</form>
   <lemma>zjistit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W5</w.rf>
   <form>únik</form>
   <lemma>únik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W6</w.rf>
   <form>ropných</form>
   <lemma>ropný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W7</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W11</w.rf>
   <form>řece</form>
   <lemma>řeka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W12</w.rf>
   <form>postavili</form>
   <lemma>postavit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W13</w.rf>
   <form>nornou</form>
   <lemma>norný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W14</w.rf>
   <form>stěnu</form>
   <lemma>stěna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W16</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W17</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W18</w.rf>
   <form>lanem</form>
   <lemma>lano</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W19</w.rf>
   <form>navijáku</form>
   <lemma>naviják</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W20</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W21</w.rf>
   <form>zásahového</form>
   <lemma>zásahový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W22</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W23</w.rf>
   <form>pokusili</form>
   <lemma>pokusit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W24</w.rf>
   <form>vytáhnout</form>
   <lemma>vytáhnout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s4W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p5s5">
  <m id="m-jihomoravsky50262.txt-001-p5s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s5W1</w.rf>
   <form>Pokus</form>
   <lemma>pokus</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s5W2</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s5W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s5W4</w.rf>
   <form>úspěšný</form>
   <lemma>úspěšný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s5W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p5s6">
  <m id="m-jihomoravsky50262.txt-001-p5s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W4</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W5</w.rf>
   <form>povolán</form>
   <lemma>povolat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W6</w.rf>
   <form>automobilový</form>
   <lemma>automobilový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W7</w.rf>
   <form>jeřáb</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W8</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W9</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W11</w.rf>
   <form>Lidické</form>
   <lemma>lidický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W12</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W14</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W16</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W17</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W18</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W19</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W20</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W21</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W23</w.rf>
   <form>hodinou</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W24</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W25</w.rf>
   <form>půlnoci</form>
   <lemma>půlnoc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W26</w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W27</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W28</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W29</w.rf>
   <form>vytáhli</form>
   <lemma>vytáhnout</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s6W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s6W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky50262.txt-001-p5s7">
  <m id="m-jihomoravsky50262.txt-001-p5s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s7W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s7W2</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s7W3</w.rf>
   <form>norné</form>
   <lemma>norný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s7W4</w.rf>
   <form>stěny</form>
   <lemma>stěna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s7W5</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s7W6</w.rf>
   <form>ukončili</form>
   <lemma>ukončit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky50262.txt-001-p5s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky50262.txt-001-p5s7W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
