<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky47460.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky47460.txt-001-p1s1">
  <m id="m-jihomoravsky47460.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W2</w.rf>
   <form>křižovatce</form>
   <lemma>křižovatka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W3</w.rf>
   <form>ulic</form>
   <lemma>ulice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W4</w.rf>
   <form>Chodská</form>
   <lemma>chodský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W6</w.rf>
   <form>Dobrovského</form>
   <lemma>Dobrovský_;S</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W8</w.rf>
   <form>střetla</form>
   <lemma>střetnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W9</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W10</w.rf>
   <form>Renault</form>
   <lemma>Renault-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W11</w.rf>
   <form>Megane</form>
   <lemma>Megane</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W13</w.rf>
   <form>Saab</form>
   <lemma>Saab_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W14</w.rf>
   <form>9000</form>
   <lemma>9000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W16</w.rf>
   <form>Opel</form>
   <lemma>Opel-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W17</w.rf>
   <form>Corsa</form>
   <lemma>Corso_;K_^(restaurace)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W19</w.rf>
   <form>čtvrtým</form>
   <lemma>čtvrtý</lemma>
   <tag>CrMS7----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W20</w.rf>
   <form>účastníkem</form>
   <lemma>účastník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W21</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W22</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W23</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W24</w.rf>
   <form>cisternový</form>
   <lemma>cisternový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W25</w.rf>
   <form>nákladní</form>
   <lemma>nákladní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W26</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W27</w.rf>
   <form>Tatra</form>
   <lemma>Tatra-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W28</w.rf>
   <form>815</form>
   <lemma>815</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47460.txt-001-p1s2">
  <m id="m-jihomoravsky47460.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W1</w.rf>
   <form>Nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W3</w.rf>
   <form>operačnímu</form>
   <lemma>operační</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W4</w.rf>
   <form>středisku</form>
   <lemma>středisko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W5</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W6</w.rf>
   <form>ohlášena</form>
   <lemma>ohlásit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W8</w.rf>
   <form>12.28</form>
   <form_change>num_normalization</form_change>
   <lemma>12.28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W12</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W13</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W14</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W15</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W16</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W17</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W18</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W20</w.rf>
   <form>Lidické</form>
   <lemma>lidický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W21</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47460.txt-001-p1s3">
  <m id="m-jihomoravsky47460.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W2</w.rf>
   <form>vozidle</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W3</w.rf>
   <form>Renault</form>
   <lemma>Renault-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W4</w.rf>
   <form>Megane</form>
   <lemma>Megane</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W5</w.rf>
   <form>zůstali</form>
   <lemma>zůstat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W6</w.rf>
   <form>zaklíněni</form>
   <lemma>zaklínit</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W7</w.rf>
   <form>zraněný</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W8</w.rf>
   <form>řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W10</w.rf>
   <form>zraněná</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W11</w.rf>
   <form>spolujezdkyně</form>
   <lemma>spolujezdkyně_^(*4ec)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47460.txt-001-p1s4">
  <m id="m-jihomoravsky47460.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W2</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W3</w.rf>
   <form>hydraulické</form>
   <lemma>hydraulický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W4</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W5</w.rf>
   <form>odstřihli</form>
   <lemma>odstřihnout_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W6</w.rf>
   <form>levé</form>
   <lemma>levý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W7</w.rf>
   <form>přední</form>
   <lemma>přední</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W8</w.rf>
   <form>dveře</form>
   <lemma>dveře</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W10</w.rf>
   <form>osádku</form>
   <lemma>osádka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W11</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W12</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W13</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W14</w.rf>
   <form>zdravotníky</form>
   <lemma>zdravotník</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W15</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W16</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W17</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s4W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47460.txt-001-p1s5">
  <m id="m-jihomoravsky47460.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s5W1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s5W2</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s5W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s5W4</w.rf>
   <form>odpojili</form>
   <lemma>odpojit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s5W5</w.rf>
   <form>baterii</form>
   <lemma>baterie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky47460.txt-001-p1s6">
  <m id="m-jihomoravsky47460.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W2</w.rf>
   <form>únik</form>
   <lemma>únik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W3</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W4</w.rf>
   <form>kapalin</form>
   <lemma>kapalina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W5</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W6</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W7</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W8</w.rf>
   <form>zjištěn</form>
   <lemma>zjistit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W10</w.rf>
   <form>ukončili</form>
   <lemma>ukončit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W11</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky47460.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky47460.txt-001-p1s6W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
