<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jihomoravsky49802.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-jihomoravsky49802.txt-001-p1s1">
  <m id="m-jihomoravsky49802.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W1</w.rf>
   <form>Výcviku</form>
   <lemma>výcvik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W3</w.rf>
   <form>kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W4</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W7</w.rf>
   <form>lezců</form>
   <lemma>lezec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W9</w.rf>
   <form>tzv.</form>
   <lemma>takzvaný_:B_,x</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W10</w.rf>
   <form>sutinového</form>
   <lemma>sutinový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W11</w.rf>
   <form>odřadu</form>
   <lemma>odřad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W12</w.rf>
   <form>příslušníků</form>
   <lemma>příslušník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W13</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W14</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W16</w.rf>
   <form>Lidické</form>
   <lemma>lidický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W17</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W19</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W20</w.rf>
   <form>zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W21</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W22</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W23</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W24</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W26</w.rf>
   <form>Mikulově</form>
   <lemma>Mikulov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W28</w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W29</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W30</w.rf>
   <form>155</form>
   <lemma>155</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W32</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W33</w.rf>
   <form>praporu</form>
   <lemma>prapor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W34</w.rf>
   <form>Armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W35</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W36</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W37</w.rf>
   <form>Bučovicích</form>
   <lemma>Bučovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W38</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W39</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W40</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W41</w.rf>
   <form>kynologové</form>
   <lemma>kynolog</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W42</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W43</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W44</w.rf>
   <form>záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p1s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p1s1W45</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49802.txt-001-p2s1">
  <m id="m-jihomoravsky49802.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W1</w.rf>
   <form>Záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W2</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W3</w.rf>
   <form>nacvičovat</form>
   <lemma>nacvičovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W5</w.rf>
   <form>záchranu</form>
   <lemma>záchrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W6</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W7</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W8</w.rf>
   <form>lezeckých</form>
   <lemma>lezecký</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W9</w.rf>
   <form>technik</form>
   <lemma>technika</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W11</w.rf>
   <form>slaňování</form>
   <lemma>slaňování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W13</w.rf>
   <form>průchod</form>
   <lemma>průchod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W14</w.rf>
   <form>týmu</form>
   <lemma>tým</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W15</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W16</w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W17</w.rf>
   <form>typy</form>
   <lemma>typ</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W18</w.rf>
   <form>zdiva</form>
   <lemma>zdivo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W20</w.rf>
   <form>rozebírání</form>
   <lemma>rozebírání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W21</w.rf>
   <form>sutin</form>
   <lemma>sutina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W23</w.rf>
   <form>průnik</form>
   <lemma>průnik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W24</w.rf>
   <form>podlahou</form>
   <lemma>podlaha</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W25</w.rf>
   <form>budovy</form>
   <lemma>budova</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W27</w.rf>
   <form>vyhledávání</form>
   <lemma>vyhledávání_^(*5at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W28</w.rf>
   <form>zavalených</form>
   <lemma>zavalený_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W29</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W30</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W31</w.rf>
   <form>štěrbinové</form>
   <lemma>štěrbinový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W32</w.rf>
   <form>kamery</form>
   <lemma>kamera</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s1W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49802.txt-001-p2s2">
  <m id="m-jihomoravsky49802.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W2</w.rf>
   <form>záchranných</form>
   <lemma>záchranný</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W3</w.rf>
   <form>pracích</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W4</w.rf>
   <form>použijí</form>
   <lemma>použít</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W6</w.rf>
   <form>trhavinu</form>
   <lemma>trhavina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W8</w.rf>
   <form>mikronáložích</form>
   <lemma>mikronálože</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49802.txt-001-p2s3">
  <m id="m-jihomoravsky49802.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W2</w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W3</w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W5</w.rf>
   <form>záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W6</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W7</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W8</w.rf>
   <form>zdokonalovat</form>
   <lemma>zdokonalovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W9</w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W10</w.rf>
   <form>předlékařské</form>
   <lemma>předlékařský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W11</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W12</w.rf>
   <form>zraněným</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49802.txt-001-p2s4">
  <m id="m-jihomoravsky49802.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W1</w.rf>
   <form>Výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W2</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W3</w.rf>
   <form>prověřit</form>
   <lemma>prověřit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W5</w.rf>
   <form>připravenost</form>
   <lemma>připravenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W8</w.rf>
   <form>vícedennímu</form>
   <lemma>vícedenní</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W9</w.rf>
   <form>nasazení</form>
   <lemma>nasazení_^(*4dit)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W10</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W12</w.rf>
   <form>vyprošťovacího</form>
   <lemma>vyprošťovací_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W13</w.rf>
   <form>odřadu</form>
   <lemma>odřad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W15</w.rf>
   <form>terénu</form>
   <lemma>terén</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W16</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W17</w.rf>
   <form>týlového</form>
   <lemma>týlový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W18</w.rf>
   <form>zabezpečení</form>
   <lemma>zabezpečení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p2s4W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49802.txt-001-p3s1">
  <m id="m-jihomoravsky49802.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W2</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W3</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W5</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W8</w.rf>
   <form>kasárnách</form>
   <lemma>kasárna</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W9</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W10</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W12</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W13</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W14</w.rf>
   <form>uskuteční</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W15</w.rf>
   <form>praktické</form>
   <lemma>praktický</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W16</w.rf>
   <form>ukázky</form>
   <lemma>ukázka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W17</w.rf>
   <form>záchranářských</form>
   <lemma>záchranářský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W18</w.rf>
   <form>činností</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W19</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W20</w.rf>
   <form>odbornou</form>
   <lemma>odborný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W21</w.rf>
   <form>veřejnost</form>
   <lemma>veřejnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W23</w.rf>
   <form>média</form>
   <lemma>médium</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49802.txt-001-p3s2">
  <m id="m-jihomoravsky49802.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W1</w.rf>
   <form>Novináři</form>
   <lemma>novinář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W2</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W4</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W5</w.rf>
   <form>pořídit</form>
   <lemma>pořídit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W7</w.rf>
   <form>obrazové</form>
   <lemma>obrazový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W9</w.rf>
   <form>zvukové</form>
   <lemma>zvukový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W10</w.rf>
   <form>záznamy</form>
   <lemma>záznam</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49802.txt-001-p3s3">
  <m id="m-jihomoravsky49802.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s3W1</w.rf>
   <form>Kontaktní</form>
   <lemma>kontaktní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s3W2</w.rf>
   <form>osobou</form>
   <lemma>osoba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s3W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s3W4</w.rf>
   <form>vedoucím</form>
   <lemma>vedoucí-1_^(*8ést-1)</lemma>
   <tag>AGIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s3W5</w.rf>
   <form>výcviku</form>
   <lemma>výcvik</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s3W6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s3W7</w.rf>
   <form>por</form>
   <lemma>poručík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-jihomoravsky49802.txt-001-p3s4">
  <m id="m-jihomoravsky49802.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W1</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W2</w.rf>
   <form>Martin</form>
   <lemma>Martin-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W3</w.rf>
   <form>Červenka</form>
   <lemma>Červenka_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W5</w.rf>
   <form>krajského</form>
   <lemma>krajský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W6</w.rf>
   <form>ředitelství</form>
   <lemma>ředitelství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W7</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W8</w.rf>
   <form>Jihomoravského</form>
   <lemma>jihomoravský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W9</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W11</w.rf>
   <form>tel</form>
   <lemma>telefon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W13</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W14</w.rf>
   <form>724143884</form>
   <form_change>num_normalization</form_change>
   <lemma>724143884</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W16</w.rf>
   <form>e-mail</form>
   <lemma>e-mail</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W17</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W18</w.rf>
   <form>martin.cervenka</form>
   <lemma>martin.cervena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W19</w.rf>
   <form>@</form>
   <lemma>@</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W20</w.rf>
   <form>firebrno.cz</form>
   <lemma>firebrno.cz</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-jihomoravsky49802.txt-001-p3s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-jihomoravsky49802.txt-001-p3s4W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
