<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="moravskoslezsky47300.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-moravskoslezsky47300.txt-001-p1s1">
  <m id="m-moravskoslezsky47300.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W2</w.rf>
   <form>Hasičském</form>
   <lemma>hasičský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W3</w.rf>
   <form>muzeu</form>
   <lemma>muzeum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W6</w.rf>
   <form>úterý</form>
   <lemma>úterý</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W7</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W8</w.rf>
   <form>oceněn</form>
   <lemma>ocenit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W11</w.rf>
   <form>tentokrát</form>
   <lemma>tentokrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W12</w.rf>
   <form>krásnou</form>
   <lemma>krásný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W13</w.rf>
   <form>hasičskou</form>
   <lemma>hasičský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W14</w.rf>
   <form>sekerkou</form>
   <lemma>sekerka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W16</w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W17</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W18</w.rf>
   <form>bývalý</form>
   <lemma>bývalý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W19</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W20</w.rf>
   <form>kanceláře</form>
   <lemma>kancelář</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W21</w.rf>
   <form>krajského</form>
   <lemma>krajský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W22</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W23</w.rf>
   <form>plk</form>
   <lemma>plukovník_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47300.txt-001-p1s2">
  <m id="m-moravskoslezsky47300.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W1</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W2</w.rf>
   <form>Neuwirth</form>
   <lemma>Neuwirth_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W4</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W5</w.rf>
   <form>odchází</form>
   <lemma>odcházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W7</w.rf>
   <form>zasloužené</form>
   <lemma>zasloužený_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W8</w.rf>
   <form>penze</form>
   <lemma>penze</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47300.txt-001-p1s3">
  <m id="m-moravskoslezsky47300.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W2</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W4</w.rf>
   <form>slouží</form>
   <lemma>sloužit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W5</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W6</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W7</w.rf>
   <form>1967</form>
   <lemma>1967</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W9</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W10</w.rf>
   <form>plných</form>
   <lemma>plný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W11</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W12</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p1s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47300.txt-001-p2s1">
  <m id="m-moravskoslezsky47300.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W2</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W3</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W4</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W5</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W6</w.rf>
   <form>slouží</form>
   <lemma>sloužit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W7</w.rf>
   <form>nejméně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W8</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W9</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W10</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W11</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W12</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W14</w.rf>
   <form>nositelů</form>
   <lemma>nositel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W15</w.rf>
   <form>medaile</form>
   <lemma>medaile</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W16</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W17</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W18</w.rf>
   <form>věrnost</form>
   <lemma>věrnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W19</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W20</w.rf>
   <form>nejvyššího</form>
   <lemma>vysoký</lemma>
   <tag>AAMS2----3A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W21</w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W23</w.rf>
   <form>stupně</form>
   <lemma>stupeň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47300.txt-001-p2s2">
  <m id="m-moravskoslezsky47300.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W1</w.rf>
   <form>Nestorem</form>
   <lemma>nestor</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W2</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W3</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W4</w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>P5XP7--3-------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W6</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W7</w.rf>
   <form>technik</form>
   <lemma>technik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W8</w.rf>
   <form>operačního</form>
   <lemma>operační</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W10</w.rf>
   <form>informačního</form>
   <lemma>informační</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W11</w.rf>
   <form>střediska</form>
   <lemma>středisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W12</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W14</w.rf>
   <form>Novém</form>
   <lemma>nový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W15</w.rf>
   <form>Jičíně</form>
   <lemma>Jičín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W17</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W18</w.rf>
   <form>začal</form>
   <lemma>začít-1</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W19</w.rf>
   <form>sloužit</form>
   <lemma>sloužit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W20</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W21</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W22</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W23</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W24</w.rf>
   <form>1.11</form>
   <form_change>num_normalization</form_change>
   <lemma>1.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W26</w.rf>
   <form>1966</form>
   <lemma>1966</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p2s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p2s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47300.txt-001-p3s1">
  <m id="m-moravskoslezsky47300.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W1</w.rf>
   <form>Hejtman</form>
   <lemma>hejtman</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W2</w.rf>
   <form>Evžen</form>
   <lemma>Evžen_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W3</w.rf>
   <form>Tošenovský</form>
   <lemma>Tošenovský_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W4</w.rf>
   <form>zavzpomínal</form>
   <lemma>zavzpomínat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W6</w.rf>
   <form>Hasičském</form>
   <lemma>hasičský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W7</w.rf>
   <form>muzeu</form>
   <lemma>muzeum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W9</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8YP4---------1</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W10</w.rf>
   <form>začátky</form>
   <lemma>začátek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W11</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W12</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W13</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W14</w.rf>
   <form>lety</form>
   <lemma>rok</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W16</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W17</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W18</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W19</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W20</w.rf>
   <form>funkcí</form>
   <lemma>funkce</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W21</w.rf>
   <form>ostravského</form>
   <lemma>ostravský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W22</w.rf>
   <form>primátora</form>
   <lemma>primátor</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W23</w.rf>
   <form>začal</form>
   <lemma>začít-1</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W24</w.rf>
   <form>učit</form>
   <lemma>učit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W25</w.rf>
   <form>pojmy</form>
   <lemma>pojem_^(termín,_označení,...)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W26</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W27</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W28</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W30</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W31</w.rf>
   <form>integrovaný</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W32</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W33</w.rf>
   <form>systém</form>
   <lemma>systém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W34</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s1W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47300.txt-001-p3s2">
  <m id="m-moravskoslezsky47300.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W1</w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W3</w.rf>
   <form>přesvědčen</form>
   <lemma>přesvědčit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W5</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W6</w.rf>
   <form>hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W7</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W9</w.rf>
   <form>Moravskoslezském</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W10</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W11</w.rf>
   <form>patří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W12</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W13</w.rf>
   <form>nejlepší</form>
   <lemma>dobrý</lemma>
   <tag>AAFS4----3A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W15</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W17</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W18</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W19</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W20</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W21</w.rf>
   <form>vyrovnaná</form>
   <lemma>vyrovnaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W22</w.rf>
   <form>organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W23</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W24</w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W25</w.rf>
   <form>lepším</form>
   <lemma>dobrý</lemma>
   <tag>AANS7----2A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W26</w.rf>
   <form>technickým</form>
   <lemma>technický</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W27</w.rf>
   <form>vybavením</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W29</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W30</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W31</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W32</w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W33</w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W34</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W35</w.rf>
   <form>zlepšovat</form>
   <lemma>zlepšovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W37</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W38</w.rf>
   <form>Už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W39</w.rf>
   <form>nejenom</form>
   <lemma>nejenom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W40</w.rf>
   <form>politici</form>
   <lemma>politik</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W41</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W42</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W43</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W44</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W45</w.rf>
   <form>vědí</form>
   <lemma>vědět</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W46</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W47</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W48</w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W49</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W50</w.rf>
   <form>dělají</form>
   <lemma>dělat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W51</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W52</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W53</w.rf>
   <form>dodal</form>
   <lemma>dodat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W54</w.rf>
   <form>hejtman</form>
   <lemma>hejtman</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47300.txt-001-p3s2W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47300.txt-001-p3s2W55</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
