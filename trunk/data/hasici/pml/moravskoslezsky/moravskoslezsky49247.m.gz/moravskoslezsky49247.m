<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="moravskoslezsky49247.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-moravskoslezsky49247.txt-001-p1s1">
  <m id="m-moravskoslezsky49247.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s1W1</w.rf>
   <form>Výbuchem</form>
   <lemma>výbuch</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s1W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s1W3</w.rf>
   <form>poškozena</form>
   <lemma>poškodit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s1W4</w.rf>
   <form>střecha</form>
   <lemma>střecha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s1W5</w.rf>
   <form>kotelny</form>
   <lemma>kotelna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s1W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s1W7</w.rf>
   <form>zákotlí</form>
   <lemma>zákotlí</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p1s2">
  <m id="m-moravskoslezsky49247.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W1</w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W2</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W3</w.rf>
   <form>pracovník</form>
   <lemma>pracovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W4</w.rf>
   <form>údržby</form>
   <lemma>údržba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W6</w.rf>
   <form>kterému</form>
   <lemma>který</lemma>
   <tag>P4ZS3----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W8</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W9</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W11</w.rf>
   <form>kotelny</form>
   <lemma>kotelna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W12</w.rf>
   <form>uniknout</form>
   <lemma>uniknout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W14</w.rf>
   <form>venkovní</form>
   <lemma>venkovní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W15</w.rf>
   <form>schodiště</form>
   <lemma>schodiště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W16</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W17</w.rf>
   <form>strojovny</form>
   <lemma>strojovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W18</w.rf>
   <form>výtahu</form>
   <lemma>výtah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p1s3">
  <m id="m-moravskoslezsky49247.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W1</w.rf>
   <form>Šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W2</w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W3</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W5</w.rf>
   <form>simulaci</form>
   <lemma>simulace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W6</w.rf>
   <form>havárie</form>
   <lemma>havárie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W8</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p1s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p2s1">
  <m id="m-moravskoslezsky49247.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W2</w.rf>
   <form>prověřovacího</form>
   <lemma>prověřovací_^(*2t)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W3</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W5</w.rf>
   <form>zapojily</form>
   <lemma>zapojit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W6</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W7</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W8</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W9</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W10</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W11</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W12</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W13</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W15</w.rf>
   <form>Krnově</form>
   <lemma>Krnov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W16</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W18</w.rf>
   <form>vysokozdvižnou</form>
   <lemma>vysokozdvižný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W19</w.rf>
   <form>plošinou</form>
   <lemma>plošina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W21</w.rf>
   <form>lezecká</form>
   <lemma>lezecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W22</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W23</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W24</w.rf>
   <form>MSK</form>
   <lemma>MSK-1_:B_^(Medvěděvova-Sponheurova-Kárníkova_stupnice)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W25</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W26</w.rf>
   <form>Bruntálu</form>
   <lemma>Bruntál_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W28</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W29</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W30</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W31</w.rf>
   <form>Krnova</form>
   <lemma>Krnov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W33</w.rf>
   <form>dobrovolná</form>
   <lemma>dobrovolný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W34</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W35</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W36</w.rf>
   <form>KOS</form>
   <lemma>kosa</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W37</w.rf>
   <form>Krnov</form>
   <lemma>Krnov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W38</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W39</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W40</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W41</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W42</w.rf>
   <form>požádána</form>
   <lemma>požádat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W43</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W44</w.rf>
   <form>krnovská</form>
   <lemma>krnovský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W45</w.rf>
   <form>městská</form>
   <lemma>městský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W46</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W47</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W48</w.rf>
   <form>Zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W49</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W50</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p2s1W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p2s1W51</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p3s1">
  <m id="m-moravskoslezsky49247.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W3</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W4</w.rf>
   <form>teplárny</form>
   <lemma>teplárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W7</w.rf>
   <form>vydali</form>
   <lemma>vydat-1_:W_^(emitovat:_cenné_papíry,_knihu,_zvuk,...)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W9</w.rf>
   <form>průzkum</form>
   <lemma>průzkum</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W11</w.rf>
   <form>zároveň</form>
   <lemma>zároveň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W13</w.rf>
   <form>vyhledání</form>
   <lemma>vyhledání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W14</w.rf>
   <form>ztraceného</form>
   <lemma>ztracený_^(*4tit)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W15</w.rf>
   <form>pracovníka</form>
   <lemma>pracovník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p3s2">
  <m id="m-moravskoslezsky49247.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W1</w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W3</w.rf>
   <form>nalezen</form>
   <lemma>naleznout</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W5</w.rf>
   <form>schodišti</form>
   <lemma>schodiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W6</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W8</w.rf>
   <form>výšce</form>
   <lemma>výška</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W9</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W10</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p3s3">
  <m id="m-moravskoslezsky49247.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W2</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W3</w.rf>
   <form>automobilové</form>
   <lemma>automobilový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W4</w.rf>
   <form>plošiny</form>
   <lemma>plošina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W5</w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W6</w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W8</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W9</w.rf>
   <form>povolána</form>
   <lemma>povolat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W10</w.rf>
   <form>specializovaná</form>
   <lemma>specializovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W11</w.rf>
   <form>lezecká</form>
   <lemma>lezecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W12</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W13</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W14</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W15</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W16</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W17</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W19</w.rf>
   <form>Bruntálu</form>
   <lemma>Bruntál_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p3s4">
  <m id="m-moravskoslezsky49247.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W1</w.rf>
   <form>Zraněný</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W3</w.rf>
   <form>nakonec</form>
   <lemma>nakonec</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W4</w.rf>
   <form>spuštěn</form>
   <lemma>spustit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W6</w.rf>
   <form>zem</form>
   <lemma>země</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W8</w.rf>
   <form>evakuačním</form>
   <lemma>evakuační</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W9</w.rf>
   <form>posedu</form>
   <lemma>posed</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W12</w.rf>
   <form>předán</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W14</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W15</w.rf>
   <form>zdravotníků</form>
   <lemma>zdravotník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p3s4W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p4s1">
  <m id="m-moravskoslezsky49247.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W1</w.rf>
   <form>Mezitím</form>
   <lemma>mezitím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W2</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W3</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W4</w.rf>
   <form>hasí</form>
   <lemma>hasit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W5</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W6</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W7</w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W8</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W9</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W10</w.rf>
   <form>směrů</form>
   <lemma>směr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p4s2">
  <m id="m-moravskoslezsky49247.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W1</w.rf>
   <form>Vodu</form>
   <lemma>Voda_;G_^(součást_názvu_Odolena_Voda)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W3</w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W4</w.rf>
   <form>dopravují</form>
   <lemma>dopravovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W5</w.rf>
   <form>suchovody</form>
   <lemma>suchovod</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W6</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W7</w.rf>
   <form>pevně</form>
   <lemma>pevně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W8</w.rf>
   <form>zabudované</form>
   <lemma>zabudovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W9</w.rf>
   <form>trubky</form>
   <lemma>trubka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W11</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W13</w.rf>
   <form>určené</form>
   <lemma>určený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W15</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W16</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W17</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W18</w.rf>
   <form>požárech</form>
   <lemma>požár</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W19</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W21</w.rf>
   <form>jejichž</form>
   <lemma>jenž_^(který...[ve_vedl._větě])</lemma>
   <tag>P1XXXXP3-------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W22</w.rf>
   <form>průchodnost</form>
   <lemma>průchodnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W23</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W24</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W25</w.rf>
   <form>prověřovalo</form>
   <lemma>prověřovat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p4s3">
  <m id="m-moravskoslezsky49247.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s3W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s3W2</w.rf>
   <form>půlhodině</form>
   <lemma>půlhodina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s3W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s3W4</w.rf>
   <form>střecha</form>
   <lemma>střecha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s3W5</w.rf>
   <form>uhašena</form>
   <lemma>uhasit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p4s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p5s1">
  <m id="m-moravskoslezsky49247.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W1</w.rf>
   <form>Zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W2</w.rf>
   <form>dvouhodinové</form>
   <lemma>dvouhodinový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W3</w.rf>
   <form>prověřovací</form>
   <lemma>prověřovací_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W4</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W5</w.rf>
   <form>vyhodnotil</form>
   <lemma>vyhodnotit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W6</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W7</w.rf>
   <form>územního</form>
   <lemma>územní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W8</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W10</w.rf>
   <form>MSK</form>
   <lemma>MSK-1_:B_^(Medvěděvova-Sponheurova-Kárníkova_stupnice)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W12</w.rf>
   <form>Bruntálu</form>
   <lemma>Bruntál_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W13</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W14</w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W15</w.rf>
   <form>Patrovský</form>
   <lemma>Patrovský_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W16</w.rf>
   <form>společně</form>
   <lemma>společně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W17</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W18</w.rf>
   <form>zástupci</form>
   <lemma>zástupce</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W19</w.rf>
   <form>krnovské</form>
   <lemma>krnovský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W20</w.rf>
   <form>teplárny</form>
   <lemma>teplárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49247.txt-001-p5s2">
  <m id="m-moravskoslezsky49247.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W1</w.rf>
   <form>Vytknuty</form>
   <lemma>vytknout_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W2</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W3</w.rf>
   <form>drobné</form>
   <lemma>drobný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W4</w.rf>
   <form>chyby</form>
   <lemma>chyba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W5</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W6</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W8</w.rf>
   <form>probírala</form>
   <lemma>probírat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W10</w.rf>
   <form>spolupráce</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W11</w.rf>
   <form>záchranářů</form>
   <lemma>záchranář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W13</w.rf>
   <form>pracovníky</form>
   <lemma>pracovník</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W14</w.rf>
   <form>teplárny</form>
   <lemma>teplárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49247.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49247.txt-001-p5s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
