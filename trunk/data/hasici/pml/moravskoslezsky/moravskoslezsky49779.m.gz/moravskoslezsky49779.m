<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="moravskoslezsky49779.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-moravskoslezsky49779.txt-001-p1s1">
  <m id="m-moravskoslezsky49779.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W1</w.rf>
   <form>Půjde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W3</w.rf>
   <form>společný</form>
   <lemma>společný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W4</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W6</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W8</w.rf>
   <form>sklepním</form>
   <lemma>sklepní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W9</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W11</w.rf>
   <form>domově</form>
   <lemma>domov</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W12</w.rf>
   <form>Konventu</form>
   <lemma>konvent</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W13</w.rf>
   <form>sester</form>
   <lemma>sestra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W14</w.rf>
   <form>Alžbětinek</form>
   <lemma>Alžbětinka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W16</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W17</w.rf>
   <form>žijí</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W18</w.rf>
   <form>především</form>
   <lemma>především</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W19</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W20</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W21</w.rf>
   <form>omezeným</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W22</w.rf>
   <form>pohybem</form>
   <lemma>pohyb</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p1s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p2s1">
  <m id="m-moravskoslezsky49779.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W4</w.rf>
   <form>zapojí</form>
   <lemma>zapojit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W5</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W6</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W7</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W8</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W9</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W10</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W12</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W15</w.rf>
   <form>Městská</form>
   <lemma>městský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W16</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W17</w.rf>
   <form>Jablunkov</form>
   <lemma>Jablunkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W19</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W20</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W22</w.rf>
   <form>Zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W23</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W24</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W26</w.rf>
   <form>krizový</form>
   <lemma>krizový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W27</w.rf>
   <form>štáb</form>
   <lemma>štáb</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W28</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W29</w.rf>
   <form>Jablunkova</form>
   <lemma>Jablunkov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p2s2">
  <m id="m-moravskoslezsky49779.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W1</w.rf>
   <form>Předpokládané</form>
   <lemma>předpokládaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W2</w.rf>
   <form>zahájení</form>
   <lemma>zahájení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W3</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W4</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W6</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W7</w.rf>
   <form>dopoledne</form>
   <lemma>dopoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W8</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W9</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W10</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W11</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W12</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W14</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W15</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W16</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W17</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W19</w.rf>
   <form>trvat</form>
   <lemma>trvat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W20</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W21</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W22</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W23</w.rf>
   <form>hodiny</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p2s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p3s1">
  <m id="m-moravskoslezsky49779.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W1</w.rf>
   <form>Cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W4</w.rf>
   <form>seznámení</form>
   <lemma>seznámení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W5</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W6</w.rf>
   <form>problematikou</form>
   <lemma>problematika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W7</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W9</w.rf>
   <form>zdravotnickém</form>
   <lemma>zdravotnický</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W10</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W12</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W13</w.rf>
   <form>slouží</form>
   <lemma>sloužit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W14</w.rf>
   <form>lidem</form>
   <lemma>člověk</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W16</w.rf>
   <form>omezeným</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W17</w.rf>
   <form>pohybem</form>
   <lemma>pohyb</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W20</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W21</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W22</w.rf>
   <form>ztížených</form>
   <lemma>ztížený_,s_^(*3it)</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W23</w.rf>
   <form>podmínkách</form>
   <lemma>podmínka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W25</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W26</w.rf>
   <form>tmy</form>
   <lemma>tma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W27</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W29</w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W30</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W32</w.rf>
   <form>silného</form>
   <lemma>silný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W33</w.rf>
   <form>zakouření</form>
   <lemma>zakouření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W34</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W35</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W36</w.rf>
   <form>členité</form>
   <lemma>členitý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W37</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W38</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W39</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W40</w.rf>
   <form>omezeném</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W41</w.rf>
   <form>počtu</form>
   <lemma>počet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W42</w.rf>
   <form>záchranářů</form>
   <lemma>záchranář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W43</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W44</w.rf>
   <form>personálu</form>
   <lemma>personál</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W45</w.rf>
   <form>domova</form>
   <lemma>domov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s1W46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p3s2">
  <m id="m-moravskoslezsky49779.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W1</w.rf>
   <form>Budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W3</w.rf>
   <form>mj.</form>
   <lemma>mj-1_:B_,x_^(mimo_jiné)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W4</w.rf>
   <form>kontrolovat</form>
   <lemma>kontrolovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W5</w.rf>
   <form>dojezdové</form>
   <lemma>dojezdový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W6</w.rf>
   <form>časy</form>
   <lemma>čas</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W7</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W9</w.rf>
   <form>spojení</form>
   <lemma>spojení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W11</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W12</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W13</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W14</w.rf>
   <form>složkami</form>
   <lemma>složka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W15</w.rf>
   <form>IZS</form>
   <lemma>IZS</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p3s3">
  <m id="m-moravskoslezsky49779.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W1</w.rf>
   <form>Prověří</form>
   <lemma>prověřit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W4</w.rf>
   <form>připravenost</form>
   <lemma>připravenost_^(*5it)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W5</w.rf>
   <form>orgánů</form>
   <lemma>orgán</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W6</w.rf>
   <form>krizového</form>
   <lemma>krizový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W7</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W9</w.rf>
   <form>Jablunkově</form>
   <lemma>Jablunkov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p3s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p4s1">
  <m id="m-moravskoslezsky49779.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W4</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W6</w.rf>
   <form>sušárně</form>
   <lemma>sušárna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W8</w.rf>
   <form>prádelně</form>
   <lemma>prádelna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W9</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W10</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W11</w.rf>
   <form>evakuováno</form>
   <lemma>evakuovat_:T_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W12</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W13</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W14</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W15</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W16</w.rf>
   <form>figuranti</form>
   <lemma>figurant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W17</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W18</w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W19</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W20</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W21</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W22</w.rf>
   <form>Frýdku-Místku</form>
   <lemma>Frýdku-Místek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W24</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W25</w.rf>
   <form>dobrovolníci</form>
   <lemma>dobrovolník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W27</w.rf>
   <form>vyvedením</form>
   <lemma>vyvedení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W29</w.rf>
   <form>vyproštěním</form>
   <lemma>vyproštění_^(*5stit)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W31</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W32</w.rf>
   <form>vynesením</form>
   <lemma>vynesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W33</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W34</w.rf>
   <form>poskytnutím</form>
   <lemma>poskytnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W35</w.rf>
   <form>předlékařské</form>
   <lemma>předlékařský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W36</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W37</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W38</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W39</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W40</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W41</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W42</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W43</w.rf>
   <form>personálem</form>
   <lemma>personál</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W44</w.rf>
   <form>domova</form>
   <lemma>domov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p4s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p4s1W45</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p5s1">
  <m id="m-moravskoslezsky49779.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W1</w.rf>
   <form>Novinářům</form>
   <lemma>novinář</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W2</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W4</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W5</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W6</w.rf>
   <form>domluvě</form>
   <lemma>domluva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W8</w.rf>
   <form>příslušníky</form>
   <lemma>příslušník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W10</w.rf>
   <form>MSK</form>
   <lemma>MSK-1_:B_^(Medvěděvova-Sponheurova-Kárníkova_stupnice)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W11</w.rf>
   <form>vyhrazeno</form>
   <lemma>vyhradit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W12</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W14</w.rf>
   <form>odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W15</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W16</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W17</w.rf>
   <form>sledovat</form>
   <lemma>sledovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W19</w.rf>
   <form>fotit</form>
   <lemma>fotit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W21</w.rf>
   <form>točit</form>
   <lemma>točit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p5s2">
  <m id="m-moravskoslezsky49779.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W1</w.rf>
   <form>Parkování</form>
   <lemma>parkování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W2</w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W4</w.rf>
   <form>povoleno</form>
   <lemma>povolit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W5</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W6</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W7</w.rf>
   <form>areál</form>
   <lemma>areál</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W8</w.rf>
   <form>konventu</form>
   <lemma>konvent</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49779.txt-001-p5s3">
  <m id="m-moravskoslezsky49779.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W1</w.rf>
   <form>Zájemci</form>
   <lemma>zájemce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W3</w.rf>
   <form>účast</form>
   <lemma>účast</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W5</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W8</w.rf>
   <form>potvrďte</form>
   <lemma>potvrdit_:W</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W9</w.rf>
   <form>účast</form>
   <lemma>účast</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W11</w.rf>
   <form>724</form>
   <lemma>724</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W12</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W13</w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W14</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49779.txt-001-p5s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49779.txt-001-p5s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
