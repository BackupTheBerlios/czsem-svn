<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="moravskoslezsky49910.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-moravskoslezsky49910.txt-001-p1s1">
  <m id="m-moravskoslezsky49910.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W2</w.rf>
   <form>suterénu</form>
   <lemma>suterén</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W3</w.rf>
   <form>domova</form>
   <lemma>domov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W5</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W6</w.rf>
   <form>žijí</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W7</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W8</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W10</w.rf>
   <form>omezeným</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W11</w.rf>
   <form>pohybem</form>
   <lemma>pohyb</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W13</w.rf>
   <form>hořelo</form>
   <lemma>hořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W15</w.rf>
   <form>sušárně</form>
   <lemma>sušárna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W17</w.rf>
   <form>prádelně</form>
   <lemma>prádelna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p1s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p2s1">
  <m id="m-moravskoslezsky49910.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W1</w.rf>
   <form>Naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W2</w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W3</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W5</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W6</w.rf>
   <form>integrovaného</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W7</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W8</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W11</w.rf>
   <form>něhož</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9ZS2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W13</w.rf>
   <form>zapojily</form>
   <lemma>zapojit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W14</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W15</w.rf>
   <form>desítky</form>
   <lemma>desítka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W16</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W18</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W19</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W20</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W21</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W22</w.rf>
   <form>Jablunkova</form>
   <lemma>Jablunkov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W24</w.rf>
   <form>Třince</form>
   <lemma>Třinec_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W26</w.rf>
   <form>Frýdku-Místku</form>
   <lemma>Frýdku-Místc</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W28</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W29</w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>P5XP7--3-------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W30</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W31</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W32</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W33</w.rf>
   <form>Městská</form>
   <lemma>městský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W34</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W35</w.rf>
   <form>Jablunkov</form>
   <lemma>Jablunkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W37</w.rf>
   <form>Zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W38</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W39</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W40</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W41</w.rf>
   <form>pracovníci</form>
   <lemma>pracovník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W42</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W43</w.rf>
   <form>Jablunkov</form>
   <lemma>Jablunkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W44</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W45</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W46</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W47</w.rf>
   <form>radnici</form>
   <lemma>radnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W48</w.rf>
   <form>zřídili</form>
   <lemma>zřídit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W49</w.rf>
   <form>krizový</form>
   <lemma>krizový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W50</w.rf>
   <form>štáb</form>
   <lemma>štáb</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s1W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s1W51</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p2s2">
  <m id="m-moravskoslezsky49910.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W1</w.rf>
   <form>Řádové</form>
   <lemma>řádový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W2</w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W4</w.rf>
   <form>zapojily</form>
   <lemma>zapojit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W6</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W7</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W8</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W9</w.rf>
   <form>ošetřovatelky</form>
   <lemma>ošetřovatelka_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W11</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W12</w.rf>
   <form>názoru</form>
   <lemma>názor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W13</w.rf>
   <form>pozorovatelů</form>
   <lemma>pozorovatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W14</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W15</w.rf>
   <form>vedly</form>
   <lemma>vést-1</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W16</w.rf>
   <form>zdatně</form>
   <lemma>zdatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W18</w.rf>
   <form>profesionálně</form>
   <lemma>profesionálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p2s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p3s1">
  <m id="m-moravskoslezsky49910.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W1</w.rf>
   <form>Vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W2</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W3</w.rf>
   <form>premiéry</form>
   <lemma>premiéra</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W5</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W6</w.rf>
   <form>IZS</form>
   <lemma>Izs</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W8</w.rf>
   <form>Moravskoslezském</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W9</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W10</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W11</w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W12</w.rf>
   <form>použit</form>
   <lemma>použít</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W13</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W14</w.rf>
   <form>neobvyklý</form>
   <lemma>obvyklý</lemma>
   <tag>AAIS1----1N----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W15</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W16</w.rf>
   <form>technický</form>
   <lemma>technický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W17</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W18</w.rf>
   <form>prostředek</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W19</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W22</w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W23</w.rf>
   <form>lepší</form>
   <lemma>dobrý</lemma>
   <tag>AAFS3----2A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W24</w.rf>
   <form>simulaci</form>
   <lemma>simulace</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W25</w.rf>
   <form>pohybu</form>
   <lemma>pohyb</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W26</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W28</w.rf>
   <form>dýchacích</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W29</w.rf>
   <form>přístrojích</form>
   <lemma>přístroj</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W30</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W31</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W32</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W33</w.rf>
   <form>tmě</form>
   <lemma>tma</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W34</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W35</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W36</w.rf>
   <form>silného</form>
   <lemma>silný</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W37</w.rf>
   <form>zakouření</form>
   <lemma>zakouření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W38</w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W39</w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W40</w.rf>
   <form>záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W41</w.rf>
   <form>přelepena</form>
   <lemma>přelepit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W42</w.rf>
   <form>skla</form>
   <lemma>sklo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W43</w.rf>
   <form>mikrotenovou</form>
   <lemma>mikrotenový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W44</w.rf>
   <form>fólií</form>
   <lemma>fólie</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s1W45</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p3s2">
  <m id="m-moravskoslezsky49910.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W1</w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W3</w.rf>
   <form>pohybů</form>
   <lemma>pohyb</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W4</w.rf>
   <form>cvičících</form>
   <lemma>cvičící_^(*3it)</lemma>
   <tag>AGNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W5</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W6</w.rf>
   <form>zjevné</form>
   <lemma>zjevný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W8</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W9</w.rf>
   <form>fólie</form>
   <lemma>fólie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W10</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W11</w.rf>
   <form>zhoršené</form>
   <lemma>zhoršený_^(*3it)</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W12</w.rf>
   <form>viditelnost</form>
   <lemma>viditelnost_^(*8ět)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W13</w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W14</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W15</w.rf>
   <form>pomohla</form>
   <lemma>pomoci</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W16</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p3s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p4s1">
  <m id="m-moravskoslezsky49910.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W1</w.rf>
   <form>Cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W4</w.rf>
   <form>seznámit</form>
   <lemma>seznámit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W7</w.rf>
   <form>problematikou</form>
   <lemma>problematika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W8</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W9</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W10</w.rf>
   <form>zdravotnickém</form>
   <lemma>zdravotnický</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W11</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W13</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W14</w.rf>
   <form>slouží</form>
   <lemma>sloužit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W15</w.rf>
   <form>lidem</form>
   <lemma>člověk</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W16</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W17</w.rf>
   <form>omezeným</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W18</w.rf>
   <form>pohybem</form>
   <lemma>pohyb</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W21</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W22</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W23</w.rf>
   <form>ztížených</form>
   <lemma>ztížený_,s_^(*3it)</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W24</w.rf>
   <form>podmínkách</form>
   <lemma>podmínka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W27</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W28</w.rf>
   <form>tmě</form>
   <lemma>tma</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W30</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W31</w.rf>
   <form>kouři</form>
   <lemma>kouř</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W33</w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W34</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W35</w.rf>
   <form>členité</form>
   <lemma>členitý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W36</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W37</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W38</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W39</w.rf>
   <form>omezeném</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W40</w.rf>
   <form>počtu</form>
   <lemma>počet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W41</w.rf>
   <form>záchranářů</form>
   <lemma>záchranář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W42</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W43</w.rf>
   <form>personálu</form>
   <lemma>personál</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W44</w.rf>
   <form>domova</form>
   <lemma>domov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W45</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W46</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W47</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W48</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W49</w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p4s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p4s1W50</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p5s1">
  <m id="m-moravskoslezsky49910.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W2</w.rf>
   <form>Noční</form>
   <lemma>noční</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W3</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W4</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W5</w.rf>
   <form>začal</form>
   <lemma>začít-1</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W6</w.rf>
   <form>průzkumem</form>
   <lemma>průzkum</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W7</w.rf>
   <form>hlavním</form>
   <lemma>hlavní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W8</w.rf>
   <form>vchodem</form>
   <lemma>vchod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W10</w.rf>
   <form>roztažením</form>
   <lemma>roztažení_^(*5áhnout)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W11</w.rf>
   <form>hadic</form>
   <lemma>hadice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W12</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W13</w.rf>
   <form>sklepení</form>
   <lemma>sklepení</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W15</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W16</w.rf>
   <form>hořelo</form>
   <lemma>hořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W18</w.rf>
   <form>sušárně</form>
   <lemma>sušárna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W20</w.rf>
   <form>prádelně</form>
   <lemma>prádelna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p5s2">
  <m id="m-moravskoslezsky49910.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W1</w.rf>
   <form>Jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W2</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrMP1----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W3</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W5</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W6</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W9</w.rf>
   <form>Jablunkova</form>
   <lemma>Jablunkov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W11</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W12</w.rf>
   <form>chvíli</form>
   <lemma>chvíle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W13</w.rf>
   <form>dojely</form>
   <lemma>dojet</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W14</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W15</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W16</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W17</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W18</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W19</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W20</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W21</w.rf>
   <form>mobilní</form>
   <lemma>mobilní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W22</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W23</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p5s3">
  <m id="m-moravskoslezsky49910.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W2</w.rf>
   <form>objevili</form>
   <lemma>objevit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W3</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFP4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W4</w.rf>
   <form>ležící</form>
   <lemma>ležící_^(*3et)</lemma>
   <tag>AGFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W5</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W6</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W7</w.rf>
   <form>figuranty</form>
   <lemma>figurant</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W9</w.rf>
   <form>učiliště</form>
   <lemma>učiliště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W10</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W11</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W13</w.rf>
   <form>Frýdku-Místku</form>
   <lemma>Frýdku-Místku</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W14</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W15</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W16</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W17</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W19</w.rf>
   <form>pokojích</form>
   <lemma>pokoj</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W20</w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W21</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W22</w.rf>
   <form>pater</form>
   <lemma>patero</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W23</w.rf>
   <form>domova</form>
   <lemma>domov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W25</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W26</w.rf>
   <form>řádových</form>
   <lemma>řádový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W27</w.rf>
   <form>sester</form>
   <lemma>sestra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s3W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p5s4">
  <m id="m-moravskoslezsky49910.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W2</w.rf>
   <form>charakteru</form>
   <lemma>charakter</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W3</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W5</w.rf>
   <form>schopnosti</form>
   <lemma>schopnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W6</w.rf>
   <form>pohybu</form>
   <lemma>pohyb</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W7</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W8</w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W9</w.rf>
   <form>vyvedli</form>
   <lemma>vyvést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W11</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W12</w.rf>
   <form>vynesli</form>
   <lemma>vynést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W13</w.rf>
   <form>ven</form>
   <lemma>ven</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p5s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p5s4W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p6s1">
  <m id="m-moravskoslezsky49910.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W2</w.rf>
   <form>dvoře</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W3</w.rf>
   <form>Konventu</form>
   <lemma>konvent</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W4</w.rf>
   <form>poskytli</form>
   <lemma>poskytnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W6</w.rf>
   <form>zachráněným</form>
   <lemma>zachráněný_^(*3it)</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W7</w.rf>
   <form>obyvatelům</form>
   <lemma>obyvatel</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W8</w.rf>
   <form>domova</form>
   <lemma>domov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W9</w.rf>
   <form>předlékařskou</form>
   <lemma>předlékařský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W10</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W12</w.rf>
   <form>uložili</form>
   <lemma>uložit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W13</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W14</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W15</w.rf>
   <form>stabilizované</form>
   <lemma>stabilizovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W16</w.rf>
   <form>polohy</form>
   <lemma>poloha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p6s2">
  <m id="m-moravskoslezsky49910.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W2</w.rf>
   <form>Zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W3</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W4</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W5</w.rf>
   <form>nemohla</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W6</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W7</w.rf>
   <form>přijet</form>
   <lemma>přijet-1_^(např._autem)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W8</w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W9</w.rf>
   <form>jiným</form>
   <lemma>jiný</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W10</w.rf>
   <form>zásahům</form>
   <lemma>zásah</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W12</w.rf>
   <form>sanitka</form>
   <lemma>sanitka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W13</w.rf>
   <form>dojela</form>
   <lemma>dojet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W14</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W15</w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W16</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W19</w.rf>
   <form>ošetřování</form>
   <lemma>ošetřování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W20</w.rf>
   <form>zraněných</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W21</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W22</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W23</w.rf>
   <form>zapojily</form>
   <lemma>zapojit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W24</w.rf>
   <form>řádové</form>
   <lemma>řádový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W25</w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p6s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p7s1">
  <m id="m-moravskoslezsky49910.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W1</w.rf>
   <form>Závěr</form>
   <lemma>závěr_^(př._z_jednání,_úvah)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W4</w.rf>
   <form>konventu</form>
   <lemma>konvent</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W5</w.rf>
   <form>sledovali</form>
   <lemma>sledovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W6</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W7</w.rf>
   <form>zástupci</form>
   <lemma>zástupce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W8</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W9</w.rf>
   <form>Jablunkov</form>
   <lemma>Jablunkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p7s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p8s1">
  <m id="m-moravskoslezsky49910.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W1</w.rf>
   <form>Cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W3</w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W4</w.rf>
   <form>domovech</form>
   <lemma>domov</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W6</w.rf>
   <form>Moravskoslezkém</form>
   <lemma>Moravskoslezký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W7</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W8</w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W9</w.rf>
   <form>zbytečné</form>
   <lemma>zbytečný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p8s2">
  <m id="m-moravskoslezsky49910.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W1</w.rf>
   <form>Například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W2</w.rf>
   <form>zkraje</form>
   <lemma>zkraje-2_,s</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W3</w.rf>
   <form>loňského</form>
   <lemma>loňský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W4</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W6</w.rf>
   <form>konalo</form>
   <lemma>konat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W7</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W9</w.rf>
   <form>domově</form>
   <lemma>domov</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W10</w.rf>
   <form>důchodců</form>
   <lemma>důchodce</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W12</w.rf>
   <form>Krnově</form>
   <lemma>Krnov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W14</w.rf>
   <form>Rooseveltově</form>
   <lemma>Rooseveltův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W15</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p8s3">
  <m id="m-moravskoslezsky49910.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W2</w.rf>
   <form>konci</form>
   <lemma>konec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W3</w.rf>
   <form>října</form>
   <lemma>říjen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W4</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W5</w.rf>
   <form>tu</form>
   <lemma>tady</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W6</w.rf>
   <form>doopravdy</form>
   <lemma>doopravdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W7</w.rf>
   <form>hořelo</form>
   <lemma>hořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W9</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W10</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W11</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W12</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W13</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W14</w.rf>
   <form>zářivka</form>
   <lemma>zářivka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p8s4">
  <m id="m-moravskoslezsky49910.txt-001-p8s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W2</w.rf>
   <form>chodeb</form>
   <lemma>chodba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W3</w.rf>
   <form>domova</form>
   <lemma>domov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W5</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W6</w.rf>
   <form>dostaly</form>
   <lemma>dostat</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W7</w.rf>
   <form>zplodiny</form>
   <lemma>zplodina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W8</w.rf>
   <form>hoření</form>
   <lemma>hoření_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky49910.txt-001-p8s5">
  <m id="m-moravskoslezsky49910.txt-001-p8s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W1</w.rf>
   <form>Sedm</form>
   <lemma>sedm`7</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W2</w.rf>
   <form>desítek</form>
   <lemma>desítka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W3</w.rf>
   <form>obyvatel</form>
   <lemma>obyvatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W4</w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W5</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W6</w.rf>
   <form>evakuováno</form>
   <lemma>evakuovat_:T_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W8</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W9</w.rf>
   <form>pokojů</form>
   <lemma>pokoj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W11</w.rf>
   <form>jídelny</form>
   <lemma>jídelna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W13</w.rf>
   <form>kinosálu</form>
   <lemma>kinosál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W15</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W16</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W17</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W18</w.rf>
   <form>nadýchali</form>
   <lemma>nadýchat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W19</w.rf>
   <form>kouře</form>
   <lemma>kouř</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W21</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W23</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W24</w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W25</w.rf>
   <form>odvézt</form>
   <lemma>odvézt</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W26</w.rf>
   <form>sanitka</form>
   <lemma>sanitka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W27</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W28</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky49910.txt-001-p8s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky49910.txt-001-p8s5W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
