<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="moravskoslezsky48327.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-moravskoslezsky48327.txt-001-p1s1">
  <m id="m-moravskoslezsky48327.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W1</w.rf>
   <form>Vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W2</w.rf>
   <form>přitom</form>
   <lemma>přitom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W3</w.rf>
   <form>narazila</form>
   <lemma>narazit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W5</w.rf>
   <form>pilotu</form>
   <lemma>pilot</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W6</w.rf>
   <form>železničního</form>
   <lemma>železniční</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W7</w.rf>
   <form>mostu</form>
   <lemma>most</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W9</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W12</w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>P5XP4--3-------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W13</w.rf>
   <form>zřítil</form>
   <lemma>zřítit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p1s2">
  <m id="m-moravskoslezsky48327.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W2</w.rf>
   <form>osobním</form>
   <lemma>osobní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W3</w.rf>
   <form>autě</form>
   <lemma>auto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W4</w.rf>
   <form>uvěznil</form>
   <lemma>uvěznit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W5</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W8</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W10</w.rf>
   <form>Avii</form>
   <lemma>Avia-1_;K</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W11</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W12</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W13</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W14</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p1s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p2s1">
  <m id="m-moravskoslezsky48327.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W1</w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W3</w.rf>
   <form>scénář</form>
   <lemma>scénář</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W4</w.rf>
   <form>simulované</form>
   <lemma>simulovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W5</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W7</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W8</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W9</w.rf>
   <form>zasahovaly</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W10</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W11</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W12</w.rf>
   <form>dopoledne</form>
   <lemma>dopoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W14</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W15</w.rf>
   <form>Libros</form>
   <lemma>Libros</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W16</w.rf>
   <form>složky</form>
   <lemma>složka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W17</w.rf>
   <form>integrovaného</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W18</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W19</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W22</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W23</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W24</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W25</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W26</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W27</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W28</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W29</w.rf>
   <form>stanic</form>
   <lemma>stanice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W30</w.rf>
   <form>Ostrava-Fifejdy</form>
   <lemma>Ostrava-Fifejda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W31</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W32</w.rf>
   <form>Ostrava-Zábřeh</form>
   <lemma>Ostrava-Zábřeh</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s1W33</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p2s2">
  <m id="m-moravskoslezsky48327.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s2W1</w.rf>
   <form>Hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s2W2</w.rf>
   <form>báňská</form>
   <lemma>báňský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s2W3</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s2W4</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s2W6</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s2W7</w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s2W8</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p2s3">
  <m id="m-moravskoslezsky48327.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s3W1</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s3W2</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s3W3</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p2s4">
  <m id="m-moravskoslezsky48327.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s4W1</w.rf>
   <form>Městská</form>
   <lemma>městský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s4W2</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s4W3</w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s4W4</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p2s5">
  <m id="m-moravskoslezsky48327.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s5W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s5W2</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s5W3</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s5W4</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s5W5</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s5W6</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s5W7</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p2s6">
  <m id="m-moravskoslezsky48327.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W1</w.rf>
   <form>Armáda</form>
   <lemma>armáda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W2</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W3</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W5</w.rf>
   <form>157</form>
   <lemma>157</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W7</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W8</w.rf>
   <form>prapor</form>
   <lemma>prapor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W10</w.rf>
   <form>Hlučína</form>
   <lemma>Hlučín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p2s6W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p3s1">
  <m id="m-moravskoslezsky48327.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W1</w.rf>
   <form>Pád</form>
   <lemma>pád</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W2</w.rf>
   <form>těžkého</form>
   <lemma>těžký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W3</w.rf>
   <form>panelu</form>
   <lemma>panel</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W4</w.rf>
   <form>nepřežil</form>
   <lemma>přežít</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W5</w.rf>
   <form>řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W6</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W7</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W10</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W12</w.rf>
   <form>přimáčknut</form>
   <lemma>přimáčknout_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W13</w.rf>
   <form>zbytky</form>
   <lemma>zbytek</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W14</w.rf>
   <form>železničního</form>
   <lemma>železniční</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W15</w.rf>
   <form>mostu</form>
   <lemma>most</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W17</w.rf>
   <form>kolejemi</form>
   <lemma>kolej</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W19</w.rf>
   <form>těžce</form>
   <lemma>těžce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W20</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W21</w.rf>
   <form>řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W23</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W24</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W25</w.rf>
   <form>nejbližší</form>
   <lemma>blízký</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W26</w.rf>
   <form>spolujezdec</form>
   <lemma>spolujezdec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p3s2">
  <m id="m-moravskoslezsky48327.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s2W1</w.rf>
   <form>Naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s2W2</w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s2W3</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s2W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s2W5</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s2W6</w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s2W7</w.rf>
   <form>figuríny</form>
   <lemma>figurína</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p3s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p4s1">
  <m id="m-moravskoslezsky48327.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W1</w.rf>
   <form>Dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W2</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W3</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W4</w.rf>
   <form>živých</form>
   <lemma>živý</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W5</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W6</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W7</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W9</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W11</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W13</w.rf>
   <form>Avii</form>
   <lemma>Avia-1_;K</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W14</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W15</w.rf>
   <form>zraněno</form>
   <lemma>zranit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W16</w.rf>
   <form>lehce</form>
   <lemma>lehce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p4s2">
  <m id="m-moravskoslezsky48327.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W1</w.rf>
   <form>Úlohu</form>
   <lemma>úloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W2</w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W3</w.rf>
   <form>cestujících</form>
   <lemma>cestující_^(*5ovat)</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W4</w.rf>
   <form>splnili</form>
   <lemma>splnit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W5</w.rf>
   <form>dočasní</form>
   <lemma>dočasný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W6</w.rf>
   <form>figuranti</form>
   <lemma>figurant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W8</w.rf>
   <form>odborného</form>
   <lemma>odborný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W9</w.rf>
   <form>učiliště</form>
   <lemma>učiliště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W10</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W11</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W13</w.rf>
   <form>Frýdku-Místku</form>
   <lemma>Frýdku-Místek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W15</w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W17</w.rf>
   <form>Hlučína</form>
   <lemma>Hlučín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W19</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W20</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W21</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W22</w.rf>
   <form>vyprošťovat</form>
   <lemma>vyprošťovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W23</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W24</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W25</w.rf>
   <form>hydraulického</form>
   <lemma>hydraulický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W26</w.rf>
   <form>vyprošťovacího</form>
   <lemma>vyprošťovací_^(*2t)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W27</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W29</w.rf>
   <form>žebříků</form>
   <lemma>žebřík</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W30</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W31</w.rf>
   <form>nosítek</form>
   <lemma>nosítka</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W32</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W33</w.rf>
   <form>dalšího</form>
   <lemma>další</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W34</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W35</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W36</w.rf>
   <form>otvorů</form>
   <lemma>otvor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W37</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W38</w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W39</w.rf>
   <form>stranách</form>
   <lemma>strana-1_^(v_prostoru)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W40</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s2W41</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p4s3">
  <m id="m-moravskoslezsky48327.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W2</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W3</w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W5</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W6</w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W7</w.rf>
   <form>přimáčknutému</form>
   <lemma>přimáčknutý_^(*3out)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W8</w.rf>
   <form>stropu</form>
   <lemma>strop</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W9</w.rf>
   <form>doslova</form>
   <lemma>doslova</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W10</w.rf>
   <form>plazit</form>
   <lemma>plazit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W12</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W13</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W14</w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W15</w.rf>
   <form>cestující</form>
   <lemma>cestující_^(*5ovat)</lemma>
   <tag>AGIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p4s4">
  <m id="m-moravskoslezsky48327.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W1</w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W2</w.rf>
   <form>zraněné</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W3</w.rf>
   <form>předávali</form>
   <lemma>předávat-1_:T_,a_^(příst)_(*6at-1)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W4</w.rf>
   <form>týmům</form>
   <lemma>tým</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W5</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W7</w.rf>
   <form>báňské</form>
   <lemma>báňský</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W8</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W9</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p4s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p5s1">
  <m id="m-moravskoslezsky48327.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W2</w.rf>
   <form>záchraně</form>
   <lemma>záchrana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W3</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W5</w.rf>
   <form>podíleli</form>
   <lemma>podílet_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W6</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W7</w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W9</w.rf>
   <form>Hlučína</form>
   <lemma>Hlučín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W11</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W12</w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W13</w.rf>
   <form>přijeli</form>
   <lemma>přijet-1_^(např._autem)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W15</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W16</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W17</w.rf>
   <form>jeřábem</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p5s2">
  <m id="m-moravskoslezsky48327.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W1</w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W2</w.rf>
   <form>postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W3</w.rf>
   <form>odklízeli</form>
   <lemma>odklízet_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W4</w.rf>
   <form>trosky</form>
   <lemma>troska</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W5</w.rf>
   <form>mostu</form>
   <lemma>most</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W7</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W10</w.rf>
   <form>mohli</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W11</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W13</w.rf>
   <form>raněným</form>
   <lemma>raněný_^(poranit)_(*3it)</lemma>
   <tag>AANP3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W14</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W15</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W16</w.rf>
   <form>tělu</form>
   <lemma>tělo</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W17</w.rf>
   <form>mrtvého</form>
   <lemma>mrtvý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W18</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W19</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W20</w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p5s3">
  <m id="m-moravskoslezsky48327.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W1</w.rf>
   <form>Bánští</form>
   <lemma>bánský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W2</w.rf>
   <form>záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W3</w.rf>
   <form>zase</form>
   <lemma>zase</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W4</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W5</w.rf>
   <form>koleje</form>
   <lemma>kolej</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W6</w.rf>
   <form>hydraulickými</form>
   <lemma>hydraulický</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W7</w.rf>
   <form>vzpěrami</form>
   <lemma>vzpěra</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W8</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W9</w.rf>
   <form>dalším</form>
   <lemma>další</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W10</w.rf>
   <form>možným</form>
   <lemma>možný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W11</w.rf>
   <form>pádem</form>
   <lemma>pád</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p5s4">
  <m id="m-moravskoslezsky48327.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W1</w.rf>
   <form>Obě</form>
   <lemma>oba`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W2</w.rf>
   <form>policejní</form>
   <lemma>policejní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W3</w.rf>
   <form>složky</form>
   <lemma>složka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W5</w.rf>
   <form>staraly</form>
   <lemma>starat_^(se)</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W7</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W8</w.rf>
   <form>dopravy</form>
   <lemma>doprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W9</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W10</w.rf>
   <form>pohybu</form>
   <lemma>pohyb</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W11</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W13</w.rf>
   <form>bezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W14</w.rf>
   <form>vzdálenosti</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W15</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W16</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W18</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W19</w.rf>
   <form>zjišťování</form>
   <lemma>zjišťování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W20</w.rf>
   <form>totožnosti</form>
   <lemma>totožnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W21</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s4W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p5s5">
  <m id="m-moravskoslezsky48327.txt-001-p5s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s5W1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s5W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s5W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s5W4</w.rf>
   <form>pohyboval</form>
   <lemma>pohybovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s5W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s5W6</w.rf>
   <form>přivolaný</form>
   <lemma>přivolaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s5W7</w.rf>
   <form>statik</form>
   <lemma>statik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p5s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p5s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p6s1">
  <m id="m-moravskoslezsky48327.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W2</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W3</w.rf>
   <form>záchranných</form>
   <lemma>záchranný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W4</w.rf>
   <form>prací</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W5</w.rf>
   <form>spolupracoval</form>
   <lemma>spolupracovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W7</w.rf>
   <form>velitelem</form>
   <lemma>velitel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W8</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W9</w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W11</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W12</w.rf>
   <form>tým</form>
   <lemma>tým</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W13</w.rf>
   <form>mobilního</form>
   <lemma>mobilní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W14</w.rf>
   <form>operačního</form>
   <lemma>operační</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W15</w.rf>
   <form>střediska</form>
   <lemma>středisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W17</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W18</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W19</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W20</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W21</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W22</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W23</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W24</w.rf>
   <form>jediný</form>
   <lemma>jediný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W25</w.rf>
   <form>hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W26</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W28</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p6s2">
  <m id="m-moravskoslezsky48327.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W1</w.rf>
   <form>Umožňuje</form>
   <lemma>umožňovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W2</w.rf>
   <form>bezproblémovou</form>
   <lemma>bezproblémový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W3</w.rf>
   <form>koordinaci</form>
   <lemma>koordinace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W4</w.rf>
   <form>prací</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W6</w.rf>
   <form>přivolávání</form>
   <lemma>přivolávání_^(*5at)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W7</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W8</w.rf>
   <form>záchranářů</form>
   <lemma>záchranář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W10</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W11</w.rf>
   <form>přímým</form>
   <lemma>přímý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W12</w.rf>
   <form>kontaktem</form>
   <lemma>kontakt</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W13</w.rf>
   <form>operačních</form>
   <lemma>operační</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W14</w.rf>
   <form>pracovníků</form>
   <lemma>pracovník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W16</w.rf>
   <form>velitele</form>
   <lemma>velitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W17</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W19</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W20</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W21</w.rf>
   <form>zpravila</form>
   <lemma>zpravit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W22</w.rf>
   <form>jednodušší</form>
   <lemma>jednoduchý</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W23</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W24</w.rf>
   <form>dorozumívání</form>
   <lemma>dorozumívání-1_^(sdělovat_si,_komunikovat)_(*5at-1)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W25</w.rf>
   <form>vysílačkou</form>
   <lemma>vysílačka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p6s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p7s1">
  <m id="m-moravskoslezsky48327.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W1</w.rf>
   <form>Účelem</form>
   <lemma>účel</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W2</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W3</w.rf>
   <form>hodinu</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W5</w.rf>
   <form>půl</form>
   <lemma>půl-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W6</w.rf>
   <form>trvajícího</form>
   <lemma>trvající_^(*4t)</lemma>
   <tag>AGNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W7</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W9</w.rf>
   <form>doprovázeného</form>
   <lemma>doprovázený_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W10</w.rf>
   <form>komentářem</form>
   <lemma>komentář</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W12</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W13</w.rf>
   <form>ověřit</form>
   <lemma>ověřit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W14</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W15</w.rf>
   <form>složek</form>
   <lemma>složka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W16</w.rf>
   <form>IZS</form>
   <lemma>Izs</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W17</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W18</w.rf>
   <form>společném</form>
   <lemma>společný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W19</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W20</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W21</w.rf>
   <form>záchranných</form>
   <lemma>záchranný</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W23</w.rf>
   <form>likvidačních</form>
   <lemma>likvidační</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W24</w.rf>
   <form>pracích</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W25</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W26</w.rf>
   <form>velením</form>
   <lemma>velení_^(*2t)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W27</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W28</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W30</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W31</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W32</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W33</w.rf>
   <form>vedoucího</form>
   <lemma>vedoucí-1_^(*8ést-1)</lemma>
   <tag>AGNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W34</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W35</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W36</w.rf>
   <form>pozorovatelů</form>
   <lemma>pozorovatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W37</w.rf>
   <form>povedlo</form>
   <lemma>povést</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s1W38</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p7s2">
  <m id="m-moravskoslezsky48327.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W1</w.rf>
   <form>Neocenitelné</form>
   <lemma>ocenitelný_^(*4)</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W2</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W3</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W5</w.rf>
   <form>ostré</form>
   <lemma>ostrý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W6</w.rf>
   <form>zásahy</form>
   <lemma>zásah</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W7</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W8</w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W9</w.rf>
   <form>poznání</form>
   <lemma>poznání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W10</w.rf>
   <form>stylu</form>
   <lemma>styl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W11</w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W12</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W13</w.rf>
   <form>spřízněných</form>
   <lemma>spřízněný_^(*3it)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W14</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W15</w.rf>
   <form>subjektů</form>
   <lemma>subjekt</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W16</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W17</w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W18</w.rf>
   <form>kontakty</form>
   <lemma>kontakt</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W19</w.rf>
   <form>záchranářů</form>
   <lemma>záchranář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W21</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W22</w.rf>
   <form>Záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W23</w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W24</w.rf>
   <form>cvičili</form>
   <lemma>cvičit_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W26</w.rf>
   <form>Ostravě</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W27</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W28</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W29</w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>ClXP7----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W30</w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W31</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W32</w.rf>
   <form>Dolní</form>
   <lemma>Dolní_;G</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W33</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W34</w.rf>
   <form>Vítkovic</form>
   <lemma>Vítkovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W35</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W36</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W37</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W38</w.rf>
   <form>simulovány</form>
   <lemma>simulovat_:T</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W39</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W40</w.rf>
   <form>závaly</form>
   <lemma>zával</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W41</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W42</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W43</w.rf>
   <form>pracujících</form>
   <lemma>pracující_^(*5ovat)</lemma>
   <tag>AGMP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W44</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W45</w.rf>
   <form>výkopech</form>
   <lemma>výkop</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p7s2W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p7s2W47</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p8s1">
  <m id="m-moravskoslezsky48327.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W2</w.rf>
   <form>čtvrteční</form>
   <lemma>čtvrteční</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W3</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W5</w.rf>
   <form>Ostravě-Přívoze</form>
   <lemma>Ostravě-Přívoze</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W7</w.rf>
   <form>přijeli</form>
   <lemma>přijet-1_^(např._autem)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W8</w.rf>
   <form>podívat</form>
   <lemma>podívat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W9</w.rf>
   <form>náměstek</form>
   <lemma>náměstek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W10</w.rf>
   <form>ostravského</form>
   <lemma>ostravský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W11</w.rf>
   <form>primátora</form>
   <lemma>primátor</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W12</w.rf>
   <form>Lukáš</form>
   <lemma>Lukáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W13</w.rf>
   <form>Ženatý</form>
   <lemma>ženatý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W15</w.rf>
   <form>senátorka</form>
   <lemma>senátorka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W16</w.rf>
   <form>Liana</form>
   <lemma>Liana</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W17</w.rf>
   <form>Janáčková</form>
   <lemma>Janáčková_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W19</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W20</w.rf>
   <form>desítky</form>
   <lemma>desítka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W21</w.rf>
   <form>starostek</form>
   <lemma>starostka_^(^FM*2a)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W23</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W24</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W26</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W27</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W28</w.rf>
   <form>setkávají</form>
   <lemma>setkávat_:T_^(*4at)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W29</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W30</w.rf>
   <form>Ostravě</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W31</w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W32</w.rf>
   <form>každým</form>
   <lemma>každý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W33</w.rf>
   <form>rokem</form>
   <lemma>rok</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W34</w.rf>
   <form>právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W35</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W36</w.rf>
   <form>květnu</form>
   <lemma>květen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s1W37</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky48327.txt-001-p8s2">
  <m id="m-moravskoslezsky48327.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W1</w.rf>
   <form>Úspěšné</form>
   <lemma>úspěšný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W2</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W3</w.rf>
   <form>zraněných</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W4</w.rf>
   <form>doprovázely</form>
   <lemma>doprovázet_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W5</w.rf>
   <form>uznalým</form>
   <lemma>uznalý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W6</w.rf>
   <form>potleskem</form>
   <lemma>potlesk</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W8</w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W9</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W10</w.rf>
   <form>samotný</form>
   <lemma>samotný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W11</w.rf>
   <form>závěr</form>
   <lemma>závěr_^(př._z_jednání,_úvah)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W12</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky48327.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky48327.txt-001-p8s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
