<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="moravskoslezsky50035.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-moravskoslezsky50035.txt-001-p1s1">
  <m id="m-moravskoslezsky50035.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W1</w.rf>
   <form>Jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W2</w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W4</w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W5</w.rf>
   <form>taktická</form>
   <lemma>taktický</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W6</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W7</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W8</w.rf>
   <form>spoluprací</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W9</w.rf>
   <form>mnoha</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W10</w.rf>
   <form>složek</form>
   <lemma>složka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W11</w.rf>
   <form>integrovaného</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W12</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W13</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W14</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W15</w.rf>
   <form>firem</form>
   <lemma>firma</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W17</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W18</w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W19</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W20</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W21</w.rf>
   <form>prověřovací</form>
   <lemma>prověřovací_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W22</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W23</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS2----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W24</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W25</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W26</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W27</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W28</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W29</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W30</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W31</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W32</w.rf>
   <form>mužích</form>
   <lemma>muž</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s1W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p1s2">
  <m id="m-moravskoslezsky50035.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W1</w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W3</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W4</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W5</w.rf>
   <form>lepší</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W7</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W8</w.rf>
   <form>kdyby</form>
   <lemma>kdyby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W10</w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W12</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W13</w.rf>
   <form>vyjíždět</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W14</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W15</w.rf>
   <form>skutečným</form>
   <lemma>skutečný</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W16</w.rf>
   <form>velkým</form>
   <lemma>velký</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W17</w.rf>
   <form>požárům</form>
   <lemma>požár</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W19</w.rf>
   <form>haváriím</form>
   <lemma>havárie</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W21</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W22</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W23</w.rf>
   <form>doprovázet</form>
   <lemma>doprovázet_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W24</w.rf>
   <form>lidská</form>
   <lemma>lidský</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W25</w.rf>
   <form>neštěstí</form>
   <lemma>neštěstí</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W27</w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W28</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p1s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p1s2W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p2s1">
  <m id="m-moravskoslezsky50035.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W2</w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W3</w.rf>
   <form>skutečných</form>
   <lemma>skutečný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W4</w.rf>
   <form>zásahů</form>
   <lemma>zásah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W6</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W7</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W8</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W10</w.rf>
   <form>připravují</form>
   <lemma>připravovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W12</w.rf>
   <form>nejrůznějších</form>
   <lemma>různý</lemma>
   <tag>AANP6----3A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W13</w.rf>
   <form>možných</form>
   <lemma>možný</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W14</w.rf>
   <form>místech</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W16</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W17</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W18</w.rf>
   <form>dojít</form>
   <lemma>dojít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W19</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W20</w.rf>
   <form>ohrožení</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W21</w.rf>
   <form>lidského</form>
   <lemma>lidský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W22</w.rf>
   <form>života</form>
   <lemma>život</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W23</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W24</w.rf>
   <form>majetku</form>
   <lemma>majetek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W27</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W28</w.rf>
   <form>letištích</form>
   <lemma>letiště</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W30</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W31</w.rf>
   <form>domovech</form>
   <lemma>domov</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W32</w.rf>
   <form>důchodců</form>
   <lemma>důchodce</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W33</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W34</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W35</w.rf>
   <form>výkopech</form>
   <lemma>výkop</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W37</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W38</w.rf>
   <form>panelových</form>
   <lemma>panelový</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W39</w.rf>
   <form>sídlištích</form>
   <lemma>sídliště</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W40</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W41</w.rf>
   <form>věznicích</form>
   <lemma>věznice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W42</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W43</w.rf>
   <form>simulují</form>
   <lemma>simulovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W44</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W45</w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W46</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W47</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W48</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W49</w.rf>
   <form>úniky</form>
   <lemma>únik</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W50</w.rf>
   <form>plynu</form>
   <lemma>plyn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p2s1W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p2s1W51</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p3s1">
  <m id="m-moravskoslezsky50035.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W2</w.rf>
   <form>Ostravě</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W3</w.rf>
   <form>umožňuje</form>
   <lemma>umožňovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W4</w.rf>
   <form>akciová</form>
   <lemma>akciový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W5</w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W6</w.rf>
   <form>Vítkovice</form>
   <lemma>Vítkovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W7</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W8</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W9</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W11</w.rf>
   <form>mnohahektarové</form>
   <lemma>mnohahektarový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W13</w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W14</w.rf>
   <form>uzavřené</form>
   <lemma>uzavřený_^(*3ít)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W15</w.rf>
   <form>Dolní</form>
   <lemma>Dolní_;G</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W16</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W17</w.rf>
   <form>Vítkovic</form>
   <lemma>Vítkovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W19</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W20</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W21</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W22</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W23</w.rf>
   <form>nepracují</form>
   <lemma>pracovat_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W24</w.rf>
   <form>vysoké</form>
   <lemma>vysoký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W25</w.rf>
   <form>pece</form>
   <lemma>pec</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W27</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W28</w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>P5XP7--3-------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W29</w.rf>
   <form>spjaté</form>
   <lemma>spjatý_^(*5epnout)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W30</w.rf>
   <form>provozy</form>
   <lemma>provoz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p3s2">
  <m id="m-moravskoslezsky50035.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W1</w.rf>
   <form>Letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W2</w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W3</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W4</w.rf>
   <form>společně</form>
   <lemma>společně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W5</w.rf>
   <form>trénovali</form>
   <lemma>trénovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W6</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W7</w.rf>
   <form>letečtí</form>
   <lemma>letecký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W8</w.rf>
   <form>záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W10</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W11</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W12</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W14</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W15</w.rf>
   <form>Jihomoravského</form>
   <lemma>jihomoravský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W16</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p3s3">
  <m id="m-moravskoslezsky50035.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W1</w.rf>
   <form>Jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W3</w.rf>
   <form>méně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W4</w.rf>
   <form>častých</form>
   <lemma>častý</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W5</w.rf>
   <form>míst</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W7</w.rf>
   <form>prověřování</form>
   <lemma>prověřování_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W8</w.rf>
   <form>připravenosti</form>
   <lemma>připravenost_^(*5it)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W9</w.rf>
   <form>moravskoslezských</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W10</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W12</w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W13</w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W14</w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W15</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W16</w.rf>
   <form>vepřín</form>
   <lemma>vepřín</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p3s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p4s1">
  <m id="m-moravskoslezsky50035.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W2</w.rf>
   <form>středu</form>
   <lemma>středa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W3</w.rf>
   <form>16.5</form>
   <form_change>num_normalization</form_change>
   <lemma>16.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W7</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W8</w.rf>
   <form>Chotěbuz</form>
   <lemma>Chotěbuz_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W10</w.rf>
   <form>Karvinsku</form>
   <lemma>Karvinsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W11</w.rf>
   <form>uskutečnilo</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W12</w.rf>
   <form>taktické</form>
   <lemma>taktický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W13</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W14</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W15</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W16</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W18</w.rf>
   <form>zaměřené</form>
   <lemma>zaměřený_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W20</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W21</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W22</w.rf>
   <form>vepřína</form>
   <lemma>vepřín</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p4s2">
  <m id="m-moravskoslezsky50035.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W1</w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W2</w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W4</w.rf>
   <form>evakuací</form>
   <lemma>evakuace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W5</w.rf>
   <form>živých</form>
   <lemma>živý</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W6</w.rf>
   <form>zvířat</form>
   <lemma>zvíře</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W8</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W9</w.rf>
   <form>provizorního</form>
   <lemma>provizorní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W10</w.rf>
   <form>ustájení</form>
   <lemma>ustájení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p4s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p5s1">
  <m id="m-moravskoslezsky50035.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W1</w.rf>
   <form>Cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W3</w.rf>
   <form>zúčastnilo</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W4</w.rf>
   <form>54</form>
   <lemma>54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W5</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W7</w.rf>
   <form>Karvinska</form>
   <lemma>Karvinsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W9</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W10</w.rf>
   <form>požárních</form>
   <lemma>požární</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W11</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W13</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W14</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W15</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W16</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W17</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W18</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W19</w.rf>
   <form>Český</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W20</w.rf>
   <form>Těšín</form>
   <lemma>Těšín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W22</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W23</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W24</w.rf>
   <form>sborů</form>
   <lemma>sbor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W25</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W26</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W27</w.rf>
   <form>Český</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W28</w.rf>
   <form>Těšín-Město</form>
   <lemma>Těšín-Město</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W30</w.rf>
   <form>Mosty</form>
   <lemma>Most-2_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W32</w.rf>
   <form>Horní</form>
   <lemma>Horní_;G</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W33</w.rf>
   <form>Žukov</form>
   <lemma>Žukov_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W34</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W35</w.rf>
   <form>Mistřovice</form>
   <lemma>Mistřovice</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W37</w.rf>
   <form>Stanislavice</form>
   <lemma>Stanislavice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W38</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W39</w.rf>
   <form>Svibice</form>
   <lemma>Svibice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W40</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W41</w.rf>
   <form>Chotěbuz</form>
   <lemma>Chotěbuz_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W42</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W43</w.rf>
   <form>Chotěbuz-Zpupná</form>
   <lemma>Chotěbuz-Zpupná</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W44</w.rf>
   <form>Lhota</form>
   <lemma>Lhota-2_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p5s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p5s1W45</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50035.txt-001-p6s1">
  <m id="m-moravskoslezsky50035.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W2</w.rf>
   <form>oznámení</form>
   <lemma>oznámení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W3</w.rf>
   <form>simulované</form>
   <lemma>simulovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W4</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W6</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W8</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W9</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W10</w.rf>
   <form>členové</form>
   <lemma>člen</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W11</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W12</w.rf>
   <form>zřídili</form>
   <lemma>zřídit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W13</w.rf>
   <form>dálkovou</form>
   <lemma>dálkový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W14</w.rf>
   <form>dopravu</form>
   <lemma>doprava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W15</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W16</w.rf>
   <form>hadicemi</form>
   <lemma>hadice</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W18</w.rf>
   <form>vytvořili</form>
   <lemma>vytvořit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W19</w.rf>
   <form>provizorní</form>
   <lemma>provizorní</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W20</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W21</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W22</w.rf>
   <form>evakuovaná</form>
   <lemma>evakuovaný_^(*2t)</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W23</w.rf>
   <form>zvířata</form>
   <lemma>zvíře</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W25</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W26</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W27</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W28</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W29</w.rf>
   <form>vodních</form>
   <lemma>vodní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W30</w.rf>
   <form>proudů</form>
   <lemma>proud</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50035.txt-001-p6s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50035.txt-001-p6s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
