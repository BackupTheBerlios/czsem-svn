<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="moravskoslezsky47547.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-moravskoslezsky47547.txt-001-p1s1">
  <m id="m-moravskoslezsky47547.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W1</w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W2</w.rf>
   <form>dubnový</form>
   <lemma>dubnový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W3</w.rf>
   <form>večer</form>
   <lemma>večer</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W5</w.rf>
   <form>tradičně</form>
   <lemma>tradičně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W6</w.rf>
   <form>zaměřen</form>
   <lemma>zaměřit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W8</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W9</w.rf>
   <form>čarodějnic</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p1s2">
  <m id="m-moravskoslezsky47547.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W1</w.rf>
   <form>Letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W2</w.rf>
   <form>vychází</form>
   <lemma>vycházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W4</w.rf>
   <form>pondělí</form>
   <lemma>pondělí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W6</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W8</w.rf>
   <form>některých</form>
   <lemma>některý</lemma>
   <tag>PZXP6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W9</w.rf>
   <form>obcích</form>
   <lemma>obec</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W10</w.rf>
   <form>našeho</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSZS2-P1-------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W11</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W13</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W14</w.rf>
   <form>vzpomínkové</form>
   <lemma>vzpomínkový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W15</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W16</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W17</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W18</w.rf>
   <form>konat</form>
   <lemma>konat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W19</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W20</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W21</w.rf>
   <form>víkendu</form>
   <lemma>víkend</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p1s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p2s1">
  <m id="m-moravskoslezsky47547.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W1</w.rf>
   <form>Každá</form>
   <lemma>každý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W2</w.rf>
   <form>aktivita</form>
   <lemma>aktivita</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W4</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W5</w.rf>
   <form>souvisí</form>
   <lemma>souviset_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W7</w.rf>
   <form>ohněm</form>
   <lemma>oheň</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W9</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W10</w.rf>
   <form>svým</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W11</w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W12</w.rf>
   <form>nebezpečná</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W14</w.rf>
   <form>riskantní</form>
   <lemma>riskantní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p2s2">
  <m id="m-moravskoslezsky47547.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W1</w.rf>
   <form>Platí</form>
   <lemma>platit_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W4</w.rf>
   <form>požárech</form>
   <lemma>požár</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W6</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W7</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W8</w.rf>
   <form>mohly</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W9</w.rf>
   <form>způsobit</form>
   <lemma>způsobit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W10</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W11</w.rf>
   <form>neobvykle</form>
   <lemma>obvykle_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W12</w.rf>
   <form>teplého</form>
   <lemma>teplý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W14</w.rf>
   <form>suchého</form>
   <lemma>suchý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W15</w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W16</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W17</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W19</w.rf>
   <form>přichystané</form>
   <lemma>přichystaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W21</w.rf>
   <form>čarodějnice</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p2s3">
  <m id="m-moravskoslezsky47547.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W1</w.rf>
   <form>Takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W2</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W3</w.rf>
   <form>bývají</form>
   <lemma>bývat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W4</w.rf>
   <form>spojeny</form>
   <lemma>spojit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W6</w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W7</w.rf>
   <form>organizátory</form>
   <lemma>organizátor</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W8</w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W9</w.rf>
   <form>přísně</form>
   <lemma>přísně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W10</w.rf>
   <form>řízeny</form>
   <lemma>řídit</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W12</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W13</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W14</w.rf>
   <form>vyhazováním</form>
   <lemma>vyhazování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W15</w.rf>
   <form>hořících</form>
   <lemma>hořící_^(*3et)</lemma>
   <tag>AGIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W16</w.rf>
   <form>kusů</form>
   <lemma>kus</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W17</w.rf>
   <form>větví</form>
   <lemma>větev</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W19</w.rf>
   <form>tyčí</form>
   <lemma>tyč</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W21</w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W22</w.rf>
   <form>dřeva</form>
   <lemma>dřevo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W23</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W24</w.rf>
   <form>vzduchu</form>
   <lemma>vzduch</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W26</w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W27</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W28</w.rf>
   <form>petardami</form>
   <lemma>petarda</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W30</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W31</w.rf>
   <form>nalévání</form>
   <lemma>nalévání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W32</w.rf>
   <form>alkoholických</form>
   <lemma>alkoholický</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W33</w.rf>
   <form>nápojů</form>
   <lemma>nápoj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W34</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W35</w.rf>
   <form>uvolněnější</form>
   <lemma>uvolněný_^(*3it)</lemma>
   <tag>AAFS3----2A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W36</w.rf>
   <form>atmosféře</form>
   <lemma>atmosféra</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W37</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W38</w.rf>
   <form>nemluvě</form>
   <lemma>nemluva</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s3W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s3W39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p2s4">
  <m id="m-moravskoslezsky47547.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W1</w.rf>
   <form>Požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W2</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W3</w.rf>
   <form>popálení</form>
   <lemma>popálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W4</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W5</w.rf>
   <form>přitom</form>
   <lemma>přitom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W6</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W7</w.rf>
   <form>způsobit</form>
   <lemma>způsobit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W9</w.rf>
   <form>obyčejná</form>
   <lemma>obyčejný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W10</w.rf>
   <form>svíčka</form>
   <lemma>svíčka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p2s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p3s1">
  <m id="m-moravskoslezsky47547.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W1</w.rf>
   <form>Hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W2</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W3</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W4</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W5</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W6</w.rf>
   <form>sice</form>
   <lemma>sice_^(spojka/příslovce;_připouští_se_určitá_fakta)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W7</w.rf>
   <form>nemůže</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W9</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W10</w.rf>
   <form>letošní</form>
   <lemma>letošní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W11</w.rf>
   <form>extrémně</form>
   <lemma>extrémno</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W12</w.rf>
   <form>suché</form>
   <lemma>suchý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W13</w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W14</w.rf>
   <form>vydat</form>
   <lemma>vydat-1_:W_^(emitovat:_cenné_papíry,_knihu,_zvuk,...)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W15</w.rf>
   <form>zákaz</form>
   <lemma>zákaz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W16</w.rf>
   <form>pořádání</form>
   <lemma>pořádání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W17</w.rf>
   <form>podobných</form>
   <lemma>podobný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W18</w.rf>
   <form>akcí</form>
   <lemma>akce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W20</w.rf>
   <form>můžeme</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W21</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W23</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W24</w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W25</w.rf>
   <form>připomenout</form>
   <lemma>připomenout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W26</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W27</w.rf>
   <form>základních</form>
   <lemma>základní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W28</w.rf>
   <form>rad</form>
   <lemma>rada-1_^(př._dát_někomu_dobrou_radu)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W29</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W30</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W31</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W32</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W33</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W34</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W35</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W36</w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W37</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W38</w.rf>
   <form>vlastním</form>
   <lemma>vlastní-1_^(příslušný_k_něčemu)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W39</w.rf>
   <form>zájmu</form>
   <lemma>zájem</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W40</w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W41</w.rf>
   <form>účastníci</form>
   <lemma>účastník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W42</w.rf>
   <form>čarodějnické</form>
   <lemma>čarodějnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W43</w.rf>
   <form>veselice</form>
   <lemma>veselice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W44</w.rf>
   <form>dodržovat</form>
   <lemma>dodržovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p3s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p3s1W45</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p4s1">
  <m id="m-moravskoslezsky47547.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W1</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W2</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W3</w.rf>
   <form>rozdělávání</form>
   <lemma>rozdělávání_^(*5at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W4</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W5</w.rf>
   <form>kdekoliv</form>
   <lemma>kdekoliv</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W7</w.rf>
   <form>přírodě</form>
   <lemma>příroda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W8</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W10</w.rf>
   <form>volném</form>
   <lemma>volný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W11</w.rf>
   <form>prostranství</form>
   <lemma>prostranství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W13</w.rf>
   <form>žádném</form>
   <lemma>žádný</lemma>
   <tag>PWZS6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W14</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W15</w.rf>
   <form>nepoužívejte</form>
   <lemma>používat_:T_^(*3t)</lemma>
   <tag>Vi-P---2--N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W16</w.rf>
   <form>vysoce</form>
   <lemma>vysoce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W17</w.rf>
   <form>hořlavé</form>
   <lemma>hořlavý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W18</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W20</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W21</w.rf>
   <form>benzín</form>
   <lemma>benzín</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W23</w.rf>
   <form>naftu</form>
   <lemma>nafta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W24</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W25</w.rf>
   <form>líh</form>
   <lemma>líh</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p4s2">
  <m id="m-moravskoslezsky47547.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W2</w.rf>
   <form>minulosti</form>
   <lemma>minulost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W4</w.rf>
   <form>nejedno</form>
   <lemma>nejeden</lemma>
   <tag>CwNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W5</w.rf>
   <form>vážné</form>
   <lemma>vážný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W6</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W7</w.rf>
   <form>způsobeno</form>
   <lemma>způsobit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W8</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W10</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W12</w.rf>
   <form>účastníkům</form>
   <lemma>účastník</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W13</w.rf>
   <form>oslav</form>
   <lemma>oslava</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W14</w.rf>
   <form>nechtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W15</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W16</w.rf>
   <form>rozhořet</form>
   <lemma>rozhořet</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W17</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W19</w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PPXP3--3-------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W20</w.rf>
   <form>zdál</form>
   <lemma>zdát</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W21</w.rf>
   <form>příliš</form>
   <lemma>příliš</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W22</w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W25</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W26</w.rf>
   <form>použili</form>
   <lemma>použít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W27</w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W28</w.rf>
   <form>vysoce</form>
   <lemma>vysoce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W29</w.rf>
   <form>hořlavé</form>
   <lemma>hořlavý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W30</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p4s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p4s2W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p5s1">
  <m id="m-moravskoslezsky47547.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W1</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W2</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W3</w.rf>
   <form>přípravách</form>
   <lemma>příprava</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W5</w.rf>
   <form>rozdělávání</form>
   <lemma>rozdělávání_^(*5at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W6</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W7</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W8</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W9</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W10</w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W11</w.rf>
   <form>rozmyslet</form>
   <lemma>rozmyslet</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W12</w.rf>
   <form>umístění</form>
   <lemma>umístění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W13</w.rf>
   <form>ohniště</form>
   <lemma>ohniště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W14</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W15</w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W16</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p5s2">
  <m id="m-moravskoslezsky47547.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W1</w.rf>
   <form>Místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W2</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W3</w.rf>
   <form>rozdělávání</form>
   <lemma>rozdělávání_^(*5at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W4</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W5</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W6</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W7</w.rf>
   <form>bezpečně</form>
   <lemma>bezpečně-1_^(*3ý-1)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W8</w.rf>
   <form>izolováno</form>
   <lemma>izolovat_:T_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W9</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W10</w.rf>
   <form>hořlavých</form>
   <lemma>hořlavý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W11</w.rf>
   <form>materiálů</form>
   <lemma>materiál</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W13</w.rf>
   <form>ohraničeno</form>
   <lemma>ohraničit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W14</w.rf>
   <form>kameny</form>
   <lemma>kámen</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W16</w.rf>
   <form>pruhem</form>
   <lemma>pruh</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W17</w.rf>
   <form>širokým</form>
   <lemma>široký</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W18</w.rf>
   <form>nejméně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W19</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W20</w.rf>
   <form>metr</form>
   <lemma>metr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W21</w.rf>
   <form>zbaveným</form>
   <lemma>zbavený_^(*3it)</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W22</w.rf>
   <form>jakýchkoliv</form>
   <lemma>jakýkoliv</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W23</w.rf>
   <form>hořlavin</form>
   <lemma>hořlavina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W25</w.rf>
   <form>pozor</form>
   <lemma>pozor-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W26</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W27</w.rf>
   <form>nutno</form>
   <lemma>nutný</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W28</w.rf>
   <form>dát</form>
   <lemma>dát</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W29</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W30</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W31</w.rf>
   <form>kořeny</form>
   <lemma>kořen</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W32</w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W33</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W34</w.rf>
   <form>keřů</form>
   <lemma>keř</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W35</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W36</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W37</w.rf>
   <form>vzdálené</form>
   <lemma>vzdálený_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W38</w.rf>
   <form>minimálně</form>
   <lemma>minimálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W39</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W40</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W41</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W42</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W43</w.rf>
   <form>lesních</form>
   <lemma>lesní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W44</w.rf>
   <form>porostů</form>
   <lemma>porost</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s2W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s2W45</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p5s3">
  <m id="m-moravskoslezsky47547.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W2</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W3</w.rf>
   <form>stohu</form>
   <lemma>stoh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W5</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W6</w.rf>
   <form>nutno</form>
   <lemma>nutný</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W7</w.rf>
   <form>dodržet</form>
   <lemma>dodržet</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W8</w.rf>
   <form>odstup</form>
   <lemma>odstup</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W9</w.rf>
   <form>minimálně</form>
   <lemma>minimálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W10</w.rf>
   <form>dvojnásobný</form>
   <lemma>dvojnásobný`2</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W12</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W13</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W14</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p5s4">
  <m id="m-moravskoslezsky47547.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W2</w.rf>
   <form>dvojnásobná</form>
   <lemma>dvojnásobný`2</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W3</w.rf>
   <form>opatrnost</form>
   <lemma>opatrnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W5</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W6</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W7</w.rf>
   <form>vyplatila</form>
   <lemma>vyplatit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p5s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p5s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p6s1">
  <m id="m-moravskoslezsky47547.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W1</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W2</w.rf>
   <form>Zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W3</w.rf>
   <form>zakázáno</form>
   <lemma>zakázat</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W5</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W6</w.rf>
   <form>rozdělávání</form>
   <lemma>rozdělávání_^(*5at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W7</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W9</w.rf>
   <form>vysoké</form>
   <lemma>vysoký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W10</w.rf>
   <form>suché</form>
   <lemma>suchý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W11</w.rf>
   <form>trávě</form>
   <lemma>tráva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W14</w.rf>
   <form>strništi</form>
   <lemma>strniště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W15</w.rf>
   <form>apod</form>
   <lemma>apod-1_:B_,x_^(a_podobně)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p6s2">
  <m id="m-moravskoslezsky47547.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W1</w.rf>
   <form>Pamatujte</form>
   <lemma>pamatovat_:T</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W2</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W4</w.rf>
   <form>bezpečnou</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W5</w.rf>
   <form>vzdálenost</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W6</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W7</w.rf>
   <form>obytných</form>
   <lemma>obytný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W8</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W9</w.rf>
   <form>hospodářských</form>
   <lemma>hospodářský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W10</w.rf>
   <form>budov</form>
   <lemma>budova</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W12</w.rf>
   <form>neboť</form>
   <lemma>neboť</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W13</w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W14</w.rf>
   <form>odletujícím</form>
   <lemma>odletující_^(*5ovat)</lemma>
   <tag>AGFP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W15</w.rf>
   <form>jiskrám</form>
   <lemma>jiskra</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W17</w.rf>
   <form>vysoké</form>
   <lemma>vysoký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W18</w.rf>
   <form>vatry</form>
   <lemma>vatra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W19</w.rf>
   <form>hrozí</form>
   <lemma>hrozit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W20</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W21</w.rf>
   <form>zapálení</form>
   <lemma>zapálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W22</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W24</w.rf>
   <form>zvláště</form>
   <lemma>zvláště</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W25</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W26</w.rf>
   <form>letošním</form>
   <lemma>letošní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W27</w.rf>
   <form>extrémně</form>
   <lemma>extrémně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W28</w.rf>
   <form>suchém</form>
   <lemma>suchý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W29</w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s2W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p6s3">
  <m id="m-moravskoslezsky47547.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W2</w.rf>
   <form>zajímavost</form>
   <lemma>zajímavost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W3</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W5</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W6</w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W7</w.rf>
   <form>připomenout</form>
   <lemma>připomenout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W8</w.rf>
   <form>nařízení</form>
   <lemma>nařízení_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W9</w.rf>
   <form>platné</form>
   <lemma>platný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W11</w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W12</w.rf>
   <form>císaře</form>
   <lemma>císař</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W13</w.rf>
   <form>Josefa</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W14</w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W17</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W18</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W19</w.rf>
   <form>povoleno</form>
   <lemma>povolit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W20</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W21</w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>ClNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W22</w.rf>
   <form>obecní</form>
   <lemma>obecní_^(v_obci;_např._úřad)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W23</w.rf>
   <form>ohniště</form>
   <lemma>ohniště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W24</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W25</w.rf>
   <form>vsí</form>
   <lemma>ves</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W26</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W27</w.rf>
   <form>bezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W28</w.rf>
   <form>vzdálenosti</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W29</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W30</w.rf>
   <form>nejbližšího</form>
   <lemma>blízký</lemma>
   <tag>AANS2----3A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W31</w.rf>
   <form>stavení</form>
   <lemma>stavení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p6s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p6s3W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p7s1">
  <m id="m-moravskoslezsky47547.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W1</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W2</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W3</w.rf>
   <form>umísťování</form>
   <lemma>umísťování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W4</w.rf>
   <form>ohniště</form>
   <lemma>ohniště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W6</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W7</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W8</w.rf>
   <form>věnovat</form>
   <lemma>věnovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W9</w.rf>
   <form>pozornost</form>
   <lemma>pozornost-1_^(všímavý,_milý,_soustředěný)_(*5ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W10</w.rf>
   <form>aktuální</form>
   <lemma>aktuální</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W11</w.rf>
   <form>povětrnostní</form>
   <lemma>povětrnostní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W12</w.rf>
   <form>situaci</form>
   <lemma>situace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W14</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W15</w.rf>
   <form>jaký</form>
   <lemma>jaký</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W16</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W17</w.rf>
   <form>směr</form>
   <lemma>směr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W19</w.rf>
   <form>síla</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W20</w.rf>
   <form>větru</form>
   <lemma>vítr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W22</w.rf>
   <form>zvážit</form>
   <lemma>zvážit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W24</w.rf>
   <form>jaká</form>
   <lemma>jaký</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W25</w.rf>
   <form>doba</form>
   <lemma>doba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W26</w.rf>
   <form>uběhla</form>
   <lemma>uběhnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W27</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W28</w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W29</w.rf>
   <form>dešťových</form>
   <lemma>dešťový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W30</w.rf>
   <form>srážek</form>
   <lemma>srážka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W31</w.rf>
   <form>atd</form>
   <lemma>atd-1_:B_,x_^(a_tak_dále)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s1W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p7s2">
  <m id="m-moravskoslezsky47547.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W1</w.rf>
   <form>Hranici</form>
   <lemma>hranice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W3</w.rf>
   <form>polen</form>
   <lemma>poleno</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W5</w.rf>
   <form>potřeba</form>
   <lemma>potřeba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W6</w.rf>
   <form>stavět</form>
   <lemma>stavět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W7</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W9</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W10</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W11</w.rf>
   <form>stabilní</form>
   <lemma>stabilní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W13</w.rf>
   <form>nehrozilo</form>
   <lemma>hrozit_:T</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W14</w.rf>
   <form>její</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSNS4FS3-------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W15</w.rf>
   <form>zhroucení</form>
   <lemma>zhroucení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W17</w.rf>
   <form>stran</form>
   <lemma>strana-1_^(v_prostoru)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W19</w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W20</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W21</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W22</w.rf>
   <form>plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W23</w.rf>
   <form>rozšířit</form>
   <lemma>rozšířit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W24</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W25</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W27</w.rf>
   <form>vymknout</form>
   <lemma>vymknout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W28</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W29</w.rf>
   <form>kontrole</form>
   <lemma>kontrola</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p7s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p7s2W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p8s1">
  <m id="m-moravskoslezsky47547.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W1</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W2</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W3</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W4</w.rf>
   <form>ohňů</form>
   <lemma>oheň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W5</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W6</w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W7</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W8</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W9</w.rf>
   <form>přítomna</form>
   <lemma>přítomný</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W10</w.rf>
   <form>alespoň</form>
   <lemma>alespoň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W11</w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W12</w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W13</w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W14</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W15</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p8s2">
  <m id="m-moravskoslezsky47547.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s2W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s2W2</w.rf>
   <form>pozor</form>
   <lemma>pozor-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s2W3</w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p8s3">
  <m id="m-moravskoslezsky47547.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W1</w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W2</w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W3</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W4</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W5</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W6</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W7</w.rf>
   <form>78</form>
   <lemma>78</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W8</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W10</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W11</w.rf>
   <form>ochraně</form>
   <lemma>ochrana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W12</w.rf>
   <form>postiženi</form>
   <lemma>postihnout</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W13</w.rf>
   <form>pokutou</form>
   <lemma>pokuta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W15</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W17</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W18</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W19</w.rf>
   <form>hlediska</form>
   <lemma>hledisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W20</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W21</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W22</w.rf>
   <form>zanedbají</form>
   <lemma>zanedbat_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W23</w.rf>
   <form>dohled</form>
   <lemma>dohled</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W24</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W25</w.rf>
   <form>svými</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8XP7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W26</w.rf>
   <form>ratolestmi</form>
   <lemma>ratolest</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p8s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p8s3W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p9s1">
  <m id="m-moravskoslezsky47547.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W1</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W2</w.rf>
   <form>Oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W4</w.rf>
   <form>nesmí</form>
   <lemma>smět_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W5</w.rf>
   <form>nechat</form>
   <lemma>nechat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W6</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W8</w.rf>
   <form>okamžik</form>
   <lemma>okamžik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W9</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W10</w.rf>
   <form>dozoru</form>
   <lemma>dozor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W12</w.rf>
   <form>opustit</form>
   <lemma>opustit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W13</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W14</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W15</w.rf>
   <form>můžete</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W16</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W17</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W19</w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W20</w.rf>
   <form>ohniště</form>
   <lemma>ohniště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W21</w.rf>
   <form>důkladně</form>
   <lemma>důkladně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W22</w.rf>
   <form>uhasíte</form>
   <lemma>uhasit_:W</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W24</w.rf>
   <form>ať</form>
   <lemma>ať</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W25</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W26</w.rf>
   <form>prolitím</form>
   <lemma>prolití_^(*3ít)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W27</w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W29</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W30</w.rf>
   <form>zasypáním</form>
   <lemma>zasypání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W31</w.rf>
   <form>zeminou</form>
   <lemma>zemina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s1W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p9s2">
  <m id="m-moravskoslezsky47547.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W1</w.rf>
   <form>Pamatujte</form>
   <lemma>pamatovat_:T</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W3</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W6</w.rf>
   <form>zdánlivě</form>
   <lemma>zdánlivě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W7</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W8</w.rf>
   <form>vyhaslém</form>
   <lemma>vyhaslý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W9</w.rf>
   <form>ohništi</form>
   <lemma>ohniště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W11</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W12</w.rf>
   <form>skrývat</form>
   <lemma>skrývat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W13</w.rf>
   <form>žhavé</form>
   <lemma>žhavý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W14</w.rf>
   <form>oharky</form>
   <lemma>oharek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W16</w.rf>
   <form>poryv</form>
   <lemma>poryv</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W17</w.rf>
   <form>větru</form>
   <lemma>vítr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W18</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W19</w.rf>
   <form>znovu</form>
   <lemma>znovu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W20</w.rf>
   <form>rozdmýchá</form>
   <lemma>rozdmýchat_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W22</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W23</w.rf>
   <form>roznese</form>
   <lemma>roznést</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W24</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W25</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p9s3">
  <m id="m-moravskoslezsky47547.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W2</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W3</w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W4</w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W5</w.rf>
   <form>dohašovat</form>
   <lemma>dohašovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W6</w.rf>
   <form>ohniště</form>
   <lemma>ohniště</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W8</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W9</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W10</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W11</w.rf>
   <form>veselici</form>
   <lemma>veselice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W12</w.rf>
   <form>ponechána</form>
   <lemma>ponechat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W13</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W14</w.rf>
   <form>dozoru</form>
   <lemma>dozor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W15</w.rf>
   <form>svému</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W16</w.rf>
   <form>osudu</form>
   <lemma>osud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p9s4">
  <m id="m-moravskoslezsky47547.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s4W1</w.rf>
   <form>Nejednou</form>
   <lemma>nejednou</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s4W2</w.rf>
   <form>takto</form>
   <lemma>takto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s4W3</w.rf>
   <form>dojde</form>
   <lemma>dojít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s4W4</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s4W5</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s4W6</w.rf>
   <form>drobných</form>
   <lemma>drobný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s4W7</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p9s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p9s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p10s1">
  <m id="m-moravskoslezsky47547.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W1</w.rf>
   <form>Rizikem</form>
   <lemma>riziko</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W2</w.rf>
   <form>spojeným</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W4</w.rf>
   <form>pálením</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W5</w.rf>
   <form>čarodějnic</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W7</w.rf>
   <form>zábavní</form>
   <lemma>zábavní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W8</w.rf>
   <form>pyrotechnika</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W10</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W12</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W13</w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W14</w.rf>
   <form>příležitost</form>
   <lemma>příležitost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W15</w.rf>
   <form>využívá</form>
   <lemma>využívat_:T_^(*3t)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W17</w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W18</w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAFS7----2A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W19</w.rf>
   <form>oblibou</form>
   <lemma>obliba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p10s2">
  <m id="m-moravskoslezsky47547.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W1</w.rf>
   <form>Světlice</form>
   <lemma>světlice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W3</w.rf>
   <form>rachejtle</form>
   <lemma>rachejtle</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W5</w.rf>
   <form>petardy</form>
   <lemma>petarda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W7</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W8</w.rf>
   <form>pyrotechnické</form>
   <lemma>pyrotechnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W10</w.rf>
   <form>radůstky</form>
   <lemma>radůstka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W11</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W12</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W13</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W14</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W15</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W16</w.rf>
   <form>nesprávném</form>
   <lemma>správný_^(podle_něj._měřítek;_př._chlap,_míra,...)</lemma>
   <tag>AANS6----1N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W17</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W18</w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W19</w.rf>
   <form>nebezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W21</w.rf>
   <form>mnohdy</form>
   <lemma>mnohdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W22</w.rf>
   <form>způsobí</form>
   <lemma>způsobit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W23</w.rf>
   <form>nejen</form>
   <lemma>nejen</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W24</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W26</w.rf>
   <form>majetkové</form>
   <lemma>majetkový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W27</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W29</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W30</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W31</w.rf>
   <form>vážná</form>
   <lemma>vážný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W32</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s2W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p10s3">
  <m id="m-moravskoslezsky47547.txt-001-p10s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W2</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W3</w.rf>
   <form>řadě</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W4</w.rf>
   <form>používejte</form>
   <lemma>používat_:T_^(*3t)</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W5</w.rf>
   <form>výhradně</form>
   <lemma>výhradně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W6</w.rf>
   <form>pyrotechniku</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W7</w.rf>
   <form>uvedenou</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W8</w.rf>
   <form>legálně</form>
   <lemma>legálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W10</w.rf>
   <form>oběhu</form>
   <lemma>oběh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W12</w.rf>
   <form>podomácku</form>
   <lemma>podomácku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W13</w.rf>
   <form>vyrobené</form>
   <lemma>vyrobený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W14</w.rf>
   <form>pyrotechnice</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W15</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W16</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W17</w.rf>
   <form>vlastním</form>
   <lemma>vlastní-1_^(příslušný_k_něčemu)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W18</w.rf>
   <form>zájmu</form>
   <lemma>zájem</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W19</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W20</w.rf>
   <form>zdálky</form>
   <lemma>zdálky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W21</w.rf>
   <form>vyhněte</form>
   <lemma>vyhníst</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p10s4">
  <m id="m-moravskoslezsky47547.txt-001-p10s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s4W1</w.rf>
   <form>Rozhodně</form>
   <lemma>rozhodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s4W2</w.rf>
   <form>nevhazujte</form>
   <lemma>vhazovat_:T</lemma>
   <tag>Vi-P---2--N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s4W3</w.rf>
   <form>zábavní</form>
   <lemma>zábavní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s4W4</w.rf>
   <form>pyrotechniku</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s4W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s4W6</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p10s5">
  <m id="m-moravskoslezsky47547.txt-001-p10s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W1</w.rf>
   <form>Zvláště</form>
   <lemma>zvláště</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W2</w.rf>
   <form>nebezpečná</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W4</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W5</w.rf>
   <form>situace</form>
   <lemma>situace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W7</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W9</w.rf>
   <form>zábavní</form>
   <lemma>zábavní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W10</w.rf>
   <form>pyrotechnikou</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W11</w.rf>
   <form>manipulují</form>
   <lemma>manipulovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W12</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W13</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W14</w.rf>
   <form>vlivem</form>
   <lemma>vliv</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W15</w.rf>
   <form>alkoholu</form>
   <lemma>alkohol</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W16</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W17</w.rf>
   <form>jiných</form>
   <lemma>jiný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W18</w.rf>
   <form>drog</form>
   <lemma>droga</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s5W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p10s6">
  <m id="m-moravskoslezsky47547.txt-001-p10s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W3</w.rf>
   <form>samozřejmé</form>
   <lemma>samozřejmý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W5</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W6</w.rf>
   <form>zábavní</form>
   <lemma>zábavní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W7</w.rf>
   <form>pyrotechnika</form>
   <lemma>pyrotechnika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W8</w.rf>
   <form>rozhodně</form>
   <lemma>rozhodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W9</w.rf>
   <form>nepatří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W11</w.rf>
   <form>rukou</form>
   <lemma>ruka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W12</w.rf>
   <form>dětem</form>
   <lemma>dítě</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p10s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p10s6W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p11s1">
  <m id="m-moravskoslezsky47547.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W1</w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W2</w.rf>
   <form>pálením</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W3</w.rf>
   <form>čarodějnic</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W6</w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W7</w.rf>
   <form>dosti</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A---3</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W8</w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W9</w.rf>
   <form>spojeno</form>
   <lemma>spojit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W10</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W11</w.rf>
   <form>pneumatik</form>
   <lemma>pneumatika</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p11s2">
  <m id="m-moravskoslezsky47547.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W1</w.rf>
   <form>Tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W2</w.rf>
   <form>zlozvyk</form>
   <lemma>zlozvyk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W3</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W4</w.rf>
   <form>poškozuje</form>
   <lemma>poškozovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W5</w.rf>
   <form>životní</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W6</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W8</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W9</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W10</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W11</w.rf>
   <form>neblahé</form>
   <lemma>blahý</lemma>
   <tag>AAIP4----1N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W12</w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní_,a</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W13</w.rf>
   <form>následky</form>
   <lemma>následek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p11s3">
  <m id="m-moravskoslezsky47547.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W1</w.rf>
   <form>Stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W2</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W3</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W4</w.rf>
   <form>jiných</form>
   <lemma>jiný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W5</w.rf>
   <form>materiálů</form>
   <lemma>materiál</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W6</w.rf>
   <form>obsahujících</form>
   <lemma>obsahující_^(*5ovat)</lemma>
   <tag>AGIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W7</w.rf>
   <form>chemické</form>
   <lemma>chemický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W8</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W10</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W11</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W12</w.rf>
   <form>pneumatik</form>
   <lemma>pneumatika</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W13</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W14</w.rf>
   <form>zákonem</form>
   <lemma>zákon</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W15</w.rf>
   <form>přísně</form>
   <lemma>přísně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W16</w.rf>
   <form>zakázáno</form>
   <lemma>zakázat</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W18</w.rf>
   <form>sankce</form>
   <lemma>sankce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W19</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W21</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W22</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W23</w.rf>
   <form>dosáhnout</form>
   <lemma>dosáhnout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W24</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W25</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W26</w.rf>
   <form>výše</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W27</w.rf>
   <form>150</form>
   <lemma>150</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W28</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W29</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p11s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p11s3W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p12s1">
  <m id="m-moravskoslezsky47547.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s1W1</w.rf>
   <form>Mnohde</form>
   <lemma>mnohde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s1W2</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s1W3</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s1W4</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s1W5</w.rf>
   <form>čarodějnic</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s1W6</w.rf>
   <form>přeskakují</form>
   <lemma>přeskakovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s1W7</w.rf>
   <form>vatry</form>
   <lemma>vatra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p12s2">
  <m id="m-moravskoslezsky47547.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W1</w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W2</w.rf>
   <form>riskantní</form>
   <lemma>riskantní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W3</w.rf>
   <form>zábava</form>
   <lemma>zábava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W4</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W5</w.rf>
   <form>způsobit</form>
   <lemma>způsobit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W9</w.rf>
   <form>vznítí</form>
   <lemma>vznítit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W10</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W11</w.rf>
   <form>vašeho</form>
   <lemma>tvůj_^(přivlast.)</lemma>
   <tag>PSZS2-P2-------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W12</w.rf>
   <form>oděvu</form>
   <lemma>oděv</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p12s3">
  <m id="m-moravskoslezsky47547.txt-001-p12s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W1</w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W3</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W4</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W5</w.rf>
   <form>nemáte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W6</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W7</w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W8</w.rf>
   <form>dostatek</form>
   <lemma>dostatek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W9</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W11</w.rf>
   <form>popř</form>
   <lemma>popřípadě_:B</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W13</w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W14</w.rf>
   <form>hasební</form>
   <lemma>hasební</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W15</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W17</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W18</w.rf>
   <form>vhodné</form>
   <lemma>vhodný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W19</w.rf>
   <form>použít</form>
   <lemma>použít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W20</w.rf>
   <form>pravidlo</form>
   <lemma>pravidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W21</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W22</w.rf>
   <form>Zastav</form>
   <lemma>Zastava_;R_,t_^(značka_automobilu)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W23</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W25</w.rf>
   <form>lehni</form>
   <lemma>lehnout_:W</lemma>
   <tag>Vi-S---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W26</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W28</w.rf>
   <form>kutálej</form>
   <lemma>kutálet_:T</lemma>
   <tag>Vi-S---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W29</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W30</w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W31</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W32</w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W33</w.rf>
   <form>vám</form>
   <lemma>ty</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W34</w.rf>
   <form>hoří</form>
   <lemma>hořet</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W35</w.rf>
   <form>oděv</form>
   <lemma>oděv</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W37</w.rf>
   <form>neutíkejte</form>
   <lemma>utíkat_:T</lemma>
   <tag>Vi-P---2--N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W38</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W39</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W40</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W41</w.rf>
   <form>chůzí</form>
   <lemma>chůze</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W42</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W43</w.rf>
   <form>oheň</form>
   <lemma>oheň</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W44</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W45</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W46</w.rf>
   <form>rozšíří</form>
   <lemma>rozšířit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s3W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s3W47</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p12s4">
  <m id="m-moravskoslezsky47547.txt-001-p12s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W1</w.rf>
   <form>Okamžitě</form>
   <lemma>okamžitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W3</w.rf>
   <form>lehněte</form>
   <lemma>lehnout_:W</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W5</w.rf>
   <form>zem</form>
   <lemma>země</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W7</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W8</w.rf>
   <form>ochranu</form>
   <lemma>ochrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W9</w.rf>
   <form>obličeje</form>
   <lemma>obličej</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W10</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W11</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W12</w.rf>
   <form>zakryjte</form>
   <lemma>zakrýt</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W13</w.rf>
   <form>dlaněmi</form>
   <lemma>dlaň</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W14</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W15</w.rf>
   <form>dlaně</form>
   <lemma>dlaň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W16</w.rf>
   <form>nepřikládejte</form>
   <lemma>přikládat_:T</lemma>
   <tag>Vi-P---2--N----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W18</w.rf>
   <form>tvář</form>
   <lemma>tvář</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W19</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W21</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W23</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W24</w.rf>
   <form>hoří</form>
   <lemma>hořet</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W25</w.rf>
   <form>rukávy</form>
   <lemma>rukáv</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W26</w.rf>
   <form>oblečení</form>
   <lemma>oblečení_^(*5éci)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W27</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s4W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p12s5">
  <m id="m-moravskoslezsky47547.txt-001-p12s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W1</w.rf>
   <form>Válejte</form>
   <lemma>válet_:T</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W4</w.rf>
   <form>dokud</form>
   <lemma>dokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W5</w.rf>
   <form>plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W6</w.rf>
   <form>neuhasnou</form>
   <lemma>uhasnout_:W</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W8</w.rf>
   <form>válením</form>
   <lemma>válení_^(*2t)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W10</w.rf>
   <form>zamezí</form>
   <lemma>zamezit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W11</w.rf>
   <form>přístupu</form>
   <lemma>přístup</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W12</w.rf>
   <form>kyslíku</form>
   <lemma>kyslík</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W13</w.rf>
   <form>potřebného</form>
   <lemma>potřebný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W15</w.rf>
   <form>hoření</form>
   <lemma>hoření_^(*2t)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s5W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p12s6">
  <m id="m-moravskoslezsky47547.txt-001-p12s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W1</w.rf>
   <form>Je-li</form>
   <lemma>Je-li</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W3</w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W4</w.rf>
   <form>deka</form>
   <lemma>deko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W6</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W7</w.rf>
   <form>jiná</form>
   <lemma>jiný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W8</w.rf>
   <form>vhodná</form>
   <lemma>vhodný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W9</w.rf>
   <form>textilie</form>
   <lemma>textilie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W10</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W11</w.rf>
   <form>nesmí</form>
   <lemma>smět_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W12</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W13</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W14</w.rf>
   <form>textilie</form>
   <lemma>textilie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W15</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W16</w.rf>
   <form>umělých</form>
   <lemma>umělý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W17</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W18</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W20</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W21</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W22</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W23</w.rf>
   <form>použít</form>
   <lemma>použít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W24</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W25</w.rf>
   <form>uhašení</form>
   <lemma>uhašení_^(*4sit)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W26</w.rf>
   <form>hořícího</form>
   <lemma>hořící_^(*3et)</lemma>
   <tag>AGIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W27</w.rf>
   <form>oděvu</form>
   <lemma>oděv</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p12s6W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p12s6W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p13s1">
  <m id="m-moravskoslezsky47547.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W1</w.rf>
   <form>Zvláště</form>
   <lemma>zvláště</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W2</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W3</w.rf>
   <form>větších</form>
   <lemma>velký</lemma>
   <tag>AAFP2----2A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W4</w.rf>
   <form>akcí</form>
   <lemma>akce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W5</w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W6</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W7</w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W8</w.rf>
   <form>povolat</form>
   <lemma>povolat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W9</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W10</w.rf>
   <form>hlídku</form>
   <lemma>hlídka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W12</w.rf>
   <form>řad</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W13</w.rf>
   <form>místních</form>
   <lemma>místní</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W14</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W15</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W16</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W18</w.rf>
   <form>vozidlem</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W20</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W21</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W22</w.rf>
   <form>doporučují</form>
   <lemma>doporučovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W23</w.rf>
   <form>informovat</form>
   <lemma>informovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W25</w.rf>
   <form>zapalování</form>
   <lemma>zapalování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W26</w.rf>
   <form>ohňů</form>
   <lemma>oheň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W27</w.rf>
   <form>místnímu</form>
   <lemma>místní</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W28</w.rf>
   <form>úřadu</form>
   <lemma>úřad</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky47547.txt-001-p13s2">
  <m id="m-moravskoslezsky47547.txt-001-p13s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W1</w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W2</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W3</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W4</w.rf>
   <form>čarodějnic</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W5</w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W6</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W7</w.rf>
   <form>rodinný</form>
   <lemma>rodinný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W8</w.rf>
   <form>charakter</form>
   <lemma>charakter</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W10</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W11</w.rf>
   <form>vhodné</form>
   <lemma>vhodný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W12</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W13</w.rf>
   <form>připravit</form>
   <lemma>připravit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W14</w.rf>
   <form>dopředu</form>
   <lemma>dopředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W16</w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W17</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W18</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W19</w.rf>
   <form>kbelíků</form>
   <lemma>kbelík</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W20</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W21</w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W24</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W25</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W26</w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWYS1----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W27</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W28</w.rf>
   <form>nevznikne</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W30</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W31</w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W32</w.rf>
   <form>posloužit</form>
   <lemma>posloužit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W33</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W34</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W35</w.rf>
   <form>osvěžení</form>
   <lemma>osvěžení_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W36</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W37</w.rf>
   <form>mytí</form>
   <lemma>mytí_^(*3ýt)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W38</w.rf>
   <form>rukou</form>
   <lemma>ruka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W39</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W40</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W41</w.rf>
   <form>skončení</form>
   <lemma>skončení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W42</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W43</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W44</w.rf>
   <form>důkladnému</form>
   <lemma>důkladný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W45</w.rf>
   <form>zalití</form>
   <lemma>zalití_^(*3ít)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W46</w.rf>
   <form>zbytků</form>
   <lemma>zbytek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W47</w.rf>
   <form>žhavých</form>
   <lemma>žhavý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W48</w.rf>
   <form>uhlíků</form>
   <lemma>uhlík</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky47547.txt-001-p13s2W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky47547.txt-001-p13s2W49</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
