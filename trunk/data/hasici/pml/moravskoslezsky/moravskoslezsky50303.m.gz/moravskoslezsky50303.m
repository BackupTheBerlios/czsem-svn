<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="moravskoslezsky50303.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-moravskoslezsky50303.txt-001-p1s1">
  <m id="m-moravskoslezsky50303.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W2</w.rf>
   <form>konkurenci</form>
   <lemma>konkurence</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W3</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W4</w.rf>
   <form>týmů</form>
   <lemma>tým</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W5</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W6</w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W7</w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W8</w.rf>
   <form>obsadila</form>
   <lemma>obsadit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W9</w.rf>
   <form>česká</form>
   <lemma>český</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W10</w.rf>
   <form>reprezentace</form>
   <lemma>reprezentace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W11</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrNS4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W12</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W14</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W15</w.rf>
   <form>odešla</form>
   <lemma>odejít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W16</w.rf>
   <form>poražena</form>
   <lemma>porazit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W17</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W19</w.rf>
   <form>jediném</form>
   <lemma>jediný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W20</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W21</w.rf>
   <form>šesti</form>
   <lemma>šest`6</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W22</w.rf>
   <form>odehraných</form>
   <lemma>odehraný_^(*3át)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W23</w.rf>
   <form>zápasů</form>
   <lemma>zápas</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p1s2">
  <m id="m-moravskoslezsky50303.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W1</w.rf>
   <form>Martin</form>
   <lemma>Martin-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W2</w.rf>
   <form>Opic</form>
   <lemma>opice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W4</w.rf>
   <form>Karviné</form>
   <lemma>Karviná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W5</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W6</w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W7</w.rf>
   <form>vyhlášen</form>
   <lemma>vyhlášet_:T_,a</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W8</w.rf>
   <form>nejlepším</form>
   <lemma>dobrý</lemma>
   <tag>AAMS7----3A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W9</w.rf>
   <form>hráčem</form>
   <lemma>hráč</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W10</w.rf>
   <form>celého</form>
   <lemma>celý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W11</w.rf>
   <form>turnaje</form>
   <lemma>turnaj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p1s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p2s1">
  <m id="m-moravskoslezsky50303.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W2</w.rf>
   <form>skupině</form>
   <lemma>skupina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W3</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W4</w.rf>
   <form>tým</form>
   <lemma>tým</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W5</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W7</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W10</w.rf>
   <form>pondělí</form>
   <lemma>pondělí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W11</w.rf>
   <form>21.5</form>
   <form_change>num_normalization</form_change>
   <lemma>21.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W13</w.rf>
   <form>vrátil</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W14</w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W16</w.rf>
   <form>postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W17</w.rf>
   <form>narazil</form>
   <lemma>narazit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W19</w.rf>
   <form>Řecko</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W21</w.rf>
   <form>Německo</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W23</w.rf>
   <form>Rumunsko</form>
   <lemma>Rumunsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W25</w.rf>
   <form>Velkou</form>
   <lemma>velký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W26</w.rf>
   <form>Británii</form>
   <lemma>Británie_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W28</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W29</w.rf>
   <form>porazil</form>
   <lemma>porazit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p2s2">
  <m id="m-moravskoslezsky50303.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W1</w.rf>
   <form>Prohrál</form>
   <lemma>prohrát</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W2</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W4</w.rf>
   <form>boji</form>
   <lemma>boj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W5</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W6</w.rf>
   <form>finále</form>
   <lemma>finále</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W8</w.rf>
   <form>domácí</form>
   <lemma>domácí</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W9</w.rf>
   <form>Francií</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W10</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W11</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W12</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W15</w.rf>
   <form>boji</form>
   <lemma>boj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W17</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrNS4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W18</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W19</w.rf>
   <form>jasně</form>
   <lemma>jasně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W20</w.rf>
   <form>přehrál</form>
   <lemma>přehrát</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W21</w.rf>
   <form>Řecko</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W22</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W23</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W24</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p2s3">
  <m id="m-moravskoslezsky50303.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s3W1</w.rf>
   <form>Pohár</form>
   <lemma>Pohár-1_;G_^(souhvězdí)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s3W2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s3W3</w.rf>
   <form>odvážejí</form>
   <lemma>odvážet_:T_^(něco_někam_např._autem)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s3W4</w.rf>
   <form>Poláci</form>
   <lemma>Polák_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p2s4">
  <m id="m-moravskoslezsky50303.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W1</w.rf>
   <form>Osm</form>
   <lemma>osm`8</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W3</w.rf>
   <form>dvanácti</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W4</w.rf>
   <form>reprezentantů</form>
   <lemma>reprezentant</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W5</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W8</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W9</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p2s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p3s1">
  <m id="m-moravskoslezsky50303.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W1</w.rf>
   <form>Výsledky</form>
   <lemma>výsledek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W2</w.rf>
   <form>týmu</form>
   <lemma>tým</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W3</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W5</w.rf>
   <form>skupině</form>
   <lemma>skupina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W7</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W10</w.rf>
   <form>Řecko</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W11</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W12</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W13</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W15</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W16</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W17</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W18</w.rf>
   <form>Německo</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W19</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W20</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W21</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W23</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W26</w.rf>
   <form>Rumunsko</form>
   <lemma>Rumunsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W27</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W28</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W29</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W30</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W31</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W32</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W33</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W34</w.rf>
   <form>Velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W35</w.rf>
   <form>Británie</form>
   <lemma>Británie_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W36</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W37</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W38</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s1W39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p3s2">
  <m id="m-moravskoslezsky50303.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W1</w.rf>
   <form>Semifinále</form>
   <lemma>semifinále</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W3</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W6</w.rf>
   <form>Francie</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W7</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W9</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W11</w.rf>
   <form>Polsko</form>
   <lemma>Polsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W14</w.rf>
   <form>Řecko</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W15</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W16</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W17</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p3s3">
  <m id="m-moravskoslezsky50303.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W1</w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W2</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrNS4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W3</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W4</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W5</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W8</w.rf>
   <form>Řecko</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W9</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W11</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p3s4">
  <m id="m-moravskoslezsky50303.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W1</w.rf>
   <form>Finále</form>
   <lemma>finále</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W3</w.rf>
   <form>Polsko</form>
   <lemma>Polsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W6</w.rf>
   <form>Francie</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W7</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W9</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p3s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p4s1">
  <m id="m-moravskoslezsky50303.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W2</w.rf>
   <form>Kolegům</form>
   <lemma>kolega</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W4</w.rf>
   <form>Polska</form>
   <lemma>Polsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W5</w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W6</w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W8</w.rf>
   <form>německými</form>
   <lemma>německý</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W10</w.rf>
   <form>holandskými</form>
   <lemma>holandský</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W12</w.rf>
   <form>vytvořili</form>
   <lemma>vytvořit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W14</w.rf>
   <form>finále</form>
   <lemma>finále</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W15</w.rf>
   <form>atmosféru</form>
   <lemma>atmosféra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W17</w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W18</w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W19</w.rf>
   <form>přinutili</form>
   <lemma>přinutit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W20</w.rf>
   <form>domácí</form>
   <lemma>domácí</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W21</w.rf>
   <form>rozhodčí</form>
   <lemma>rozhodčí</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W22</w.rf>
   <form>přestat</form>
   <lemma>přestat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W23</w.rf>
   <form>jednostranně</form>
   <lemma>jednostranně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W24</w.rf>
   <form>pískat</form>
   <lemma>pískat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W25</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W26</w.rf>
   <form>mužstvo</form>
   <lemma>mužstvo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W27</w.rf>
   <form>Francie</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W30</w.rf>
   <form>umožnili</form>
   <lemma>umožnit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W31</w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PPXP3--3-------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W32</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W33</w.rf>
   <form>zvednout</form>
   <lemma>zvednout_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W34</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W35</w.rf>
   <form>hlavy</form>
   <lemma>hlava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W36</w.rf>
   <form>vítězný</form>
   <lemma>vítězný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W37</w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W38</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W39</w.rf>
   <form>mistry</form>
   <lemma>mistr</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W40</w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W41</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W42</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W43</w.rf>
   <form>řekl</form>
   <lemma>říci_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W44</w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-1_^(*8ést-1)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W45</w.rf>
   <form>týmu</form>
   <lemma>tým</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W46</w.rf>
   <form>Jozef</form>
   <lemma>Jozef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W47</w.rf>
   <form>Dankovič</form>
   <lemma>Dankovič_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W48</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W49</w.rf>
   <form>Ostravy</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p4s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p4s1W50</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p5s1">
  <m id="m-moravskoslezsky50303.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W2</w.rf>
   <form>Děkujeme</form>
   <lemma>děkovat_:T</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W3</w.rf>
   <form>hráčům</form>
   <lemma>hráč</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W5</w.rf>
   <form>výběru</form>
   <lemma>výběr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W6</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W7</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W8</w.rf>
   <form>vynikající</form>
   <lemma>vynikající_^(*4t)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W9</w.rf>
   <form>reprezentaci</form>
   <lemma>reprezentace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W11</w.rf>
   <form>kolektivní</form>
   <lemma>kolektivní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W12</w.rf>
   <form>výkon</form>
   <lemma>výkon</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W14</w.rf>
   <form>děkujeme</form>
   <lemma>děkovat_:T</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W15</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W16</w.rf>
   <form>Generálnímu</form>
   <lemma>generální</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W17</w.rf>
   <form>ředitelství</form>
   <lemma>ředitelství</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W18</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W19</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W20</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W21</w.rf>
   <form>vyslání</form>
   <lemma>vyslání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W23</w.rf>
   <form>uvedenou</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W24</w.rf>
   <form>akci</form>
   <lemma>akce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W26</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W27</w.rf>
   <form>řediteli</form>
   <lemma>ředitel</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W28</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W29</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W30</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W31</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W32</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W33</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W34</w.rf>
   <form>zajištění</form>
   <lemma>zajištění_^(*5stit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W35</w.rf>
   <form>dopravy</form>
   <lemma>doprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W37</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W38</w.rf>
   <form>dodal</form>
   <lemma>dodat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W39</w.rf>
   <form>spokojený</form>
   <lemma>spokojený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W40</w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-1_^(*8ést-1)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W41</w.rf>
   <form>týmu</form>
   <lemma>tým</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p5s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p5s1W42</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p6s1">
  <m id="m-moravskoslezsky50303.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W1</w.rf>
   <form>Sálová</form>
   <lemma>sálový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W2</w.rf>
   <form>kopaná</form>
   <lemma>kopaná_^(fotbal)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W4</w.rf>
   <form>kombinací</form>
   <lemma>kombinace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W5</w.rf>
   <form>futsalu</form>
   <lemma>futsal_;w_,t</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W7</w.rf>
   <form>halového</form>
   <lemma>halový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W8</w.rf>
   <form>fotbalu</form>
   <lemma>fotbal</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W9</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W10</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W11</w.rf>
   <form>hráči</form>
   <lemma>hráč</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W12</w.rf>
   <form>+</form>
   <lemma>+</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W14</w.rf>
   <form>brankář</form>
   <lemma>brankář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W16</w.rf>
   <form>branka</form>
   <lemma>branka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W17</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W18</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W19</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W20</w.rf>
   <form>metry</form>
   <lemma>metrum</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W22</w.rf>
   <form>pokutový</form>
   <lemma>pokutový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W23</w.rf>
   <form>kop</form>
   <lemma>kop</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W24</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W25</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W27</w.rf>
   <form>ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W28</w.rf>
   <form>pravidla</form>
   <lemma>pravidlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W29</w.rf>
   <form>platí</form>
   <lemma>platit_:T_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W30</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W31</w.rf>
   <form>pravidel</form>
   <lemma>pravidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W32</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W33</w.rf>
   <form>futsal</form>
   <lemma>futsal_;w_,t</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W34</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s1W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p6s2">
  <m id="m-moravskoslezsky50303.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W1</w.rf>
   <form>Tým</form>
   <lemma>tým</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W2</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W3</w.rf>
   <form>tvořilo</form>
   <lemma>tvořit_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W4</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W5</w.rf>
   <form>příslušníků</form>
   <lemma>příslušník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W6</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W7</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W8</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W10</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W11</w.rf>
   <form>reprezentanti</form>
   <lemma>reprezentant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W12</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W13</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W14</w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W16</w.rf>
   <form>Kutné</form>
   <lemma>kutný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W17</w.rf>
   <form>Hory</form>
   <lemma>hora</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W19</w.rf>
   <form>Litoměřic</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W21</w.rf>
   <form>Soběslavi</form>
   <lemma>Soběslav-1_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W23</w.rf>
   <form>řada</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W24</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W25</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W26</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W27</w.rf>
   <form>ligové</form>
   <lemma>ligový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W28</w.rf>
   <form>futsalové</form>
   <lemma>futsalový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W29</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W30</w.rf>
   <form>fotbalové</form>
   <lemma>fotbalový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W31</w.rf>
   <form>zkušenosti</form>
   <lemma>zkušenost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p6s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p6s2W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-moravskoslezsky50303.txt-001-p7s1">
  <m id="m-moravskoslezsky50303.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W1</w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W2</w.rf>
   <form>evropský</form>
   <lemma>evropský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W3</w.rf>
   <form>šampionát</form>
   <lemma>šampionát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W5</w.rf>
   <form>konal</form>
   <lemma>konat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W6</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W7</w.rf>
   <form>osmi</form>
   <lemma>osm`8</lemma>
   <tag>Cn-P7----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W8</w.rf>
   <form>lety</form>
   <lemma>rok</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W10</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W11</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W12</w.rf>
   <form>skončila</form>
   <lemma>skončit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W13</w.rf>
   <form>druhá</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W14</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W15</w.rf>
   <form>vítězným</form>
   <lemma>vítězný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W16</w.rf>
   <form>Německem</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W18</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W19</w.rf>
   <form>čtyřmi</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP7----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W20</w.rf>
   <form>lety</form>
   <lemma>rok</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W21</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W22</w.rf>
   <form>ME</form>
   <lemma>ME-1_:B_;w_^(mistrovství_Evropy)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W23</w.rf>
   <form>neuskutečnilo</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W25</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W26</w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W27</w.rf>
   <form>příslib</form>
   <lemma>příslib</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W28</w.rf>
   <form>prezidenta</form>
   <lemma>prezident</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W29</w.rf>
   <form>E.S.F</form>
   <lemma>E.S.F</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W31</w.rf>
   <form>ucházet</form>
   <lemma>ucházet_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W32</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W33</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W34</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W35</w.rf>
   <form>šampionát</form>
   <lemma>šampionát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W37</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W38</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W39</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W40</w.rf>
   <form>2011</form>
   <lemma>2011</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W41</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W42</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W43</w.rf>
   <form>upozornil</form>
   <lemma>upozornit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W44</w.rf>
   <form>Jozef</form>
   <lemma>Jozef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W45</w.rf>
   <form>Dankovič</form>
   <lemma>Dankovič_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-moravskoslezsky50303.txt-001-p7s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-moravskoslezsky50303.txt-001-p7s1W46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
