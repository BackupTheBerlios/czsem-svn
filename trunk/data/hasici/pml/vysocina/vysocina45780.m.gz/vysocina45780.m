<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina45780.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina45780.txt-001-p1s1">
  <m id="m-vysocina45780.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W3</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W5</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W6</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W7</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W8</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W9</w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W10</w.rf>
   <form>chata</form>
   <lemma>chata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W12</w.rf>
   <form>plamenech</form>
   <lemma>plamen</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45780.txt-001-p1s2">
  <m id="m-vysocina45780.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W3</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W4</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W5</w.rf>
   <form>C</form>
   <lemma>C-3`100</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W6</w.rf>
   <form>proudy</form>
   <lemma>proud</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W8</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W10</w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PPXP3--3-------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W11</w.rf>
   <form>zabránit</form>
   <lemma>zabránit_:W_^(někomu_v_něčem)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W12</w.rf>
   <form>rozšíření</form>
   <lemma>rozšíření_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W13</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W14</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W15</w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45780.txt-001-p1s3">
  <m id="m-vysocina45780.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W2</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W6</w.rf>
   <form>chatě</form>
   <lemma>chata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W7</w.rf>
   <form>nacházela</form>
   <lemma>nacházet_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W8</w.rf>
   <form>propan-butanová</form>
   <lemma>propan-butan</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W9</w.rf>
   <form>láhev</form>
   <lemma>láhev</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W11</w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W12</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W13</w.rf>
   <form>vynesli</form>
   <lemma>vynést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W15</w.rf>
   <form>následně</form>
   <lemma>následně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W16</w.rf>
   <form>ochlazovali</form>
   <lemma>ochlazovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p1s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45780.txt-001-p2s1">
  <m id="m-vysocina45780.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W2</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W4</w.rf>
   <form>57</form>
   <lemma>57</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W6</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W7</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W8</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W9</w.rf>
   <form>předáno</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W10</w.rf>
   <form>majiteli</form>
   <lemma>majitel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45780.txt-001-p2s2">
  <m id="m-vysocina45780.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W4</w.rf>
   <form>Dolní</form>
   <lemma>Dolní_;G</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W5</w.rf>
   <form>Cerekve</form>
   <lemma>Cerekev_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W8</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W9</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W10</w.rf>
   <form>vrátili</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W11</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W12</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W13</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W14</w.rf>
   <form>hodiny</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W15</w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W17</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W18</w.rf>
   <form>požářiště</form>
   <lemma>požářiště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W19</w.rf>
   <form>zkontrolovali</form>
   <lemma>zkontrolovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45780.txt-001-p2s3">
  <m id="m-vysocina45780.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s3W1</w.rf>
   <form>Zasahovat</form>
   <lemma>zasahovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s3W2</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s3W3</w.rf>
   <form>nemuseli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p2s3W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45780.txt-001-p3s1">
  <m id="m-vysocina45780.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s1W3</w.rf>
   <form>obešel</form>
   <lemma>obejít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s1W4</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s1W5</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s1W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45780.txt-001-p3s2">
  <m id="m-vysocina45780.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W2</w.rf>
   <form>způsobená</form>
   <lemma>způsobený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W3</w.rf>
   <form>požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W5</w.rf>
   <form>stanovena</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W7</w.rf>
   <form>690000</form>
   <form_change>num_normalization</form_change>
   <lemma>690000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W8</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45780.txt-001-p3s3">
  <m id="m-vysocina45780.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W4</w.rf>
   <form>nadále</form>
   <lemma>nadále</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W6</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W7</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W8</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-vysocina45780.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45780.txt-001-p3s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
