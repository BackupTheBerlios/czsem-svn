<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina38933.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina38933.txt-001-p1s1">
  <m id="m-vysocina38933.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W4</w.rf>
   <form>zjištěno</form>
   <lemma>zjistit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W6</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W8</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W11</w.rf>
   <form>doprovodného</form>
   <lemma>doprovodný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W12</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W13</w.rf>
   <form>štábu</form>
   <lemma>štáb</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W14</w.rf>
   <form>televize</form>
   <lemma>televize</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina38933.txt-001-p1s2">
  <m id="m-vysocina38933.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W2</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W3</w.rf>
   <form>dohašení</form>
   <lemma>dohašení_^(*4sit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W5</w.rf>
   <form>evakuaci</form>
   <lemma>evakuace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W6</w.rf>
   <form>materiálu</form>
   <lemma>materiál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W8</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina38933.txt-001-p1s3">
  <m id="m-vysocina38933.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W3</w.rf>
   <form>zasahovaly</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W4</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W5</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W8</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W9</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W10</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W11</w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina38933.txt-001-p2s1">
  <m id="m-vysocina38933.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W3</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W4</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W6</w.rf>
   <form>1900000</form>
   <form_change>num_normalization</form_change>
   <lemma>1900000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W7</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W9</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W10</w.rf>
   <form>uchráněny</form>
   <lemma>uchránit</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W11</w.rf>
   <form>hodnoty</form>
   <lemma>hodnota</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W13</w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W14</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W15</w.rf>
   <form>miliónů</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W16</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p2s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina38933.txt-001-p3s1">
  <m id="m-vysocina38933.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W1</w.rf>
   <form>Jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W2</w.rf>
   <form>příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W5</w.rf>
   <form>stanovena</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W6</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W7</w.rf>
   <form>závada</form>
   <lemma>závada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W9</w.rf>
   <form>přímotopu</form>
   <lemma>přímotop</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina38933.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina38933.txt-001-p3s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
