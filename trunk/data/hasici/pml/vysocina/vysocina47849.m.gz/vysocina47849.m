<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina47849.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina47849.txt-001-p1s1">
  <m id="m-vysocina47849.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W2</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W3</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W4</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W5</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W6</w.rf>
   <form>střetu</form>
   <lemma>střet</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W7</w.rf>
   <form>maďarského</form>
   <lemma>maďarský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W8</w.rf>
   <form>kamionu</form>
   <lemma>kamión</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W9</w.rf>
   <form>Scania</form>
   <lemma>Scania_;K_,t</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W10</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W11</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W12</w.rf>
   <form>kravami</form>
   <lemma>kráva</lemma>
   <tag>NNFP7-----A---1</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s2">
  <m id="m-vysocina47849.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W1</w.rf>
   <form>Následně</form>
   <lemma>následně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W2</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W3</w.rf>
   <form>kamionu</form>
   <lemma>kamión</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W4</w.rf>
   <form>narazil</form>
   <lemma>narazit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W5</w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W6</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W7</w.rf>
   <form>Ford</form>
   <lemma>Ford-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W8</w.rf>
   <form>Escort</form>
   <lemma>Escort-2_;R_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s3">
  <m id="m-vysocina47849.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W2</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W3</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W4</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W5</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W6</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W7</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W8</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W9</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W11</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W12</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W13</w.rf>
   <form>odvezla</form>
   <lemma>odvézt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W14</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W15</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W16</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s4">
  <m id="m-vysocina47849.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W1</w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W3</w.rf>
   <form>krav</form>
   <lemma>kráva</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W6</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W7</w.rf>
   <form>usmrcena</form>
   <lemma>usmrtit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W9</w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W10</w.rf>
   <form>zraněna</form>
   <lemma>zranit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W12</w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W13</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W14</w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W15</w.rf>
   <form>utracena</form>
   <lemma>utratit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W16</w.rf>
   <form>přivolaným</form>
   <lemma>přivolaný_^(*2t)</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W17</w.rf>
   <form>veterinářem</form>
   <lemma>veterinář</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s4W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s5">
  <m id="m-vysocina47849.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W1</w.rf>
   <form>Hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W3</w.rf>
   <form>nahlášena</form>
   <lemma>nahlásit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W4</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W5</w.rf>
   <form>zatoulaná</form>
   <lemma>zatoulaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W6</w.rf>
   <form>kráva</form>
   <lemma>kráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W7</w.rf>
   <form>cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W9</w.rf>
   <form>67</form>
   <lemma>67</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W10</w.rf>
   <form>km</form>
   <lemma>km-1`kilometr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W11</w.rf>
   <form>dálnice</form>
   <lemma>dálnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W12</w.rf>
   <form>D1</form>
   <lemma>D1_:B_^(dálnice_v_ČR)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W13</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W14</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W15</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W17</w.rf>
   <form>Prahu</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s6">
  <m id="m-vysocina47849.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W1</w.rf>
   <form>Než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W3</w.rf>
   <form>stačili</form>
   <lemma>stačit_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W4</w.rf>
   <form>zaběhlé</form>
   <lemma>zaběhlý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W5</w.rf>
   <form>zvíře</form>
   <lemma>zvíře</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W6</w.rf>
   <form>odchytit</form>
   <lemma>odchytit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W8</w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W9</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W10</w.rf>
   <form>příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W11</w.rf>
   <form>tragické</form>
   <lemma>tragický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W12</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W13</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W14</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W15</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W16</w.rf>
   <form>VW</form>
   <lemma>VW-1_:B_;R_,t_^(automobil_značky_Volkswagen)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W17</w.rf>
   <form>Golf</form>
   <lemma>Golf-2_;R_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W19</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W20</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W21</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W22</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W23</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W25</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W26</w.rf>
   <form>usmrceny</form>
   <lemma>usmrtit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s6W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s7">
  <m id="m-vysocina47849.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W2</w.rf>
   <form>67</form>
   <lemma>67</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W3</w.rf>
   <form>km</form>
   <lemma>km-1`kilometr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W4</w.rf>
   <form>dálnice</form>
   <lemma>dálnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W5</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W8</w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W9</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W10</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W11</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W13</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W14</w.rf>
   <form>nedobrzdil</form>
   <lemma>dobrzdit_:W</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W16</w.rf>
   <form>narazil</form>
   <lemma>narazit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W17</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W18</w.rf>
   <form>sraženého</form>
   <lemma>sražený_^(*4zit)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W19</w.rf>
   <form>zvířete</form>
   <lemma>zvíře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s7W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s8">
  <m id="m-vysocina47849.txt-001-p1s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W1</w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W4</w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W5</w.rf>
   <form>obešla</form>
   <lemma>obejít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W6</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W7</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W8</w.rf>
   <form>škodou</form>
   <lemma>škoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W10</w.rf>
   <form>majetku</form>
   <lemma>majetek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s8W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s9">
  <m id="m-vysocina47849.txt-001-p1s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W1</w.rf>
   <form>Kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W2</w.rf>
   <form>půlnoci</form>
   <lemma>půlnoc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W3</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W5</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W8</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W9</w.rf>
   <form>dálnice</form>
   <lemma>dálnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W11</w.rf>
   <form>toulá</form>
   <lemma>toulat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W12</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W13</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W14</w.rf>
   <form>kusů</form>
   <lemma>kus</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W15</w.rf>
   <form>krav</form>
   <lemma>kráva</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s9W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p1s10">
  <m id="m-vysocina47849.txt-001-p1s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s10W1</w.rf>
   <form>Došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s10W2</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s10W3</w.rf>
   <form>odchytu</form>
   <lemma>odchyt</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s10W4</w.rf>
   <form>zvířat</form>
   <lemma>zvíře</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p1s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p1s10W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p2s1">
  <m id="m-vysocina47849.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W3</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W4</w.rf>
   <form>probíhala</form>
   <lemma>probíhat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W5</w.rf>
   <form>spolupráce</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W7</w.rf>
   <form>Policií</form>
   <lemma>policie</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W8</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W9</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W10</w.rf>
   <form>vyšetřování</form>
   <lemma>vyšetřování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W11</w.rf>
   <form>dopravních</form>
   <lemma>dopravní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W12</w.rf>
   <form>nehod</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p2s2">
  <m id="m-vysocina47849.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W2</w.rf>
   <form>uklízeli</form>
   <lemma>uklízet_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W3</w.rf>
   <form>dálnici</form>
   <lemma>dálnice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W5</w.rf>
   <form>pomáhali</form>
   <lemma>pomáhat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W6</w.rf>
   <form>odtahové</form>
   <lemma>odtahový</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W7</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W9</w.rf>
   <form>celkově</form>
   <lemma>celkově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W10</w.rf>
   <form>zajišťovali</form>
   <lemma>zajišťovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W11</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W12</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p2s3">
  <m id="m-vysocina47849.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s3W1</w.rf>
   <form>Zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s3W3</w.rf>
   <form>ukončen</form>
   <lemma>ukončit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s3W4</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s3W5</w.rf>
   <form>druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s3W6</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s3W7</w.rf>
   <form>ranní</form>
   <lemma>ranní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p2s4">
  <m id="m-vysocina47849.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W2</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W3</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W5</w.rf>
   <form>dálnice</form>
   <lemma>dálnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W6</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W7</w.rf>
   <form>aspoň</form>
   <lemma>aspoň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W8</w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W9</w.rf>
   <form>pruhem</form>
   <lemma>pruh</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W10</w.rf>
   <form>průjezdná</form>
   <lemma>průjezdný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina47849.txt-001-p2s5">
  <m id="m-vysocina47849.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W3</w.rf>
   <form>dálnici</form>
   <lemma>dálnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W4</w.rf>
   <form>D1</form>
   <lemma>D1_:B_^(dálnice_v_ČR)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W6</w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W7</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W8</w.rf>
   <form>zatoulanými</form>
   <lemma>zatoulaný_^(*2t)</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W9</w.rf>
   <form>kravami</form>
   <lemma>kráva</lemma>
   <tag>NNFP7-----A---1</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W10</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W11</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W13</w.rf>
   <form>ranních</form>
   <lemma>ranní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W14</w.rf>
   <form>hodinách</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W16</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W17</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W19</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W21</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W22</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W23</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W24</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W25</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W27</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W28</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W29</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W30</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W31</w.rf>
   <form>škodě</form>
   <lemma>škoda</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W32</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W33</w.rf>
   <form>majetku</form>
   <lemma>majetek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina47849.txt-001-p2s5W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina47849.txt-001-p2s5W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
