<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina48986.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina48986.txt-001-p1s1">
  <m id="m-vysocina48986.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W1</w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W2</w.rf>
   <form>preventivní</form>
   <lemma>preventivní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W3</w.rf>
   <form>kampaň</form>
   <lemma>kampaň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W4</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W5</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W6</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W7</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W8</w.rf>
   <form>Vysočina</form>
   <lemma>vysočina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W9</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W10</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W11</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W12</w.rf>
   <form>dalšími</form>
   <lemma>další</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W13</w.rf>
   <form>složkami</form>
   <lemma>složka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W14</w.rf>
   <form>integrovaného</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W15</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W16</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W18</w.rf>
   <form>reklamní</form>
   <lemma>reklamní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W19</w.rf>
   <form>firmou</form>
   <lemma>firma</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W20</w.rf>
   <form>SNIP</form>
   <lemma>Snip</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W21</w.rf>
   <form>&amp;</form>
   <lemma>&amp;</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W22</w.rf>
   <form>CO</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W23</w.rf>
   <form>navazuje</form>
   <lemma>navazovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W25</w.rf>
   <form>preventivní</form>
   <lemma>preventivní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W26</w.rf>
   <form>akci</form>
   <lemma>akce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W27</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W28</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W29</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W30</w.rf>
   <form>Bezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W31</w.rf>
   <form>cestování</form>
   <lemma>cestování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W32</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s1W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina48986.txt-001-p1s2">
  <m id="m-vysocina48986.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W1</w.rf>
   <form>Cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W2</w.rf>
   <form>preventivní</form>
   <lemma>preventivní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W3</w.rf>
   <form>kampaně</form>
   <lemma>kampaň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W5</w.rf>
   <form>seznámit</form>
   <lemma>seznámit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W6</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W7</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W8</w.rf>
   <form>připomenout</form>
   <lemma>připomenout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W9</w.rf>
   <form>čísla</form>
   <lemma>číslo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W10</w.rf>
   <form>tísňového</form>
   <lemma>tísňový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W11</w.rf>
   <form>volání</form>
   <lemma>volání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W13</w.rf>
   <form>základní</form>
   <lemma>základní_,s</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W14</w.rf>
   <form>postup</form>
   <lemma>postup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W15</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W16</w.rf>
   <form>volání</form>
   <lemma>volání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W18</w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W19</w.rf>
   <form>linky</form>
   <lemma>link-1_;c</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p1s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina48986.txt-001-p2s1">
  <m id="m-vysocina48986.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W1</w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W2</w.rf>
   <form>preventivní</form>
   <lemma>preventivní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W3</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W4</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W5</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W6</w.rf>
   <form>různou</form>
   <lemma>různý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W7</w.rf>
   <form>grafickou</form>
   <lemma>grafický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W8</w.rf>
   <form>podobu</form>
   <lemma>podoba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W10</w.rf>
   <form>cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W11</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W12</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W13</w.rf>
   <form>rozšířit</form>
   <lemma>rozšířit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W14</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W15</w.rf>
   <form>možností</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W17</w.rf>
   <form>městské</form>
   <lemma>městský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W18</w.rf>
   <form>hromadné</form>
   <lemma>hromadný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W19</w.rf>
   <form>dopravy</form>
   <lemma>doprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W20</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W21</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W22</w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W25</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W26</w.rf>
   <form>veřejná</form>
   <lemma>veřejný</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W27</w.rf>
   <form>prostranství</form>
   <lemma>prostranství</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p2s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina48986.txt-001-p3s1">
  <m id="m-vysocina48986.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W2</w.rf>
   <form>závěr</form>
   <lemma>závěr_^(př._z_jednání,_úvah)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W3</w.rf>
   <form>zbývá</form>
   <lemma>zbývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W5</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W6</w.rf>
   <form>položit</form>
   <lemma>položit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W7</w.rf>
   <form>otázky</form>
   <lemma>otázka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W10</w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W11</w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W12</w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W14</w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W15</w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W16</w.rf>
   <form>zavolat</form>
   <lemma>zavolat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W18</w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W19</w.rf>
   <form>budu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W20</w.rf>
   <form>potřebovat</form>
   <lemma>potřebovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W21</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W22</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W23</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W25</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W26</w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W28</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W29</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W30</w.rf>
   <form>důležité</form>
   <lemma>důležitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W31</w.rf>
   <form>sdělit</form>
   <lemma>sdělit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W33</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W34</w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W35</w.rf>
   <form>správná</form>
   <lemma>správný_^(podle_něj._měřítek;_př._chlap,_míra,...)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W36</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W37</w.rf>
   <form>přijela</form>
   <lemma>přijet-1_^(např._autem)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W38</w.rf>
   <form>včas</form>
   <lemma>včas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W39</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W40</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W41</w.rf>
   <form>dostatečném</form>
   <lemma>dostatečný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W42</w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W43</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W44</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p3s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p3s1W45</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina48986.txt-001-p4s1">
  <m id="m-vysocina48986.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p4s1W1</w.rf>
   <form>Plakát</form>
   <lemma>plakát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p4s1W2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p4s1W3</w.rf>
   <form>tísňové</form>
   <lemma>tísňový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p4s1W4</w.rf>
   <form>volání</form>
   <lemma>volání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p4s1W5</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p4s1W6</w.rf>
   <form>240kb</form>
   <lemma>240kb</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-vysocina48986.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48986.txt-001-p4s1W7</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
