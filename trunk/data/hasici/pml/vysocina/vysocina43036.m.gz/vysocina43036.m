<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina43036.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina43036.txt-001-p1s1">
  <m id="m-vysocina43036.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s1W1</w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s1W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s1W3</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s1W5</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s1W6</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s1W7</w.rf>
   <form>zvláštního</form>
   <lemma>zvláštní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s1W8</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43036.txt-001-p1s2">
  <m id="m-vysocina43036.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W1</w.rf>
   <form>Příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W2</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W5</w.rf>
   <form>nedohašené</form>
   <lemma>dohašený_^(*4sit)</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W6</w.rf>
   <form>ohniště</form>
   <lemma>ohniště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W7</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W8</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W9</w.rf>
   <form>klestí</form>
   <lemma>klestí</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W11</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W12</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W13</w.rf>
   <form>prováděno</form>
   <lemma>provádět_:T</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W14</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W15</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W17</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W21</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W22</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W23</w.rf>
   <form>dní</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W24</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W25</w.rf>
   <form>vznikem</form>
   <lemma>vznik</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W26</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43036.txt-001-p1s3">
  <m id="m-vysocina43036.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W1</w.rf>
   <form>Neuhašené</form>
   <lemma>uhašený_^(*4sit)</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W2</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W3</w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W4</w.rf>
   <form>dohašené</form>
   <lemma>dohašený_^(*4sit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W5</w.rf>
   <form>ohniště</form>
   <lemma>ohniště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W6</w.rf>
   <form>skrývá</form>
   <lemma>skrývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W7</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W8</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W9</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W10</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W11</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W12</w.rf>
   <form>delší</form>
   <lemma>dlouhý-1_^(fyz._délka;_př._dlouhá_tyč)</lemma>
   <tag>AAFS6----2A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W13</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43036.txt-001-p1s4">
  <m id="m-vysocina43036.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s4W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s4W2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s4W3</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s4W5</w.rf>
   <form>Skočidolovicích</form>
   <lemma>Skočidolovice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s4W6</w.rf>
   <form>vědí</form>
   <lemma>vědět</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-vysocina43036.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43036.txt-001-p1s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
