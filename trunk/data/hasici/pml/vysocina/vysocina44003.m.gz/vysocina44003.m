<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina44003.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina44003.txt-001-p1s1">
  <m id="m-vysocina44003.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W2</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W4</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W6</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W9</w.rf>
   <form>Humpolci</form>
   <lemma>Humpolec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W11</w.rf>
   <form>Masarykovy</form>
   <lemma>Masarykův_;S_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W12</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W14</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W15</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W16</w.rf>
   <form>osobním</form>
   <lemma>osobní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W17</w.rf>
   <form>automobilem</form>
   <lemma>automobil</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W18</w.rf>
   <form>sraženo</form>
   <lemma>srazit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W19</w.rf>
   <form>dítě</form>
   <lemma>dítě</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W22</w.rf>
   <form>holčička</form>
   <lemma>holčička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p1s2">
  <m id="m-vysocina44003.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W2</w.rf>
   <form>pomohli</form>
   <lemma>pomoci</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W4</w.rf>
   <form>naložením</form>
   <lemma>naložení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W5</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W7</w.rf>
   <form>sanitky</form>
   <lemma>sanitka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W8</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W9</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W10</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W12</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W13</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W14</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W16</w.rf>
   <form>událost</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W17</w.rf>
   <form>předali</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W18</w.rf>
   <form>Policii</form>
   <lemma>policie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W19</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W20</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W21</w.rf>
   <form>vyšetřování</form>
   <lemma>vyšetřování_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p1s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p2s1">
  <m id="m-vysocina44003.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W2</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W4</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W6</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W7</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W8</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W9</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W11</w.rf>
   <form>Jihlavy</form>
   <lemma>Jihlava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W13</w.rf>
   <form>záchranu</form>
   <lemma>záchrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W14</w.rf>
   <form>sražené</form>
   <lemma>sražený_^(*4zit)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W15</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W16</w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W18</w.rf>
   <form>kolejišti</form>
   <lemma>kolejiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W20</w.rf>
   <form>Malém</form>
   <lemma>malý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W21</w.rf>
   <form>Beranově</form>
   <lemma>Beranov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p2s2">
  <m id="m-vysocina44003.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W3</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W4</w.rf>
   <form>pomáhali</form>
   <lemma>pomáhat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W5</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W6</w.rf>
   <form>resuscitací</form>
   <lemma>resuscitace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W7</w.rf>
   <form>zraněného</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W9</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W10</w.rf>
   <form>transportem</form>
   <lemma>transport</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W12</w.rf>
   <form>sanitky</form>
   <lemma>sanitka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p2s3">
  <m id="m-vysocina44003.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W1</w.rf>
   <form>Místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W3</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W4</w.rf>
   <form>předáno</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W5</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W6</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W7</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W8</w.rf>
   <form>dráhy</form>
   <lemma>dráha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W9</w.rf>
   <form>Brno</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p2s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p3s1">
  <m id="m-vysocina44003.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W2</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W4</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W6</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W9</w.rf>
   <form>Třeště</form>
   <lemma>Třešť_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W11</w.rf>
   <form>Jihlavy</form>
   <lemma>Jihlava_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W13</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W14</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W15</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W17</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W18</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W19</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W20</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W21</w.rf>
   <form>Škody</form>
   <lemma>Škoda-3_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W22</w.rf>
   <form>Favorit</form>
   <lemma>favorit-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W24</w.rf>
   <form>centru</form>
   <lemma>centrum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W25</w.rf>
   <form>Dolní</form>
   <lemma>Dolní_;G</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W26</w.rf>
   <form>Cerekve</form>
   <lemma>Cerekev_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p3s2">
  <m id="m-vysocina44003.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W2</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W3</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W5</w.rf>
   <form>poškozen</form>
   <lemma>poškodit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W6</w.rf>
   <form>hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W7</w.rf>
   <form>uzávěr</form>
   <lemma>uzávěr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W8</w.rf>
   <form>plynu</form>
   <lemma>plyn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W9</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS2----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W11</w.rf>
   <form>rodinných</form>
   <lemma>rodinný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W12</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W15</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W17</w.rf>
   <form>masivnímu</form>
   <lemma>masivní</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W18</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W19</w.rf>
   <form>zemního</form>
   <lemma>zemní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W20</w.rf>
   <form>plynu</form>
   <lemma>plyn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p3s3">
  <m id="m-vysocina44003.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W2</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W3</w.rf>
   <form>odtlačili</form>
   <lemma>odtlačit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W5</w.rf>
   <form>provizorně</form>
   <lemma>provizorně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W6</w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W7</w.rf>
   <form>uzavřeli</form>
   <lemma>uzavřít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W8</w.rf>
   <form>ventil</form>
   <lemma>ventil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W9</w.rf>
   <form>uzávěru</form>
   <lemma>uzávěr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W10</w.rf>
   <form>plynu</form>
   <lemma>plyn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p3s4">
  <m id="m-vysocina44003.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W3</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W5</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W6</w.rf>
   <form>povolána</form>
   <lemma>povolat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W7</w.rf>
   <form>plynařská</form>
   <lemma>plynařský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W8</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p3s5">
  <m id="m-vysocina44003.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W2</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W4</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W6</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W7</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W8</w.rf>
   <form>předáno</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W9</w.rf>
   <form>majiteli</form>
   <lemma>majitel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W10</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W11</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W12</w.rf>
   <form>opatřeními</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s5W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina44003.txt-001-p3s6">
  <m id="m-vysocina44003.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W3</w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W4</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W5</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W7</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W8</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W9</w.rf>
   <form>nehodu</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W10</w.rf>
   <form>vyšetřovala</form>
   <lemma>vyšetřovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina44003.txt-001-p3s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina44003.txt-001-p3s6W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
