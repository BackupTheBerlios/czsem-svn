<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina42217.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina42217.txt-001-p1s1">
  <m id="m-vysocina42217.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W1</w.rf>
   <form>Pomyslel</form>
   <lemma>pomyslet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W2</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W5</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W6</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W8</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W9</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W11</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W12</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W13</w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W14</w.rf>
   <form>zahrádkář</form>
   <lemma>zahrádkář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W15</w.rf>
   <form>začal</form>
   <lemma>začít-1</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W16</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W17</w.rf>
   <form>jarním</form>
   <lemma>jarní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W18</w.rf>
   <form>úklidem</form>
   <lemma>úklid</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W19</w.rf>
   <form>zahrádky</form>
   <lemma>zahrádka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p1s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p2s1">
  <m id="m-vysocina42217.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W1</w.rf>
   <form>Během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W2</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W3</w.rf>
   <form>málo</form>
   <lemma>málo-1_^(málo_+_2._p.,_málo_peněz)</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W4</w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W5</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W7</w.rf>
   <form>vyrozuměn</form>
   <lemma>vyrozumět_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W9</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W10</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W11</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W12</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W13</w.rf>
   <form>chatky</form>
   <lemma>chatka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W14</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W15</w.rf>
   <form>výrobním</form>
   <lemma>výrobní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W16</w.rf>
   <form>závodem</form>
   <lemma>závod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W17</w.rf>
   <form>Bosch</form>
   <lemma>Bosch_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W18</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W19</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W20</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W21</w.rf>
   <form>Dolech</form>
   <lemma>důl</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p2s2">
  <m id="m-vysocina42217.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W2</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W3</w.rf>
   <form>mého</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W4</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W6</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W7</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W8</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W9</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W10</w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W11</w.rf>
   <form>chata</form>
   <lemma>chata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W13</w.rf>
   <form>plamenech</form>
   <lemma>plamen</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W15</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W16</w.rf>
   <form>zřejmé</form>
   <lemma>zřejmý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W18</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W19</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W20</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W21</w.rf>
   <form>rychlý</form>
   <lemma>rychlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W22</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W23</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W24</w.rf>
   <form>jihlavských</form>
   <lemma>jihlavský</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W25</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W26</w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W27</w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W28</w.rf>
   <form>chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W29</w.rf>
   <form>zachránit</form>
   <lemma>zachránit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p2s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p2s2W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p3s1">
  <m id="m-vysocina42217.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W1</w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W2</w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W3</w.rf>
   <form>neděle</form>
   <lemma>neděle</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W5</w.rf>
   <form>spousty</form>
   <lemma>spousta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W6</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W7</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W9</w.rf>
   <form>procházce</form>
   <lemma>procházka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W11</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W12</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W13</w.rf>
   <form>krátké</form>
   <lemma>krátký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W14</w.rf>
   <form>chvíle</form>
   <lemma>chvíle</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W15</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W17</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W18</w.rf>
   <form>hořící</form>
   <lemma>hořící_^(*3et)</lemma>
   <tag>AGFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W19</w.rf>
   <form>chaty</form>
   <lemma>chata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W20</w.rf>
   <form>spousty</form>
   <lemma>spousta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W21</w.rf>
   <form>diskutujících</form>
   <lemma>diskutující_^(*5ovat)</lemma>
   <tag>AGMP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W22</w.rf>
   <form>občanů</form>
   <lemma>občan</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W24</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W25</w.rf>
   <form>posléze</form>
   <lemma>posléze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W26</w.rf>
   <form>pokračovali</form>
   <lemma>pokračovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W28</w.rf>
   <form>procházce</form>
   <lemma>procházka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p3s2">
  <m id="m-vysocina42217.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W2</w.rf>
   <form>hořící</form>
   <lemma>hořící_^(*3et)</lemma>
   <tag>AGFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W3</w.rf>
   <form>chaty</form>
   <lemma>chata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W5</w.rf>
   <form>pohybovaly</form>
   <lemma>pohybovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W7</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W8</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W10</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W12</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W13</w.rf>
   <form>pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W14</w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W16</w.rf>
   <form>chatou</form>
   <lemma>chata</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W17</w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PZ--4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W18</w.rf>
   <form>společného</form>
   <lemma>společný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p3s3">
  <m id="m-vysocina42217.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W1</w.rf>
   <form>Zjistil</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W2</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W4</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W5</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W6</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W7</w.rf>
   <form>muži</form>
   <lemma>muž</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W9</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W10</w.rf>
   <form>chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W11</w.rf>
   <form>užívali</form>
   <lemma>užívat_:T_^(*3t)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W12</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W13</w.rf>
   <form>svému</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS3----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W14</w.rf>
   <form>celoročnímu</form>
   <lemma>celoroční</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W15</w.rf>
   <form>pobývání</form>
   <lemma>pobývání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p3s4">
  <m id="m-vysocina42217.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W2</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W3</w.rf>
   <form>slov</form>
   <lemma>slovo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W5</w.rf>
   <form>pohledů</form>
   <lemma>pohled</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W6</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W7</w.rf>
   <form>vycítil</form>
   <lemma>vycítit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W9</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W10</w.rf>
   <form>nenávratně</form>
   <lemma>návratně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W11</w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W12</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W13</w.rf>
   <form>svoji</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W14</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W15</w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W16</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W17</w.rf>
   <form>hlavou</form>
   <lemma>hlava</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W18</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W20</w.rf>
   <form>náhlou</form>
   <lemma>náhlý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W21</w.rf>
   <form>situaci</form>
   <lemma>situace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W22</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W23</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W24</w.rf>
   <form>muset</form>
   <lemma>muset</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W25</w.rf>
   <form>okamžitě</form>
   <lemma>okamžitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W26</w.rf>
   <form>řešit</form>
   <lemma>řešit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W27</w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p3s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p3s4W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p4s1">
  <m id="m-vysocina42217.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W1</w.rf>
   <form>Požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W2</w.rf>
   <form>vznikla</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W3</w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W4</w.rf>
   <form>cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W5</w.rf>
   <form>20000</form>
   <form_change>num_normalization</form_change>
   <lemma>20000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W6</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W8</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W9</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W11</w.rf>
   <form>daném</form>
   <lemma>daný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W12</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W13</w.rf>
   <form>zanedbatelná</form>
   <lemma>zanedbatelný_^(*4)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W15</w.rf>
   <form>bezvýznamná</form>
   <lemma>bezvýznamný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W16</w.rf>
   <form>oproti</form>
   <lemma>oproti</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W17</w.rf>
   <form>faktu</form>
   <lemma>fakt</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W19</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W20</w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PZM-1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W21</w.rf>
   <form>ztratil</form>
   <lemma>ztratit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W22</w.rf>
   <form>domov</form>
   <lemma>domov</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p4s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p5s1">
  <m id="m-vysocina42217.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W3</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W4</w.rf>
   <form>probíhalo</form>
   <lemma>probíhat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W5</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W6</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W7</w.rf>
   <form>stanovení</form>
   <lemma>stanovení_^(určit)_(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W8</w.rf>
   <form>příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W9</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W10</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p5s2">
  <m id="m-vysocina42217.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s2W2</w.rf>
   <form>současné</form>
   <lemma>současný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s2W3</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s2W5</w.rf>
   <form>příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s2W7</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p5s3">
  <m id="m-vysocina42217.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W1</w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W2</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W3</w.rf>
   <form>stanoveny</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W4</w.rf>
   <form>předběžné</form>
   <lemma>předběžný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W5</w.rf>
   <form>verze</form>
   <lemma>verze</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W7</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W9</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W10</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W11</w.rf>
   <form>prošetřovat</form>
   <lemma>prošetřovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p5s4">
  <m id="m-vysocina42217.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s4W1</w.rf>
   <form>Jednou</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS7----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s4W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s4W3</w.rf>
   <form>nejpravděpodobnějších</form>
   <lemma>pravděpodobný</lemma>
   <tag>AAFP2----3A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s4W4</w.rf>
   <form>verzí</form>
   <lemma>verze</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s4W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s4W6</w.rf>
   <form>úmyslné</form>
   <lemma>úmyslný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s4W7</w.rf>
   <form>zapálení</form>
   <lemma>zapálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p5s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p6s1">
  <m id="m-vysocina42217.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W2</w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W3</w.rf>
   <form>zbytku</form>
   <lemma>zbytek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W4</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W5</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W7</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W8</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W9</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W10</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W11</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W13</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W14</w.rf>
   <form>hlavním</form>
   <lemma>hlavní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W15</w.rf>
   <form>důvodem</form>
   <lemma>důvod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W16</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W17</w.rf>
   <form>vznik</form>
   <lemma>vznik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W18</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W19</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W20</w.rf>
   <form>lidská</form>
   <lemma>lidský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W21</w.rf>
   <form>nedbalost</form>
   <lemma>nedbalost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W22</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W23</w.rf>
   <form>úmyslné</form>
   <lemma>úmyslný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W24</w.rf>
   <form>zapálení</form>
   <lemma>zapálení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p6s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p7s1">
  <m id="m-vysocina42217.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W1</w.rf>
   <form>Jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W3</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W5</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W6</w.rf>
   <form>dřevotřískových</form>
   <lemma>dřevotřískový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W7</w.rf>
   <form>desek</form>
   <lemma>deska</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W9</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W11</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W12</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W13</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W14</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W15</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W17</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W18</w.rf>
   <form>Tovární</form>
   <lemma>tovární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W20</w.rf>
   <form>Třešti</form>
   <lemma>Třešť_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W22</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W23</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W24</w.rf>
   <form>likvidován</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W25</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W26</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W27</w.rf>
   <form>C</form>
   <lemma>c-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W28</w.rf>
   <form>proudu</form>
   <lemma>proud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p7s2">
  <m id="m-vysocina42217.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s2W3</w.rf>
   <form>beze</form>
   <lemma>bez-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s2W4</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p7s2W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p8s1">
  <m id="m-vysocina42217.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W1</w.rf>
   <form>Druhým</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W2</w.rf>
   <form>požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W4</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W5</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W7</w.rf>
   <form>sklepě</form>
   <lemma>sklep</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W9</w.rf>
   <form>Křižíkově</form>
   <lemma>Křižíkův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W10</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W12</w.rf>
   <form>Jihlavě</form>
   <lemma>Jihlava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W14</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W15</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W16</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W17</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W18</w.rf>
   <form>vysokotlaku</form>
   <lemma>vysokotlak</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p8s2">
  <m id="m-vysocina42217.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s2W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s2W3</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s2W4</w.rf>
   <form>obešel</form>
   <lemma>obejít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s2W5</w.rf>
   <form>beze</form>
   <lemma>bez-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s2W6</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina42217.txt-001-p8s3">
  <m id="m-vysocina42217.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s3W1</w.rf>
   <form>Příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s3W3</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s3W4</w.rf>
   <form>odhozený</form>
   <lemma>odhozený_^(*4dit)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s3W5</w.rf>
   <form>nedopalek</form>
   <lemma>nedopalek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s3W6</w.rf>
   <form>cigarety</form>
   <lemma>cigareta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina42217.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina42217.txt-001-p8s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
