<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina43039.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina43039.txt-001-p1s1">
  <m id="m-vysocina43039.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W2</w.rf>
   <form>osobním</form>
   <lemma>osobní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W3</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W5</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W6</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W7</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W8</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W9</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43039.txt-001-p1s2">
  <m id="m-vysocina43039.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W3</w.rf>
   <form>havarovaného</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W4</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W5</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W6</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W7</w.rf>
   <form>hydraulického</form>
   <lemma>hydraulický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W8</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W9</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W10</w.rf>
   <form>zraněnou</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W11</w.rf>
   <form>osobu</form>
   <lemma>osoba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W13</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W14</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W15</w.rf>
   <form>zraněné</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W16</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W17</w.rf>
   <form>předali</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W19</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W20</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W21</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W22</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43039.txt-001-p1s3">
  <m id="m-vysocina43039.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s3W1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s3W2</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS2----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s3W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s3W4</w.rf>
   <form>cestujících</form>
   <lemma>cestující_^(*5ovat)</lemma>
   <tag>AGMP2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s3W5</w.rf>
   <form>lékař</form>
   <lemma>lékař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s3W6</w.rf>
   <form>konstatoval</form>
   <lemma>konstatovat_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s3W7</w.rf>
   <form>smrt</form>
   <lemma>smrt</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p1s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43039.txt-001-p2s1">
  <m id="m-vysocina43039.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W3</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W5</w.rf>
   <form>ranních</form>
   <lemma>ranní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W6</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W7</w.rf>
   <form>probíhalo</form>
   <lemma>probíhat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W8</w.rf>
   <form>vyšetřování</form>
   <lemma>vyšetřování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W9</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W10</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43039.txt-001-p2s2">
  <m id="m-vysocina43039.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W1</w.rf>
   <form>Před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W2</w.rf>
   <form>sedmou</form>
   <lemma>sedma</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W3</w.rf>
   <form>hodinou</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W4</w.rf>
   <form>ranní</form>
   <lemma>ranní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W6</w.rf>
   <form>naložili</form>
   <lemma>naložit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W7</w.rf>
   <form>havarované</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W8</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W10</w.rf>
   <form>odtahovou</form>
   <lemma>odtahový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W11</w.rf>
   <form>službu</form>
   <lemma>služba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W13</w.rf>
   <form>doklidili</form>
   <lemma>doklidit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W14</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43039.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43039.txt-001-p2s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
