<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina43599.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina43599.txt-001-p1s1">
  <m id="m-vysocina43599.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W2</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W4</w.rf>
   <form>53</form>
   <lemma>53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W8</w.rf>
   <form>Krajské</form>
   <lemma>krajský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W9</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W11</w.rf>
   <form>informační</form>
   <lemma>informační</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W12</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W13</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W14</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W15</w.rf>
   <form>Vysočina</form>
   <lemma>vysočina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W16</w.rf>
   <form>ohlášena</form>
   <lemma>ohlásit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W17</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W18</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W19</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W20</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W21</w.rf>
   <form>Obrataň</form>
   <lemma>Obrataň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W22</w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W24</w.rf>
   <form>obec</form>
   <lemma>obec</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W25</w.rf>
   <form>Kámen</form>
   <lemma>kámen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W27</w.rf>
   <form>Pelhřimovsku</form>
   <lemma>Pelhřimovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p1s2">
  <m id="m-vysocina43599.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W3</w.rf>
   <form>vyjeli</form>
   <lemma>vyjet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W5</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W6</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W7</w.rf>
   <form>Pacov</form>
   <lemma>Pacov_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W9</w.rf>
   <form>Pelhřimov</form>
   <lemma>Pelhřimov_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p1s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p2s1">
  <m id="m-vysocina43599.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W2</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W3</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W4</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W5</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W6</w.rf>
   <form>vyjetí</form>
   <lemma>vyjetí_^(*1)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W7</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W8</w.rf>
   <form>Volkswagen</form>
   <lemma>Volkswagen-1_;K_,x</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W9</w.rf>
   <form>Transporter</form>
   <lemma>Transporter-2_;R_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W10</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W11</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W12</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W13</w.rf>
   <form>svodidla</form>
   <lemma>svodidlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W14</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W15</w.rf>
   <form>čtyřmetrového</form>
   <lemma>čtyřmetrový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W16</w.rf>
   <form>srázu</form>
   <lemma>sráz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p2s2">
  <m id="m-vysocina43599.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s2W1</w.rf>
   <form>Vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s2W2</w.rf>
   <form>skončilo</form>
   <lemma>skončit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s2W3</w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s2W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s2W5</w.rf>
   <form>vodě</form>
   <lemma>voda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s2W6</w.rf>
   <form>místního</form>
   <lemma>místní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s2W7</w.rf>
   <form>rybníka</form>
   <lemma>rybník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p2s3">
  <m id="m-vysocina43599.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W2</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W3</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W4</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W5</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W6</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W7</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W8</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W10</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W11</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W12</w.rf>
   <form>předána</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W13</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W14</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W15</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p2s4">
  <m id="m-vysocina43599.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W2</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W3</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W4</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W5</w.rf>
   <form>pohonných</form>
   <lemma>pohonný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W6</w.rf>
   <form>hmot</form>
   <lemma>hmota</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W8</w.rf>
   <form>cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W9</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W12</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W13</w.rf>
   <form>litrů</form>
   <lemma>l-1`litr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W14</w.rf>
   <form>nafty</form>
   <lemma>nafta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W17</w.rf>
   <form>rybníka</form>
   <lemma>rybník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p2s4W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p3s1">
  <m id="m-vysocina43599.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W4</w.rf>
   <form>povolána</form>
   <lemma>povolat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W5</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W6</w.rf>
   <form>inspekce</form>
   <lemma>inspekce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W7</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W8</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W10</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W11</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W12</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W13</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W14</w.rf>
   <form>Pacov</form>
   <lemma>Pacov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W16</w.rf>
   <form>majitel</form>
   <lemma>majitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W17</w.rf>
   <form>rybníka</form>
   <lemma>rybník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p3s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p4s1">
  <m id="m-vysocina43599.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W2</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W3</w.rf>
   <form>člunu</form>
   <lemma>člun</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W5</w.rf>
   <form>sorbčních</form>
   <lemma>sorbční</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W6</w.rf>
   <form>hadů</form>
   <lemma>had</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W8</w.rf>
   <form>sorbentů</form>
   <lemma>sorbent</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W9</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W10</w.rf>
   <form>skvrnu</form>
   <lemma>skvrna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W12</w.rf>
   <form>vodní</form>
   <lemma>vodní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W13</w.rf>
   <form>ploše</form>
   <lemma>plocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p4s2">
  <m id="m-vysocina43599.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W1</w.rf>
   <form>Před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W2</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W4</w.rf>
   <form>hodinou</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W6</w.rf>
   <form>začalo</form>
   <lemma>začít-1</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W8</w.rf>
   <form>vyprošťováním</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W9</w.rf>
   <form>havarovaného</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W10</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W11</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W12</w.rf>
   <form>jeřábu</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p4s3">
  <m id="m-vysocina43599.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W2</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W4</w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W6</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W7</w.rf>
   <form>úseku</form>
   <lemma>úsek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W9</w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W10</w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W11</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W12</w.rf>
   <form>uzavřena</form>
   <lemma>uzavřít</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p4s4">
  <m id="m-vysocina43599.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W2</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W4</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W7</w.rf>
   <form>zprovozněn</form>
   <lemma>zprovoznit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W8</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W9</w.rf>
   <form>jízdní</form>
   <lemma>jízdní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W10</w.rf>
   <form>pruh</form>
   <lemma>pruh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p4s5">
  <m id="m-vysocina43599.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s5W1</w.rf>
   <form>Pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s5W2</w.rf>
   <form>bagru</form>
   <lemma>bagr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s5W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s5W4</w.rf>
   <form>odbagrována</form>
   <lemma>odbagrovat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s5W5</w.rf>
   <form>kontaminovaná</form>
   <lemma>kontaminovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s5W6</w.rf>
   <form>zemina</form>
   <lemma>zemina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s5W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p4s6">
  <m id="m-vysocina43599.txt-001-p4s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s6W1</w.rf>
   <form>Cca</form>
   <lemma>cca</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s6W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s6W3</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s6W4</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s6W5</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s6W6</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s6W7</w.rf>
   <form>ukončen</form>
   <lemma>ukončit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p4s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p4s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p5s1">
  <m id="m-vysocina43599.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W2</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W4</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W5</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W8</w.rf>
   <form>Jihlavy</form>
   <lemma>Jihlava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W10</w.rf>
   <form>ohlášenou</form>
   <lemma>ohlášený_^(*4sit)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W11</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W12</w.rf>
   <form>nehodu</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W14</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W16</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W17</w.rf>
   <form>nákladního</form>
   <lemma>nákladní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W18</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W20</w.rf>
   <form>109.5</form>
   <form_change>num_normalization</form_change>
   <lemma>109.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W21</w.rf>
   <form>km</form>
   <lemma>km-1`kilometr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W22</w.rf>
   <form>dálnice</form>
   <lemma>dálnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W23</w.rf>
   <form>D1</form>
   <lemma>D1_:B_^(dálnice_v_ČR)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W24</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W25</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W27</w.rf>
   <form>Brno</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p5s2">
  <m id="m-vysocina43599.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W3</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W4</w.rf>
   <form>vyprošťovali</form>
   <lemma>vyprošťovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W5</w.rf>
   <form>zraněnou</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W6</w.rf>
   <form>řidičku</form>
   <lemma>řidička_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W7</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W8</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W9</w.rf>
   <form>Renault</form>
   <lemma>Renault-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W10</w.rf>
   <form>Clio</form>
   <lemma>Clio_;R_^(automobil_Renault_Clio)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W12</w.rf>
   <form>předali</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W13</w.rf>
   <form>jí</form>
   <lemma>on-1_^(ona)</lemma>
   <tag>PPFS3--3-------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W14</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W15</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W16</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p5s3">
  <m id="m-vysocina43599.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s3W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s3W3</w.rf>
   <form>zasahoval</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s3W4</w.rf>
   <form>zdravotnický</form>
   <lemma>zdravotnický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s3W5</w.rf>
   <form>vrtulník</form>
   <lemma>vrtulník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p5s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p6s1">
  <m id="m-vysocina43599.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W2</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W4</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W5</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W6</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W7</w.rf>
   <form>havarovaných</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W8</w.rf>
   <form>automobilů</form>
   <lemma>automobil</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W9</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W10</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p6s2">
  <m id="m-vysocina43599.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W2</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W4</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W6</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W7</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W8</w.rf>
   <form>předáno</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W9</w.rf>
   <form>Policii</form>
   <lemma>policie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W10</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W12</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W14</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W15</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W16</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W18</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W19</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W20</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W21</w.rf>
   <form>připojil</form>
   <lemma>připojit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W22</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W23</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClIS4----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W24</w.rf>
   <form>nákladní</form>
   <lemma>nákladní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W25</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W27</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W28</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W29</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W30</w.rf>
   <form>odpoledních</form>
   <lemma>odpolední</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W31</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s2W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43599.txt-001-p6s3">
  <m id="m-vysocina43599.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W1</w.rf>
   <form>Dálnice</form>
   <lemma>dálnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W2</w.rf>
   <form>D1</form>
   <lemma>D1_:B_^(dálnice_v_ČR)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W5</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W6</w.rf>
   <form>úseku</form>
   <lemma>úsek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W7</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W9</w.rf>
   <form>neprůjezdná</form>
   <lemma>průjezdný</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m-vysocina43599.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43599.txt-001-p6s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
