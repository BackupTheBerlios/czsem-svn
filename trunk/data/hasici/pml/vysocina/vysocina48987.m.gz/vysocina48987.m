<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina48987.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina48987.txt-001-p1s1">
  <m id="m-vysocina48987.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W2</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W3</w.rf>
   <form>Vysočina</form>
   <lemma>vysočina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W5</w.rf>
   <form>touto</form>
   <lemma>tento</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W6</w.rf>
   <form>akcí</form>
   <lemma>akce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W8</w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W9</w.rf>
   <form>Měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W10</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W13</w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W14</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W15</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W16</w.rf>
   <form>snaží</form>
   <lemma>snažit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W17</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W18</w.rf>
   <form>propagaci</form>
   <lemma>propagace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W19</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W20</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W21</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W22</w.rf>
   <form>veřejností</form>
   <lemma>veřejnost_^(*3ý)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina48987.txt-001-p1s2">
  <m id="m-vysocina48987.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W2</w.rf>
   <form>stanicích</form>
   <lemma>stanice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W4</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W5</w.rf>
   <form>prohlédnout</form>
   <lemma>prohlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W6</w.rf>
   <form>zázemí</form>
   <lemma>zázemí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W8</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W9</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W11</w.rf>
   <form>seznámit</form>
   <lemma>seznámit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W13</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W14</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W15</w.rf>
   <form>prací</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W17</w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W18</w.rf>
   <form>návštěvu</form>
   <lemma>návštěva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W19</w.rf>
   <form>využít</form>
   <lemma>využít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W20</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W21</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W22</w.rf>
   <form>preventivně</form>
   <lemma>preventivně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W25</w.rf>
   <form>výchovné</form>
   <lemma>výchovný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W26</w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p1s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina48987.txt-001-p2s1">
  <m id="m-vysocina48987.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W1</w.rf>
   <form>Telefonické</form>
   <lemma>telefonický</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W2</w.rf>
   <form>kontakty</form>
   <lemma>kontakt</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W3</w.rf>
   <form>najdete</form>
   <lemma>najít</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W5</w.rf>
   <form>našich</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSXP6-P1-------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W6</w.rf>
   <form>webových</form>
   <lemma>webový_,t</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W7</w.rf>
   <form>stránkách</form>
   <lemma>stránka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W10</w.rf>
   <form>www.hasici-vysocina.cz</form>
   <lemma>www.hasici-vysocina.cz</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p2s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina48987.txt-001-p3s1">
  <m id="m-vysocina48987.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W1</w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W3</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W4</w.rf>
   <form>domluvit</form>
   <lemma>domluvit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W6</w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W7</w.rf>
   <form>termín</form>
   <lemma>termín</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W8</w.rf>
   <form>Vaší</form>
   <lemma>tvůj_^(přivlast.)</lemma>
   <tag>PSFS2-P2-------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W9</w.rf>
   <form>návštěvy</form>
   <lemma>návštěva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W11</w.rf>
   <form>stanicích</form>
   <lemma>stanice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vysocina48987.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina48987.txt-001-p3s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
