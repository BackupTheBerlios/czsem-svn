<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina43255.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina43255.txt-001-p1s1">
  <m id="m-vysocina43255.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W1</w.rf>
   <form>Jednu</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS4----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W2</w.rf>
   <form>hodinu</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W4</w.rf>
   <form>půlnoci</form>
   <lemma>půlnoc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W5</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W8</w.rf>
   <form>Hrotovic</form>
   <lemma>Hrotovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W10</w.rf>
   <form>Náměště</form>
   <lemma>Náměšť_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W11</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W12</w.rf>
   <form>Oslavou</form>
   <lemma>oslava</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W14</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W15</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W16</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W17</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W18</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W19</w.rf>
   <form>Mohelno</form>
   <lemma>Mohelno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W21</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W22</w.rf>
   <form>dřevěné</form>
   <lemma>dřevěný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W23</w.rf>
   <form>zahradní</form>
   <lemma>zahradní_,a</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W24</w.rf>
   <form>boudy</form>
   <lemma>bouda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43255.txt-001-p1s2">
  <m id="m-vysocina43255.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W3</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W4</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W5</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W6</w.rf>
   <form>C</form>
   <lemma>c-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W7</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W8</w.rf>
   <form>proudy</form>
   <lemma>proud</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43255.txt-001-p1s3">
  <m id="m-vysocina43255.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s3W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s3W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s3W3</w.rf>
   <form>stanovena</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s3W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s3W5</w.rf>
   <form>20000</form>
   <form_change>num_normalization</form_change>
   <lemma>20000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s3W6</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43255.txt-001-p1s4">
  <m id="m-vysocina43255.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s4W1</w.rf>
   <form>Uchráněny</form>
   <lemma>uchránit</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s4W2</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s4W3</w.rf>
   <form>hodnoty</form>
   <lemma>hodnota</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s4W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s4W5</w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s4W6</w.rf>
   <form>200000</form>
   <form_change>num_normalization</form_change>
   <lemma>200000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s4W7</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43255.txt-001-p1s5">
  <m id="m-vysocina43255.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s5W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s5W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s5W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s5W4</w.rf>
   <form>nadále</form>
   <lemma>nadále</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s5W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s5W6</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p1s5W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43255.txt-001-p2s1">
  <m id="m-vysocina43255.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W1</w.rf>
   <form>Během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W2</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W3</w.rf>
   <form>dopravu</form>
   <lemma>doprava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W5</w.rf>
   <form>Vysočině</form>
   <lemma>vysočina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W6</w.rf>
   <form>komplikovalo</form>
   <lemma>komplikovat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W7</w.rf>
   <form>vytrvalé</form>
   <lemma>vytrvalý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W8</w.rf>
   <form>sněžení</form>
   <lemma>sněžení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43255.txt-001-p2s2">
  <m id="m-vysocina43255.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W2</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W3</w.rf>
   <form>odpoledních</form>
   <lemma>odpolední</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W4</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W5</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W6</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W7</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W8</w.rf>
   <form>dopravních</form>
   <lemma>dopravní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W9</w.rf>
   <form>nehod</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W11</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W12</w.rf>
   <form>kterých</form>
   <lemma>který</lemma>
   <tag>P4XP2----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W13</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W14</w.rf>
   <form>zraněny</form>
   <lemma>zranit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W15</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W16</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43255.txt-001-p2s3">
  <m id="m-vysocina43255.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W1</w.rf>
   <form>Většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W3</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W5</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W6</w.rf>
   <form>sjetá</form>
   <lemma>sjetý_^(*1)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W8</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W9</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W10</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W11</w.rf>
   <form>blokující</form>
   <lemma>blokující_^(*5ovat)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W12</w.rf>
   <form>dopravu</form>
   <lemma>doprava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43255.txt-001-p2s4">
  <m id="m-vysocina43255.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W2</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W3</w.rf>
   <form>dopravním</form>
   <lemma>dopravní</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W4</w.rf>
   <form>nehodám</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W5</w.rf>
   <form>vyjíždějí</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W7</w.rf>
   <form>celém</form>
   <lemma>celý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W8</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W9</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W10</w.rf>
   <form>Vysočina</form>
   <lemma>vysočina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W12</w.rf>
   <form>např.</form>
   <lemma>například_:B_,x</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W14</w.rf>
   <form>Jihlavsku</form>
   <lemma>Jihlavsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W15</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W16</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W17</w.rf>
   <form>Markvartice</form>
   <lemma>Markvartic_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W19</w.rf>
   <form>Svojkovice</form>
   <lemma>Svojkovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W21</w.rf>
   <form>Hubenov</form>
   <lemma>Hubenov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W24</w.rf>
   <form>Třebíčsku</form>
   <lemma>Třebíčsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W25</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W26</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W27</w.rf>
   <form>Myslibořice</form>
   <lemma>Myslibořice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W29</w.rf>
   <form>Valeč</form>
   <lemma>Valeč_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W31</w.rf>
   <form>Rudíkov</form>
   <lemma>Rudíkovy_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W33</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W34</w.rf>
   <form>Havlíčkobrodsku</form>
   <lemma>Havlíčkobrodsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W35</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W36</w.rf>
   <form>Chotěboři</form>
   <lemma>Chotěboř_;G</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W37</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W38</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W39</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W40</w.rf>
   <form>Havlíčkova</form>
   <lemma>Havlíčkův-1_;S_^(*5ek-1)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W41</w.rf>
   <form>Borová</form>
   <lemma>bórový-2_;H</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W42</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W43</w.rf>
   <form>Leština</form>
   <lemma>Leština_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W44</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W45</w.rf>
   <form>Světlé</form>
   <lemma>Světlá_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W46</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W47</w.rf>
   <form>Rozsochatec</form>
   <lemma>Rozsochatec</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W48</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W49</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W50</w.rf>
   <form>Pelhřimovsku</form>
   <lemma>Pelhřimovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W51</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W52</w.rf>
   <form>Žďársku</form>
   <lemma>Žďársko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W53</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W54</w.rf>
   <form>dálnici</form>
   <lemma>dálnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W55</w.rf>
   <form>D1</form>
   <lemma>D1_:B_^(dálnice_v_ČR)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina43255.txt-001-p2s4W56-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43255.txt-001-p2s4W56</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
