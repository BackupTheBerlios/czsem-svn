<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina45207.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina45207.txt-001-p1s1">
  <m id="m-vysocina45207.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W1</w.rf>
   <form>Častěji</form>
   <lemma>častě_^(*1ý)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W2</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W3</w.rf>
   <form>vyjíždějí</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W4</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W5</w.rf>
   <form>požárům</form>
   <lemma>požár</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W6</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W8</w.rf>
   <form>dohašování</form>
   <lemma>dohašování_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W9</w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W10</w.rf>
   <form>zabezpečených</form>
   <lemma>zabezpečený_^(*3it)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W11</w.rf>
   <form>ohnišť</form>
   <lemma>ohniště</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p1s2">
  <m id="m-vysocina45207.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s2W1</w.rf>
   <form>Vypalování</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s2W2</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s2W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s2W4</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s2W5</w.rf>
   <form>neustále</form>
   <lemma>neustále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s2W6</w.rf>
   <form>oblíbené</form>
   <lemma>oblíbený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p1s3">
  <m id="m-vysocina45207.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W1</w.rf>
   <form>Jarní</form>
   <lemma>jarní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W2</w.rf>
   <form>úklid</form>
   <lemma>úklid</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W4</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W5</w.rf>
   <form>nemusí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W6</w.rf>
   <form>majitelům</form>
   <lemma>majitel</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W7</w.rf>
   <form>zahrad</form>
   <lemma>zahrada</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W8</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W9</w.rf>
   <form>remízků</form>
   <lemma>remízek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W10</w.rf>
   <form>vyplatit</form>
   <lemma>vyplatit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p1s4">
  <m id="m-vysocina45207.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W1</w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W3</w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PKM-1----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W5</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W6</w.rf>
   <form>rozhodne</form>
   <lemma>rozhodnout_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W7</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W8</w.rf>
   <form>vyčistit</form>
   <lemma>vyčistit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W10</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W11</w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W12</w.rf>
   <form>ohněm</form>
   <lemma>oheň</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W14</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W15</w.rf>
   <form>zaplatit</form>
   <lemma>zaplatit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W16</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W17</w.rf>
   <form>několikatisícovou</form>
   <lemma>několikatisícový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W18</w.rf>
   <form>pokutu</form>
   <lemma>pokuta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p1s4W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p2s1">
  <m id="m-vysocina45207.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W1</w.rf>
   <form>Pár</form>
   <lemma>pár-2</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W2</w.rf>
   <form>čísel</form>
   <lemma>číslo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W3</w.rf>
   <form>úvodem</form>
   <lemma>úvod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W5</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W6</w.rf>
   <form>lesních</form>
   <lemma>lesní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W7</w.rf>
   <form>porostů</form>
   <lemma>porost</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W9</w.rf>
   <form>polí</form>
   <lemma>pole</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W11</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W14</w.rf>
   <form>kraj</form>
   <lemma>kraj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p2s1W15</w.rf>
   <form>Vysočina</form>
   <lemma>vysočina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p3s1">
  <m id="m-vysocina45207.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p3s1W1</w.rf>
   <form>Rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p3s1W2</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p4s1">
  <m id="m-vysocina45207.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p4s1W1</w.rf>
   <form>Rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p4s1W2</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p5s1">
  <m id="m-vysocina45207.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p5s1W1</w.rf>
   <form>Rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p5s1W2</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p5s1W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p5s1W4</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p5s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p5s1W6</w.rf>
   <form>čtvrtletí</form>
   <lemma>čtvrtletí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p5s1W7</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p6s1">
  <m id="m-vysocina45207.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W1</w.rf>
   <form>Dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W2</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W3</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W4</w.rf>
   <form>133</form>
   <lemma>133</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W5</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W6</w.rf>
   <form>1985</form>
   <lemma>1985</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W7</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W10</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W11</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W12</w.rf>
   <form>ochraně</form>
   <lemma>ochrana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W14</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W15</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W16</w.rf>
   <form>pozdějších</form>
   <lemma>pozdní-1_^(v_krátkém_čase,_následující_o_něco_později)</lemma>
   <tag>AAIP2----2A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W17</w.rf>
   <form>předpisů</form>
   <lemma>předpis</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W18</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W19</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W20</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W21</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W22</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W23</w.rf>
   <form>PO</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W24</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W25</w.rf>
   <form>fyzická</form>
   <lemma>fyzický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W26</w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W27</w.rf>
   <form>nesmí</form>
   <lemma>smět_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W28</w.rf>
   <form>provádět</form>
   <lemma>provádět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W29</w.rf>
   <form>plošné</form>
   <lemma>plošný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W30</w.rf>
   <form>vypalování</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W31</w.rf>
   <form>porostů</form>
   <lemma>porost</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s1W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p6s2">
  <m id="m-vysocina45207.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W2</w.rf>
   <form>plošném</form>
   <lemma>plošný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W3</w.rf>
   <form>vypalování</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W4</w.rf>
   <form>porostů</form>
   <lemma>porost</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W6</w.rf>
   <form>dopouští</form>
   <lemma>dopouštět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W7</w.rf>
   <form>přestupku</form>
   <lemma>přestupek</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W8</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W9</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W10</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W11</w.rf>
   <form>PO</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W13</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W14</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W15</w.rf>
   <form>jí</form>
   <lemma>on-1_^(ona)</lemma>
   <tag>PPFS3--3-------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W16</w.rf>
   <form>hrozí</form>
   <lemma>hrozit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W17</w.rf>
   <form>pokuta</form>
   <lemma>pokuta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W19</w.rf>
   <form>25000</form>
   <form_change>num_normalization</form_change>
   <lemma>25000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W20</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p6s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p7s1">
  <m id="m-vysocina45207.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W1</w.rf>
   <form>Fyzické</form>
   <lemma>fyzický</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W2</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W3</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W4</w.rf>
   <form>provádět</form>
   <lemma>provádět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W5</w.rf>
   <form>kontrolované</form>
   <lemma>kontrolovaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W6</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W7</w.rf>
   <form>hořlavých</form>
   <lemma>hořlavý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W8</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W10</w.rf>
   <form>např.</form>
   <lemma>například_:B_,x</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W11</w.rf>
   <form>shrabanou</form>
   <lemma>shrabaný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W12</w.rf>
   <form>trávu</form>
   <lemma>tráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W13</w.rf>
   <form>pálit</form>
   <lemma>pálit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W15</w.rf>
   <form>hromadě</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p7s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p8s1">
  <m id="m-vysocina45207.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W1</w.rf>
   <form>Podnikající</form>
   <lemma>podnikající_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W2</w.rf>
   <form>právnické</form>
   <lemma>právnický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W4</w.rf>
   <form>podnikající</form>
   <lemma>podnikající_^(*4t)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W5</w.rf>
   <form>fyzické</form>
   <lemma>fyzický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W6</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W7</w.rf>
   <form>taktéž</form>
   <lemma>taktéž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W8</w.rf>
   <form>nesmí</form>
   <lemma>smět_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W9</w.rf>
   <form>plošně</form>
   <lemma>plošně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W10</w.rf>
   <form>vypalovat</form>
   <lemma>vypalovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W11</w.rf>
   <form>porosty</form>
   <lemma>porost</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p8s2">
  <m id="m-vysocina45207.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W2</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W3</w.rf>
   <form>hořlavých</form>
   <lemma>hořlavý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W4</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W6</w.rf>
   <form>volném</form>
   <lemma>volný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W7</w.rf>
   <form>prostranství</form>
   <lemma>prostranství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W8</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W9</w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W10</w.rf>
   <form>povinny</form>
   <lemma>povinný</lemma>
   <tag>ACTP------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W12</w.rf>
   <form>stanovit</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W13</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W14</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W15</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W17</w.rf>
   <form>šíření</form>
   <lemma>šíření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W18</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p8s3">
  <m id="m-vysocina45207.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W2</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W3</w.rf>
   <form>povinni</form>
   <lemma>povinný</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W4</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W5</w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W6</w.rf>
   <form>oznámit</form>
   <lemma>oznámit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W7</w.rf>
   <form>příslušnému</form>
   <lemma>příslušný_^(*2et)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W8</w.rf>
   <form>hasičskému</form>
   <lemma>hasičský</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W9</w.rf>
   <form>záchrannému</form>
   <lemma>záchranný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W10</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W11</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W13</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W14</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W15</w.rf>
   <form>případně</form>
   <lemma>případně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W16</w.rf>
   <form>stanovit</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W17</w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W18</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W19</w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W20</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W21</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W22</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W23</w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W24</w.rf>
   <form>zakázat</form>
   <lemma>zakázat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p8s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p8s3W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p9s1">
  <m id="m-vysocina45207.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W1</w.rf>
   <form>Podnikající</form>
   <lemma>podnikající_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W2</w.rf>
   <form>právnické</form>
   <lemma>právnický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W4</w.rf>
   <form>podnikající</form>
   <lemma>podnikající_^(*4t)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W5</w.rf>
   <form>fyzické</form>
   <lemma>fyzický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W6</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W8</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W9</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W10</w.rf>
   <form>vypalování</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W11</w.rf>
   <form>porostů</form>
   <lemma>porost</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W12</w.rf>
   <form>dopouští</form>
   <lemma>dopouštět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W13</w.rf>
   <form>přestupku</form>
   <lemma>přestupek</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W14</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W15</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W17</w.rf>
   <form>PO</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W19</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W20</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W21</w.rf>
   <form>jí</form>
   <lemma>on-1_^(ona)</lemma>
   <tag>PPFS3--3-------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W22</w.rf>
   <form>hrozí</form>
   <lemma>hrozit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W23</w.rf>
   <form>pokuta</form>
   <lemma>pokuta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W24</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W25</w.rf>
   <form>500000</form>
   <form_change>num_normalization</form_change>
   <lemma>500000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W26</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W27</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W28</w.rf>
   <form>stejná</form>
   <lemma>stejný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W29</w.rf>
   <form>pokuta</form>
   <lemma>pokuta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W30</w.rf>
   <form>hrozí</form>
   <lemma>hrozit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W31</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W32</w.rf>
   <form>nenahlášení</form>
   <lemma>nahlášení_^(*4sit)</lemma>
   <tag>NNNS4-----N----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W33</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W34</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p9s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p9s1W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p10s1">
  <m id="m-vysocina45207.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W1</w.rf>
   <form>Navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W2</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W3</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W5</w.rf>
   <form>PO</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W6</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W7</w.rf>
   <form>fyzické</form>
   <lemma>fyzický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W8</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W10</w.rf>
   <form>podnikající</form>
   <lemma>podnikající_^(*4t)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W11</w.rf>
   <form>právnické</form>
   <lemma>právnický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W13</w.rf>
   <form>podnikající</form>
   <lemma>podnikající_^(*4t)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W14</w.rf>
   <form>fyzické</form>
   <lemma>fyzický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W15</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W16</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W17</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W18</w.rf>
   <form>bezodkladně</form>
   <lemma>bezodkladně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W19</w.rf>
   <form>oznamovat</form>
   <lemma>oznamovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W20</w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W21</w.rf>
   <form>vzniklý</form>
   <lemma>vzniklý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W22</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W23</w.rf>
   <form>příslušnému</form>
   <lemma>příslušný_^(*2et)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W24</w.rf>
   <form>hasičskému</form>
   <lemma>hasičský</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W25</w.rf>
   <form>záchrannému</form>
   <lemma>záchranný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W26</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W27</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p10s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p10s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p11s1">
  <m id="m-vysocina45207.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W2</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W4</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W5</w.rf>
   <form>dodržovat</form>
   <lemma>dodržovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W6</w.rf>
   <form>následující</form>
   <lemma>následující_^(*5ovat)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W7</w.rf>
   <form>požárně</form>
   <lemma>požárně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W8</w.rf>
   <form>bezpečnostní</form>
   <lemma>bezpečnostní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W9</w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p11s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p11s1W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p12s1">
  <m id="m-vysocina45207.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W1</w.rf>
   <form>Místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W2</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W4</w.rf>
   <form>nutno</form>
   <lemma>nutný</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W5</w.rf>
   <form>zabezpečit</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W6</w.rf>
   <form>dostatečným</form>
   <lemma>dostatečný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W7</w.rf>
   <form>množstvím</form>
   <lemma>množství</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W8</w.rf>
   <form>hasebních</form>
   <lemma>hasební</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W9</w.rf>
   <form>prostředků</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p12s2">
  <m id="m-vysocina45207.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W1</w.rf>
   <form>Spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W3</w.rf>
   <form>povoleno</form>
   <lemma>povolit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W4</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W6</w.rf>
   <form>bezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W7</w.rf>
   <form>vzdálenosti</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W8</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W9</w.rf>
   <form>objektů</form>
   <lemma>objekt</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W11</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W13</w.rf>
   <form>hořlavými</form>
   <lemma>hořlavý</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W14</w.rf>
   <form>stavebními</form>
   <lemma>stavební</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W15</w.rf>
   <form>konstrukcemi</form>
   <lemma>konstrukce</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W18</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W19</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W20</w.rf>
   <form>ohledem</form>
   <lemma>ohled</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W22</w.rf>
   <form>povětrnostní</form>
   <lemma>povětrnostní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W23</w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W24</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W25</w.rf>
   <form>síla</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W27</w.rf>
   <form>směr</form>
   <lemma>směr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W28</w.rf>
   <form>větru</form>
   <lemma>vítr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W29</w.rf>
   <form>apod</form>
   <lemma>apod-1_:B_,x_^(a_podobně)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p12s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p12s2W31</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p13s1">
  <m id="m-vysocina45207.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W1</w.rf>
   <form>Pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W3</w.rf>
   <form>hlásí</form>
   <lemma>hlásit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W5</w.rf>
   <form>Krajské</form>
   <lemma>krajský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W6</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W8</w.rf>
   <form>informační</form>
   <lemma>informační</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W9</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W10</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W11</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W12</w.rf>
   <form>Vysočina</form>
   <lemma>vysočina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W13</w.rf>
   <form>tel.</form>
   <lemma>telefon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W14</w.rf>
   <form>950270102</form>
   <form_change>num_normalization</form_change>
   <lemma>950270102</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W16</w.rf>
   <form>105</form>
   <lemma>105</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p13s2">
  <m id="m-vysocina45207.txt-001-p13s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W2</w.rf>
   <form>ohlášení</form>
   <lemma>ohlášení_^(*4sit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W4</w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W5</w.rf>
   <form>uvést</form>
   <lemma>uvést</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W6</w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W8</w.rf>
   <form>telefonické</form>
   <lemma>telefonický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W9</w.rf>
   <form>spojení</form>
   <lemma>spojení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W11</w.rf>
   <form>osobu</form>
   <lemma>osoba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W13</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W14</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W15</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W16</w.rf>
   <form>provádět</form>
   <lemma>provádět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W18</w.rf>
   <form>přesná</form>
   <lemma>přesný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W19</w.rf>
   <form>identifikace</form>
   <lemma>identifikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W20</w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W22</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W23</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W24</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W25</w.rf>
   <form>probíhat</form>
   <lemma>probíhat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W27</w.rf>
   <form>datum</form>
   <lemma>datum_^(kalendářní)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W28</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W30</w.rf>
   <form>hodinu</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W31</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W32</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W33</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W34</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W35</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W36</w.rf>
   <form>spalování</form>
   <lemma>spalování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W37</w.rf>
   <form>probíhat</form>
   <lemma>probíhat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W38</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W39</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W40</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W41</w.rf>
   <form>údaje</form>
   <lemma>údaj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W42</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W43</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W44</w.rf>
   <form>požadovat</form>
   <lemma>požadovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W45</w.rf>
   <form>příslušník</form>
   <lemma>příslušník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W46</w.rf>
   <form>hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W47</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W48</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s2W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s2W49</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p13s3">
  <m id="m-vysocina45207.txt-001-p13s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W1</w.rf>
   <form>Ohlášení</form>
   <lemma>ohlášení_^(*4sit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W3</w.rf>
   <form>rozhodně</form>
   <lemma>rozhodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W4</w.rf>
   <form>neprovádí</form>
   <lemma>provádět_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W6</w.rf>
   <form>čísla</form>
   <lemma>číslo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W7</w.rf>
   <form>linek</form>
   <lemma>linka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W8</w.rf>
   <form>tísňového</form>
   <lemma>tísňový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W9</w.rf>
   <form>volání</form>
   <lemma>volání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W10</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W11</w.rf>
   <form>112</form>
   <lemma>112</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W13</w.rf>
   <form>150</form>
   <lemma>150</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W14</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W16</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W17</w.rf>
   <form>slouží</form>
   <lemma>sloužit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W18</w.rf>
   <form>přímé</form>
   <lemma>přímý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W19</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W20</w.rf>
   <form>postiženým</form>
   <lemma>postižený_^(*4hnout)</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p13s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p13s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina45207.txt-001-p14s1">
  <m id="m-vysocina45207.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W1</w.rf>
   <form>Ohlášením</form>
   <lemma>ohlášení_^(*4sit)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W2</w.rf>
   <form>předejdete</form>
   <lemma>předejít_^(díky_rychlejší_chůzi)</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W3</w.rf>
   <form>zbytečným</form>
   <lemma>zbytečný</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W4</w.rf>
   <form>výjezdům</form>
   <lemma>výjezd</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W5</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W7</w.rf>
   <form>ohlášeným</form>
   <lemma>ohlášený_^(*4sit)</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W8</w.rf>
   <form>požárům</form>
   <lemma>požár</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W9</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W11</w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W13</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W14</w.rf>
   <form>atd</form>
   <lemma>atd-1_:B_,x_^(a_tak_dále)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W17</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W18</w.rf>
   <form>naopak</form>
   <lemma>naopak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W21</w.rf>
   <form>přesným</form>
   <lemma>přesný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W22</w.rf>
   <form>udáním</form>
   <lemma>udání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W23</w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W24</w.rf>
   <form>zajistíte</form>
   <lemma>zajistit_:W</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W26</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W27</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W28</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W29</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W30</w.rf>
   <form>přesnější</form>
   <lemma>přesný</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W31</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W32</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W33</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W34</w.rf>
   <form>rychlejší</form>
   <lemma>rychlý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m-vysocina45207.txt-001-p14s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina45207.txt-001-p14s1W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
