<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vysocina43037.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-vysocina43037.txt-001-p1s1">
  <m id="m-vysocina43037.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W4</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W5</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W9</w.rf>
   <form>nejedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W10</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W11</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W12</w.rf>
   <form>komína</form>
   <lemma>komín</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W14</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W15</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W16</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W17</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W19</w.rf>
   <form>půdního</form>
   <lemma>půdní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W20</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W21</w.rf>
   <form>bytového</form>
   <lemma>bytový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W22</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W23</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W24</w.rf>
   <form>přístavbou</form>
   <lemma>přístavba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43037.txt-001-p1s2">
  <m id="m-vysocina43037.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W4</w.rf>
   <form>povolány</form>
   <lemma>povolat_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W5</w.rf>
   <form>posily</form>
   <lemma>posila</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W10</w.rf>
   <form>Pelhřimova</form>
   <lemma>Pelhřimov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W12</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W15</w.rf>
   <form>Humpolce</form>
   <lemma>Humpolec_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W17</w.rf>
   <form>Herálce</form>
   <lemma>Herálec_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p1s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43037.txt-001-p2s1">
  <m id="m-vysocina43037.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W2</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W4</w.rf>
   <form>dýchací</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W5</w.rf>
   <form>technice</form>
   <lemma>technika</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W6</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W7</w.rf>
   <form>C</form>
   <lemma>c-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W8</w.rf>
   <form>proudy</form>
   <lemma>proud</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W10</w.rf>
   <form>vysokotlakem</form>
   <lemma>vysokotlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W12</w.rf>
   <form>rozebírali</form>
   <lemma>rozebírat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W13</w.rf>
   <form>konstrukci</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W14</w.rf>
   <form>rozestavěné</form>
   <lemma>rozestavěný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W15</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p2s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43037.txt-001-p3s1">
  <m id="m-vysocina43037.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W1</w.rf>
   <form>Příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W4</w.rf>
   <form>úlet</form>
   <lemma>úlet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W5</w.rf>
   <form>jiskry</form>
   <lemma>jiskra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W7</w.rf>
   <form>komína</form>
   <lemma>komín</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W8</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W9</w.rf>
   <form>následným</form>
   <lemma>následný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W10</w.rf>
   <form>vznícením</form>
   <lemma>vznícení_^(*4tit)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W11</w.rf>
   <form>nedokončené</form>
   <lemma>dokončený_^(*3it)</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W12</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W13</w.rf>
   <form>vlivem</form>
   <lemma>vliv</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W14</w.rf>
   <form>nepříznivých</form>
   <lemma>příznivý</lemma>
   <tag>AAFP2----1N----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W15</w.rf>
   <form>povětrnostních</form>
   <lemma>povětrnostní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W16</w.rf>
   <form>podmínek</form>
   <lemma>podmínka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43037.txt-001-p3s2">
  <m id="m-vysocina43037.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s2W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s2W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s2W3</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s2W5</w.rf>
   <form>100000</form>
   <form_change>num_normalization</form_change>
   <lemma>100000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s2W6</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vysocina43037.txt-001-p3s3">
  <m id="m-vysocina43037.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s3W1</w.rf>
   <form>Uchráněny</form>
   <lemma>uchránit</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s3W2</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s3W3</w.rf>
   <form>hodnoty</form>
   <lemma>hodnota</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s3W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s3W5</w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s3W6</w.rf>
   <form>2000000</form>
   <form_change>num_normalization</form_change>
   <lemma>2000000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s3W7</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-vysocina43037.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-vysocina43037.txt-001-p3s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
