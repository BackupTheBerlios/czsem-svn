<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky48860.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky48860.txt-001-p1s1">
  <m id="m-kralovehradecky48860.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p1s1W1</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p1s1W2</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p2s1">
  <m id="m-kralovehradecky48860.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s1W1</w.rf>
   <form>Královéhradečtí</form>
   <lemma>královéhradecký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s1W3</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s1W4</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s1W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s1W6</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s1W7</w.rf>
   <form>událostí</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p2s2">
  <m id="m-kralovehradecky48860.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W1</w.rf>
   <form>Krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W3</w.rf>
   <form>čtrnácté</form>
   <lemma>čtrnáctý</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W4</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W5</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W6</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W8</w.rf>
   <form>odstranění</form>
   <lemma>odstranění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W9</w.rf>
   <form>poškozeného</form>
   <lemma>poškozený_^(*4dit)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W10</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W12</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W13</w.rf>
   <form>hrozil</form>
   <lemma>hrozit_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W14</w.rf>
   <form>pádem</form>
   <lemma>pád</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W16</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W17</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W18</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W19</w.rf>
   <form>Těchlovice</form>
   <lemma>Těchlovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p2s3">
  <m id="m-kralovehradecky48860.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W1</w.rf>
   <form>Prasklý</form>
   <lemma>prasklý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W2</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W3</w.rf>
   <form>zůstal</form>
   <lemma>zůstat</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W4</w.rf>
   <form>zaklíněný</form>
   <lemma>zaklíněný_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W5</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W6</w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>ClXP7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W7</w.rf>
   <form>kmeny</form>
   <lemma>kmen-1_^(stromu)</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W8</w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p2s4">
  <m id="m-kralovehradecky48860.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W2</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W3</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W4</w.rf>
   <form>navijáku</form>
   <lemma>naviják</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W5</w.rf>
   <form>stáhli</form>
   <lemma>stáhnout</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W6</w.rf>
   <form>poškozený</form>
   <lemma>poškozený_^(*4dit)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W7</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W8</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W9</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p2s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p3s1">
  <m id="m-kralovehradecky48860.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W2</w.rf>
   <form>Těchlovic</form>
   <lemma>Těchlovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W3</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W5</w.rf>
   <form>odvoláni</form>
   <lemma>odvolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W7</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W8</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W9</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W10</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W12</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W13</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W14</w.rf>
   <form>Dubech</form>
   <lemma>dub</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W16</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W17</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W20</w.rf>
   <form>Pouchově</form>
   <lemma>Pouchov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p3s2">
  <m id="m-kralovehradecky48860.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s2W1</w.rf>
   <form>Osobní</form>
   <lemma>osobní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s2W2</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s2W3</w.rf>
   <form>skončilo</form>
   <lemma>skončit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s2W5</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s2W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p3s3">
  <m id="m-kralovehradecky48860.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W1</w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W2</w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W3</w.rf>
   <form>utrpěla</form>
   <lemma>utrpět</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W4</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W7</w.rf>
   <form>odvezena</form>
   <lemma>odvézt</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W8</w.rf>
   <form>záchrannou</form>
   <lemma>záchranný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W9</w.rf>
   <form>službou</form>
   <lemma>služba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W11</w.rf>
   <form>dalšímu</form>
   <lemma>další</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W12</w.rf>
   <form>vyšetření</form>
   <lemma>vyšetření_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p3s4">
  <m id="m-kralovehradecky48860.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W2</w.rf>
   <form>odpojili</form>
   <lemma>odpojit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W3</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W4</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W5</w.rf>
   <form>akumulátor</form>
   <lemma>akumulátor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W7</w.rf>
   <form>zamezili</form>
   <lemma>zamezit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W8</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W9</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W10</w.rf>
   <form>náplní</form>
   <lemma>náplň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p3s5">
  <m id="m-kralovehradecky48860.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s5W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s5W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s5W3</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s5W4</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s5W5</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p3s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p4s1">
  <m id="m-kralovehradecky48860.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W1</w.rf>
   <form>Bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W2</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W4</w.rf>
   <form>obešla</form>
   <lemma>obejít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W5</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W6</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W8</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W9</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W10</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W12</w.rf>
   <form>Vysokou</form>
   <lemma>vysoká_^(zvěř)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W13</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W14</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p4s2">
  <m id="m-kralovehradecky48860.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s2W1</w.rf>
   <form>Havarované</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s2W2</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s2W3</w.rf>
   <form>skončilo</form>
   <lemma>skončit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s2W5</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s2W7</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p4s3">
  <m id="m-kralovehradecky48860.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W2</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W6</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W7</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W8</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W9</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W10</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W11</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p4s4">
  <m id="m-kralovehradecky48860.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s4W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s4W2</w.rf>
   <form>zajištění</form>
   <lemma>zajištění_^(*5stit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s4W3</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s4W4</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s4W5</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s4W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s4W7</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p4s5">
  <m id="m-kralovehradecky48860.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s5W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s5W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s5W3</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s5W4</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s5W5</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p4s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p5s1">
  <m id="m-kralovehradecky48860.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p5s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p5s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p5s1W3</w.rf>
   <form>Rychnov</form>
   <lemma>Rychnov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p5s1W4</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p5s1W5</w.rf>
   <form>Kněžnou</form>
   <lemma>Kněžná_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p6s1">
  <m id="m-kralovehradecky48860.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W3</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W4</w.rf>
   <form>Rychnov</form>
   <lemma>Rychnov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W5</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W6</w.rf>
   <form>Kněžnou</form>
   <lemma>Kněžná_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W7</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W8</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W9</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W10</w.rf>
   <form>dopravních</form>
   <lemma>dopravní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W11</w.rf>
   <form>nehod</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p6s2">
  <m id="m-kralovehradecky48860.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W1</w.rf>
   <form>První</form>
   <lemma>první</lemma>
   <tag>CrFS4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W3</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W5</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W6</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W7</w.rf>
   <form>jedenácté</form>
   <lemma>jedenáctý</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W8</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W9</w.rf>
   <form>dopoledne</form>
   <lemma>dopoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W11</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W12</w.rf>
   <form>Žamberecká</form>
   <lemma>žamberecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W14</w.rf>
   <form>Vamberku</form>
   <lemma>Vamberk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p6s3">
  <m id="m-kralovehradecky48860.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s3W1</w.rf>
   <form>Osobní</form>
   <lemma>osobní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s3W2</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s3W3</w.rf>
   <form>zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s3W4</w.rf>
   <form>skončilo</form>
   <lemma>skončit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s3W6</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p6s4">
  <m id="m-kralovehradecky48860.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s4W1</w.rf>
   <form>Posádka</form>
   <lemma>posádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s4W2</w.rf>
   <form>vyvázla</form>
   <lemma>vyváznout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s4W3</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s4W4</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p6s4W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p7s1">
  <m id="m-kralovehradecky48860.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W1</w.rf>
   <form>Druhá</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W4</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W5</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W6</w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W7</w.rf>
   <form>osmé</form>
   <lemma>osmý</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W8</w.rf>
   <form>večer</form>
   <lemma>večer</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W9</w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W10</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W11</w.rf>
   <form>Vamberku</form>
   <lemma>Vamberk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p7s2">
  <m id="m-kralovehradecky48860.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W2</w.rf>
   <form>střetu</form>
   <lemma>střet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W3</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W4</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W5</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W6</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W7</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W8</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W9</w.rf>
   <form>zraněny</form>
   <lemma>zranit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p7s3">
  <m id="m-kralovehradecky48860.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W2</w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W3</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W5</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W6</w.rf>
   <form>havarovaná</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W7</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W8</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W9</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W11</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W12</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W13</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p7s4">
  <m id="m-kralovehradecky48860.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W2</w.rf>
   <form>nehod</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W4</w.rf>
   <form>míru</form>
   <lemma>míra_^(měřítko,poměr)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W5</w.rf>
   <form>zavinění</form>
   <lemma>zavinění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W6</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W7</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W8</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p7s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p7s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p8s1">
  <m id="m-kralovehradecky48860.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p8s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p8s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p8s1W3</w.rf>
   <form>Náchod</form>
   <lemma>Náchod_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p9s1">
  <m id="m-kralovehradecky48860.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W4</w.rf>
   <form>Náchoda</form>
   <lemma>Náchod_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W5</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W7</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W8</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W9</w.rf>
   <form>57</form>
   <lemma>57</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W11</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W14</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W16</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W17</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W18</w.rf>
   <form>301</form>
   <lemma>301</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W19</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W20</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W21</w.rf>
   <form>Stárkova</form>
   <lemma>Stárkov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p9s2">
  <m id="m-kralovehradecky48860.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W1</w.rf>
   <form>Řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W2</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W3</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W4</w.rf>
   <form>Fiat</form>
   <lemma>Fiat-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W5</w.rf>
   <form>Punto</form>
   <lemma>Punto_;R_^(auto)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W7</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W8</w.rf>
   <form>nejasných</form>
   <lemma>jasný</lemma>
   <tag>AAFP2----1N----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W9</w.rf>
   <form>příčin</form>
   <lemma>příčina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W10</w.rf>
   <form>vyjel</form>
   <lemma>vyjet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W11</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W12</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p9s3">
  <m id="m-kralovehradecky48860.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W1</w.rf>
   <form>Přední</form>
   <lemma>přední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W2</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W3</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W4</w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W5</w.rf>
   <form>viset</form>
   <lemma>viset_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W6</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W7</w.rf>
   <form>příkrým</form>
   <lemma>příkrý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W8</w.rf>
   <form>svahem</form>
   <lemma>svah</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p9s4">
  <m id="m-kralovehradecky48860.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s4W1</w.rf>
   <form>Pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s4W2</w.rf>
   <form>lana</form>
   <lemma>lano</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s4W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s4W4</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s4W5</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s4W6</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s4W7</w.rf>
   <form>pádu</form>
   <lemma>pád</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p9s5">
  <m id="m-kralovehradecky48860.txt-001-p9s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W2</w.rf>
   <form>zadokumentování</form>
   <lemma>zadokumentování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W3</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W4</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W5</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W6</w.rf>
   <form>navijáku</form>
   <lemma>naviják</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W7</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W8</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W10</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W12</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W13</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W15</w.rf>
   <form>polní</form>
   <lemma>polní-1</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W16</w.rf>
   <form>cestu</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p9s6">
  <m id="m-kralovehradecky48860.txt-001-p9s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s6W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s6W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s6W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s6W4</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s6W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s6W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p9s7">
  <m id="m-kralovehradecky48860.txt-001-p9s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s7W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s7W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s7W3</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s7W4</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s7W5</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p9s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p9s7W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p10s1">
  <m id="m-kralovehradecky48860.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W4</w.rf>
   <form>Červeného</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W5</w.rf>
   <form>Kostelce</form>
   <lemma>Kostelec_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W6</w.rf>
   <form>vyjeli</form>
   <lemma>vyjet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W8</w.rf>
   <form>odstranění</form>
   <lemma>odstranění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W9</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W11</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W12</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W14</w.rf>
   <form>listopadu</form>
   <lemma>listopad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W16</w.rf>
   <form>Červeném</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W17</w.rf>
   <form>Kostelci</form>
   <lemma>Kostelec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p10s2">
  <m id="m-kralovehradecky48860.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W1</w.rf>
   <form>Část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W2</w.rf>
   <form>poškozeného</form>
   <lemma>poškozený_^(*4dit)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W3</w.rf>
   <form>kmene</form>
   <lemma>kmen-1_^(stromu)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W4</w.rf>
   <form>kaštanu</form>
   <lemma>kaštan</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W5</w.rf>
   <form>spadla</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W6</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W7</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W9</w.rf>
   <form>parkovišti</form>
   <lemma>parkoviště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W10</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W11</w.rf>
   <form>pošty</form>
   <lemma>pošta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p10s3">
  <m id="m-kralovehradecky48860.txt-001-p10s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W1</w.rf>
   <form>Žádné</form>
   <lemma>žádný</lemma>
   <tag>PWNS1----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W3</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W4</w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W5</w.rf>
   <form>poškozeno</form>
   <lemma>poškodit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W7</w.rf>
   <form>nedošlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W8</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W9</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W10</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W11</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p10s4">
  <m id="m-kralovehradecky48860.txt-001-p10s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s4W2</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s4W3</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s4W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s4W5</w.rf>
   <form>parkoviště</form>
   <lemma>parkoviště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p10s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p10s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p11s1">
  <m id="m-kralovehradecky48860.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p11s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p11s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p11s1W3</w.rf>
   <form>Trutnov</form>
   <lemma>Trutnov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p12s1">
  <m id="m-kralovehradecky48860.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W4</w.rf>
   <form>Trutnova</form>
   <lemma>Trutnov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W6</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W9</w.rf>
   <form>Horního</form>
   <lemma>Horní_;G</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W10</w.rf>
   <form>Maršova</form>
   <lemma>Maršov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W12</w.rf>
   <form>Svobody</form>
   <lemma>svoboda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W13</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W14</w.rf>
   <form>Úpou</form>
   <lemma>Úpa_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W15</w.rf>
   <form>vyjeli</form>
   <lemma>vyjet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W17</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W18</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W19</w.rf>
   <form>Svobodě</form>
   <lemma>svoboda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W20</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W21</w.rf>
   <form>Úpou</form>
   <lemma>Úpa_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p12s2">
  <m id="m-kralovehradecky48860.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W3</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W5</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W6</w.rf>
   <form>určení</form>
   <lemma>určení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W7</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W8</w.rf>
   <form>zjištěno</form>
   <lemma>zjistit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W10</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W12</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W13</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W14</w.rf>
   <form>neohlášené</form>
   <lemma>ohlášený_^(*4sit)</lemma>
   <tag>AANS4----1N----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W15</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W16</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W17</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W18</w.rf>
   <form>garáží</form>
   <lemma>garáž</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W20</w.rf>
   <form>Rýchorském</form>
   <lemma>rýchorský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W21</w.rf>
   <form>sídlišti</form>
   <lemma>sídliště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p12s3">
  <m id="m-kralovehradecky48860.txt-001-p12s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W2</w.rf>
   <form>uhasili</form>
   <lemma>uhasit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W3</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W4</w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W5</w.rf>
   <form>vodním</form>
   <lemma>vodní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W6</w.rf>
   <form>proudem</form>
   <lemma>proud</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W8</w.rf>
   <form>vrátili</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W11</w.rf>
   <form>základnu</form>
   <lemma>základna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p12s4">
  <m id="m-kralovehradecky48860.txt-001-p12s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s4W2</w.rf>
   <form>nenapáchal</form>
   <lemma>napáchat_:W</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s4W3</w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s4W4</w.rf>
   <form>hmotné</form>
   <lemma>hmotný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s4W5</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p12s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p12s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p13s1">
  <m id="m-kralovehradecky48860.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W4</w.rf>
   <form>Dolní</form>
   <lemma>Dolní_;G</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W5</w.rf>
   <form>Kalné</form>
   <lemma>kalný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W6</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W7</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W9</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W10</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W12</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W13</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W14</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W15</w.rf>
   <form>Slemeno</form>
   <lemma>Slemeno</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p13s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p13s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p14s1">
  <m id="m-kralovehradecky48860.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p14s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p14s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p14s1W3</w.rf>
   <form>Jičín</form>
   <lemma>Jičín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p15s1">
  <m id="m-kralovehradecky48860.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W2</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W5</w.rf>
   <form>Jičína</form>
   <lemma>Jičín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W7</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W9</w.rf>
   <form>05</form>
   <lemma>05</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W11</w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W12</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W13</w.rf>
   <form>přivolána</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W15</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W16</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W17</w.rf>
   <form>dodávkového</form>
   <lemma>dodávkový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W18</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W19</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W20</w.rf>
   <form>Bartoušovem</form>
   <lemma>Bartoušov</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W22</w.rf>
   <form>Pševsí</form>
   <lemma>Pševsí</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p15s2">
  <m id="m-kralovehradecky48860.txt-001-p15s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s2W1</w.rf>
   <form>Dodávka</form>
   <lemma>dodávka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s2W2</w.rf>
   <form>skončila</form>
   <lemma>skončit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s2W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s2W4</w.rf>
   <form>boku</form>
   <lemma>bok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s2W5</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s2W6</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p15s3">
  <m id="m-kralovehradecky48860.txt-001-p15s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s3W1</w.rf>
   <form>Nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s3W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s3W3</w.rf>
   <form>posádky</form>
   <lemma>posádka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s3W4</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s3W5</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s3W6</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p15s4">
  <m id="m-kralovehradecky48860.txt-001-p15s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W2</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W6</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W7</w.rf>
   <form>dodávku</form>
   <lemma>dodávka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W8</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W9</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W10</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W11</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p15s5">
  <m id="m-kralovehradecky48860.txt-001-p15s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s5W1</w.rf>
   <form>Následně</form>
   <lemma>následně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s5W2</w.rf>
   <form>převrátili</form>
   <lemma>převrátit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s5W3</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s5W4</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s5W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s5W6</w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s5W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48860.txt-001-p15s6">
  <m id="m-kralovehradecky48860.txt-001-p15s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s6W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s6W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s6W3</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s6W4</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s6W5</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky48860.txt-001-p15s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48860.txt-001-p15s6W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
