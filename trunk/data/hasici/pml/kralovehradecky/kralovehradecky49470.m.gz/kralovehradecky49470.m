<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky49470.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky49470.txt-001-p1s1">
  <m id="m-kralovehradecky49470.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W1</w.rf>
   <form>Společného</form>
   <lemma>společný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W4</w.rf>
   <form>kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W5</w.rf>
   <form>základních</form>
   <lemma>základní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W6</w.rf>
   <form>složek</form>
   <lemma>složka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W7</w.rf>
   <form>IZS</form>
   <lemma>Izs</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W8</w.rf>
   <form>zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W9</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W10</w.rf>
   <form>152</form>
   <lemma>152</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W12</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W13</w.rf>
   <form>prapor</form>
   <lemma>prapor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W14</w.rf>
   <form>Kutná</form>
   <lemma>Kutná_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W15</w.rf>
   <form>Hora</form>
   <lemma>hora</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W17</w.rf>
   <form>příslušníci</form>
   <lemma>příslušník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W18</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W19</w.rf>
   <form>vojenského</form>
   <lemma>vojenský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W20</w.rf>
   <form>velitelství</form>
   <lemma>velitelství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W21</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W22</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p1s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49470.txt-001-p2s1">
  <m id="m-kralovehradecky49470.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W1</w.rf>
   <form>Námětem</form>
   <lemma>námět</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W4</w.rf>
   <form>výbuch</form>
   <lemma>výbuch</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W5</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W6</w.rf>
   <form>následným</form>
   <lemma>následný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W7</w.rf>
   <form>požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W9</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W11</w.rf>
   <form>nález</form>
   <lemma>nález</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W12</w.rf>
   <form>sudů</form>
   <lemma>sud</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W13</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W14</w.rf>
   <form>nebezpečnou</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS7----1N----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W15</w.rf>
   <form>látkou</form>
   <lemma>látka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49470.txt-001-p2s2">
  <m id="m-kralovehradecky49470.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W1</w.rf>
   <form>Uvnitř</form>
   <lemma>uvnitř-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W2</w.rf>
   <form>zčásti</form>
   <lemma>zčásti</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W3</w.rf>
   <form>zřícené</form>
   <lemma>zřícený_^(*4tit)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W4</w.rf>
   <form>budovy</form>
   <lemma>budova</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W5</w.rf>
   <form>zůstane</form>
   <lemma>zůstat</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W6</w.rf>
   <form>uvězněno</form>
   <lemma>uvěznit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W8</w.rf>
   <form>zraněno</form>
   <lemma>zranit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W9</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W10</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W11</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49470.txt-001-p2s3">
  <m id="m-kralovehradecky49470.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W1</w.rf>
   <form>Úkolem</form>
   <lemma>úkol</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W2</w.rf>
   <form>zasahujících</form>
   <lemma>zasahující_^(*5ovat)</lemma>
   <tag>AGFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W3</w.rf>
   <form>složek</form>
   <lemma>složka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W4</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W5</w.rf>
   <form>zajistit</form>
   <lemma>zajistit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W6</w.rf>
   <form>poškozené</form>
   <lemma>poškozený_^(*4dit)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W7</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W8</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W10</w.rf>
   <form>poskytnout</form>
   <lemma>poskytnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W11</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS4----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W12</w.rf>
   <form>předlékařskou</form>
   <lemma>předlékařský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W13</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W15</w.rf>
   <form>vyprostit</form>
   <lemma>vyprostit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W16</w.rf>
   <form>zraněné</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W17</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W19</w.rf>
   <form>zajistit</form>
   <lemma>zajistit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W20</w.rf>
   <form>sudy</form>
   <lemma>sud</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W21</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W22</w.rf>
   <form>neznámou</form>
   <lemma>známý-2_^(co_[ne]známe)</lemma>
   <tag>AAFS7----1N----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W23</w.rf>
   <form>látkou</form>
   <lemma>látka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p2s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p2s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49470.txt-001-p3s1">
  <m id="m-kralovehradecky49470.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W1</w.rf>
   <form>Cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W4</w.rf>
   <form>ověření</form>
   <lemma>ověření_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W5</w.rf>
   <form>akceschopnosti</form>
   <lemma>akceschopnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W7</w.rf>
   <form>součinnosti</form>
   <lemma>součinnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W9</w.rf>
   <form>připravenosti</form>
   <lemma>připravenost_^(*5it)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W10</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W11</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W12</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W14</w.rf>
   <form>složek</form>
   <lemma>složka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W15</w.rf>
   <form>integrovaného</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W16</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W17</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W18</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W19</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W20</w.rf>
   <form>mimořádné</form>
   <lemma>mimořádný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W21</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W23</w.rf>
   <form>ověření</form>
   <lemma>ověření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W24</w.rf>
   <form>komunikace</form>
   <lemma>komunikace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W25</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W26</w.rf>
   <form>složkami</form>
   <lemma>složka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W27</w.rf>
   <form>integrovaného</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W28</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W29</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p3s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49470.txt-001-p4s1">
  <m id="m-kralovehradecky49470.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p4s1W1</w.rf>
   <form>Místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p4s1W2</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p4s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49470.txt-001-p5s1">
  <m id="m-kralovehradecky49470.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W1</w.rf>
   <form>Sobotka</form>
   <lemma>Sobotka_;G_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W3</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W4</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W5</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W6</w.rf>
   <form>Školou</form>
   <lemma>škola</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W8</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W10</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W11</w.rf>
   <form>jednopatrový</form>
   <lemma>jednopatrový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W12</w.rf>
   <form>montovaný</form>
   <lemma>montovaný_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W13</w.rf>
   <form>objekt</form>
   <lemma>objekt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W15</w.rf>
   <form>majetku</form>
   <lemma>majetek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W16</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W18</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W19</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W20</w.rf>
   <form>určený</form>
   <lemma>určený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W21</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W22</w.rf>
   <form>demolici</form>
   <lemma>demolice</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p5s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49470.txt-001-p6s1">
  <m id="m-kralovehradecky49470.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p6s1W1</w.rf>
   <form>Zúčastněné</form>
   <lemma>zúčastněný_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p6s1W2</w.rf>
   <form>složky</form>
   <lemma>složka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49470.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49470.txt-001-p6s1W3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
