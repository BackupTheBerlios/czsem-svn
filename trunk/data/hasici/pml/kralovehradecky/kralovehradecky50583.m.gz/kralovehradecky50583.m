<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky50583.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky50583.txt-001-p1s1">
  <m id="m-kralovehradecky50583.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W3</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W5</w.rf>
   <form>Královéhradeckého</form>
   <lemma>královéhradecký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W6</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W7</w.rf>
   <form>odčerpávali</form>
   <lemma>odčerpávat_:T_^(*4at)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W8</w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W9</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W10</w.rf>
   <form>zatopených</form>
   <lemma>zatopený-1_^(udělat_teplo)_(*5it-1)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W11</w.rf>
   <form>sklepů</form>
   <lemma>sklep</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W13</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W14</w.rf>
   <form>popadané</form>
   <lemma>popadaný_^(*2t)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W15</w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p1s2">
  <m id="m-kralovehradecky50583.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W1</w.rf>
   <form>Nejvíce</form>
   <lemma>hodně</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W2</w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W3</w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W6</w.rf>
   <form>Jičínsku</form>
   <lemma>Jičínsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W7</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W8</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W9</w.rf>
   <form>zásahů</form>
   <lemma>zásah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W12</w.rf>
   <form>Trutnovsku</form>
   <lemma>Trutnovsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W14</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W15</w.rf>
   <form>zásahů</form>
   <lemma>zásah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W16</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p1s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p2s1">
  <m id="m-kralovehradecky50583.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p2s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p2s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p2s1W3</w.rf>
   <form>Jičín</form>
   <lemma>Jičín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p3s1">
  <m id="m-kralovehradecky50583.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W2</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W3</w.rf>
   <form>Královéhradeckého</form>
   <lemma>královéhradecký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W4</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W5</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W6</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W7</w.rf>
   <form>Nová</form>
   <lemma>nový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W8</w.rf>
   <form>Paka</form>
   <lemma>Paka_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W10</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W13</w.rf>
   <form>Nové</form>
   <lemma>nový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W14</w.rf>
   <form>Paky</form>
   <lemma>Paka_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W15</w.rf>
   <form>odčerpávali</form>
   <lemma>odčerpávat_:T_^(*4at)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W16</w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W17</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W18</w.rf>
   <form>zatopeného</form>
   <lemma>zatopený-1_^(udělat_teplo)_(*5it-1)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W19</w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W21</w.rf>
   <form>divadle</form>
   <lemma>divadlo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W23</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W24</w.rf>
   <form>F</form>
   <lemma>F-0_:B_;Y</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W26</w.rf>
   <form>Procházky</form>
   <lemma>Procházka_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W28</w.rf>
   <form>Nové</form>
   <lemma>nový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W29</w.rf>
   <form>Pace</form>
   <lemma>Paka_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p3s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p3s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p4s1">
  <m id="m-kralovehradecky50583.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W4</w.rf>
   <form>Libáně</form>
   <lemma>Libáň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W5</w.rf>
   <form>vyjeli</form>
   <lemma>vyjet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W7</w.rf>
   <form>zatopenému</form>
   <lemma>zatopený-1_^(udělat_teplo)_(*5it-1)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W8</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W9</w.rf>
   <form>čerpací</form>
   <lemma>čerpací_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W10</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W12</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p4s2">
  <m id="m-kralovehradecky50583.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W1</w.rf>
   <form>Vodu</form>
   <lemma>Voda_;G_^(součást_názvu_Odolena_Voda)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W3</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W4</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W5</w.rf>
   <form>odčerpali</form>
   <lemma>odčerpat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W7</w.rf>
   <form>přejeli</form>
   <lemma>přejet_^(např._autem)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W8</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W9</w.rf>
   <form>čerpání</form>
   <lemma>čerpání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W10</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W12</w.rf>
   <form>sklepních</form>
   <lemma>sklepní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W13</w.rf>
   <form>prostor</form>
   <lemma>prostora</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W14</w.rf>
   <form>závodu</form>
   <lemma>závod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W15</w.rf>
   <form>Cadence</form>
   <lemma>Cadence</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W16</w.rf>
   <form>Innovation</form>
   <lemma>Innovation</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W18</w.rf>
   <form>Libni</form>
   <lemma>Libeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p4s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p5s1">
  <m id="m-kralovehradecky50583.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W4</w.rf>
   <form>Libně</form>
   <lemma>Libeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W6</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W8</w.rf>
   <form>profesionálními</form>
   <lemma>profesionální</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W11</w.rf>
   <form>Jičína</form>
   <lemma>Jičín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W12</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W13</w.rf>
   <form>vrbu</form>
   <lemma>vrba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W15</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W16</w.rf>
   <form>spadla</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W18</w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W19</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W20</w.rf>
   <form>domů</form>
   <lemma>dům</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W22</w.rf>
   <form>Tyršově</form>
   <lemma>Tyršův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W23</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W25</w.rf>
   <form>Libáni</form>
   <lemma>Libáň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p5s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p6s1">
  <m id="m-kralovehradecky50583.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W2</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W5</w.rf>
   <form>Lázní</form>
   <lemma>lázeň</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W6</w.rf>
   <form>Bělohrad</form>
   <lemma>Bělohrad_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W7</w.rf>
   <form>odstraňovala</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W8</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W9</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W11</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W12</w.rf>
   <form>blokoval</form>
   <lemma>blokovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W13</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W14</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W15</w.rf>
   <form>Lázní</form>
   <lemma>lázeň</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W16</w.rf>
   <form>Bělohrad</form>
   <lemma>Bělohrad_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p6s2">
  <m id="m-kralovehradecky50583.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W2</w.rf>
   <form>odčerpávali</form>
   <lemma>odčerpávat_:T_^(*4at)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W3</w.rf>
   <form>půl</form>
   <lemma>půl-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W4</w.rf>
   <form>metru</form>
   <lemma>metr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W5</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W7</w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W8</w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W10</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W11</w.rf>
   <form>Sehnalů</form>
   <lemma>Sehnal_;S</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W12</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W14</w.rf>
   <form>Dolní</form>
   <lemma>Dolní_;G</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W15</w.rf>
   <form>Nové</form>
   <lemma>nový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W16</w.rf>
   <form>Vsi</form>
   <lemma>ves</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p6s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p7s1">
  <m id="m-kralovehradecky50583.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W2</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W3</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W4</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W5</w.rf>
   <form>Nová</form>
   <lemma>nový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W6</w.rf>
   <form>Paka</form>
   <lemma>Paka_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W7</w.rf>
   <form>večer</form>
   <lemma>večer</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W8</w.rf>
   <form>znovu</form>
   <lemma>znovu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W9</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W11</w.rf>
   <form>čerpání</form>
   <lemma>čerpání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W12</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W13</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W14</w.rf>
   <form>suterénu</form>
   <lemma>suterén</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W15</w.rf>
   <form>místního</form>
   <lemma>místní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W16</w.rf>
   <form>divadla</form>
   <lemma>divadlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p7s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p8s1">
  <m id="m-kralovehradecky50583.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W2</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W5</w.rf>
   <form>Mladějova</form>
   <lemma>Mladějov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W6</w.rf>
   <form>vyjela</form>
   <lemma>vyjet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W8</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W10</w.rf>
   <form>odčerpáním</form>
   <lemma>odčerpání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W11</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W12</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W13</w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W14</w.rf>
   <form>chaty</form>
   <lemma>chata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W15</w.rf>
   <form>Nebákov</form>
   <lemma>Nebákov</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W17</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W18</w.rf>
   <form>Troskovice</form>
   <lemma>Troskovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W20</w.rf>
   <form>Libereckém</form>
   <lemma>liberecký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W21</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p8s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p8s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p9s1">
  <m id="m-kralovehradecky50583.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p9s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p9s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p9s1W3</w.rf>
   <form>Trutnov</form>
   <lemma>Trutnov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p10s1">
  <m id="m-kralovehradecky50583.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W3</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W4</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W5</w.rf>
   <form>Dvůr</form>
   <lemma>Dvůr_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W7</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W8</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W9</w.rf>
   <form>odčerpávali</form>
   <lemma>odčerpávat_:T_^(*4at)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W10</w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W12</w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W13</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W15</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W16</w.rf>
   <form>Čelakovského</form>
   <lemma>Čelakovský_;S</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W18</w.rf>
   <form>Švehlova</form>
   <lemma>Švehlův_;S_^(*2a)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W20</w.rf>
   <form>Žirečská</form>
   <lemma>Žirečská</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W21</w.rf>
   <form>podstráň</form>
   <lemma>podstráň</lemma>
   <tag>NNFSX-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W22</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W23</w.rf>
   <form>Dvoře</form>
   <lemma>Dvůr_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W24</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W25</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W26</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p10s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p10s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p11s1">
  <m id="m-kralovehradecky50583.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W4</w.rf>
   <form>Dolní</form>
   <lemma>Dolní_;G</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W5</w.rf>
   <form>Kalné</form>
   <lemma>kalný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W6</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W7</w.rf>
   <form>naplavené</form>
   <lemma>naplavený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W8</w.rf>
   <form>bahno</form>
   <lemma>bahno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W9</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W10</w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p11s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p11s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p12s1">
  <m id="m-kralovehradecky50583.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W2</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W5</w.rf>
   <form>Bílé</form>
   <lemma>bílý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W6</w.rf>
   <form>Třemešné</form>
   <lemma>Třemešná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W7</w.rf>
   <form>čerpala</form>
   <lemma>čerpat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W8</w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W9</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W10</w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W11</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W13</w.rf>
   <form>Heydukově</form>
   <lemma>Heydukův_;S_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W14</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W15</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W16</w.rf>
   <form>Dvoře</form>
   <lemma>Dvůr_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W17</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W18</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W19</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p12s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p12s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p13s1">
  <m id="m-kralovehradecky50583.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W4</w.rf>
   <form>Hajnice</form>
   <lemma>Hajnice_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W5</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W6</w.rf>
   <form>požádáni</form>
   <lemma>požádat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W7</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W8</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W10</w.rf>
   <form>odstraněním</form>
   <lemma>odstranění_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W11</w.rf>
   <form>naplavenin</form>
   <lemma>naplavenina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W13</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W14</w.rf>
   <form>ucpaly</form>
   <lemma>ucpat_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W15</w.rf>
   <form>kanalizaci</form>
   <lemma>kanalizace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W17</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W18</w.rf>
   <form>Dobrovského</form>
   <lemma>Dobrovský_;S</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W19</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W20</w.rf>
   <form>Dvoře</form>
   <lemma>Dvůr_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W21</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W22</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W23</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p13s2">
  <m id="m-kralovehradecky50583.txt-001-p13s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s2W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s2W2</w.rf>
   <form>nakonec</form>
   <lemma>nakonec</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s2W3</w.rf>
   <form>nemusela</form>
   <lemma>muset</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s2W4</w.rf>
   <form>zasahovat</form>
   <lemma>zasahovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s2W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p13s3">
  <m id="m-kralovehradecky50583.txt-001-p13s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s3W1</w.rf>
   <form>Voda</form>
   <lemma>Voda_;G_^(součást_názvu_Odolena_Voda)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s3W2</w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s3W3</w.rf>
   <form>ustoupila</form>
   <lemma>ustoupit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s3W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s3W5</w.rf>
   <form>kanalizace</form>
   <lemma>kanalizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s3W6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s3W7</w.rf>
   <form>průchodná</form>
   <lemma>průchodný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p13s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p13s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p14s1">
  <m id="m-kralovehradecky50583.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p14s1W1</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p14s1W2</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p15s1">
  <m id="m-kralovehradecky50583.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W4</w.rf>
   <form>Hořiněvsi</form>
   <lemma>Hořiněves_;G</lemma>
   <tag>XX-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W5</w.rf>
   <form>odčerpávali</form>
   <lemma>odčerpávat_:T_^(*4at)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W6</w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W8</w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W9</w.rf>
   <form>rodinného</form>
   <lemma>rodinný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W10</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W12</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p15s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p15s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p16s1">
  <m id="m-kralovehradecky50583.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W2</w.rf>
   <form>desáté</form>
   <lemma>desátý</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W3</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W4</w.rf>
   <form>večer</form>
   <lemma>večer</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W5</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W6</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W9</w.rf>
   <form>Hořiněvsi</form>
   <lemma>Hořiněves_;G</lemma>
   <tag>XX-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W10</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W11</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W12</w.rf>
   <form>odstranění</form>
   <lemma>odstranění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W13</w.rf>
   <form>bahna</form>
   <lemma>bahno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W15</w.rf>
   <form>naplavenin</form>
   <lemma>naplavenina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W16</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W17</w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W18</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W19</w.rf>
   <form>Hořiněvsí</form>
   <lemma>Hořiněves_;G</lemma>
   <tag>XX-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W21</w.rf>
   <form>Žíželevsí</form>
   <lemma>Žíželevsí</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p16s2">
  <m id="m-kralovehradecky50583.txt-001-p16s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W2</w.rf>
   <form>odstranění</form>
   <lemma>odstranění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W3</w.rf>
   <form>bahna</form>
   <lemma>bahno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W5</w.rf>
   <form>přivolána</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W6</w.rf>
   <form>Správa</form>
   <lemma>správa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W8</w.rf>
   <form>údržba</form>
   <lemma>údržba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W9</w.rf>
   <form>silnic</form>
   <lemma>silnice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p16s3">
  <m id="m-kralovehradecky50583.txt-001-p16s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s3W1</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s3W2</w.rf>
   <form>nemusela</form>
   <lemma>muset</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s3W3</w.rf>
   <form>zasahovat</form>
   <lemma>zasahovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p16s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p16s3W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p17s1">
  <m id="m-kralovehradecky50583.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p17s1W1</w.rf>
   <form>Územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p17s1W2</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p17s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p17s1W3</w.rf>
   <form>Rychnov</form>
   <lemma>Rychnov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p17s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p17s1W4</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p17s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p17s1W5</w.rf>
   <form>Kněžnou</form>
   <lemma>Kněžná_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50583.txt-001-p18s1">
  <m id="m-kralovehradecky50583.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W1</w.rf>
   <form>Dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W4</w.rf>
   <form>Kostelce</form>
   <lemma>Kostelec_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W5</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W6</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W7</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W8</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W10</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W11</w.rf>
   <form>blokoval</form>
   <lemma>blokovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W12</w.rf>
   <form>komunikaci</form>
   <lemma>komunikace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W14</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W15</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W16</w.rf>
   <form>Nádražím</form>
   <lemma>nádraží</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W18</w.rf>
   <form>Kostelci</form>
   <lemma>Kostelec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W19</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W20</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50583.txt-001-p18s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50583.txt-001-p18s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
