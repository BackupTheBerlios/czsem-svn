<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky48194.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky48194.txt-001-p1s1">
  <m id="m-kralovehradecky48194.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W1</w.rf>
   <form>Řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W2</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W3</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W4</w.rf>
   <form>Fiat</form>
   <lemma>Fiat-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W5</w.rf>
   <form>Tempra</form>
   <lemma>Tempra-2_;R_^(vozidlo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W6</w.rf>
   <form>zřejmě</form>
   <lemma>zřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W7</w.rf>
   <form>nepřizpůsobil</form>
   <lemma>přizpůsobit_:W</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W8</w.rf>
   <form>rychlost</form>
   <lemma>rychlost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W9</w.rf>
   <form>jízdy</form>
   <lemma>jízda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W12</w.rf>
   <form>rovném</form>
   <lemma>rovný-1_^(přímý)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W13</w.rf>
   <form>úseku</form>
   <lemma>úsek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W14</w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W15</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W16</w.rf>
   <form>3081</form>
   <lemma>3081</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W17</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W18</w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W20</w.rf>
   <form>Librantice</form>
   <lemma>Librantice_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W21</w.rf>
   <form>vyjel</form>
   <lemma>vyjet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W22</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W23</w.rf>
   <form>protisměru</form>
   <lemma>protisměr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48194.txt-001-p1s2">
  <m id="m-kralovehradecky48194.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W1</w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W2</w.rf>
   <form>vozidlem</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W3</w.rf>
   <form>vjel</form>
   <lemma>vjet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W5</w.rf>
   <form>příkopu</form>
   <lemma>příkop</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W7</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W8</w.rf>
   <form>narazil</form>
   <lemma>narazit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W10</w.rf>
   <form>stromu</form>
   <lemma>strom</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48194.txt-001-p1s3">
  <m id="m-kralovehradecky48194.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W1</w.rf>
   <form>Vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W3</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W4</w.rf>
   <form>převrátilo</form>
   <lemma>převrátit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W5</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W6</w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W8</w.rf>
   <form>skončilo</form>
   <lemma>skončit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W9</w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W10</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W11</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48194.txt-001-p2s1">
  <m id="m-kralovehradecky48194.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W1</w.rf>
   <form>Řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W2</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W3</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W4</w.rf>
   <form>utrpěl</form>
   <lemma>utrpět</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W5</w.rf>
   <form>těžká</form>
   <lemma>těžký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W6</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W8</w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W10</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W11</w.rf>
   <form>podlehl</form>
   <lemma>podlehnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48194.txt-001-p2s2">
  <m id="m-kralovehradecky48194.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W1</w.rf>
   <form>Spolujezdec</form>
   <lemma>spolujezdec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W4</w.rf>
   <form>vážném</form>
   <lemma>vážný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W5</w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W6</w.rf>
   <form>přepraven</form>
   <lemma>přepravit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W8</w.rf>
   <form>královéhradecké</form>
   <lemma>královéhradecký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W9</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W11</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W13</w.rf>
   <form>následky</form>
   <lemma>následek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W14</w.rf>
   <form>svých</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8XP2----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W15</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W16</w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48194.txt-001-p2s3">
  <m id="m-kralovehradecky48194.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W1</w.rf>
   <form>Zasahující</form>
   <lemma>zasahující_^(*5ovat)</lemma>
   <tag>AGMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W3</w.rf>
   <form>pomohli</form>
   <lemma>pomoci</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W4</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W5</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W7</w.rf>
   <form>naložením</form>
   <lemma>naložení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W8</w.rf>
   <form>těžce</form>
   <lemma>těžce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W9</w.rf>
   <form>zraněného</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W10</w.rf>
   <form>spolujezdce</form>
   <lemma>spolujezdec</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W12</w.rf>
   <form>vrtulníku</form>
   <lemma>vrtulník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48194.txt-001-p2s4">
  <m id="m-kralovehradecky48194.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W1</w.rf>
   <form>Následně</form>
   <lemma>následně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W2</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W3</w.rf>
   <form>havarované</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W4</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W5</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W6</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W8</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W9</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W10</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48194.txt-001-p2s5">
  <m id="m-kralovehradecky48194.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s5W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s5W2</w.rf>
   <form>zadokumentování</form>
   <lemma>zadokumentování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s5W3</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s5W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s5W5</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s5W6</w.rf>
   <form>tělo</form>
   <lemma>tělo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s5W7</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48194.txt-001-p2s6">
  <m id="m-kralovehradecky48194.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W4</w.rf>
   <form>míru</form>
   <lemma>míra_^(měřítko,poměr)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W5</w.rf>
   <form>zavinění</form>
   <lemma>zavinění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W6</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W7</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W8</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky48194.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48194.txt-001-p2s6W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
