<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky48202.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky48202.txt-001-p1s1">
  <m id="m-kralovehradecky48202.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W2</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W3</w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AAFS7----3A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W4</w.rf>
   <form>pravděpodobností</form>
   <lemma>pravděpodobnost_^(*3ý)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W5</w.rf>
   <form>způsobila</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W6</w.rf>
   <form>nedbalost</form>
   <lemma>nedbalost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W7</w.rf>
   <form>mladých</form>
   <lemma>mladý</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W8</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W10</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W11</w.rf>
   <form>uvnitř</form>
   <lemma>uvnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W12</w.rf>
   <form>čekárny</form>
   <lemma>čekárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W13</w.rf>
   <form>kouřili</form>
   <lemma>kouřit_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48202.txt-001-p1s2">
  <m id="m-kralovehradecky48202.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W1</w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W2</w.rf>
   <form>odhozeného</form>
   <lemma>odhozený_^(*4dit)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W3</w.rf>
   <form>žhavého</form>
   <lemma>žhavý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W4</w.rf>
   <form>nedopalku</form>
   <lemma>nedopalek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W5</w.rf>
   <form>cigarety</form>
   <lemma>cigareta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W7</w.rf>
   <form>vznítilo</form>
   <lemma>vznítit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W8</w.rf>
   <form>suché</form>
   <lemma>suchý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W9</w.rf>
   <form>listí</form>
   <lemma>listí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W10</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W11</w.rf>
   <form>prkny</form>
   <lemma>prkno</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W12</w.rf>
   <form>zadní</form>
   <lemma>zadní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W13</w.rf>
   <form>stěny</form>
   <lemma>stěna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W14</w.rf>
   <form>čekárny</form>
   <lemma>čekárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48202.txt-001-p1s3">
  <m id="m-kralovehradecky48202.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W1</w.rf>
   <form>Zasahující</form>
   <lemma>zasahující_^(*5ovat)</lemma>
   <tag>AGMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W3</w.rf>
   <form>lokalizovali</form>
   <lemma>lokalizovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W4</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W5</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W6</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W7</w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W9</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W10</w.rf>
   <form>rozebrání</form>
   <lemma>rozebrání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W11</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W12</w.rf>
   <form>dřevěné</form>
   <lemma>dřevěný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W13</w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W15</w.rf>
   <form>dohašení</form>
   <lemma>dohašení_^(*4sit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W16</w.rf>
   <form>ohnisek</form>
   <lemma>ohnisko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W17</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48202.txt-001-p1s4">
  <m id="m-kralovehradecky48202.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W1</w.rf>
   <form>Hmotná</form>
   <lemma>hmotný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W2</w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W4</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W6</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W7</w.rf>
   <form>tisíce</form>
   <lemma>tisíc-2`1000</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W8</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W10</w.rf>
   <form>uchráněné</form>
   <lemma>uchráněný_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W11</w.rf>
   <form>hodnoty</form>
   <lemma>hodnota</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W12</w.rf>
   <form>činí</form>
   <lemma>činit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W13</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W14</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W15</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s4W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48202.txt-001-p1s5">
  <m id="m-kralovehradecky48202.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s5W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s5W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s5W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s5W4</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s5W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48202.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48202.txt-001-p1s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
