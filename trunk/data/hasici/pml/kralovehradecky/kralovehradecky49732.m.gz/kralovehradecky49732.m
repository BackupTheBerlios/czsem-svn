<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky49732.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky49732.txt-001-p1s1">
  <m id="m-kralovehradecky49732.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W2</w.rf>
   <form>těžbě</form>
   <lemma>těžba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W3</w.rf>
   <form>dřeva</form>
   <lemma>dřevo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W4</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W6</w.rf>
   <form>lesního</form>
   <lemma>lesní</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W7</w.rf>
   <form>dělníka</form>
   <lemma>dělník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W8</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W10</w.rf>
   <form>těžce</form>
   <lemma>těžce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W11</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W12</w.rf>
   <form>zranil</form>
   <lemma>zranit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49732.txt-001-p1s2">
  <m id="m-kralovehradecky49732.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W1</w.rf>
   <form>Muže</form>
   <lemma>muž</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W2</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W3</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W4</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W5</w.rf>
   <form>příjezdem</form>
   <lemma>příjezd</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W7</w.rf>
   <form>ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W8</w.rf>
   <form>dělníci</form>
   <lemma>dělník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W10</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W11</w.rf>
   <form>pracovali</form>
   <lemma>pracovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W13</w.rf>
   <form>lese</form>
   <lemma>les</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49732.txt-001-p1s3">
  <m id="m-kralovehradecky49732.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W1</w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W2</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W3</w.rf>
   <form>veškerou</form>
   <lemma>veškerý</lemma>
   <tag>PLFS4----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W4</w.rf>
   <form>snahu</form>
   <lemma>snaha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W5</w.rf>
   <form>lékařů</form>
   <lemma>lékař</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W6</w.rf>
   <form>Rychlé</form>
   <lemma>rychlý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W8</w.rf>
   <form>Letecké</form>
   <lemma>letecký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W9</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W10</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W12</w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W13</w.rf>
   <form>nepodařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W14</w.rf>
   <form>zachránit</form>
   <lemma>zachránit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49732.txt-001-p1s4">
  <m id="m-kralovehradecky49732.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W2</w.rf>
   <form>ohledání</form>
   <lemma>ohledání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W4</w.rf>
   <form>zadokumentování</form>
   <lemma>zadokumentování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W5</w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W6</w.rf>
   <form>neštěstí</form>
   <lemma>neštěstí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W7</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W8</w.rf>
   <form>tělo</form>
   <lemma>tělo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W9</w.rf>
   <form>mrtvého</form>
   <lemma>mrtvý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W10</w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W11</w.rf>
   <form>naloženo</form>
   <lemma>naložit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W13</w.rf>
   <form>nosítka</form>
   <lemma>nosítka</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W15</w.rf>
   <form>opatrně</form>
   <lemma>opatrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W16</w.rf>
   <form>sneseno</form>
   <lemma>snést</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49732.txt-001-p1s5">
  <m id="m-kralovehradecky49732.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W3</w.rf>
   <form>policisté</form>
   <lemma>policista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W5</w.rf>
   <form>člen</form>
   <lemma>člen</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W6</w.rf>
   <form>Horské</form>
   <lemma>horský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W7</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W8</w.rf>
   <form>Deštné</form>
   <lemma>deštný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W10</w.rf>
   <form>Orlických</form>
   <lemma>Orlický_;G</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W11</w.rf>
   <form>horách</form>
   <lemma>hora</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W12</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W14</w.rf>
   <form>těžko</form>
   <lemma>těžko-2_^(sotva)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W15</w.rf>
   <form>přístupném</form>
   <lemma>přístupný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W16</w.rf>
   <form>lesním</form>
   <lemma>lesní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W17</w.rf>
   <form>terénu</form>
   <lemma>terén</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W18</w.rf>
   <form>zdolat</form>
   <lemma>zdolat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W19</w.rf>
   <form>80</form>
   <lemma>80</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W20</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W21</w.rf>
   <form>převýšení</form>
   <lemma>převýšení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W22</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W23</w.rf>
   <form>350</form>
   <lemma>350</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W24</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W25</w.rf>
   <form>vzdálené</form>
   <lemma>vzdálený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W26</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s5W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49732.txt-001-p1s6">
  <m id="m-kralovehradecky49732.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s6W1</w.rf>
   <form>Zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s6W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s6W3</w.rf>
   <form>tělo</form>
   <lemma>tělo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s6W4</w.rf>
   <form>dělníka</form>
   <lemma>dělník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s6W5</w.rf>
   <form>předáno</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s6W6</w.rf>
   <form>pohřební</form>
   <lemma>pohřební</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s6W7</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky49732.txt-001-p1s7">
  <m id="m-kralovehradecky49732.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s7W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s7W2</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s7W3</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s7W4</w.rf>
   <form>šetří</form>
   <lemma>šetřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s7W5</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s7W6</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky49732.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky49732.txt-001-p1s7W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
