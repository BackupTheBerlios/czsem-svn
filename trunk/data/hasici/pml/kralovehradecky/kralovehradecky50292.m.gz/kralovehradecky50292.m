<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky50292.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky50292.txt-001-p1s1">
  <m id="m-kralovehradecky50292.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W1</w.rf>
   <form>Událost</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W4</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W5</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W7</w.rf>
   <form>ohlášena</form>
   <lemma>ohlásit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W9</w.rf>
   <form>04</form>
   <lemma>04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W11</w.rf>
   <form>48</form>
   <lemma>48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W12</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p1s2">
  <m id="m-kralovehradecky50292.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W3</w.rf>
   <form>vyjeli</form>
   <lemma>vyjet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W4</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W7</w.rf>
   <form>Jaroměře</form>
   <lemma>Jaroměř_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W9</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W12</w.rf>
   <form>Jaroměře</form>
   <lemma>Jaroměř_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W14</w.rf>
   <form>Jasenné</form>
   <lemma>Jasenná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W16</w.rf>
   <form>Nového</form>
   <lemma>nový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W17</w.rf>
   <form>Plesu</form>
   <lemma>ples</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p1s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s1">
  <m id="m-kralovehradecky50292.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W5</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W6</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W8</w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W9</w.rf>
   <form>kouř</form>
   <lemma>kouř</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W11</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W12</w.rf>
   <form>vycházel</form>
   <lemma>vycházet_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W13</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W14</w.rf>
   <form>přízemí</form>
   <lemma>přízemí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W15</w.rf>
   <form>dvoupodlažní</form>
   <lemma>dvoupodlažní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W16</w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W17</w.rf>
   <form>drůbežárny</form>
   <lemma>drůbežárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s2">
  <m id="m-kralovehradecky50292.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W1</w.rf>
   <form>Jakmile</form>
   <lemma>jakmile</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W3</w.rf>
   <form>otevřeli</form>
   <lemma>otevřít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W4</w.rf>
   <form>vrata</form>
   <lemma>vrata</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W5</w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W7</w.rf>
   <form>podestýlka</form>
   <lemma>podestýlka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W9</w.rf>
   <form>okamžitě</form>
   <lemma>okamžitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W10</w.rf>
   <form>rozhořela</form>
   <lemma>rozhořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W11</w.rf>
   <form>plamenem</form>
   <lemma>plamen</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s3">
  <m id="m-kralovehradecky50292.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W2</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W3</w.rf>
   <form>začali</form>
   <lemma>začít-1</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W4</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W5</w.rf>
   <form>hašením</form>
   <lemma>hašení_^(*4sit)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W7</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W8</w.rf>
   <form>třídenní</form>
   <lemma>třídenní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W9</w.rf>
   <form>osádku</form>
   <lemma>osádka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W10</w.rf>
   <form>drůbeže</form>
   <lemma>drůbež</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W12</w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PPXP3--3-------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W13</w.rf>
   <form>nepodařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W14</w.rf>
   <form>zachránit</form>
   <lemma>zachránit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s4">
  <m id="m-kralovehradecky50292.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W1</w.rf>
   <form>Téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W2</w.rf>
   <form>15600</form>
   <form_change>num_normalization</form_change>
   <lemma>15600</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W3</w.rf>
   <form>kusů</form>
   <lemma>kus</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W4</w.rf>
   <form>malých</form>
   <lemma>malý</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W5</w.rf>
   <form>kuřátek</form>
   <lemma>kuřátko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W7</w.rf>
   <form>udusilo</form>
   <lemma>udusit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W8</w.rf>
   <form>kouřem</form>
   <lemma>kouř</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s5">
  <m id="m-kralovehradecky50292.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s5W1</w.rf>
   <form>Druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s5W2</w.rf>
   <form>patro</form>
   <lemma>patro</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s5W3</w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s5W4</w.rf>
   <form>zůstalo</form>
   <lemma>zůstat</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s5W5</w.rf>
   <form>neporušeno</form>
   <lemma>porušit_:W</lemma>
   <tag>VsNS---XX-NP---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s6">
  <m id="m-kralovehradecky50292.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W2</w.rf>
   <form>uhašení</form>
   <lemma>uhašení_^(*4sit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W3</w.rf>
   <form>plamenů</form>
   <lemma>plamen</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W5</w.rf>
   <form>odvětrali</form>
   <lemma>odvětrat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W6</w.rf>
   <form>zakouřené</form>
   <lemma>zakouřený_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W7</w.rf>
   <form>prostory</form>
   <lemma>prostora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W9</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W10</w.rf>
   <form>dostatečný</form>
   <lemma>dostatečný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W11</w.rf>
   <form>přívod</form>
   <lemma>přívod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W12</w.rf>
   <form>vzduchu</form>
   <lemma>vzduch</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W14</w.rf>
   <form>druhého</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W15</w.rf>
   <form>patra</form>
   <lemma>patro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W16</w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W17</w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W18</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W19</w.rf>
   <form>drůbeži</form>
   <lemma>drůbež</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s6W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s7">
  <m id="m-kralovehradecky50292.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s7W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s7W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s7W3</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s7W4</w.rf>
   <form>zlikvidovat</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s7W5</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s7W6</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s7W7</w.rf>
   <form>hodiny</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s7W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s8">
  <m id="m-kralovehradecky50292.txt-001-p2s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W1</w.rf>
   <form>Majitel</form>
   <lemma>majitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W2</w.rf>
   <form>vyčíslil</form>
   <lemma>vyčíslit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W3</w.rf>
   <form>škodu</form>
   <lemma>škoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W4</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W6</w.rf>
   <form>950</form>
   <lemma>950</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W7</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W8</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W9</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W10</w.rf>
   <form>200</form>
   <lemma>200</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W11</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W12</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W15</w.rf>
   <form>kuřata</form>
   <lemma>kuře</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W17</w.rf>
   <form>750</form>
   <lemma>750</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W18</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W19</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W22</w.rf>
   <form>technologie</form>
   <lemma>technologie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W24</w.rf>
   <form>následné</form>
   <lemma>následný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W25</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s8W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s8W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s9">
  <m id="m-kralovehradecky50292.txt-001-p2s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s9W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s9W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s9W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s9W4</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s9W5</w.rf>
   <form>předmětem</form>
   <lemma>předmět</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s9W6</w.rf>
   <form>dalšího</form>
   <lemma>další</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s9W7</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s9W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50292.txt-001-p2s10">
  <m id="m-kralovehradecky50292.txt-001-p2s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s10W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s10W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s10W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s10W4</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s10W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50292.txt-001-p2s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50292.txt-001-p2s10W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
