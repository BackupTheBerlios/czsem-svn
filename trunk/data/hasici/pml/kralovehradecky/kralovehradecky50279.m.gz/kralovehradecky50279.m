<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky50279.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky50279.txt-001-p1s1">
  <m id="m-kralovehradecky50279.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W1</w.rf>
   <form>Požár</form>
   <lemma>Požár-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W2</w.rf>
   <form>zpozoroval</form>
   <lemma>zpozorovat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W4</w.rf>
   <form>ohlásil</form>
   <lemma>ohlásit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W5</w.rf>
   <form>řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W7</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W8</w.rf>
   <form>projížděl</form>
   <lemma>projíždět_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W9</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W10</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W11</w.rf>
   <form>nedaleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W12</w.rf>
   <form>usedlosti</form>
   <lemma>usedlost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p1s2">
  <m id="m-kralovehradecky50279.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W1</w.rf>
   <form>Kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W2</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W5</w.rf>
   <form>Rychnova</form>
   <lemma>Rychnov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W6</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W7</w.rf>
   <form>Kněžnou</form>
   <lemma>Kněžná_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W8</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W10</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W11</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W12</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W15</w.rf>
   <form>Kostelce</form>
   <lemma>Kostelec_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W16</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W17</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W19</w.rf>
   <form>Rychnova</form>
   <lemma>Rychnov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W20</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W21</w.rf>
   <form>Kněžnou</form>
   <lemma>Kněžná_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W23</w.rf>
   <form>Vamberku</form>
   <lemma>Vamberk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W25</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W26</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W27</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W28</w.rf>
   <form>Auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W29</w.rf>
   <form>Kvasiny</form>
   <lemma>Kvasiny_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p1s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p1s2W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p2s1">
  <m id="m-kralovehradecky50279.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W5</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W6</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W8</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W9</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W10</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W12</w.rf>
   <form>čtvrté</form>
   <lemma>čtvrtý</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W14</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W15</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W17</w.rf>
   <form>fázi</form>
   <lemma>fáze</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W18</w.rf>
   <form>hoření</form>
   <lemma>hoření_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p2s2">
  <m id="m-kralovehradecky50279.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W3</w.rf>
   <form>dýchacích</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W4</w.rf>
   <form>přístrojích</form>
   <lemma>přístroj</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W5</w.rf>
   <form>nasadili</form>
   <lemma>nasadit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W6</w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W7</w.rf>
   <form>vodních</form>
   <lemma>vodní</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W8</w.rf>
   <form>proudů</form>
   <lemma>proud</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W10</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W11</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W12</w.rf>
   <form>půl</form>
   <lemma>půl-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W13</w.rf>
   <form>hodině</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W14</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W15</w.rf>
   <form>nahlášení</form>
   <lemma>nahlášení_^(*4sit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W16</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W17</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W18</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p2s3">
  <m id="m-kralovehradecky50279.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W1</w.rf>
   <form>Zasažena</form>
   <lemma>zasáhnout</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W3</w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W4</w.rf>
   <form>nově</form>
   <lemma>nově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W5</w.rf>
   <form>zrekonstruovaná</form>
   <lemma>zrekonstruovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W6</w.rf>
   <form>zemědělská</form>
   <lemma>zemědělský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W7</w.rf>
   <form>usedlost</form>
   <lemma>usedlost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W8</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W9</w.rf>
   <form>rozměru</form>
   <lemma>rozměr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W10</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W11</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W12</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W13</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W14</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W16</w.rf>
   <form>stodola</form>
   <lemma>stodola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W17</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W18</w.rf>
   <form>rozměru</form>
   <lemma>rozměr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W19</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W20</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W21</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W22</w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s3W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p2s4">
  <m id="m-kralovehradecky50279.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W2</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W6</w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W7</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W8</w.rf>
   <form>nenacházel</form>
   <lemma>nacházet_:T</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p2s5">
  <m id="m-kralovehradecky50279.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W2</w.rf>
   <form>vznikl</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W4</w.rf>
   <form>stodole</form>
   <lemma>stodola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W6</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W7</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W8</w.rf>
   <form>uskladněno</form>
   <lemma>uskladnit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W9</w.rf>
   <form>seno</form>
   <lemma>seno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W11</w.rf>
   <form>nakladač</form>
   <lemma>nakladač</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W13</w.rf>
   <form>drobné</form>
   <lemma>drobný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W14</w.rf>
   <form>nářadí</form>
   <lemma>nářadí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s5W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p2s6">
  <m id="m-kralovehradecky50279.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W1</w.rf>
   <form>Ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W2</w.rf>
   <form>stodoly</form>
   <lemma>stodola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W3</w.rf>
   <form>plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W4</w.rf>
   <form>přeskočily</form>
   <lemma>přeskočit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W6</w.rf>
   <form>celodřevěnou</form>
   <lemma>celodřevěný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W7</w.rf>
   <form>obytnou</form>
   <lemma>obytný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W8</w.rf>
   <form>budovu</form>
   <lemma>budova</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W10</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W11</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W12</w.rf>
   <form>zničily</form>
   <lemma>zničit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s6W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p2s7">
  <m id="m-kralovehradecky50279.txt-001-p2s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W1</w.rf>
   <form>Ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W2</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W3</w.rf>
   <form>příjezdem</form>
   <lemma>příjezd</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W4</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W6</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W7</w.rf>
   <form>sousedovi</form>
   <lemma>soused</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W9</w.rf>
   <form>policejní</form>
   <lemma>policejní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W10</w.rf>
   <form>hlídce</form>
   <lemma>hlídka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W11</w.rf>
   <form>vyvést</form>
   <lemma>vyvést</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W13</w.rf>
   <form>hořícího</form>
   <lemma>hořící_^(*3et)</lemma>
   <tag>AGIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W14</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W15</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W16</w.rf>
   <form>koně</form>
   <lemma>kůň</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W18</w.rf>
   <form>psa</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p2s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p2s7W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p3s1">
  <m id="m-kralovehradecky50279.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W3</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W4</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W5</w.rf>
   <form>zlikvidovat</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W6</w.rf>
   <form>krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W7</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W8</w.rf>
   <form>šestou</form>
   <lemma>šestý</lemma>
   <tag>CrFS7----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W9</w.rf>
   <form>hodinou</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W10</w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p3s2">
  <m id="m-kralovehradecky50279.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W1</w.rf>
   <form>Voda</form>
   <lemma>Voda_;G_^(součást_názvu_Odolena_Voda)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W3</w.rf>
   <form>uhašení</form>
   <lemma>uhašení_^(*4sit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W4</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W5</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W7</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W8</w.rf>
   <form>dopravována</form>
   <lemma>dopravovat_:T</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W9</w.rf>
   <form>kyvadlově</form>
   <lemma>kyvadlově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W10</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W11</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W12</w.rf>
   <form>čerpacích</form>
   <lemma>čerpací_^(*2t)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W13</w.rf>
   <form>stanovišť</form>
   <lemma>stanoviště</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W15</w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W16</w.rf>
   <form>Zdobnice</form>
   <lemma>Zdobnice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W18</w.rf>
   <form>nadzemního</form>
   <lemma>nadzemní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W19</w.rf>
   <form>hydrantu</form>
   <lemma>hydrant</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W21</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W22</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W23</w.rf>
   <form>Vamberku</form>
   <lemma>Vamberk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p3s3">
  <m id="m-kralovehradecky50279.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W1</w.rf>
   <form>Hmotná</form>
   <lemma>hmotný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W2</w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W4</w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W5</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W6</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W7</w.rf>
   <form>odhadnuta</form>
   <lemma>odhadnout_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W9</w.rf>
   <form>1.5</form>
   <form_change>num_normalization</form_change>
   <lemma>1.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W10</w.rf>
   <form>mil</form>
   <lemma>milión`1000000_:B_,x</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W12</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p3s4">
  <m id="m-kralovehradecky50279.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W1</w.rf>
   <form>Přesné</form>
   <lemma>přesný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W2</w.rf>
   <form>příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W3</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W4</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W5</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W6</w.rf>
   <form>předmětem</form>
   <lemma>předmět</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W7</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W10</w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AAFS7----3A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W11</w.rf>
   <form>pravděpodobností</form>
   <lemma>pravděpodobnost_^(*3ý)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W13</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W14</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W15</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W16</w.rf>
   <form>úmyslné</form>
   <lemma>úmyslný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W17</w.rf>
   <form>založení</form>
   <lemma>založení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W18</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s4W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky50279.txt-001-p3s5">
  <m id="m-kralovehradecky50279.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s5W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s5W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s5W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s5W4</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s5W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky50279.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky50279.txt-001-p3s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
