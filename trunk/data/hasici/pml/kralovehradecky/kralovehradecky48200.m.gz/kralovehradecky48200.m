<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="kralovehradecky48200.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-kralovehradecky48200.txt-001-p1s1">
  <m id="m-kralovehradecky48200.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W3</w.rf>
   <form>vyjeli</form>
   <lemma>vyjet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W4</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W5</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W8</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W11</w.rf>
   <form>Bílé</form>
   <lemma>bílý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W12</w.rf>
   <form>Třemešné</form>
   <lemma>Třemešná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p1s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48200.txt-001-p2s1">
  <m id="m-kralovehradecky48200.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W1</w.rf>
   <form>Dřevěnou</form>
   <lemma>dřevěný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W2</w.rf>
   <form>kůlnu</form>
   <lemma>kůlna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W4</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W5</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W6</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W7</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W8</w.rf>
   <form>metry</form>
   <lemma>metrum</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W9</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W10</w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PZM-1----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W11</w.rf>
   <form>úmyslně</form>
   <lemma>úmyslně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W12</w.rf>
   <form>zapálil</form>
   <lemma>zapálit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48200.txt-001-p2s2">
  <m id="m-kralovehradecky48200.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W1</w.rf>
   <form>Plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W3</w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W4</w.rf>
   <form>silnému</form>
   <lemma>silný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W5</w.rf>
   <form>větru</form>
   <lemma>vítr</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W6</w.rf>
   <form>rozšířily</form>
   <lemma>rozšířit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W7</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W9</w.rf>
   <form>rozestavěnou</form>
   <lemma>rozestavěný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W10</w.rf>
   <form>dřevěnou</form>
   <lemma>dřevěný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W11</w.rf>
   <form>chatku</form>
   <lemma>chatka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W12</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W13</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W14</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W15</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W16</w.rf>
   <form>5.4</form>
   <form_change>num_normalization</form_change>
   <lemma>5.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W17</w.rf>
   <form>metry</form>
   <lemma>metrum</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48200.txt-001-p2s3">
  <m id="m-kralovehradecky48200.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W1</w.rf>
   <form>Požár</form>
   <lemma>Požár-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W3</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W4</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W5</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W6</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W7</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W8</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W9</w.rf>
   <form>hodinu</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48200.txt-001-p2s4">
  <m id="m-kralovehradecky48200.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W2</w.rf>
   <form>uhašení</form>
   <lemma>uhašení_^(*4sit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W3</w.rf>
   <form>rozebrali</form>
   <lemma>rozebrat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W5</w.rf>
   <form>dohasili</form>
   <lemma>dohasit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W6</w.rf>
   <form>hromadu</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W7</w.rf>
   <form>palivového</form>
   <lemma>palivový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W8</w.rf>
   <form>dřeva</form>
   <lemma>dřevo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W9</w.rf>
   <form>nedaleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W10</w.rf>
   <form>požářiště</form>
   <lemma>požářiště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48200.txt-001-p2s5">
  <m id="m-kralovehradecky48200.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W1</w.rf>
   <form>Oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W2</w.rf>
   <form>objekty</form>
   <lemma>objekt</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W5</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W6</w.rf>
   <form>vybavením</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W7</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W8</w.rf>
   <form>zničeny</form>
   <lemma>zničit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W10</w.rf>
   <form>hmotná</form>
   <lemma>hmotný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W11</w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W12</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W13</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W15</w.rf>
   <form>110</form>
   <lemma>110</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W16</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W17</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-kralovehradecky48200.txt-001-p2s6">
  <m id="m-kralovehradecky48200.txt-001-p2s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s6W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s6W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s6W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s6W4</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s6W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-kralovehradecky48200.txt-001-p2s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-kralovehradecky48200.txt-001-p2s6W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
