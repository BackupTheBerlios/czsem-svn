<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky50117.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky50117.txt-001-p1s1">
  <m id="m-pardubicky50117.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W1</w.rf>
   <form>Profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W4</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W5</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W6</w.rf>
   <form>soutěžili</form>
   <lemma>soutěžit_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W8</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS6----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W10</w.rf>
   <form>disciplín</form>
   <lemma>disciplína</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W11</w.rf>
   <form>požárního</form>
   <lemma>požární</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W12</w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W15</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W16</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W17</w.rf>
   <form>výstupu</form>
   <lemma>výstup</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W19</w.rf>
   <form>čtvrtého</form>
   <lemma>čtvrtý</lemma>
   <tag>CrNS2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W20</w.rf>
   <form>patra</form>
   <lemma>patro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W21</w.rf>
   <form>cvičné</form>
   <lemma>cvičný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W22</w.rf>
   <form>věže</form>
   <lemma>věž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W23</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W24</w.rf>
   <form>hákového</form>
   <lemma>hákový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W25</w.rf>
   <form>žebříku</form>
   <lemma>žebřík</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p1s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p2s1">
  <m id="m-pardubicky50117.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W2</w.rf>
   <form>úvod</form>
   <lemma>úvod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W3</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W5</w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W6</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W7</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W9</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W10</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W11</w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W12</w.rf>
   <form>Ligy</form>
   <lemma>liga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W13</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W15</w.rf>
   <form>přijeli</form>
   <lemma>přijet-1_^(např._autem)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W16</w.rf>
   <form>povzbudit</form>
   <lemma>povzbudit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W17</w.rf>
   <form>soutěžící</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W18</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W19</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W20</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W21</w.rf>
   <form>Šilar</form>
   <lemma>Šilar_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W23</w.rf>
   <form>člen</form>
   <lemma>člen</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W24</w.rf>
   <form>Rady</form>
   <lemma>rada-1_^(př._dát_někomu_dobrou_radu)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W25</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W26</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W28</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W29</w.rf>
   <form>místostarosta</form>
   <lemma>místostarosta</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W30</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W31</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W32</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W33</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W34</w.rf>
   <form>Mgr</form>
   <lemma>Mgr-1_:B_,x_^(magistr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s1W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p2s2">
  <m id="m-pardubicky50117.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s2W1</w.rf>
   <form>Luboš</form>
   <lemma>Luboš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s2W2</w.rf>
   <form>Bäuchel</form>
   <lemma>Bäuchel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p2s2W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p3s1">
  <m id="m-pardubicky50117.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W2</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W4</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W5</w.rf>
   <form>přihlášeno</form>
   <lemma>přihlásit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W6</w.rf>
   <form>123</form>
   <lemma>123</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W7</w.rf>
   <form>soutěžících</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGMP2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W9</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W10</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W11</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p3s2">
  <m id="m-pardubicky50117.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W1</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W2</w.rf>
   <form>okres</form>
   <lemma>okres</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W3</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W4</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W5</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W6</w.rf>
   <form>bojovali</form>
   <lemma>bojovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W7</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W8</w.rf>
   <form>vítězství</form>
   <lemma>vítězství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W9</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W12</w.rf>
   <form>domácí</form>
   <lemma>domácí</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W13</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W16</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W17</w.rf>
   <form>Marcel</form>
   <lemma>Marcel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W18</w.rf>
   <form>Novotný</form>
   <lemma>Novotný_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W20</w.rf>
   <form>David</form>
   <lemma>David_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W21</w.rf>
   <form>Hynek</form>
   <lemma>Hynek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W22</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W23</w.rf>
   <form>Jindřich</form>
   <lemma>Jindřich_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W24</w.rf>
   <form>Matějíček</form>
   <lemma>Matějíček_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p3s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p4s1">
  <m id="m-pardubicky50117.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W1</w.rf>
   <form>Nejlepším</form>
   <lemma>dobrý</lemma>
   <tag>AAMS7----3A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W2</w.rf>
   <form>závodníkem</form>
   <lemma>závodník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W3</w.rf>
   <form>Orlické</form>
   <lemma>Orlický_;G</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W4</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W5</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W7</w.rf>
   <form>letech</form>
   <lemma>rok</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W8</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W10</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W12</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W14</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W15</w.rf>
   <form>Radek</form>
   <lemma>Radek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W16</w.rf>
   <form>Vyvial</form>
   <lemma>Vyvial</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W17</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W18</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W19</w.rf>
   <form>ÚO</form>
   <lemma>ÚO</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W20</w.rf>
   <form>Kolín</form>
   <lemma>Kolín-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W22</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W23</w.rf>
   <form>vystoupal</form>
   <lemma>vystoupat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W25</w.rf>
   <form>věž</form>
   <lemma>věž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W26</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W27</w.rf>
   <form>14.09</form>
   <form_change>num_normalization</form_change>
   <lemma>14.09</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W28</w.rf>
   <form>sekund</form>
   <lemma>sekunda</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p4s2">
  <m id="m-pardubicky50117.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W1</w.rf>
   <form>Před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W2</w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>P5ZS7--3-------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W4</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W5</w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W6</w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W7</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W9</w.rf>
   <form>1995-1999</form>
   <lemma>1995-1999</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W11</w.rf>
   <form>nejlepším</form>
   <lemma>dobrý</lemma>
   <tag>AAMS7----3A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W12</w.rf>
   <form>závodníkem</form>
   <lemma>závodník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W13</w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W14</w.rf>
   <form>Pěnča</form>
   <lemma>Pěnča</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W15</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W16</w.rf>
   <form>Strakonic</form>
   <lemma>Strakonice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p4s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p5s1">
  <m id="m-pardubicky50117.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W1</w.rf>
   <form>Letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W3</w.rf>
   <form>stal</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W4</w.rf>
   <form>nejlepším</form>
   <lemma>dobrý</lemma>
   <tag>AAMS7----3A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W5</w.rf>
   <form>závodníkem</form>
   <lemma>závodník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W6</w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W7</w.rf>
   <form>Ryl</form>
   <lemma>rýt</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W9</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W10</w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p5s2">
  <m id="m-pardubicky50117.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W1</w.rf>
   <form>Druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W2</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W3</w.rf>
   <form>obsadil</form>
   <lemma>obsadit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W4</w.rf>
   <form>Marek</form>
   <lemma>Marek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W5</w.rf>
   <form>Jarůšek</form>
   <lemma>Jarůšek_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W7</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W8</w.rf>
   <form>Blansko</form>
   <lemma>Blansko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W11</w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrNS6----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W12</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W13</w.rf>
   <form>skončil</form>
   <lemma>skončit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W14</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W15</w.rf>
   <form>Neubert</form>
   <lemma>Neubert_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W17</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W18</w.rf>
   <form>Jílové</form>
   <lemma>jílový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p5s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p6s1">
  <m id="m-pardubicky50117.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W2</w.rf>
   <form>stanici</form>
   <lemma>stanice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W4</w.rf>
   <form>zároveň</form>
   <lemma>zároveň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W5</w.rf>
   <form>konal</form>
   <lemma>konat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W6</w.rf>
   <form>Den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W7</w.rf>
   <form>otevřených</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W8</w.rf>
   <form>dveří</form>
   <lemma>dveře</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W11</w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W12</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W14</w.rf>
   <form>putovaly</form>
   <lemma>putovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W15</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W16</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W17</w.rf>
   <form>základních</form>
   <lemma>základní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W18</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W19</w.rf>
   <form>mateřských</form>
   <lemma>mateřský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W20</w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W21</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W22</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W24</w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W25</w.rf>
   <form>široká</form>
   <lemma>široký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W26</w.rf>
   <form>veřejnost</form>
   <lemma>veřejnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p6s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50117.txt-001-p7s1">
  <m id="m-pardubicky50117.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p7s1W1</w.rf>
   <form>Výsledková</form>
   <lemma>výsledkový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p7s1W2</w.rf>
   <form>listina</form>
   <lemma>listina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p7s1W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p7s1W4</w.rf>
   <form>62kb</form>
   <lemma>62kb</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky50117.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50117.txt-001-p7s1W5</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
