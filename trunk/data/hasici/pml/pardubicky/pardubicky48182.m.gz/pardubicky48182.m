<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky48182.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky48182.txt-001-p1s1">
  <m id="m-pardubicky48182.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W1</w.rf>
   <form>Během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W2</w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W3</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W4</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W5</w.rf>
   <form>vzniklo</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VpNS---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W7</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W8</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W9</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W10</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W11</w.rf>
   <form>130</form>
   <lemma>130</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W12</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W14</w.rf>
   <form>přičemž</form>
   <lemma>přičemž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W15</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W16</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W17</w.rf>
   <form>polovina</form>
   <lemma>polovina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W18</w.rf>
   <form>jich</form>
   <lemma>on-1</lemma>
   <tag>PPXP2--3-------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W19</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W21</w.rf>
   <form>přírodním</form>
   <lemma>přírodní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W22</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W23</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W24</w.rf>
   <form>požáry</form>
   <lemma>požár</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W25</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W27</w.rf>
   <form>lesních</form>
   <lemma>lesní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W28</w.rf>
   <form>porostů</form>
   <lemma>porost</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W29</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p1s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48182.txt-001-p2s1">
  <m id="m-pardubicky48182.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W1</w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W2</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W3</w.rf>
   <form>zvýšenému</form>
   <lemma>zvýšený_^(*3it)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W4</w.rf>
   <form>počtu</form>
   <lemma>počet</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W5</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W7</w.rf>
   <form>nepříznivým</form>
   <lemma>příznivý</lemma>
   <tag>AAFP3----1N----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W8</w.rf>
   <form>klimatickým</form>
   <lemma>klimatický</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W9</w.rf>
   <form>podmínkám</form>
   <lemma>podmínka</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W10</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W11</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W12</w.rf>
   <form>dlouhodobé</form>
   <lemma>dlouhodobý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W13</w.rf>
   <form>předpovědi</form>
   <lemma>předpověď</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W14</w.rf>
   <form>Českého</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W15</w.rf>
   <form>hydrometeorologického</form>
   <lemma>hydrometeorologický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W16</w.rf>
   <form>ústavu</form>
   <lemma>ústav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W17</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W18</w.rf>
   <form>suché</form>
   <lemma>suchý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W19</w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W20</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W21</w.rf>
   <form>srážek</form>
   <lemma>srážka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W22</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W24</w.rf>
   <form>měsíci</form>
   <lemma>měsíc</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W25</w.rf>
   <form>květnu</form>
   <lemma>květen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W27</w.rf>
   <form>navrhuje</form>
   <lemma>navrhovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W28</w.rf>
   <form>Hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W29</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W30</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W31</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W32</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W33</w.rf>
   <form>vyhlásit</form>
   <lemma>vyhlásit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W34</w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W35</w.rf>
   <form>zvýšeného</form>
   <lemma>zvýšený_^(*3it)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W36</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W37</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W38</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W39</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W40</w.rf>
   <form>celém</form>
   <lemma>celý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W41</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W42</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W43</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W44</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W45</w.rf>
   <form>odvolání</form>
   <lemma>odvolání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48182.txt-001-p2s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48182.txt-001-p2s1W46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
