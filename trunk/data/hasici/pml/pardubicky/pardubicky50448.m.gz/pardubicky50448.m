<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky50448.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky50448.txt-001-p1s1">
  <m id="m-pardubicky50448.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W2</w.rf>
   <form>Jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W5</w.rf>
   <form>procvičila</form>
   <lemma>procvičit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W6</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W7</w.rf>
   <form>připravenost</form>
   <lemma>připravenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W8</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W9</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W11</w.rf>
   <form>nejvyšších</form>
   <lemma>vysoký</lemma>
   <tag>AANP2----3A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W12</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W13</w.rf>
   <form>výškové</form>
   <lemma>výškový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W14</w.rf>
   <form>budovy</form>
   <lemma>budova</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W16</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W17</w.rf>
   <form>uvedl</form>
   <lemma>uvést</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W18</w.rf>
   <form>velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W19</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W20</w.rf>
   <form>nprap</form>
   <lemma>nadpraporčík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50448.txt-001-p1s2">
  <m id="m-pardubicky50448.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s2W1</w.rf>
   <form>Mgr</form>
   <lemma>Mgr-1_:B_,x_^(magistr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s2W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50448.txt-001-p1s3">
  <m id="m-pardubicky50448.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s3W1</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s3W2</w.rf>
   <form>Drápalík</form>
   <lemma>Drápalík_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s3W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50448.txt-001-p1s4">
  <m id="m-pardubicky50448.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W2</w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>P5ZS2--3-------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W4</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W5</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W6</w.rf>
   <form>prioritou</form>
   <lemma>priorita</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W7</w.rf>
   <form>provést</form>
   <lemma>provést</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W8</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W10</w.rf>
   <form>vnitřní</form>
   <lemma>vnitřní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W11</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W12</w.rf>
   <form>zásahovou</form>
   <lemma>zásahový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W13</w.rf>
   <form>cestou</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W14</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W15</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W16</w.rf>
   <form>suchovodu</form>
   <lemma>suchovod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50448.txt-001-p1s5">
  <m id="m-pardubicky50448.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W1</w.rf>
   <form>Další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W2</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W4</w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W5</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W6</w.rf>
   <form>úkol</form>
   <lemma>úkol</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W7</w.rf>
   <form>ochránit</form>
   <lemma>ochránit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W8</w.rf>
   <form>vnější</form>
   <lemma>vnější</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W9</w.rf>
   <form>plášť</form>
   <lemma>plášť</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W10</w.rf>
   <form>budovy</form>
   <lemma>budova</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W11</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W12</w.rf>
   <form>lafetové</form>
   <lemma>lafetový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W13</w.rf>
   <form>proudnice</form>
   <lemma>proudnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W15</w.rf>
   <form>automobilového</form>
   <lemma>automobilový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W16</w.rf>
   <form>žebříku</form>
   <lemma>žebřík</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W17</w.rf>
   <form>AZ</form>
   <lemma>AZ-1_:B_;G_^(Azerbájdžán,_mez._zkr.)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W18</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W19</w.rf>
   <form>Camiva</form>
   <lemma>Camiva</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s5W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50448.txt-001-p1s6">
  <m id="m-pardubicky50448.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W1</w.rf>
   <form>Ač</form>
   <lemma>ač</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W3</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W4</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W5</w.rf>
   <form>simulovaný</form>
   <lemma>simulovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W7</w.rf>
   <form>nedošlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W8</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W9</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W10</w.rf>
   <form>evakuaci</form>
   <lemma>evakuace</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W11</w.rf>
   <form>obyvatel</form>
   <lemma>obyvatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W14</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W15</w.rf>
   <form>cvičný</form>
   <lemma>cvičný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W16</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W17</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W18</w.rf>
   <form>problémů</form>
   <lemma>problém</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W20</w.rf>
   <form>zvládli</form>
   <lemma>zvládnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W21</w.rf>
   <form>taktiku</form>
   <lemma>taktika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W22</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W23</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W24</w.rf>
   <form>chybičky</form>
   <lemma>chybička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p1s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p1s6W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50448.txt-001-p2s1">
  <m id="m-pardubicky50448.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W2</w.rf>
   <form>Taktická</form>
   <lemma>taktický</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W3</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W4</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W5</w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W6</w.rf>
   <form>odborné</form>
   <lemma>odborný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W7</w.rf>
   <form>přípravy</form>
   <lemma>příprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W8</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W9</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W10</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W11</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W13</w.rf>
   <form>prohlubují</form>
   <lemma>prohlubovat_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W14</w.rf>
   <form>schopnosti</form>
   <lemma>schopnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W15</w.rf>
   <form>velitelů</form>
   <lemma>velitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W17</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W19</w.rf>
   <form>pomáhají</form>
   <lemma>pomáhat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W20</w.rf>
   <form>vytvořit</form>
   <lemma>vytvořit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W21</w.rf>
   <form>dynamické</form>
   <lemma>dynamický</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W22</w.rf>
   <form>stereotypy</form>
   <lemma>stereotyp</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W23</w.rf>
   <form>zasahující</form>
   <lemma>zasahující_^(*5ovat)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W24</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W26</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W27</w.rf>
   <form>doplnil</form>
   <lemma>doplnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W28</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W29</w.rf>
   <form>závěr</form>
   <lemma>závěr_^(př._z_jednání,_úvah)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W30</w.rf>
   <form>nprap</form>
   <lemma>nadpraporčík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50448.txt-001-p2s2">
  <m id="m-pardubicky50448.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s2W1</w.rf>
   <form>Mgr</form>
   <lemma>Mgr-1_:B_,x_^(magistr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s2W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50448.txt-001-p2s3">
  <m id="m-pardubicky50448.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s3W1</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s3W2</w.rf>
   <form>Drápalík</form>
   <lemma>Drápalík_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50448.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50448.txt-001-p2s3W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
