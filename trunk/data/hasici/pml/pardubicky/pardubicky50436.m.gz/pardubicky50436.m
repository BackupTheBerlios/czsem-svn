<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky50436.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky50436.txt-001-p1s1">
  <m id="m-pardubicky50436.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p1s1W9</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p2s1">
  <m id="m-pardubicky50436.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W2</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W7</w.rf>
   <form>3.55</form>
   <form_change>num_normalization</form_change>
   <lemma>3.55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W9</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W10</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W12</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W15</w.rf>
   <form>Lanškrouna</form>
   <lemma>Lanškroun_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W17</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W18</w.rf>
   <form>lisu</form>
   <lemma>lis</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W20</w.rf>
   <form>papír</form>
   <lemma>papír</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W21</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W22</w.rf>
   <form>obchodnímu</form>
   <lemma>obchodní</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W23</w.rf>
   <form>řetězci</form>
   <lemma>řetězec</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W24</w.rf>
   <form>Lidl</form>
   <lemma>Lidl</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W25</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W26</w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p2s2">
  <m id="m-pardubicky50436.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W1</w.rf>
   <form>Šnekový</form>
   <lemma>šnekový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W2</w.rf>
   <form>lis</form>
   <lemma>lis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W4</w.rf>
   <form>kontejnerem</form>
   <lemma>kontejner</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W6</w.rf>
   <form>umístěn</form>
   <lemma>umístit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W8</w.rf>
   <form>těsné</form>
   <lemma>těsný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W9</w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W10</w.rf>
   <form>prodejny</form>
   <lemma>prodejna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p2s3">
  <m id="m-pardubicky50436.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W1</w.rf>
   <form>Požár</form>
   <lemma>Požár-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W3</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W4</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W5</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W7</w.rf>
   <form>4.07</form>
   <form_change>num_normalization</form_change>
   <lemma>4.07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W10</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W11</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W12</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W14</w.rf>
   <form>4.58</form>
   <form_change>num_normalization</form_change>
   <lemma>4.58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W15</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p2s4">
  <m id="m-pardubicky50436.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W2</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W3</w.rf>
   <form>způsobila</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W4</w.rf>
   <form>technická</form>
   <lemma>technický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W5</w.rf>
   <form>závada</form>
   <lemma>závada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W7</w.rf>
   <form>šnekovém</form>
   <lemma>šnekový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W8</w.rf>
   <form>lisu</form>
   <lemma>lis</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W10</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W11</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W12</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W14</w.rf>
   <form>prasknutí</form>
   <lemma>prasknutí_^(*3out)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W15</w.rf>
   <form>šneku</form>
   <lemma>šnek</lemma>
   <tag>NNMS3-----A---1</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W16</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W17</w.rf>
   <form>předchozím</form>
   <lemma>předchozí</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W18</w.rf>
   <form>lisování</form>
   <lemma>lisování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W19</w.rf>
   <form>papíru</form>
   <lemma>papír</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s4W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p2s5">
  <m id="m-pardubicky50436.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W3</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W4</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W6</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W7</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W8</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p2s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p3s1">
  <m id="m-pardubicky50436.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p3s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p3s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p3s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p3s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p3s1W5</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p3s1W6</w.rf>
   <form>Holice</form>
   <lemma>Holice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p4s1">
  <m id="m-pardubicky50436.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W2</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W7</w.rf>
   <form>23.58</form>
   <form_change>num_normalization</form_change>
   <lemma>23.58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W10</w.rf>
   <form>holičtí</form>
   <lemma>holický</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W14</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W16</w.rf>
   <form>jež</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJFS1----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W17</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W18</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W20</w.rf>
   <form>Horním</form>
   <lemma>Horní_;G</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W21</w.rf>
   <form>Jelení</form>
   <lemma>jelení</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p4s2">
  <m id="m-pardubicky50436.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s2W4</w.rf>
   <form>kolizi</form>
   <lemma>kolize</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s2W5</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s2W6</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p4s3">
  <m id="m-pardubicky50436.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W2</w.rf>
   <form>voze</form>
   <lemma>vůz</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W4</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W5</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W7</w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS4----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W8</w.rf>
   <form>zraněnou</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W9</w.rf>
   <form>osobu</form>
   <lemma>osoba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W10</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W12</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W13</w.rf>
   <form>převzala</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W14</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W15</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W16</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p4s4">
  <m id="m-pardubicky50436.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W1</w.rf>
   <form>Havarovaný</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W2</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W4</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W5</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W6</w.rf>
   <form>pohybu</form>
   <lemma>pohyb</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W8</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W10</w.rf>
   <form>zamezili</form>
   <lemma>zamezit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W11</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W12</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W13</w.rf>
   <form>náplní</form>
   <lemma>náplň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s4W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50436.txt-001-p4s5">
  <m id="m-pardubicky50436.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s5W1</w.rf>
   <form>Odstraňování</form>
   <lemma>odstraňování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s5W2</w.rf>
   <form>následků</form>
   <lemma>následek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s5W3</w.rf>
   <form>trvalo</form>
   <lemma>trvat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s5W4</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s5W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s5W6</w.rf>
   <form>1.28</form>
   <form_change>num_normalization</form_change>
   <lemma>1.28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s5W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50436.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50436.txt-001-p4s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
