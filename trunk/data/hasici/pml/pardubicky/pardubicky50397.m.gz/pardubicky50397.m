<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky50397.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky50397.txt-001-p1s1">
  <m id="m-pardubicky50397.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W1</w.rf>
   <form>Všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W2</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W3</w.rf>
   <form>soutěžících</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W4</w.rf>
   <form>nejnáročnější</form>
   <lemma>náročný</lemma>
   <tag>AAFS2----3A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W5</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W6</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W8</w.rf>
   <form>nejtvrdší</form>
   <lemma>tvrdý</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W9</w.rf>
   <form>hasič</form>
   <lemma>hasič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W10</w.rf>
   <form>přežívá</form>
   <lemma>přežívat_:T_^(*3t)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W11</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W12</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W13</w.rf>
   <form>startu</form>
   <lemma>start</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W14</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W16</w.rf>
   <form>8.45</form>
   <form_change>num_normalization</form_change>
   <lemma>8.45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W17</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W18</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W19</w.rf>
   <form>uchopit</form>
   <lemma>uchopit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W20</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W21</w.rf>
   <form>nezavodněné</form>
   <lemma>zavodněný_^(*3it)</lemma>
   <tag>AAFP4----1N----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W22</w.rf>
   <form>hadice</form>
   <lemma>hadice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W23</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W24</w.rf>
   <form>B</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W25</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W26</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W27</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W28</w.rf>
   <form>proudnicemi</form>
   <lemma>proudnice</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W30</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W31</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W32</w.rf>
   <form>rozvinout</form>
   <lemma>rozvinout_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W33</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W34</w.rf>
   <form>vzdálenost</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W35</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W36</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W37</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W38</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W39</w.rf>
   <form>proudnice</form>
   <lemma>proudnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W40</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W41</w.rf>
   <form>odložit</form>
   <lemma>odložit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W42</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W43</w.rf>
   <form>metu</form>
   <lemma>meta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s1W44</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p1s2">
  <m id="m-pardubicky50397.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W1</w.rf>
   <form>Obouručním</form>
   <lemma>obouruční</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W2</w.rf>
   <form>kladivem</form>
   <lemma>kladivo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W3</w.rf>
   <form>provedou</form>
   <lemma>provést</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W4</w.rf>
   <form>soutěžící</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGIP1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W5</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W6</w.rf>
   <form>úderů</form>
   <lemma>úder</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W8</w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W10</w.rf>
   <form>hammer</form>
   <lemma>hammer</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W11</w.rf>
   <form>boxu</form>
   <lemma>box</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W12</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W13</w.rf>
   <form>střídavě</form>
   <lemma>střídavě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W14</w.rf>
   <form>nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W16</w.rf>
   <form>dolů</form>
   <lemma>dolů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p1s3">
  <m id="m-pardubicky50397.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W2</w.rf>
   <form>překonají</form>
   <lemma>překonat_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W3</w.rf>
   <form>dvoumetrovou</form>
   <lemma>dvoumetrový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W4</w.rf>
   <form>bariéru</form>
   <lemma>bariéra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W6</w.rf>
   <form>transportují</form>
   <lemma>transportovat_:T_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W7</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W8</w.rf>
   <form>dvacetimetrové</form>
   <lemma>dvacetimetrový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W9</w.rf>
   <form>dráze</form>
   <lemma>dráha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W10</w.rf>
   <form>80</form>
   <lemma>80</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W11</w.rf>
   <form>kg</form>
   <lemma>kg-1`kilogram_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W12</w.rf>
   <form>těžkou</form>
   <lemma>těžký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W13</w.rf>
   <form>figurínu</form>
   <lemma>figurína</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W14</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W15</w.rf>
   <form>úchopem</form>
   <lemma>úchop</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W16</w.rf>
   <form>obouruč</form>
   <lemma>obouruč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W17</w.rf>
   <form>zezadu</form>
   <lemma>zezadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W20</w.rf>
   <form>tzv.</form>
   <lemma>takzvaný_:B_,x</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W21</w.rf>
   <form>Raitekův</form>
   <lemma>Raitekův</lemma>
   <tag>AUIS1M---------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W22</w.rf>
   <form>úchop</form>
   <lemma>úchop</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W23</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p1s4">
  <m id="m-pardubicky50397.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W2</w.rf>
   <form>vyznačeném</form>
   <lemma>vyznačený_^(*3it)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W3</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W4</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W5</w.rf>
   <form>budovou</form>
   <lemma>budova</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W6</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W7</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W8</w.rf>
   <form>uchopit</form>
   <lemma>uchopit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W9</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W10</w.rf>
   <form>barely</form>
   <lemma>barel</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W12</w.rf>
   <form>obsahu</form>
   <lemma>obsah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W13</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W14</w.rf>
   <form>litrů</form>
   <lemma>l-1`litr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W15</w.rf>
   <form>naplněné</form>
   <lemma>naplněný_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W16</w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W18</w.rf>
   <form>odnese</form>
   <lemma>odnést</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W19</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W20</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W21</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W23</w.rf>
   <form>nadzemního</form>
   <lemma>nadzemní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W24</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W26</w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s4W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p1s5">
  <m id="m-pardubicky50397.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W1</w.rf>
   <form>Barely</form>
   <lemma>barel</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W2</w.rf>
   <form>položí</form>
   <lemma>položit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W4</w.rf>
   <form>vyznačené</form>
   <lemma>vyznačený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W5</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W7</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W8</w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W9</w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W10</w.rf>
   <form>málo</form>
   <lemma>málo-1_^(málo_+_2._p.,_málo_peněz)</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W12</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W13</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W14</w.rf>
   <form>pokračovat</form>
   <lemma>pokračovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W15</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W17</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W19</w.rf>
   <form>nadzemního</form>
   <lemma>nadzemní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W20</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W22</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W23</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W24</w.rf>
   <form>nachází</form>
   <lemma>nacházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W25</w.rf>
   <form>cíl</form>
   <lemma>cíl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W26</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W27</w.rf>
   <form>náročné</form>
   <lemma>náročný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W28</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p1s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p1s5W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p2s1">
  <m id="m-pardubicky50397.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W1</w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W2</w.rf>
   <form>vše</form>
   <lemma>všechen</lemma>
   <tag>PLNS1---------1</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W4</w.rf>
   <form>jednom</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W5</w.rf>
   <form>čase</form>
   <lemma>čas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W6</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W7</w.rf>
   <form>přestávky</form>
   <lemma>přestávka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W10</w.rf>
   <form>těžkém</form>
   <lemma>těžký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W11</w.rf>
   <form>zásahové</form>
   <lemma>zásahový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W12</w.rf>
   <form>obleku</form>
   <lemma>oblek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W15</w.rf>
   <form>dýchacím</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W16</w.rf>
   <form>přístrojem</form>
   <lemma>přístroj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W18</w.rf>
   <form>zádech</form>
   <lemma>záda</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W20</w.rf>
   <form>maskou</form>
   <lemma>maska</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W22</w.rf>
   <form>obličeji</form>
   <lemma>obličej</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p2s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p3s1">
  <m id="m-pardubicky50397.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W3</w.rf>
   <form>pojata</form>
   <lemma>pojmout</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W4</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W5</w.rf>
   <form>modifikace</form>
   <lemma>modifikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W6</w.rf>
   <form>disciplín</form>
   <lemma>disciplína</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W7</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W9</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W12</w.rf>
   <form>simulaci</form>
   <lemma>simulace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W13</w.rf>
   <form>zásahové</form>
   <lemma>zásahový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W14</w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W16</w.rf>
   <form>ochranném</form>
   <lemma>ochranný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W17</w.rf>
   <form>oděvu</form>
   <lemma>oděv</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W18</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W19</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W20</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W21</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W22</w.rf>
   <form>izolačního</form>
   <lemma>izolační</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W23</w.rf>
   <form>vzduchového</form>
   <lemma>vzduchový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W24</w.rf>
   <form>dýchacího</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W25</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p3s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p4s1">
  <m id="m-pardubicky50397.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s1W1</w.rf>
   <form>Jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s1W4</w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s1W5</w.rf>
   <form>jednotlivců</form>
   <lemma>jednotlivec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s1W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s1W7</w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p4s2">
  <m id="m-pardubicky50397.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W1</w.rf>
   <form>Družstva</form>
   <lemma>družstvo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W2</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W3</w.rf>
   <form>složena</form>
   <lemma>složit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W4</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W5</w.rf>
   <form>čtyř</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W10</w.rf>
   <form>dosažených</form>
   <lemma>dosažený_^(*5áhnout)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W11</w.rf>
   <form>časů</form>
   <lemma>čas</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W13</w.rf>
   <form>sečtou</form>
   <lemma>sečíst</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W14</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W15</w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W16</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W17</w.rf>
   <form>nejlepší</form>
   <lemma>dobrý</lemma>
   <tag>AAIP4----3A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W18</w.rf>
   <form>časy</form>
   <lemma>čas</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p4s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p5s1">
  <m id="m-pardubicky50397.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W2</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W3</w.rf>
   <form>patří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W4</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W5</w.rf>
   <form>nejatraktivnější</form>
   <lemma>atraktivní</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W7</w.rf>
   <form>nejpopulárnější</form>
   <lemma>populární</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W8</w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W10</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W11</w.rf>
   <form>historii</form>
   <lemma>historie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W12</w.rf>
   <form>nejen</form>
   <lemma>nejen</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W14</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W15</w.rf>
   <form>republice</form>
   <lemma>republika</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W17</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W18</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W20</w.rf>
   <form>mnoha</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W21</w.rf>
   <form>státech</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W22</w.rf>
   <form>Evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W23</w.rf>
   <form>unie</form>
   <lemma>unie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p5s2">
  <m id="m-pardubicky50397.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W1</w.rf>
   <form>Popularitu</form>
   <lemma>popularita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W2</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W3</w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W4</w.rf>
   <form>ukazuje</form>
   <lemma>ukazovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W5</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W6</w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W8</w.rf>
   <form>mistrovství</form>
   <lemma>mistrovství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W9</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W10</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W12</w.rf>
   <form>disciplínách</form>
   <lemma>disciplína</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W13</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W15</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W16</w.rf>
   <form>účastí</form>
   <lemma>účast</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W18</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W19</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W20</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W21</w.rf>
   <form>konat</form>
   <lemma>konat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W22</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W23</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W25</w.rf>
   <form>června</form>
   <lemma>červen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W26</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W27</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W28</w.rf>
   <form>Zlíně</form>
   <lemma>Zlín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p5s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p5s2W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky50397.txt-001-p6s1">
  <m id="m-pardubicky50397.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W1</w.rf>
   <form>Přijďte</form>
   <lemma>přijít</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W3</w.rf>
   <form>podívat</form>
   <lemma>podívat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W5</w.rf>
   <form>povzbudit</form>
   <lemma>povzbudit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W6</w.rf>
   <form>záchranáře</form>
   <lemma>záchranář</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W8</w.rf>
   <form>nejtěžší</form>
   <lemma>těžký</lemma>
   <tag>AAFS6----3A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W9</w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky50397.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky50397.txt-001-p6s1W10</w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
