<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky49607.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky49607.txt-001-p1s1">
  <m id="m-pardubicky49607.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W2</w.rf>
   <form>pondělí</form>
   <lemma>pondělí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W4</w.rf>
   <form>14.5</form>
   <form_change>num_normalization</form_change>
   <lemma>14.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W6</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W9</w.rf>
   <form>Institutu</form>
   <lemma>institut</lemma>
   <tag>NNMS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W10</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W11</w.rf>
   <form>obyvatelstva</form>
   <lemma>obyvatelstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W12</w.rf>
   <form>Lázně</form>
   <lemma>lázeň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W13</w.rf>
   <form>Bohdaneč</form>
   <lemma>Bohdaneč_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W14</w.rf>
   <form>zahájen</form>
   <lemma>zahájit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W15</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W16</w.rf>
   <form>kurz</form>
   <lemma>kurs-1_^(měny,akcií,...)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W17</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W18</w.rf>
   <form>pokročilé</form>
   <lemma>pokročilý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W19</w.rf>
   <form>zaměřený</form>
   <lemma>zaměřený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W21</w.rf>
   <form>ochranu</form>
   <lemma>ochrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W22</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W23</w.rf>
   <form>chemickými</form>
   <lemma>chemický</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W24</w.rf>
   <form>zbraněmi</form>
   <lemma>zbraň</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s1W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p1s2">
  <m id="m-pardubicky49607.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W1</w.rf>
   <form>Tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W2</w.rf>
   <form>kurz</form>
   <lemma>kurs-1_^(měny,akcií,...)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W4</w.rf>
   <form>pořádaný</form>
   <lemma>pořádaný_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W6</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W7</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W8</w.rf>
   <form>Státním</form>
   <lemma>státní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W9</w.rf>
   <form>úřadem</form>
   <lemma>úřad</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W10</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W11</w.rf>
   <form>jadernou</form>
   <lemma>jaderný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W12</w.rf>
   <form>bezpečnost</form>
   <lemma>bezpečnost-1_^(*5ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W15</w.rf>
   <form>koná</form>
   <lemma>konat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W16</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W17</w.rf>
   <form>hlavičkou</form>
   <lemma>hlavička</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W18</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W19</w.rf>
   <form>Organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W20</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W21</w.rf>
   <form>zákaz</form>
   <lemma>zákaz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W22</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W23</w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W24</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W25</w.rf>
   <form>OPCW</form>
   <lemma>OPCW</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W28</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W29</w.rf>
   <form>probíhat</form>
   <lemma>probíhat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W30</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W31</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W32</w.rf>
   <form>pátku</form>
   <lemma>pátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W33</w.rf>
   <form>18.5</form>
   <form_change>num_normalization</form_change>
   <lemma>18.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p1s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p1s2W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p2s1">
  <m id="m-pardubicky49607.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W1</w.rf>
   <form>Kurzu</form>
   <lemma>kurs-1_^(měny,akcií,...)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W3</w.rf>
   <form>účastní</form>
   <lemma>účastnit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W4</w.rf>
   <form>vybraní</form>
   <lemma>vybraný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W5</w.rf>
   <form>experti</form>
   <lemma>expert</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W7</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W8</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W9</w.rf>
   <form>evropských</form>
   <lemma>evropský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W10</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W11</w.rf>
   <form>mimoevropských</form>
   <lemma>mimoevropský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W12</w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W14</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W15</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W16</w.rf>
   <form>školit</form>
   <lemma>školit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W17</w.rf>
   <form>špičkoví</form>
   <lemma>špičkový</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W18</w.rf>
   <form>tuzemští</form>
   <lemma>tuzemský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W19</w.rf>
   <form>odborníci</form>
   <lemma>odborník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W21</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W22</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W23</w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p2s2">
  <m id="m-pardubicky49607.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W1</w.rf>
   <form>Účastníci</form>
   <lemma>účastník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W2</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W3</w.rf>
   <form>seznámeni</form>
   <lemma>seznámit</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W4</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W5</w.rf>
   <form>platnou</form>
   <lemma>platný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W6</w.rf>
   <form>legislativou</form>
   <lemma>legislativa</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W8</w.rf>
   <form>tématem</form>
   <lemma>téma</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W9</w.rf>
   <form>školení</form>
   <lemma>školení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W10</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W11</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W12</w.rf>
   <form>detekční</form>
   <lemma>detekční</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W13</w.rf>
   <form>prostředky</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W15</w.rf>
   <form>problematika</form>
   <lemma>problematika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W16</w.rf>
   <form>dekontaminace</form>
   <lemma>dekontaminace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W18</w.rf>
   <form>individuální</form>
   <lemma>individuální</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W19</w.rf>
   <form>ochrana</form>
   <lemma>ochrana</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W20</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W21</w.rf>
   <form>chemickými</form>
   <lemma>chemický</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W22</w.rf>
   <form>zraněni</form>
   <lemma>zranit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W23</w.rf>
   <form>apod</form>
   <lemma>apod-1_:B_,x_^(a_podobně)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p2s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p3s1">
  <m id="m-pardubicky49607.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W1</w.rf>
   <form>Jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W3</w.rf>
   <form>prestižní</form>
   <lemma>prestižní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W4</w.rf>
   <form>akci</form>
   <lemma>akce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W6</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W7</w.rf>
   <form>dokladuje</form>
   <lemma>dokladovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W9</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W11</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W13</w.rf>
   <form>zahájení</form>
   <lemma>zahájení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W14</w.rf>
   <form>zúčastnil</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W15</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W16</w.rf>
   <form>český</form>
   <lemma>český</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W17</w.rf>
   <form>velvyslanec</form>
   <lemma>velvyslanec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W19</w.rf>
   <form>Nizozemsku</form>
   <lemma>Nizozemsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W20</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W21</w.rf>
   <form>Mareš</form>
   <lemma>Mareš_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W23</w.rf>
   <form>ředitelka</form>
   <lemma>ředitelka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W24</w.rf>
   <form>sekce</form>
   <lemma>sekce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W25</w.rf>
   <form>OPCW</form>
   <lemma>OPCW</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W26</w.rf>
   <form>Kalimi</form>
   <lemma>Kalimi</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W27</w.rf>
   <form>Mworia</form>
   <lemma>Mworia</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p3s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p4s1">
  <m id="m-pardubicky49607.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W1</w.rf>
   <form>Vyvrcholením</form>
   <lemma>vyvrcholení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W2</w.rf>
   <form>kurzu</form>
   <lemma>kurs-1_^(měny,akcií,...)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W3</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W4</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W5</w.rf>
   <form>praktický</form>
   <lemma>praktický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W6</w.rf>
   <form>výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W7</w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W8</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W9</w.rf>
   <form>týmu</form>
   <lemma>tým</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W11</w.rf>
   <form>kontaminovaném</form>
   <lemma>kontaminovaný_^(*2t)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W12</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W14</w.rf>
   <form>jenž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJYS1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W15</w.rf>
   <form>účastníky</form>
   <lemma>účastník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W16</w.rf>
   <form>čeká</form>
   <lemma>čekat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W17</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W18</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W19</w.rf>
   <form>17.5</form>
   <form_change>num_normalization</form_change>
   <lemma>17.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p4s2">
  <m id="m-pardubicky49607.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W1</w.rf>
   <form>Počítá</form>
   <lemma>počítat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W3</w.rf>
   <form>rovnou</form>
   <lemma>rovnou_^(hned,_najednou)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W4</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W5</w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>ClXP7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W6</w.rf>
   <form>scénáři</form>
   <lemma>scénář</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W9</w.rf>
   <form>nálezem</form>
   <lemma>nález</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W10</w.rf>
   <form>bojové</form>
   <lemma>bojový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W11</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W12</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W14</w.rf>
   <form>interiéru</form>
   <lemma>interiér</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W16</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W18</w.rf>
   <form>exteriéru</form>
   <lemma>exteriér</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p4s3">
  <m id="m-pardubicky49607.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W1</w.rf>
   <form>Cvičící</form>
   <lemma>cvičící_^(*3it)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W3</w.rf>
   <form>kompletním</form>
   <lemma>kompletní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W4</w.rf>
   <form>protichemickém</form>
   <lemma>protichemický</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W5</w.rf>
   <form>oděvu</form>
   <lemma>oděv</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W6</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W8</w.rf>
   <form>terénu</form>
   <lemma>terén</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W9</w.rf>
   <form>vyzkouší</form>
   <lemma>vyzkoušet_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W10</w.rf>
   <form>postup</form>
   <lemma>postup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W11</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W12</w.rf>
   <form>samotné</form>
   <lemma>samotný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W13</w.rf>
   <form>detekce</form>
   <lemma>detekce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W14</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W16</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W17</w.rf>
   <form>odběr</form>
   <lemma>odběr</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W18</w.rf>
   <form>vzorků</form>
   <lemma>vzorek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W19</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W20</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W21</w.rf>
   <form>následnou</form>
   <lemma>následný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W22</w.rf>
   <form>kontaminaci</form>
   <lemma>kontaminace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W23</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W25</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p4s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p4s3W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p5s1">
  <m id="m-pardubicky49607.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W1</w.rf>
   <form>Praktického</form>
   <lemma>praktický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W2</w.rf>
   <form>výcviku</form>
   <lemma>výcvik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W3</w.rf>
   <form>zahraničních</form>
   <lemma>zahraniční</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W4</w.rf>
   <form>expertů</form>
   <lemma>expert</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W6</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W7</w.rf>
   <form>osobně</form>
   <lemma>osobně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W8</w.rf>
   <form>zúčastnit</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W9</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W10</w.rf>
   <form>zástupci</form>
   <lemma>zástupce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W11</w.rf>
   <form>médií</form>
   <lemma>médium</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W15</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W16</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W17</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W18</w.rf>
   <form>17.5</form>
   <form_change>num_normalization</form_change>
   <lemma>17.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W20</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W21</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W22</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W23</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W25</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W26</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W27</w.rf>
   <form>00</form>
   <lemma>00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p5s2">
  <m id="m-pardubicky49607.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W1</w.rf>
   <form>Výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W2</w.rf>
   <form>probíhá</form>
   <lemma>probíhat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W4</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W5</w.rf>
   <form>Institutu</form>
   <lemma>institut</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W6</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W7</w.rf>
   <form>obyvatelstva</form>
   <lemma>obyvatelstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W8</w.rf>
   <form>Lázně</form>
   <lemma>lázeň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W9</w.rf>
   <form>Bohdaneč</form>
   <lemma>Bohdaneč_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W10</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W11</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W12</w.rf>
   <form>Lužci</form>
   <lemma>Lužec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W13</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p5s3">
  <m id="m-pardubicky49607.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W4</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W5</w.rf>
   <form>dispozici</form>
   <lemma>dispozice</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W6</w.rf>
   <form>tlumočník</form>
   <lemma>tlumočník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W8</w.rf>
   <form>novináři</form>
   <lemma>novinář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W9</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W10</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W11</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W12</w.rf>
   <form>ojedinělou</form>
   <lemma>ojedinělý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W13</w.rf>
   <form>příležitost</form>
   <lemma>příležitost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W14</w.rf>
   <form>získat</form>
   <lemma>získat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W15</w.rf>
   <form>informace</form>
   <lemma>informace</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W17</w.rf>
   <form>problematice</form>
   <lemma>problematika</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W18</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W19</w.rf>
   <form>zbraních</form>
   <lemma>zbraň</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W21</w.rf>
   <form>ochraně</form>
   <lemma>ochrana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W22</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W23</w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>P5XP3--3-------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W24</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W25</w.rf>
   <form>odborníků</form>
   <lemma>odborník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W27</w.rf>
   <form>mnoha</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W28</w.rf>
   <form>zahraničních</form>
   <lemma>zahraniční</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W29</w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p5s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p5s3W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p6s1">
  <m id="m-pardubicky49607.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W1</w.rf>
   <form>Právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W3</w.rf>
   <form>letošní</form>
   <lemma>letošní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W4</w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W5</w.rf>
   <form>připadá</form>
   <lemma>připadat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W6</w.rf>
   <form>desetileté</form>
   <lemma>desetiletý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W7</w.rf>
   <form>výročí</form>
   <lemma>výročí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W8</w.rf>
   <form>platnosti</form>
   <lemma>platnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W9</w.rf>
   <form>Mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W10</w.rf>
   <form>úmluvy</form>
   <lemma>úmluva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W12</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W13</w.rf>
   <form>zbraních</form>
   <lemma>zbraň</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W15</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W16</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W17</w.rf>
   <form>kulaté</form>
   <lemma>kulatý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W18</w.rf>
   <form>výročí</form>
   <lemma>výročí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W19</w.rf>
   <form>existence</form>
   <lemma>existence</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W20</w.rf>
   <form>Organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W21</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W22</w.rf>
   <form>zákaz</form>
   <lemma>zákaz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W23</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W24</w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W25</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W26</w.rf>
   <form>OPCW</form>
   <lemma>OPCW</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W27</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p6s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p6s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p7s1">
  <m id="m-pardubicky49607.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W1</w.rf>
   <form>Mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W2</w.rf>
   <form>úmluva</form>
   <lemma>úmluva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W4</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W5</w.rf>
   <form>zbraních</form>
   <lemma>zbraň</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W7</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W8</w.rf>
   <form>nabyla</form>
   <lemma>nabýt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W9</w.rf>
   <form>účinnosti</form>
   <lemma>účinnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W11</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W12</w.rf>
   <form>1997</form>
   <lemma>1997</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W14</w.rf>
   <form>zakázala</form>
   <lemma>zakázat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W15</w.rf>
   <form>vývoj</form>
   <lemma>vývoj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W17</w.rf>
   <form>výrobu</form>
   <lemma>výroba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W19</w.rf>
   <form>shromažďování</form>
   <lemma>shromažďování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W21</w.rf>
   <form>šíření</form>
   <lemma>šíření_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W23</w.rf>
   <form>užívání</form>
   <lemma>užívání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W24</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W25</w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p7s2">
  <m id="m-pardubicky49607.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W1</w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W2</w.rf>
   <form>úmluva</form>
   <lemma>úmluva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W3</w.rf>
   <form>garantovaná</form>
   <lemma>garantovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W4</w.rf>
   <form>OSN</form>
   <lemma>OSN-1_:B_;K_^(Organizace_spojených_národů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W5</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W6</w.rf>
   <form>stanovuje</form>
   <lemma>stanovovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W7</w.rf>
   <form>harmonogram</form>
   <lemma>harmonogram</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W8</w.rf>
   <form>postupného</form>
   <lemma>postupný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W9</w.rf>
   <form>ničení</form>
   <lemma>ničení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W10</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W11</w.rf>
   <form>existujícího</form>
   <lemma>existující_^(*5ovat)</lemma>
   <tag>AGIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W12</w.rf>
   <form>arsenálu</form>
   <lemma>arsenál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W13</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W14</w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p7s3">
  <m id="m-pardubicky49607.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W2</w.rf>
   <form>právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W3</w.rf>
   <form>OPCW</form>
   <lemma>OPCW</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W5</w.rf>
   <form>svěřen</form>
   <lemma>svěřit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W6</w.rf>
   <form>dohled</form>
   <lemma>dohled</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W8</w.rf>
   <form>kontrola</form>
   <lemma>kontrola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W9</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W10</w.rf>
   <form>dodržováním</form>
   <lemma>dodržování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W11</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W12</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W13</w.rf>
   <form>dohody</form>
   <lemma>dohoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p7s4">
  <m id="m-pardubicky49607.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W1</w.rf>
   <form>Dohodu</form>
   <lemma>dohoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W2</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W3</w.rf>
   <form>podepsalo</form>
   <lemma>podepsat</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W4</w.rf>
   <form>182</form>
   <lemma>182</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W5</w.rf>
   <form>států</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W6</w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W7</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W8</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W11</w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W12</w.rf>
   <form>signatářské</form>
   <lemma>signatářský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W13</w.rf>
   <form>státy</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W14</w.rf>
   <form>reprezentují</form>
   <lemma>reprezentovat_:T_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W15</w.rf>
   <form>plných</form>
   <lemma>plný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W16</w.rf>
   <form>98</form>
   <lemma>98</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W17</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W18</w.rf>
   <form>světové</form>
   <lemma>světový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W19</w.rf>
   <form>populace</form>
   <lemma>populace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W21</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W22</w.rf>
   <form>chemického</form>
   <lemma>chemický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W23</w.rf>
   <form>průmyslu</form>
   <lemma>průmysl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p7s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p7s4W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p8s1">
  <m id="m-pardubicky49607.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W2</w.rf>
   <form>informací</form>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W4</w.rf>
   <form>webových</form>
   <lemma>webový_,t</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W5</w.rf>
   <form>stránek</form>
   <lemma>stránka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W6</w.rf>
   <form>organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W9</w.rf>
   <form>současnosti</form>
   <lemma>současnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W10</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W11</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W12</w.rf>
   <form>zlikvidovat</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W13</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W14</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W15</w.rf>
   <form>deklarovaných</form>
   <lemma>deklarovaný_^(*2t)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W16</w.rf>
   <form>výrobních</form>
   <lemma>výrobní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W17</w.rf>
   <form>kapacit</form>
   <lemma>kapacita</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W19</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W20</w.rf>
   <form>chemických</form>
   <lemma>chemický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W21</w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W23</w.rf>
   <form>zničeno</form>
   <lemma>zničit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W24</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W25</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W26</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W27</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W28</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W29</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W30</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W31</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W32</w.rf>
   <form>8.6</form>
   <form_change>num_normalization</form_change>
   <lemma>8.6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W33</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W34</w.rf>
   <form>deklarovaných</form>
   <lemma>deklarovaný_^(*2t)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W35</w.rf>
   <form>kusů</form>
   <lemma>kus</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W36</w.rf>
   <form>chemické</form>
   <lemma>chemický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W37</w.rf>
   <form>munice</form>
   <lemma>munice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W38</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W39</w.rf>
   <form>kontejnerů</form>
   <lemma>kontejner</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s1W40</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p8s2">
  <m id="m-pardubicky49607.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W2</w.rf>
   <form>stovkách</form>
   <lemma>stovka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W3</w.rf>
   <form>továren</form>
   <lemma>továrna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W5</w.rf>
   <form>skladišť</form>
   <lemma>skladiště</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W7</w.rf>
   <form>chemickými</form>
   <lemma>chemický</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W8</w.rf>
   <form>zbraněmi</form>
   <lemma>zbraň</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W10</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W11</w.rf>
   <form>77</form>
   <lemma>77</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W12</w.rf>
   <form>států</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W13</w.rf>
   <form>proběhlo</form>
   <lemma>proběhnout_:W</lemma>
   <tag>VpNS---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W14</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W15</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W16</w.rf>
   <form>1997</form>
   <lemma>1997</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W17</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W18</w.rf>
   <form>2800</form>
   <form_change>num_normalization</form_change>
   <lemma>2800</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W19</w.rf>
   <form>inspekcí</form>
   <lemma>inspekce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p8s3">
  <m id="m-pardubicky49607.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W1</w.rf>
   <form>Kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W2</w.rf>
   <form>boje</form>
   <lemma>boj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W3</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W4</w.rf>
   <form>chemickým</form>
   <lemma>chemický</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W5</w.rf>
   <form>zbraním</form>
   <lemma>zbraň</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W6</w.rf>
   <form>OPCW</form>
   <lemma>OPCW</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W7</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W8</w.rf>
   <form>napomáhá</form>
   <lemma>napomáhat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W9</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W10</w.rf>
   <form>spoluprácei</form>
   <lemma>spolupráceě</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W12</w.rf>
   <form>poli</form>
   <lemma>pole</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W13</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W14</w.rf>
   <form>mírové</form>
   <lemma>mírový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W15</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W16</w.rf>
   <form>chemie</form>
   <lemma>chemie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W18</w.rf>
   <form>např.</form>
   <lemma>například_:B_,x</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W19</w.rf>
   <form>výzkumu</form>
   <lemma>výzkum</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W21</w.rf>
   <form>vývoje</form>
   <lemma>vývoj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p8s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p8s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p9s1">
  <m id="m-pardubicky49607.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p9s1W1</w.rf>
   <form>Více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p9s1W2</w.rf>
   <form>informací</form>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p9s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p9s1W4</w.rf>
   <form>OPCW</form>
   <lemma>OPCW</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p9s1W5</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p9s1W6</w.rf>
   <form>nalézt</form>
   <lemma>nalézt</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p9s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p9s1W8</w.rf>
   <form>www.opcw.org</form>
   <lemma>www.opcw.org</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p10s1">
  <m id="m-pardubicky49607.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W1</w.rf>
   <form>Institut</form>
   <lemma>institut</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W2</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W3</w.rf>
   <form>obyvatelstva</form>
   <lemma>obyvatelstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W4</w.rf>
   <form>Lázně</form>
   <lemma>lázeň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W5</w.rf>
   <form>Bohdaneč</form>
   <lemma>Bohdaneč_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W7</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W9</w.rf>
   <form>minulém</form>
   <lemma>minulý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W10</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W11</w.rf>
   <form>oslavil</form>
   <lemma>oslavit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W12</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W13</w.rf>
   <form>padesátileté</form>
   <lemma>padesátiletý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W14</w.rf>
   <form>výročí</form>
   <lemma>výročí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W15</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FP4---------1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W16</w.rf>
   <form>existence</form>
   <lemma>existence</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W18</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W19</w.rf>
   <form>organizační</form>
   <lemma>organizační</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W20</w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W21</w.rf>
   <form>Ministerstva</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W22</w.rf>
   <form>vnitra-</form>
   <lemma>vnitra-</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W23</w.rf>
   <form>generálního</form>
   <lemma>generální</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W24</w.rf>
   <form>ředitelství</form>
   <lemma>ředitelství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W25</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W26</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W27</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W28</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p10s2">
  <m id="m-pardubicky49607.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W1</w.rf>
   <form>Slouží</form>
   <lemma>sloužit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W2</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W3</w.rf>
   <form>centrální</form>
   <lemma>centrální</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W4</w.rf>
   <form>vědecko-výzkumné</form>
   <lemma>vědecko-výzkumný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W6</w.rf>
   <form>vzdělávací</form>
   <lemma>vzdělávací_^(*5at)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W8</w.rf>
   <form>informační</form>
   <lemma>informační</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W9</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W10</w.rf>
   <form>celého</form>
   <lemma>celý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W11</w.rf>
   <form>Hasičského</form>
   <lemma>hasičský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W12</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W13</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W14</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W17</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W18</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W19</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W20</w.rf>
   <form>ochrany</form>
   <lemma>ochrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W21</w.rf>
   <form>obyvatelstva</form>
   <lemma>obyvatelstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W23</w.rf>
   <form>krizového</form>
   <lemma>krizový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W24</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W26</w.rf>
   <form>civilního</form>
   <lemma>civilní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W27</w.rf>
   <form>nouzového</form>
   <lemma>nouzový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W28</w.rf>
   <form>plánování</form>
   <lemma>plánování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W30</w.rf>
   <form>integrovaného</form>
   <lemma>integrovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W31</w.rf>
   <form>záchranného</form>
   <lemma>záchranný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W32</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p10s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p10s2W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p11s1">
  <m id="m-pardubicky49607.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p11s1W1</w.rf>
   <form>Více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p11s1W2</w.rf>
   <form>informací</form>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p11s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p11s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p11s1W4</w.rf>
   <form>Institutu</form>
   <lemma>institut</lemma>
   <tag>NNMS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p11s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p11s1W5</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p11s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p11s1W6</w.rf>
   <form>nalézt</form>
   <lemma>nalézt</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p11s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p11s1W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p11s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p11s1W8</w.rf>
   <form>www.ioolb.cz</form>
   <lemma>www.ioolb.cz</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p12s1">
  <m id="m-pardubicky49607.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p12s1W1</w.rf>
   <form>kpt</form>
   <lemma>kapitán_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p12s1W2</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49607.txt-001-p12s2">
  <m id="m-pardubicky49607.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p12s2W1</w.rf>
   <form>PhDr.</form>
   <lemma>PhDr-1_:B_,t_,x_^(philosophiae_doctor)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p12s2W2</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49607.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49607.txt-001-p12s2W3</w.rf>
   <form>Kopáček</form>
   <lemma>Kopáček_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
</mdata>
