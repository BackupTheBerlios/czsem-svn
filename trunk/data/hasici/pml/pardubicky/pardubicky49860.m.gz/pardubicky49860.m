<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky49860.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky49860.txt-001-p1s1">
  <m id="m-pardubicky49860.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p1s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p1s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p1s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p1s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p1s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p1s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p1s1W7</w.rf>
   <form>Chrudim</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p2s1">
  <m id="m-pardubicky49860.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W2</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W7</w.rf>
   <form>10.58</form>
   <form_change>num_normalization</form_change>
   <lemma>10.58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W12</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W13</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W14</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W15</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W16</w.rf>
   <form>Mitsubishi</form>
   <lemma>Mitsubishi-1_;K</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W17</w.rf>
   <form>Carisma</form>
   <lemma>Carisma-2_;R_^(vozidlo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p2s2">
  <m id="m-pardubicky49860.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s2W1</w.rf>
   <form>Nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s2W3</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s2W5</w.rf>
   <form>Seči</form>
   <lemma>Seč_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s2W6</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s2W7</w.rf>
   <form>Chrudimi</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p2s3">
  <m id="m-pardubicky49860.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s3W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s3W3</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s3W4</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s3W5</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p2s4">
  <m id="m-pardubicky49860.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s4W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s4W2</w.rf>
   <form>kolizi</form>
   <lemma>kolize</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s4W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s4W4</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s4W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p2s5">
  <m id="m-pardubicky49860.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s5W1</w.rf>
   <form>Příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s5W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s5W3</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s5W4</w.rf>
   <form>vyšetřuje</form>
   <lemma>vyšetřovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s5W5</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s5W6</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p2s5W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s1">
  <m id="m-pardubicky49860.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W2</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W7</w.rf>
   <form>4.37</form>
   <form_change>num_normalization</form_change>
   <lemma>4.37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W12</w.rf>
   <form>Chrudimi</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W14</w.rf>
   <form>Vlčnově</form>
   <lemma>Vlčnov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W16</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W17</w.rf>
   <form>hořelo</form>
   <lemma>hořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W19</w.rf>
   <form>hromadné</form>
   <lemma>hromadný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W20</w.rf>
   <form>garáži</form>
   <lemma>garáž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W21</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W22</w.rf>
   <form>servisní</form>
   <lemma>servisní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W23</w.rf>
   <form>dílnou</form>
   <lemma>dílna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W25</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W26</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W27</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s2">
  <m id="m-pardubicky49860.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W2</w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W3</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W4</w.rf>
   <form>velkému</form>
   <lemma>velký</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W5</w.rf>
   <form>zakouření</form>
   <lemma>zakouření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W6</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W7</w.rf>
   <form>použít</form>
   <lemma>použít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W8</w.rf>
   <form>dýchací</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W9</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s3">
  <m id="m-pardubicky49860.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W1</w.rf>
   <form>Požár</form>
   <lemma>Požár-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W3</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W4</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W5</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W6</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W7</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W9</w.rf>
   <form>4.56</form>
   <form_change>num_normalization</form_change>
   <lemma>4.56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W12</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W13</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W14</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W15</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W16</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W17</w.rf>
   <form>minuty</form>
   <lemma>minuta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W18</w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s3W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s4">
  <m id="m-pardubicky49860.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s4W2</w.rf>
   <form>garáži</form>
   <lemma>garáž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s4W3</w.rf>
   <form>hořela</form>
   <lemma>hořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s4W4</w.rf>
   <form>dodávka</form>
   <lemma>dodávka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s4W5</w.rf>
   <form>Peugeot</form>
   <lemma>Peugeot-3_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s4W6</w.rf>
   <form>Boxer</form>
   <lemma>boxer</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s5">
  <m id="m-pardubicky49860.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W2</w.rf>
   <form>poničil</form>
   <lemma>poničit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W3</w.rf>
   <form>nejen</form>
   <lemma>nejen</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W4</w.rf>
   <form>dodávku</form>
   <lemma>dodávka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W6</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W7</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W8</w.rf>
   <form>objekt</form>
   <lemma>objekt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s6">
  <m id="m-pardubicky49860.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W1</w.rf>
   <form>Díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W2</w.rf>
   <form>včasnému</form>
   <lemma>včasný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W3</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W4</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W5</w.rf>
   <form>nedošlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W7</w.rf>
   <form>rozšíření</form>
   <lemma>rozšíření_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W8</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W10</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W11</w.rf>
   <form>zaparkovaná</form>
   <lemma>zaparkovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W12</w.rf>
   <form>nákladní</form>
   <lemma>nákladní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W13</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s6W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s7">
  <m id="m-pardubicky49860.txt-001-p3s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s7W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s7W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s7W3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s7W4</w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PWM-1----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s7W5</w.rf>
   <form>zraněn</form>
   <lemma>zranit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s7W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s8">
  <m id="m-pardubicky49860.txt-001-p3s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W4</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W5</w.rf>
   <form>dnešního</form>
   <lemma>dnešní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W6</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W7</w.rf>
   <form>dostaví</form>
   <lemma>dostavět_:W_^(dokončit_stavbu)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W9</w.rf>
   <form>soudní</form>
   <lemma>soudní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W10</w.rf>
   <form>znalec</form>
   <lemma>znalec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W12</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W13</w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W15</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W16</w.rf>
   <form>stanovil</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W17</w.rf>
   <form>příčinu</form>
   <lemma>příčina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W18</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W19</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s8W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p3s9">
  <m id="m-pardubicky49860.txt-001-p3s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W3</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W4</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W6</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W7</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W8</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p3s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p3s9W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p4s1">
  <m id="m-pardubicky49860.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p4s1W9</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p5s1">
  <m id="m-pardubicky49860.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W2</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W7</w.rf>
   <form>15.56</form>
   <form_change>num_normalization</form_change>
   <lemma>15.56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W9</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W10</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W13</w.rf>
   <form>Jablonného</form>
   <lemma>Jablonné_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W14</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W15</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W16</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W17</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W18</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W19</w.rf>
   <form>cestu</form>
   <lemma>cesta_^(konkrétní_i_abstr.;_i_'soudní_cestou')</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W21</w.rf>
   <form>Těchoníně</form>
   <lemma>Těchonín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p5s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p6s1">
  <m id="m-pardubicky49860.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p6s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p6s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p6s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p6s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p6s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p6s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p6s1W7</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p7s1">
  <m id="m-pardubicky49860.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W2</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W7</w.rf>
   <form>7.59</form>
   <form_change>num_normalization</form_change>
   <lemma>7.59</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W12</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W13</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W15</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W17</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W19</w.rf>
   <form>Litomyšli</form>
   <lemma>Litomyšl_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p7s2">
  <m id="m-pardubicky49860.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W4</w.rf>
   <form>střet</form>
   <lemma>střet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W5</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W6</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W7</w.rf>
   <form>Renault</form>
   <lemma>Renault-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W8</w.rf>
   <form>Kangoo</form>
   <lemma>Kangoo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W10</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W11</w.rf>
   <form>Felicia</form>
   <lemma>Felicia-2_;R_^(vozidlo)</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p7s3">
  <m id="m-pardubicky49860.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s3W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s3W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s3W4</w.rf>
   <form>zraněny</form>
   <lemma>zranit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s3W5</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s3W6</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s3W7</w.rf>
   <form>lehce</form>
   <lemma>lehce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p7s4">
  <m id="m-pardubicky49860.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W2</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W4</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W5</w.rf>
   <form>převzala</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W6</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W7</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W8</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p7s5">
  <m id="m-pardubicky49860.txt-001-p7s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W2</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W3</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W4</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W7</w.rf>
   <form>zamezili</form>
   <lemma>zamezit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W8</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W9</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W10</w.rf>
   <form>náplní</form>
   <lemma>náplň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W12</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W13</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W14</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W15</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W16</w.rf>
   <form>odpojením</form>
   <lemma>odpojení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W17</w.rf>
   <form>akumulátorů</form>
   <lemma>akumulátor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49860.txt-001-p7s6">
  <m id="m-pardubicky49860.txt-001-p7s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s6W1</w.rf>
   <form>Odstraňování</form>
   <lemma>odstraňování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s6W2</w.rf>
   <form>následků</form>
   <lemma>následek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s6W3</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s6W4</w.rf>
   <form>trvalo</form>
   <lemma>trvat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s6W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s6W6</w.rf>
   <form>8.42</form>
   <form_change>num_normalization</form_change>
   <lemma>8.42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s6W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49860.txt-001-p7s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49860.txt-001-p7s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
