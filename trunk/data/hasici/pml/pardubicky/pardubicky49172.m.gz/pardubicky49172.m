<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky49172.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky49172.txt-001-p1s1">
  <m id="m-pardubicky49172.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p1s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p1s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p1s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p1s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p1s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p1s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p1s1W7</w.rf>
   <form>Chrudim</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p2s1">
  <m id="m-pardubicky49172.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W2</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W7</w.rf>
   <form>8.10</form>
   <form_change>num_normalization</form_change>
   <lemma>8.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W12</w.rf>
   <form>Chrudimi</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W14</w.rf>
   <form>Čáslavi</form>
   <lemma>Čáslav_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W15</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W16</w.rf>
   <form>kolize</form>
   <lemma>kolize</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W17</w.rf>
   <form>nákladního</form>
   <lemma>nákladní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W18</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W20</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W22</w.rf>
   <form>katastru</form>
   <lemma>katastr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W23</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W24</w.rf>
   <form>Podhořany</form>
   <lemma>Podhořany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W25</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W26</w.rf>
   <form>Ronova</form>
   <lemma>Ronov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p2s2">
  <m id="m-pardubicky49172.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W1</w.rf>
   <form>Zástupce</form>
   <lemma>zástupce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W2</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W3</w.rf>
   <form>havarovaného</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W4</w.rf>
   <form>kamionu</form>
   <lemma>kamión</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W5</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W6</w.rf>
   <form>vyproštění</form>
   <lemma>vyproštění_^(*5stit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W7</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W8</w.rf>
   <form>zajistil</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W9</w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p2s3">
  <m id="m-pardubicky49172.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W2</w.rf>
   <form>přečerpali</form>
   <lemma>přečerpat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W3</w.rf>
   <form>pohonné</form>
   <lemma>pohonný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W4</w.rf>
   <form>hmoty</form>
   <lemma>hmota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W6</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W7</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W8</w.rf>
   <form>dohlédli</form>
   <lemma>dohlédnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W10</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W12</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W13</w.rf>
   <form>případně</form>
   <lemma>případně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W14</w.rf>
   <form>neunikly</form>
   <lemma>uniknout_:W</lemma>
   <tag>VpTP---XR-NA--1</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W15</w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W16</w.rf>
   <form>provozní</form>
   <lemma>provozní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W17</w.rf>
   <form>náplně</form>
   <lemma>náplň</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p2s4">
  <m id="m-pardubicky49172.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W3</w.rf>
   <form>vrátili</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W4</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W6</w.rf>
   <form>základnu</form>
   <lemma>základna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W8</w.rf>
   <form>11.04</form>
   <form_change>num_normalization</form_change>
   <lemma>11.04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p2s4W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p3s1">
  <m id="m-pardubicky49172.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p3s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p3s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p3s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p3s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p3s1W5</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p3s1W6</w.rf>
   <form>Pardubice</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p4s1">
  <m id="m-pardubicky49172.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W2</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W7</w.rf>
   <form>11.58</form>
   <form_change>num_normalization</form_change>
   <lemma>11.58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W9</w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W11</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W12</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W13</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W14</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W15</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W16</w.rf>
   <form>Polabinám</form>
   <lemma>Polabiny_;G</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W18</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W19</w.rf>
   <form>hořelo</form>
   <lemma>hořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W21</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W22</w.rf>
   <form>Prokopovy</form>
   <lemma>prokopův_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W23</w.rf>
   <form>továrny</form>
   <lemma>továrna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p4s2">
  <m id="m-pardubicky49172.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W2</w.rf>
   <form>provedeném</form>
   <lemma>provedený_^(*5ést)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W3</w.rf>
   <form>průzkumu</form>
   <lemma>průzkum</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W5</w.rf>
   <form>zjištěno</form>
   <lemma>zjistit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W8</w.rf>
   <form>hoří</form>
   <lemma>hořet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W9</w.rf>
   <form>stropní</form>
   <lemma>stropní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W10</w.rf>
   <form>podhledy</form>
   <lemma>podhled</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p4s3">
  <m id="m-pardubicky49172.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W3</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W4</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W5</w.rf>
   <form>vysokotlaku</form>
   <lemma>vysokotlak</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W7</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W8</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W9</w.rf>
   <form>podhledy</form>
   <lemma>podhled</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W10</w.rf>
   <form>strhnout</form>
   <lemma>strhnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W12</w.rf>
   <form>rozebrat</form>
   <lemma>rozebrat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p4s4">
  <m id="m-pardubicky49172.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W3</w.rf>
   <form>lokalizován</form>
   <lemma>lokalizovat_:T_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W4</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W5</w.rf>
   <form>12.12</form>
   <form_change>num_normalization</form_change>
   <lemma>12.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W6</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W8</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W9</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W10</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W11</w.rf>
   <form>12.56</form>
   <form_change>num_normalization</form_change>
   <lemma>12.56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W12</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p4s5">
  <m id="m-pardubicky49172.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W4</w.rf>
   <form>dostavil</form>
   <lemma>dostavit_:W_^(se)_(na_dané_místo)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W6</w.rf>
   <form>vyšetřovatel</form>
   <lemma>vyšetřovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W7</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W9</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W10</w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W11</w.rf>
   <form>zjišťuje</form>
   <lemma>zjišťovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W13</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W14</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W15</w.rf>
   <form>příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W16</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W17</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W19</w.rf>
   <form>jakou</form>
   <lemma>jaký</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W20</w.rf>
   <form>škodu</form>
   <lemma>škoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W21</w.rf>
   <form>plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W22</w.rf>
   <form>způsobily</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p4s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p4s5W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p5s1">
  <m id="m-pardubicky49172.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W2</w.rf>
   <form>15.08</form>
   <form_change>num_normalization</form_change>
   <lemma>15.08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W3</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W4</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W7</w.rf>
   <form>Sezemic</form>
   <lemma>Sezemice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W8</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W9</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W11</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W12</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W14</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W16</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W17</w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49172.txt-001-p5s2">
  <m id="m-pardubicky49172.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W2</w.rf>
   <form>15.35</form>
   <form_change>num_normalization</form_change>
   <lemma>15.35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W3</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W4</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W6</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W7</w.rf>
   <form>Lázní</form>
   <lemma>lázeň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W8</w.rf>
   <form>Bohdanče</form>
   <lemma>Bohdaneč_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W9</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W10</w.rf>
   <form>spadlý</form>
   <lemma>spadlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W11</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W12</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W13</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W15</w.rf>
   <form>Pravech</form>
   <lemma>Pravy_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-pardubicky49172.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49172.txt-001-p5s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
