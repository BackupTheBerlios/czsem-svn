<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky47578.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky47578.txt-001-p1s1">
  <m id="m-pardubicky47578.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W2</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W4</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W7</w.rf>
   <form>19.42</form>
   <form_change>num_normalization</form_change>
   <lemma>19.42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W9</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W12</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W13</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W14</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W15</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W17</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W18</w.rf>
   <form>lesní</form>
   <lemma>lesní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W19</w.rf>
   <form>paseky</form>
   <lemma>paseka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W20</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W21</w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W22</w.rf>
   <form>Horní</form>
   <lemma>Horní_;G</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W23</w.rf>
   <form>Houžovec</form>
   <lemma>Houžovec</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p1s2">
  <m id="m-pardubicky47578.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W4</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W5</w.rf>
   <form>paseky</form>
   <lemma>paseka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W7</w.rf>
   <form>klestí</form>
   <lemma>klestí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W9</w.rf>
   <form>lesní</form>
   <lemma>lesní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W10</w.rf>
   <form>mýtině</form>
   <lemma>mýtina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p1s3">
  <m id="m-pardubicky47578.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W1</w.rf>
   <form>Hořelo</form>
   <lemma>hořet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W3</w.rf>
   <form>stejném</form>
   <lemma>stejný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W4</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W5</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W6</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W7</w.rf>
   <form>třemi</form>
   <lemma>tři`3</lemma>
   <tag>ClXP7----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W8</w.rf>
   <form>dny</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W10</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W11</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W13</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W14</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p1s4">
  <m id="m-pardubicky47578.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W1</w.rf>
   <form>Včerejší</form>
   <lemma>včerejší</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W4</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W5</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W6</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W7</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W8</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W9</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W10</w.rf>
   <form>20.17</form>
   <form_change>num_normalization</form_change>
   <lemma>20.17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W13</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W14</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W15</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W16</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W17</w.rf>
   <form>20.48</form>
   <form_change>num_normalization</form_change>
   <lemma>20.48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W18</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s4W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p1s5">
  <m id="m-pardubicky47578.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W2</w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W4</w.rf>
   <form>odjížděly</form>
   <lemma>odjíždět_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W5</w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W6</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W7</w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W9</w.rf>
   <form>22.17</form>
   <form_change>num_normalization</form_change>
   <lemma>22.17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p1s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p2s1">
  <m id="m-pardubicky47578.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W2</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W4</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W7</w.rf>
   <form>9.53</form>
   <form_change>num_normalization</form_change>
   <lemma>9.53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W9</w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W10</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W11</w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W12</w.rf>
   <form>směřovaly</form>
   <lemma>směřovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W14</w.rf>
   <form>louku</form>
   <lemma>louka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W16</w.rf>
   <form>Horního</form>
   <lemma>Horní_;G</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W17</w.rf>
   <form>Houžovce</form>
   <lemma>Houžovce</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W19</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W20</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W21</w.rf>
   <form>rozhořela</form>
   <lemma>rozhořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W22</w.rf>
   <form>ohniska</form>
   <lemma>ohnisko</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W23</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W24</w.rf>
   <form>včerejším</form>
   <lemma>včerejší</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W25</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p2s2">
  <m id="m-pardubicky47578.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W1</w.rf>
   <form>Tentokrát</form>
   <lemma>tentokrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W2</w.rf>
   <form>hořela</form>
   <lemma>hořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W3</w.rf>
   <form>paseka</form>
   <lemma>paseka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W5</w.rf>
   <form>rozloze</form>
   <lemma>rozloha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W6</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W7</w.rf>
   <form>10x50</form>
   <lemma>10x50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W8</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p2s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p3s1">
  <m id="m-pardubicky47578.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W2</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W4</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W7</w.rf>
   <form>20.11</form>
   <form_change>num_normalization</form_change>
   <lemma>20.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W12</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W13</w.rf>
   <form>domku</form>
   <lemma>domek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W15</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W16</w.rf>
   <form>Svinná</form>
   <lemma>svinný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W17</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W18</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W19</w.rf>
   <form>Třebové</form>
   <lemma>Třebová_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p3s2">
  <m id="m-pardubicky47578.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W4</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W6</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W7</w.rf>
   <form>založily</form>
   <lemma>založit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W8</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W9</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W10</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W11</w.rf>
   <form>věku</form>
   <lemma>věk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W12</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W13</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W15</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W16</w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p3s3">
  <m id="m-pardubicky47578.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W1</w.rf>
   <form>Děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W2</w.rf>
   <form>založily</form>
   <lemma>založit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W3</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W5</w.rf>
   <form>balkóně</form>
   <lemma>balkón</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W7</w.rf>
   <form>2.nadzemním</form>
   <lemma>2.nadzemní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W8</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p3s4">
  <m id="m-pardubicky47578.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W1</w.rf>
   <form>Vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W2</w.rf>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W3</w.rf>
   <form>nefunkční</form>
   <lemma>funkční</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W4</w.rf>
   <form>pračky</form>
   <lemma>pračka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W5</w.rf>
   <form>zapálily</form>
   <lemma>zapálit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W6</w.rf>
   <form>hořlavé</form>
   <lemma>hořlavý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W7</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W9</w.rf>
   <form>hadry</form>
   <lemma>hadr</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W11</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W12</w.rf>
   <form>nichž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9XP2----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W13</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W14</w.rf>
   <form>vzňala</form>
   <lemma>vznítit</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W15</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W16</w.rf>
   <form>zmíněná</form>
   <lemma>zmíněný_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W17</w.rf>
   <form>pračka</form>
   <lemma>pračka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W19</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W20</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W21</w.rf>
   <form>mohl</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W22</w.rf>
   <form>rozšířit</form>
   <lemma>rozšířit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W23</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W24</w.rf>
   <form>dřevěném</form>
   <lemma>dřevěný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W25</w.rf>
   <form>obložení</form>
   <lemma>obložení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W26</w.rf>
   <form>podhledu</form>
   <lemma>podhled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W27</w.rf>
   <form>balkónu</form>
   <lemma>balkón</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W28</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W29</w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W30</w.rf>
   <form>budovy</form>
   <lemma>budova</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s4W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p3s5">
  <m id="m-pardubicky47578.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W1</w.rf>
   <form>Díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W2</w.rf>
   <form>včasnému</form>
   <lemma>včasný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W3</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W4</w.rf>
   <form>majitele</form>
   <lemma>majitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W6</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W7</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W8</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W9</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W11</w.rf>
   <form>ohoření</form>
   <lemma>ohoření_^(*2t)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W12</w.rf>
   <form>podhledu</form>
   <lemma>podhled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s5W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p3s6">
  <m id="m-pardubicky47578.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s6W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s6W2</w.rf>
   <form>nevznikla</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VpQW---XR-NA--1</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s6W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47578.txt-001-p3s7">
  <m id="m-pardubicky47578.txt-001-p3s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s7W1</w.rf>
   <form>Vyšetřovatel</form>
   <lemma>vyšetřovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s7W2</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s7W3</w.rf>
   <form>řešil</form>
   <lemma>řešit_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s7W4</w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s7W5</w.rf>
   <form>případ</form>
   <lemma>případ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s7W6</w.rf>
   <form>blokovou</form>
   <lemma>blokový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s7W7</w.rf>
   <form>pokutou</form>
   <lemma>pokuta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky47578.txt-001-p3s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47578.txt-001-p3s7W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
