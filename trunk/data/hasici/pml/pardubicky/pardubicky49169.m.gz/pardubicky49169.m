<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky49169.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky49169.txt-001-p1s1">
  <m id="m-pardubicky49169.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s1W1</w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s1W2</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s1W3</w.rf>
   <form>stanici</form>
   <lemma>stanice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s1W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s1W5</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p1s2">
  <m id="m-pardubicky49169.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s2W1</w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s2W2</w.rf>
   <form>vypadá</form>
   <lemma>vypadat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s2W3</w.rf>
   <form>hasič</form>
   <lemma>hasič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s2W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s2W5</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s2W6</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p1s3">
  <m id="m-pardubicky49169.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s3W1</w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s3W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s3W3</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s3W4</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s3W5</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s3W6</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p1s4">
  <m id="m-pardubicky49169.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W1</w.rf>
   <form>Takové</form>
   <lemma>takový</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W2</w.rf>
   <form>otázky</form>
   <lemma>otázka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W4</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W5</w.rf>
   <form>spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W6</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W7</w.rf>
   <form>čeká</form>
   <lemma>čekat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W9</w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W10</w.rf>
   <form>dnech</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W12</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W14</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W15</w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W16</w.rf>
   <form>provádějí</form>
   <lemma>provádět_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W17</w.rf>
   <form>preventivně</form>
   <lemma>preventivně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W18</w.rf>
   <form>výchovnou</form>
   <lemma>výchovný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W19</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p1s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p1s4W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p2s1">
  <m id="m-pardubicky49169.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W1</w.rf>
   <form>Provádění</form>
   <lemma>provádění_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W2</w.rf>
   <form>preventivně</form>
   <lemma>preventivně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W3</w.rf>
   <form>výchovné</form>
   <lemma>výchovný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W4</w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W6</w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W7</w.rf>
   <form>rozsáhlý</form>
   <lemma>rozsáhlý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W8</w.rf>
   <form>úkol</form>
   <lemma>úkol</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W11</w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W13</w.rf>
   <form>podílejí</form>
   <lemma>podílet_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W14</w.rf>
   <form>příslušníci</form>
   <lemma>příslušník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W15</w.rf>
   <form>jednotlivých</form>
   <lemma>jednotlivý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W16</w.rf>
   <form>odborů</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W18</w.rf>
   <form>navzájem</form>
   <lemma>navzájem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W19</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W20</w.rf>
   <form>pomáhají</form>
   <lemma>pomáhat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p2s2">
  <m id="m-pardubicky49169.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W1</w.rf>
   <form>Organizačně</form>
   <lemma>organizačně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W3</w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W4</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W5</w.rf>
   <form>připojena</form>
   <lemma>připojit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W7</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W8</w.rf>
   <form>prevence</form>
   <lemma>prevence</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p2s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s1">
  <m id="m-pardubicky49169.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W1</w.rf>
   <form>Besedy</form>
   <lemma>beseda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W2</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W3</w.rf>
   <form>zaměřené</form>
   <lemma>zaměřený_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W4</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W6</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W8</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W10</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W11</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W12</w.rf>
   <form>chovat</form>
   <lemma>chovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W14</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W15</w.rf>
   <form>mimořádné</form>
   <lemma>mimořádný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W16</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s2">
  <m id="m-pardubicky49169.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W1</w.rf>
   <form>Nedávno</form>
   <lemma>nedávno</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W3</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W4</w.rf>
   <form>150</form>
   <lemma>150</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W5</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W6</w.rf>
   <form>seznámilo</form>
   <lemma>seznámit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W8</w.rf>
   <form>hasičskou</form>
   <lemma>hasičský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W9</w.rf>
   <form>profesí</form>
   <lemma>profese</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W11</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W12</w.rf>
   <form>zbrojnici</form>
   <lemma>zbrojnice_,a_^(*3ík)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W14</w.rf>
   <form>Heřmanově</form>
   <lemma>Heřmanův_;S_;Y_^(*2)</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W15</w.rf>
   <form>Městci</form>
   <lemma>Městec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s3">
  <m id="m-pardubicky49169.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W1</w.rf>
   <form>Svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W2</w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W3</w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W4</w.rf>
   <form>dětem</form>
   <lemma>dítě</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W5</w.rf>
   <form>přiblížili</form>
   <lemma>přiblížit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W6</w.rf>
   <form>nejen</form>
   <lemma>nejen</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W7</w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W9</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W10</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W11</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W12</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s4">
  <m id="m-pardubicky49169.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W2</w.rf>
   <form>prvních</form>
   <lemma>první</lemma>
   <tag>CrFP6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W3</w.rf>
   <form>minutách</form>
   <lemma>minuta</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W4</w.rf>
   <form>besedy</form>
   <lemma>beseda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W6</w.rf>
   <form>prověřovaly</form>
   <lemma>prověřovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W7</w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W8</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s5">
  <m id="m-pardubicky49169.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s5W1</w.rf>
   <form>Poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s5W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s5W3</w.rf>
   <form>hovořilo</form>
   <lemma>hovořit_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s5W4</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s5W5</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s5W6</w.rf>
   <form>tísňové</form>
   <lemma>tísňový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s5W7</w.rf>
   <form>lince</form>
   <lemma>linka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s6">
  <m id="m-pardubicky49169.txt-001-p3s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W1</w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W2</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W3</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W4</w.rf>
   <form>následky</form>
   <lemma>následek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W6</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W8</w.rf>
   <form>tísňová</form>
   <lemma>tísňový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W9</w.rf>
   <form>linka</form>
   <lemma>linka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W10</w.rf>
   <form>zneužije</form>
   <lemma>zneužít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W12</w.rf>
   <form>naopak</form>
   <lemma>naopak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W14</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W15</w.rf>
   <form>správně</form>
   <lemma>správně_^(podle_něj._měřítek;_př._chlap,_míra,...)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W16</w.rf>
   <form>oznamovat</form>
   <lemma>oznamovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W17</w.rf>
   <form>mimořádnou</form>
   <lemma>mimořádný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W18</w.rf>
   <form>událost</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s6W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s7">
  <m id="m-pardubicky49169.txt-001-p3s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W1</w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W2</w.rf>
   <form>dělat</form>
   <lemma>dělat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W4</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W5</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W6</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W8</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W9</w.rf>
   <form>nebezpečné</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W10</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W11</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W12</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s7W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s8">
  <m id="m-pardubicky49169.txt-001-p3s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W1</w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W3</w.rf>
   <form>nejlépe</form>
   <lemma>dobře</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W4</w.rf>
   <form>chránit</form>
   <lemma>chránit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W5</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W6</w.rf>
   <form>hustým</form>
   <lemma>hustý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W7</w.rf>
   <form>kouřem</form>
   <lemma>kouř</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W9</w.rf>
   <form>nebezpečným</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAIS7----1N----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W10</w.rf>
   <form>ohněm</form>
   <lemma>oheň</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s8W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p3s9">
  <m id="m-pardubicky49169.txt-001-p3s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s9W1</w.rf>
   <form>Beseda</form>
   <lemma>beseda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s9W2</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s9W3</w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s9W4</w.rf>
   <form>zaujala</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p3s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p3s9W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p4s1">
  <m id="m-pardubicky49169.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W1</w.rf>
   <form>Se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W2</w.rf>
   <form>zájmem</form>
   <lemma>zájem</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W3</w.rf>
   <form>sledovaly</form>
   <lemma>sledovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W4</w.rf>
   <form>desítky</form>
   <lemma>desítka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W5</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W6</w.rf>
   <form>ukázky</form>
   <lemma>ukázka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W7</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W9</w.rf>
   <form>Chocni</form>
   <lemma>Choceň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p4s2">
  <m id="m-pardubicky49169.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s2W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s2W2</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s2W3</w.rf>
   <form>sv</form>
   <lemma>svatý_:B</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s2W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p4s3">
  <m id="m-pardubicky49169.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W1</w.rf>
   <form>Floriána</form>
   <lemma>Florian_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W3</w.rf>
   <form>patrona</form>
   <lemma>patrona</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W4</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W6</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W7</w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W8</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W10</w.rf>
   <form>mateřských</form>
   <lemma>mateřský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W12</w.rf>
   <form>základních</form>
   <lemma>základní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W13</w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W14</w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W16</w.rf>
   <form>maskotem</form>
   <lemma>maskot</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W17</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W18</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W19</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W21</w.rf>
   <form>dráčkem</form>
   <lemma>dráček</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W22</w.rf>
   <form>Ohniváčkem</form>
   <lemma>Ohniváčcu</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W24</w.rf>
   <form>prohlédly</form>
   <lemma>prohlédnout_:W</lemma>
   <tag>VpTP---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W25</w.rf>
   <form>hasičskou</form>
   <lemma>hasičský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W26</w.rf>
   <form>techniku</form>
   <lemma>technika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W28</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W29</w.rf>
   <form>vlastní</form>
   <lemma>vlastní-1_^(příslušný_k_něčemu)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W30</w.rf>
   <form>oči</form>
   <lemma>oko</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W31</w.rf>
   <form>uviděly</form>
   <lemma>uvidět</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W32</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W33</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W34</w.rf>
   <form>zraněných</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W35</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W36</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W37</w.rf>
   <form>havarovaných</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W38</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s3W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s3W39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49169.txt-001-p4s4">
  <m id="m-pardubicky49169.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W1</w.rf>
   <form>Středoškoláci</form>
   <lemma>středoškolák</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W2</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W4</w.rf>
   <form>vlastní</form>
   <lemma>vlastní-1_^(příslušný_k_něčemu)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W5</w.rf>
   <form>kůži</form>
   <lemma>kůže</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W6</w.rf>
   <form>vyzkoušeli</form>
   <lemma>vyzkoušet_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W7</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W8</w.rf>
   <form>přetlakový</form>
   <lemma>přetlakový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W9</w.rf>
   <form>protichemický</form>
   <lemma>protichemický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W10</w.rf>
   <form>oblek</form>
   <lemma>oblek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W11</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W12</w.rf>
   <form>dýchací</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W13</w.rf>
   <form>techniku</form>
   <lemma>technika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49169.txt-001-p4s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49169.txt-001-p4s4W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
