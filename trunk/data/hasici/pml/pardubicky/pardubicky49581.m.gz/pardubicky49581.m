<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky49581.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky49581.txt-001-p1s1">
  <m id="m-pardubicky49581.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W1</w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W2</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W3</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W4</w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W6</w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W7</w.rf>
   <form>jedinečnou</form>
   <lemma>jedinečný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W8</w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W9</w.rf>
   <form>nahlédnout</form>
   <lemma>nahlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W11</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49581.txt-001-p1s2">
  <m id="m-pardubicky49581.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W1</w.rf>
   <form>Prohlédnout</form>
   <lemma>prohlédnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W3</w.rf>
   <form>můžete</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W4</w.rf>
   <form>výjezdová</form>
   <lemma>výjezdový</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W5</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W7</w.rf>
   <form>potápěčskou</form>
   <lemma>potápěčský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W8</w.rf>
   <form>techniku</form>
   <lemma>technika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W10</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W11</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W12</w.rf>
   <form>lezců</form>
   <lemma>lezec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W14</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W15</w.rf>
   <form>zásahovou</form>
   <lemma>zásahový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W16</w.rf>
   <form>techniku</form>
   <lemma>technika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49581.txt-001-p1s3">
  <m id="m-pardubicky49581.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W2</w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W3</w.rf>
   <form>návštěvníky</form>
   <lemma>návštěvník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W4</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W5</w.rf>
   <form>připraveny</form>
   <lemma>připravit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W7</w.rf>
   <form>drobné</form>
   <lemma>drobný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W8</w.rf>
   <form>propagační</form>
   <lemma>propagační</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W9</w.rf>
   <form>materiály</form>
   <lemma>materiál</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W10</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W11</w.rf>
   <form>hasičskou</form>
   <lemma>hasičský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W12</w.rf>
   <form>tematikou</form>
   <lemma>tematika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p1s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p1s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49581.txt-001-p2s1">
  <m id="m-pardubicky49581.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W2</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W4</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W7</w.rf>
   <form>připravena</form>
   <lemma>připravit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W8</w.rf>
   <form>ukázka</form>
   <lemma>ukázka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W9</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W10</w.rf>
   <form>zraněných</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W11</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W13</w.rf>
   <form>havarovaných</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W14</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p2s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49581.txt-001-p3s1">
  <m id="m-pardubicky49581.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W3</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W4</w.rf>
   <form>lezci</form>
   <lemma>lezec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W5</w.rf>
   <form>připravili</form>
   <lemma>připravit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W6</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W7</w.rf>
   <form>ukázek</form>
   <lemma>ukázka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W9</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W10</w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W12</w.rf>
   <form>představí</form>
   <lemma>představit-1_:W_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W13</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W14</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W15</w.rf>
   <form>mladí</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W16</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p3s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49581.txt-001-p4s1">
  <m id="m-pardubicky49581.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p4s1W1</w.rf>
   <form>Pozvánka</form>
   <lemma>pozvánka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p4s1W2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p4s1W3</w.rf>
   <form>Den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p4s1W4</w.rf>
   <form>otevřených</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p4s1W5</w.rf>
   <form>dveří</form>
   <lemma>dveře</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p4s1W6</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p4s1W7</w.rf>
   <form>389kb</form>
   <lemma>389kb</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p4s1W8</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49581.txt-001-p5s1">
  <m id="m-pardubicky49581.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p5s1W1</w.rf>
   <form>Jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p5s1W2</w.rf>
   <form>srdečně</form>
   <lemma>srdečně_^(př._pozdrav,_člověk)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p5s1W3</w.rf>
   <form>zváni</form>
   <lemma>zvát</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49581.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49581.txt-001-p5s1W4</w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
