<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky48655.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky48655.txt-001-p1s1">
  <m id="m-pardubicky48655.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p1s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p1s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p1s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p1s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p1s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p1s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p1s1W7</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p2s1">
  <m id="m-pardubicky48655.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W2</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W7</w.rf>
   <form>14.25</form>
   <form_change>num_normalization</form_change>
   <lemma>14.25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W12</w.rf>
   <form>Poličky</form>
   <lemma>polička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W14</w.rf>
   <form>obcí</form>
   <lemma>obec</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W15</w.rf>
   <form>Telecí</form>
   <lemma>telecí</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W17</w.rf>
   <form>Březiny</form>
   <lemma>Březina-2_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W18</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W19</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W20</w.rf>
   <form>porostu</form>
   <lemma>porost</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W21</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W22</w.rf>
   <form>obcemi</form>
   <lemma>obec</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W23</w.rf>
   <form>Borová</form>
   <lemma>bórový-2_;H</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W25</w.rf>
   <form>Telecí</form>
   <lemma>telecí</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p2s2">
  <m id="m-pardubicky48655.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W4</w.rf>
   <form>rozlohu</form>
   <lemma>rozloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W5</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W6</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W7</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W8</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p2s3">
  <m id="m-pardubicky48655.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W2</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W3</w.rf>
   <form>zlikvidovali</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W6</w.rf>
   <form>16.59</form>
   <form_change>num_normalization</form_change>
   <lemma>16.59</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W9</w.rf>
   <form>vrátili</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W10</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W12</w.rf>
   <form>základnu</form>
   <lemma>základna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p2s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p3s1">
  <m id="m-pardubicky48655.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p3s1W9</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p4s1">
  <m id="m-pardubicky48655.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W2</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W7</w.rf>
   <form>20.40</form>
   <form_change>num_normalization</form_change>
   <lemma>20.40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W9</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W10</w.rf>
   <form>lanškrounští</form>
   <lemma>lanškrounský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W12</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W14</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W15</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W16</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W17</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W19</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W21</w.rf>
   <form>Anenské</form>
   <lemma>anenský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W22</w.rf>
   <form>Studánce</form>
   <lemma>studánka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W23</w.rf>
   <form>narazilo</form>
   <lemma>narazit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W24</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W25</w.rf>
   <form>sloupu</form>
   <lemma>sloup</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W26</w.rf>
   <form>elektrického</form>
   <lemma>elektrický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W27</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p4s2">
  <m id="m-pardubicky48655.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W1</w.rf>
   <form>Zraněny</form>
   <lemma>zranit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W2</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W3</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W4</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W6</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W7</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W9</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W10</w.rf>
   <form>převzala</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W11</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W12</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W13</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p4s3">
  <m id="m-pardubicky48655.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W2</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W3</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W4</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W5</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W6</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W8</w.rf>
   <form>zamezili</form>
   <lemma>zamezit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W9</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W10</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W11</w.rf>
   <form>náplní</form>
   <lemma>náplň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W13</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p4s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p5s1">
  <m id="m-pardubicky48655.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W7</w.rf>
   <form>5.32</form>
   <form_change>num_normalization</form_change>
   <lemma>5.32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W9</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W10</w.rf>
   <form>lanškrounští</form>
   <lemma>lanškrounský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W12</w.rf>
   <form>následky</form>
   <lemma>následek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W14</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W16</w.rf>
   <form>Ostrově</form>
   <lemma>Ostrov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p5s2">
  <m id="m-pardubicky48655.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W1</w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W2</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W3</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W4</w.rf>
   <form>střetu</form>
   <lemma>střet</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W5</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W6</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W8</w.rf>
   <form>cyklisty</form>
   <lemma>cyklista</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p5s3">
  <m id="m-pardubicky48655.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W1</w.rf>
   <form>Sražený</form>
   <lemma>sražený_^(*4zit)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W3</w.rf>
   <form>zraněný</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W4</w.rf>
   <form>cyklista</form>
   <lemma>cyklista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W5</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W6</w.rf>
   <form>převezen</form>
   <lemma>převézt</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W7</w.rf>
   <form>zdravotnickou</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W8</w.rf>
   <form>záchrannou</form>
   <lemma>záchranný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W9</w.rf>
   <form>službou</form>
   <lemma>služba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W11</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p5s4">
  <m id="m-pardubicky48655.txt-001-p5s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W2</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W3</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W4</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W6</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W8</w.rf>
   <form>vrátili</form>
   <lemma>vrátit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W9</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W11</w.rf>
   <form>základnu</form>
   <lemma>základna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p5s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p5s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p6s1">
  <m id="m-pardubicky48655.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p6s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p6s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p6s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p6s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p6s1W5</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p6s1W6</w.rf>
   <form>Holice</form>
   <lemma>Holice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p7s1">
  <m id="m-pardubicky48655.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W2</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W7</w.rf>
   <form>23.55</form>
   <form_change>num_normalization</form_change>
   <lemma>23.55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W10</w.rf>
   <form>holičtí</form>
   <lemma>holický</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W13</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W14</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W15</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W16</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W17</w.rf>
   <form>120</form>
   <lemma>120</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W19</w.rf>
   <form>Horním</form>
   <lemma>Horní_;G</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W20</w.rf>
   <form>Jelení</form>
   <lemma>jelení</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p7s2">
  <m id="m-pardubicky48655.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W1</w.rf>
   <form>Požár</form>
   <lemma>Požár-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W3</w.rf>
   <form>hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W4</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W5</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W6</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W7</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W9</w.rf>
   <form>0.10</form>
   <form_change>num_normalization</form_change>
   <lemma>0.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W11</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W12</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W13</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W14</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W15</w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W16</w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W17</w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p7s3">
  <m id="m-pardubicky48655.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W3</w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W4</w.rf>
   <form>způsobily</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W5</w.rf>
   <form>plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W7</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W8</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W9</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W11</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClIS4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W12</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W13</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p7s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p7s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p8s1">
  <m id="m-pardubicky48655.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p8s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p8s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p8s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p8s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p8s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p8s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p8s1W7</w.rf>
   <form>Chrudim</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p9s1">
  <m id="m-pardubicky48655.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W2</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W7</w.rf>
   <form>5.40</form>
   <form_change>num_normalization</form_change>
   <lemma>5.40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W9</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W10</w.rf>
   <form>chrudimští</form>
   <lemma>chrudimský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W12</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W14</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W15</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W17</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W19</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W21</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W22</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W23</w.rf>
   <form>Slatiňanech-Škrovádu</form>
   <lemma>Slatiňanech-Škrovád</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p9s2">
  <m id="m-pardubicky48655.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s2W4</w.rf>
   <form>střet</form>
   <lemma>střet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s2W5</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s2W6</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p9s3">
  <m id="m-pardubicky48655.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W2</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W3</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W4</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W5</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W6</w.rf>
   <form>odpojením</form>
   <lemma>odpojení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W7</w.rf>
   <form>akumulátoru</form>
   <lemma>akumulátor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W9</w.rf>
   <form>zamezili</form>
   <lemma>zamezit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W10</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W11</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W12</w.rf>
   <form>náplní</form>
   <lemma>náplň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p9s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p9s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s1">
  <m id="m-pardubicky48655.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W2</w.rf>
   <form>10.54</form>
   <form_change>num_normalization</form_change>
   <lemma>10.54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W3</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W4</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W5</w.rf>
   <form>chrudimští</form>
   <lemma>chrudimský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W7</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W8</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W9</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W10</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W12</w.rf>
   <form>Markovic</form>
   <lemma>Markovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s2">
  <m id="m-pardubicky48655.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W4</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W5</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W6</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W8</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W9</w.rf>
   <form>směřovalo</form>
   <lemma>směřovat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W10</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W11</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W12</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W13</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W14</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s3">
  <m id="m-pardubicky48655.txt-001-p10s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W1</w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W2</w.rf>
   <form>nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W4</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W6</w.rf>
   <form>kruhovém</form>
   <lemma>kruhový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W7</w.rf>
   <form>objezdu</form>
   <lemma>objezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W9</w.rf>
   <form>Chrudimi</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W11</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W12</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W13</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s3W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s4">
  <m id="m-pardubicky48655.txt-001-p10s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s4W1</w.rf>
   <form>Vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s4W2</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s4W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s4W4</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s4W5</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s4W6</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s4W7</w.rf>
   <form>nedojelo</form>
   <lemma>dojet</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s5">
  <m id="m-pardubicky48655.txt-001-p10s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W2</w.rf>
   <form>Markovicích</form>
   <lemma>Markovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W3</w.rf>
   <form>narazilo</form>
   <lemma>narazit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W5</w.rf>
   <form>mostku</form>
   <lemma>mostek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W7</w.rf>
   <form>převrátilo</form>
   <lemma>převrátit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W10</w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s6">
  <m id="m-pardubicky48655.txt-001-p10s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W1</w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W2</w.rf>
   <form>policista</form>
   <lemma>policista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W3</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W5</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W6</w.rf>
   <form>vypadnout</form>
   <lemma>vypadnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W8</w.rf>
   <form>druhého</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W10</w.rf>
   <form>havarovaného</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W11</w.rf>
   <form>vozu</form>
   <lemma>vůz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W12</w.rf>
   <form>pomohli</form>
   <lemma>pomoci</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W13</w.rf>
   <form>vytáhnout</form>
   <lemma>vytáhnout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W14</w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W15</w.rf>
   <form>obyvatelé</form>
   <lemma>obyvatel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s6W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s7">
  <m id="m-pardubicky48655.txt-001-p10s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W3</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W4</w.rf>
   <form>pomáhali</form>
   <lemma>pomáhat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W5</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W6</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W8</w.rf>
   <form>oživováním</form>
   <lemma>oživování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s7W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s8">
  <m id="m-pardubicky48655.txt-001-p10s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W1</w.rf>
   <form>Oživovací</form>
   <lemma>oživovací_^(*2t)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W2</w.rf>
   <form>pokusy</form>
   <lemma>pokus</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W4</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W5</w.rf>
   <form>marné</form>
   <lemma>marný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W7</w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W8</w.rf>
   <form>policisté</form>
   <lemma>policista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W9</w.rf>
   <form>svému</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W10</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W12</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W13</w.rf>
   <form>podlehli</form>
   <lemma>podlehnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s8W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p10s9">
  <m id="m-pardubicky48655.txt-001-p10s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s9W1</w.rf>
   <form>Silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s9W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s9W3</w.rf>
   <form>uzavřena</form>
   <lemma>uzavřít</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s9W4</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s9W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s9W6</w.rf>
   <form>odpoledních</form>
   <lemma>odpolední</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s9W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p10s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p10s9W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p11s1">
  <m id="m-pardubicky48655.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W2</w.rf>
   <form>15.12</form>
   <form_change>num_normalization</form_change>
   <lemma>15.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W3</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W4</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W5</w.rf>
   <form>hlinečtí</form>
   <lemma>hlinecký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W7</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W8</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W9</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W11</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W13</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W15</w.rf>
   <form>obci</form>
   <lemma>obec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W16</w.rf>
   <form>Slavíkov</form>
   <lemma>Slavíkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p11s2">
  <m id="m-pardubicky48655.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s2W4</w.rf>
   <form>kolizi</form>
   <lemma>kolize</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s2W5</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s2W6</w.rf>
   <form>Ford</form>
   <lemma>Ford-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s2W7</w.rf>
   <form>Mondeo</form>
   <lemma>Mondeo_;R_^(značka_automobilu_Ford_Mondeo)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p11s3">
  <m id="m-pardubicky48655.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W2</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W4</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W6</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W7</w.rf>
   <form>započali</form>
   <lemma>započít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W8</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W9</w.rf>
   <form>vyprošťování</form>
   <lemma>vyprošťování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W10</w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W11</w.rf>
   <form>zraněné</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W12</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W14</w.rf>
   <form>druhou</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W15</w.rf>
   <form>zraněnou</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W16</w.rf>
   <form>osobu</form>
   <lemma>osoba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W17</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W19</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W20</w.rf>
   <form>převzala</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W21</w.rf>
   <form>zdravotnická</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W22</w.rf>
   <form>záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W23</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p11s4">
  <m id="m-pardubicky48655.txt-001-p11s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s4W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s4W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s4W4</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s4W5</w.rf>
   <form>vrtulník</form>
   <lemma>vrtulník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p11s5">
  <m id="m-pardubicky48655.txt-001-p11s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W1</w.rf>
   <form>Jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W3</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W5</w.rf>
   <form>nehodu</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W7</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W9</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W11</w.rf>
   <form>okrese</form>
   <lemma>okres</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W12</w.rf>
   <form>Havlíčkův</form>
   <lemma>Havlíčkův-1_;S_^(*5ek-1)</lemma>
   <tag>AUIS1M---------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W13</w.rf>
   <form>Brod</form>
   <lemma>Brod-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W15</w.rf>
   <form>následky</form>
   <lemma>následek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W16</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W17</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W18</w.rf>
   <form>odstraňovala</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W19</w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W20</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W21</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W22</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W23</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W24</w.rf>
   <form>Chotěboř</form>
   <lemma>Chotěboř_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p11s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p11s5W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p12s1">
  <m id="m-pardubicky48655.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W7</w.rf>
   <form>7.08</form>
   <form_change>num_normalization</form_change>
   <lemma>7.08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W10</w.rf>
   <form>chrudimští</form>
   <lemma>chrudimský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W14</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W15</w.rf>
   <form>čtyř</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W16</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W17</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W19</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W20</w.rf>
   <form>nákladního</form>
   <lemma>nákladní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W21</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W23</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W24</w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W25</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s1W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p12s2">
  <m id="m-pardubicky48655.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s2W1</w.rf>
   <form>Nehoda</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s2W3</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s2W5</w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s2W6</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s2W7</w.rf>
   <form>Medlešic</form>
   <lemma>Medlešice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p12s3">
  <m id="m-pardubicky48655.txt-001-p12s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W1</w.rf>
   <form>Silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W3</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W4</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W5</w.rf>
   <form>neprůjezdnou</form>
   <lemma>průjezdný</lemma>
   <tag>AAFS4----1N----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W7</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W8</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W9</w.rf>
   <form>zablokovala</form>
   <lemma>zablokovat_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W10</w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W11</w.rf>
   <form>jízdní</form>
   <lemma>jízdní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W12</w.rf>
   <form>pruhy</form>
   <lemma>pruh</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p12s4">
  <m id="m-pardubicky48655.txt-001-p12s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s4W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s4W2</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s4W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s4W4</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s4W5</w.rf>
   <form>zraněno</form>
   <lemma>zranit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s4W6</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s4W7</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p12s5">
  <m id="m-pardubicky48655.txt-001-p12s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W1</w.rf>
   <form>Nákladní</form>
   <lemma>nákladní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W2</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W3</w.rf>
   <form>skončil</form>
   <lemma>skončit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W4</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W5</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W7</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W9</w.rf>
   <form>začaly</form>
   <lemma>začít-1</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W11</w.rf>
   <form>něho</form>
   <lemma>on-1_^(on)</lemma>
   <tag>P5ZS2--3------1</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W12</w.rf>
   <form>unikat</form>
   <lemma>unikat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W13</w.rf>
   <form>pohonné</form>
   <lemma>pohonný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W14</w.rf>
   <form>hmoty</form>
   <lemma>hmota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s5W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p12s6">
  <m id="m-pardubicky48655.txt-001-p12s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W2</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W3</w.rf>
   <form>protipožární</form>
   <lemma>protipožární</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W4</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W6</w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W7</w.rf>
   <form>havarovaných</form>
   <lemma>havarovaný_^(*2t)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W8</w.rf>
   <form>automobilů</form>
   <lemma>automobil</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W10</w.rf>
   <form>zamezili</form>
   <lemma>zamezit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W11</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W12</w.rf>
   <form>nafty</form>
   <lemma>nafta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W13</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W14</w.rf>
   <form>nákladního</form>
   <lemma>nákladní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W15</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s6W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48655.txt-001-p12s7">
  <m id="m-pardubicky48655.txt-001-p12s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s7W1</w.rf>
   <form>Odstraňování</form>
   <lemma>odstraňování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s7W2</w.rf>
   <form>následků</form>
   <lemma>následek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s7W3</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s7W4</w.rf>
   <form>trvalo</form>
   <lemma>trvat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s7W5</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s7W6</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48655.txt-001-p12s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48655.txt-001-p12s7W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
