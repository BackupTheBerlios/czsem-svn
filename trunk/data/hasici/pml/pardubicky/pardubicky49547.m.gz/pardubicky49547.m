<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky49547.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky49547.txt-001-p1s1">
  <m id="m-pardubicky49547.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p1s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p1s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p1s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p1s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p1s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p1s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p1s1W7</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p2s1">
  <m id="m-pardubicky49547.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W2</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W7</w.rf>
   <form>11.19</form>
   <form_change>num_normalization</form_change>
   <lemma>11.19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W9</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W11</w.rf>
   <form>únik</form>
   <lemma>únik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W12</w.rf>
   <form>nafty</form>
   <lemma>nafta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W13</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W14</w.rf>
   <form>agregátu</form>
   <lemma>agregát</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W16</w.rf>
   <form>korbě</form>
   <lemma>korba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W17</w.rf>
   <form>nákladního</form>
   <lemma>nákladní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W18</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W19</w.rf>
   <form>Tatra</form>
   <lemma>Tatra-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W21</w.rf>
   <form>Litomyšli</form>
   <lemma>Litomyšl_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p2s2">
  <m id="m-pardubicky49547.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s2W1</w.rf>
   <form>Došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s2W2</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s2W3</w.rf>
   <form>otevření</form>
   <lemma>otevření_^(*3ít)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s2W4</w.rf>
   <form>ventilu</form>
   <lemma>ventil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s2W5</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s2W6</w.rf>
   <form>přepravě</form>
   <lemma>přeprava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p2s3">
  <m id="m-pardubicky49547.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W2</w.rf>
   <form>zamezili</form>
   <lemma>zamezit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W3</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W5</w.rf>
   <form>ropnou</form>
   <lemma>ropný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W6</w.rf>
   <form>skvrnu</form>
   <lemma>skvrna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W8</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W9</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W11</w.rf>
   <form>vozovce</form>
   <lemma>vozovka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W13</w.rf>
   <form>zasypali</form>
   <lemma>zasypat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W14</w.rf>
   <form>sorbentem</form>
   <lemma>sorbent</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W16</w.rf>
   <form>odstranili</form>
   <lemma>odstranit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p2s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p3s1">
  <m id="m-pardubicky49547.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p3s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p3s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p3s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p3s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p3s1W5</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p3s1W6</w.rf>
   <form>Pardubice</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p4s1">
  <m id="m-pardubicky49547.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W2</w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W7</w.rf>
   <form>15.11</form>
   <form_change>num_normalization</form_change>
   <lemma>15.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W10</w.rf>
   <form>pardubičtí</form>
   <lemma>pardubický</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W11</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W13</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W14</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W16</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W17</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W18</w.rf>
   <form>stala</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W20</w.rf>
   <form>Poděbradské</form>
   <lemma>poděbradský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W21</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W23</w.rf>
   <form>Pardubicích</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W25</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W26</w.rf>
   <form>výjezdu</form>
   <lemma>výjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W27</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W28</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W29</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p4s2">
  <m id="m-pardubicky49547.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W4</w.rf>
   <form>kolizi</form>
   <lemma>kolize</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W5</w.rf>
   <form>osobního</form>
   <lemma>osobní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W6</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W8</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W9</w.rf>
   <form>prorazilo</form>
   <lemma>prorazit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W10</w.rf>
   <form>svodidla</form>
   <lemma>svodidlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W12</w.rf>
   <form>skončilo</form>
   <lemma>skončit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W13</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W14</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p4s3">
  <m id="m-pardubicky49547.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W2</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W4</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W5</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W7</w.rf>
   <form>zdemolovaného</form>
   <lemma>zdemolovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W8</w.rf>
   <form>Fiatu</form>
   <lemma>Fiat-2_;K_;R_^(vozidlo)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W9</w.rf>
   <form>Croma</form>
   <lemma>Croma</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W10</w.rf>
   <form>vyprostit</form>
   <lemma>vyprostit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W11</w.rf>
   <form>zraněného</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W12</w.rf>
   <form>řidiče</form>
   <lemma>řidič</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p4s4">
  <m id="m-pardubicky49547.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W4</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W5</w.rf>
   <form>přivolán</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W6</w.rf>
   <form>hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W7</w.rf>
   <form>jeřáb</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W9</w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W10</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W11</w.rf>
   <form>zdemolovaný</form>
   <lemma>zdemolovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W12</w.rf>
   <form>fiat</form>
   <lemma>Fiat-2_;R_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W13</w.rf>
   <form>naložen</form>
   <lemma>naložit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W15</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W16</w.rf>
   <form>odtahové</form>
   <lemma>odtahový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W17</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s4W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p4s5">
  <m id="m-pardubicky49547.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s5W1</w.rf>
   <form>Následky</form>
   <lemma>následek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s5W2</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s5W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s5W4</w.rf>
   <form>odstraněny</form>
   <lemma>odstranit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s5W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s5W6</w.rf>
   <form>17.28</form>
   <form_change>num_normalization</form_change>
   <lemma>17.28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s5W7</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p4s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p5s1">
  <m id="m-pardubicky49547.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p5s1W1</w.rf>
   <form>Roje</form>
   <lemma>Roja_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p5s1W2</w.rf>
   <form>včel</form>
   <lemma>včela</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p5s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p5s1W4</w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p6s1">
  <m id="m-pardubicky49547.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W1</w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W2</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W3</w.rf>
   <form>včerejšího</form>
   <lemma>včerejší</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W4</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W5</w.rf>
   <form>zaznamenalo</form>
   <lemma>zaznamenat_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W6</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W8</w.rf>
   <form>informační</form>
   <lemma>informační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W9</w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W10</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W12</w.rf>
   <form>Pardubicích</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W13</w.rf>
   <form>telefonáty</form>
   <lemma>telefonát</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W14</w.rf>
   <form>oznamující</form>
   <lemma>oznamující_^(*5ovat)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W15</w.rf>
   <form>výskyt</form>
   <lemma>výskyt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W16</w.rf>
   <form>nebezpečného</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAIS2----1N----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W17</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W18</w.rf>
   <form>poblíž</form>
   <lemma>poblíž-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W19</w.rf>
   <form>obydlí</form>
   <lemma>obydlí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W22</w.rf>
   <form>veřejných</form>
   <lemma>veřejný</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W23</w.rf>
   <form>prostranstvích</form>
   <lemma>prostranství</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W25</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W26</w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W27</w.rf>
   <form>apod</form>
   <lemma>apod-1_:B_,x_^(a_podobně)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p6s2">
  <m id="m-pardubicky49547.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W2</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W3</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W4</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W6</w.rf>
   <form>Moravské</form>
   <lemma>moravský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W7</w.rf>
   <form>Třebové</form>
   <lemma>Třebová_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W9</w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W10</w.rf>
   <form>T.G</form>
   <lemma>T.G</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W12</w.rf>
   <form>Masaryka</form>
   <lemma>Masaryk_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W14</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W15</w.rf>
   <form>Mládežnické</form>
   <lemma>mládežnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W16</w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W17</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W18</w.rf>
   <form>Vysokém</form>
   <lemma>Vysoký-1_;K</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W19</w.rf>
   <form>Mýtě</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p6s3">
  <m id="m-pardubicky49547.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W1</w.rf>
   <form>Včely</form>
   <lemma>včela</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W2</w.rf>
   <form>ohrožovaly</form>
   <lemma>ohrožovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W3</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W5</w.rf>
   <form>hřišti</form>
   <lemma>hřiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W7</w.rf>
   <form>Jiráskově</form>
   <lemma>Jiráskův_;S_^(*3ek)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W8</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W10</w.rf>
   <form>Litomyšli</form>
   <lemma>Litomyšl_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W12</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W13</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W14</w.rf>
   <form>odvraceli</form>
   <lemma>odvracet_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W15</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W16</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W17</w.rf>
   <form>Chvojenci</form>
   <lemma>Chvojenec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W19</w.rf>
   <form>Pardubicku</form>
   <lemma>Pardubicko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W20</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W22</w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W23</w.rf>
   <form>Erno</form>
   <lemma>Erna_;Y</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W24</w.rf>
   <form>Košťála</form>
   <lemma>Košťál_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W26</w.rf>
   <form>Pardubicích</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p6s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p6s3W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p7s1">
  <m id="m-pardubicky49547.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W1</w.rf>
   <form>Činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W2</w.rf>
   <form>související</form>
   <lemma>související_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W4</w.rf>
   <form>likvidací</form>
   <lemma>likvidace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W5</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W6</w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W7</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W8</w.rf>
   <form>úkolem</form>
   <lemma>úkol</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W9</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W11</w.rf>
   <form>provádějí</form>
   <lemma>provádět_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W12</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W13</w.rf>
   <form>soukromé</form>
   <lemma>soukromý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W14</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p7s2">
  <m id="m-pardubicky49547.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W1</w.rf>
   <form>Přestože</form>
   <lemma>přestože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W2</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS7---------1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W3</w.rf>
   <form>činností</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W4</w.rf>
   <form>dokáží</form>
   <lemma>dokázat</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W7</w.rf>
   <form>naléhavých</form>
   <lemma>naléhavý</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W8</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W9</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W11</w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W13</w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W14</w.rf>
   <form>setkávají</form>
   <lemma>setkávat_:T_^(*4at)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W16</w.rf>
   <form>nepřátelskou</form>
   <lemma>přátelský</lemma>
   <tag>AAFS7----1N----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W17</w.rf>
   <form>reakcí</form>
   <lemma>reakce</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W18</w.rf>
   <form>veřejnosti</form>
   <lemma>veřejnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p7s3">
  <m id="m-pardubicky49547.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W2</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W3</w.rf>
   <form>obtížného</form>
   <lemma>obtížný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W4</w.rf>
   <form>hmyzu</form>
   <lemma>hmyz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W6</w.rf>
   <form>objevují</form>
   <lemma>objevovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W7</w.rf>
   <form>stížnosti</form>
   <lemma>stížnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W8</w.rf>
   <form>některých</form>
   <lemma>některý</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W9</w.rf>
   <form>tzv.</form>
   <lemma>takzvaný_:B_,x</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W10</w.rf>
   <form>ochránců</form>
   <lemma>ochránce</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W11</w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W13</w.rf>
   <form>tvrdících</form>
   <lemma>tvrdící_^(*3it)</lemma>
   <tag>AGMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W15</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W16</w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W18</w.rf>
   <form>sršni</form>
   <lemma>sršeň</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W19</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W20</w.rf>
   <form>chráněny</form>
   <lemma>chránit</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W21</w.rf>
   <form>zákonem</form>
   <lemma>zákon</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W23</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W24</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W25</w.rf>
   <form>činností</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W26</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W27</w.rf>
   <form>dochází</form>
   <lemma>docházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W28</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W29</w.rf>
   <form>porušování</form>
   <lemma>porušování_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W30</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W31</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W32</w.rf>
   <form>ochranu</form>
   <lemma>ochrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W33</w.rf>
   <form>zvířat</form>
   <lemma>zvíře</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W34</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W35</w.rf>
   <form>týrání</form>
   <lemma>týrání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s3W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s3W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p7s4">
  <m id="m-pardubicky49547.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s4W1</w.rf>
   <form>Nemají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s4W2</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s4W3</w.rf>
   <form>pravdu</form>
   <lemma>pravda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s4W4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p7s5">
  <m id="m-pardubicky49547.txt-001-p7s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W1</w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W3</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W5</w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W6</w.rf>
   <form>hmyz</form>
   <lemma>hmyz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W7</w.rf>
   <form>podléhá</form>
   <lemma>podléhat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W8</w.rf>
   <form>obecným</form>
   <lemma>obecný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W9</w.rf>
   <form>ustanovením</form>
   <lemma>ustanovení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W10</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W11</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W12</w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W13</w.rf>
   <form>rady</form>
   <lemma>rada-1_^(př._dát_někomu_dobrou_radu)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W14</w.rf>
   <form>č.114</form>
   <lemma>č.114</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W15</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W16</w.rf>
   <form>1992</form>
   <lemma>1992</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W17</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W20</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W21</w.rf>
   <form>ochraně</form>
   <lemma>ochrana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W22</w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W24</w.rf>
   <form>krajiny</form>
   <lemma>krajina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W27</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W28</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W29</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W30</w.rf>
   <form>hubit</form>
   <lemma>hubit_^(např._hmyz)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W31</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W32</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W33</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W34</w.rf>
   <form>ohrožení</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W35</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W36</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W37</w.rf>
   <form>jiných</form>
   <lemma>jiný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W38</w.rf>
   <form>živočichů</form>
   <lemma>živočich</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s5W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s5W39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p7s6">
  <m id="m-pardubicky49547.txt-001-p7s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W1</w.rf>
   <form>Včely</form>
   <lemma>včela</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W3</w.rf>
   <form>vosy</form>
   <lemma>vosa</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W4</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W5</w.rf>
   <form>sršni</form>
   <lemma>sršeň</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W6</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W7</w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W8</w.rf>
   <form>uvedeny</form>
   <lemma>uvést</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W10</w.rf>
   <form>seznamu</form>
   <lemma>seznam</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W11</w.rf>
   <form>druhů</form>
   <lemma>druh-2_^(partner)</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W12</w.rf>
   <form>zvláště</form>
   <lemma>zvláště</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W13</w.rf>
   <form>chráněných</form>
   <lemma>chráněný_^(*3it)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W14</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W15</w.rf>
   <form>ohrožených</form>
   <lemma>ohrožený_^(*4zit)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W16</w.rf>
   <form>živočichů</form>
   <lemma>živočich</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W18</w.rf>
   <form>příloze</form>
   <lemma>příloha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W19</w.rf>
   <form>č.III</form>
   <lemma>č.III</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W20</w.rf>
   <form>vyhlášky</form>
   <lemma>vyhláška</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W21</w.rf>
   <form>Ministerstva</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W22</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W23</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W24</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W25</w.rf>
   <form>č.395</form>
   <lemma>č.395</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W26</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W27</w.rf>
   <form>1992</form>
   <lemma>1992</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W28</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s6W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s6W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p7s7">
  <m id="m-pardubicky49547.txt-001-p7s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s7W1</w.rf>
   <form>Hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s7W2</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s7W3</w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s7W4</w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s7W5</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s7W6</w.rf>
   <form>provádí</form>
   <lemma>provádět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s7W7</w.rf>
   <form>dobrovolně</form>
   <lemma>dobrovolně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s7W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p7s8">
  <m id="m-pardubicky49547.txt-001-p7s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W1</w.rf>
   <form>Míra</form>
   <lemma>Míra-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W2</w.rf>
   <form>ohrožení</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W3</w.rf>
   <form>zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W4</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W5</w.rf>
   <form>málokdy</form>
   <lemma>málokdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W6</w.rf>
   <form>odpovídá</form>
   <lemma>odpovídat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W7</w.rf>
   <form>definici</form>
   <lemma>definice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W8</w.rf>
   <form>mimořádné</form>
   <lemma>mimořádný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W9</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p7s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p7s8W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p8s1">
  <m id="m-pardubicky49547.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W1</w.rf>
   <form>Limitem</form>
   <lemma>limit-1</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W2</w.rf>
   <form>zásahů</form>
   <lemma>zásah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W3</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W4</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W6</w.rf>
   <form>také</form>
   <lemma>také_^(rovněž)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W7</w.rf>
   <form>vybavenost</form>
   <lemma>vybavenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W8</w.rf>
   <form>prostředky</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W9</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W10</w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W11</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W12</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W13</w.rf>
   <form>např.</form>
   <lemma>například_:B_,x</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W14</w.rf>
   <form>stroji</form>
   <lemma>stroj</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W15</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W16</w.rf>
   <form>šetrné</form>
   <lemma>šetrný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W17</w.rf>
   <form>usmrcení</form>
   <lemma>usmrcení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W18</w.rf>
   <form>včelstev</form>
   <lemma>včelstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W19</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W20</w.rf>
   <form>odchytu</form>
   <lemma>odchyt</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W23</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W24</w.rf>
   <form>veterinárních</form>
   <lemma>veterinární</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W25</w.rf>
   <form>předpisů</form>
   <lemma>předpis</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W26</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W27</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W28</w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W29</w.rf>
   <form>nemocí</form>
   <lemma>nemoc_^(choroba)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W30</w.rf>
   <form>nesmí</form>
   <lemma>smět_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W31</w.rf>
   <form>neznámá</form>
   <lemma>neznámá_^(potkat_neznámého_[člověka])_(*1ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W32</w.rf>
   <form>včelstva</form>
   <lemma>včelstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W33</w.rf>
   <form>vracet</form>
   <lemma>vracet_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W34</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s1W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p8s2">
  <m id="m-pardubicky49547.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W1</w.rf>
   <form>Míru</form>
   <lemma>míra_^(měřítko,poměr)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W2</w.rf>
   <form>ohrožení</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W3</w.rf>
   <form>posoudí</form>
   <lemma>posoudit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W5</w.rf>
   <form>převzetí</form>
   <lemma>převzetí_^(př._od_někoho_věc,_zodpovědnost...)_(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W6</w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W7</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W8</w.rf>
   <form>ohlašovatele</form>
   <lemma>ohlašovatel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W9</w.rf>
   <form>operační</form>
   <lemma>operační</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W10</w.rf>
   <form>důstojník</form>
   <lemma>důstojník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W12</w.rf>
   <form>případně</form>
   <lemma>případně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W14</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W15</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W16</w.rf>
   <form>velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W17</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p8s3">
  <m id="m-pardubicky49547.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W3</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W4</w.rf>
   <form>velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W5</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W6</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W7</w.rf>
   <form>průzkumu</form>
   <lemma>průzkum</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W8</w.rf>
   <form>provede</form>
   <lemma>provést</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W9</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W11</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W13</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W14</w.rf>
   <form>zabránilo</form>
   <lemma>zabránit_:W_^(někomu_v_něčem)</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W15</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W16</w.rf>
   <form>ohrožení</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W17</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W19</w.rf>
   <form>vytýčí</form>
   <lemma>vytýčit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W20</w.rf>
   <form>prostor</form>
   <lemma>prostor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W23</w.rf>
   <form>případně</form>
   <lemma>případně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W24</w.rf>
   <form>počká</form>
   <lemma>počkat_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W25</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W26</w.rf>
   <form>odbornou</form>
   <lemma>odborný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W27</w.rf>
   <form>firmu</form>
   <lemma>firma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p8s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p8s3W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p9s1">
  <m id="m-pardubicky49547.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W2</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W3</w.rf>
   <form>jednou</form>
   <lemma>jednou</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W5</w.rf>
   <form>závěr</form>
   <lemma>závěr_^(př._z_jednání,_úvah)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W6</w.rf>
   <form>připojuji</form>
   <lemma>připojovat_:T</lemma>
   <tag>VB-S---1P-AA--1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W7</w.rf>
   <form>radu</form>
   <lemma>rada-1_^(př._dát_někomu_dobrou_radu)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W8</w.rf>
   <form>včelařů</form>
   <lemma>včelař</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W9</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W10</w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W11</w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W13</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W15</w.rf>
   <form>zachovat</form>
   <lemma>zachovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W17</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W18</w.rf>
   <form>výskytu</form>
   <lemma>výskyt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W19</w.rf>
   <form>včelího</form>
   <lemma>včelí</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W20</w.rf>
   <form>roje</form>
   <lemma>roj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p9s2">
  <m id="m-pardubicky49547.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W1</w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W3</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W5</w.rf>
   <form>roj</form>
   <lemma>roj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W6</w.rf>
   <form>včel</form>
   <lemma>včela</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W8</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W10</w.rf>
   <form>usadí</form>
   <lemma>usadit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W12</w.rf>
   <form>nějakém</form>
   <lemma>nějaký</lemma>
   <tag>PZZS6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W13</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W16</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W18</w.rf>
   <form>stromě</form>
   <lemma>strom</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W19</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W20</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W21</w.rf>
   <form>hrozen</form>
   <lemma>hrozen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W22</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W24</w.rf>
   <form>lidé</form>
   <lemma>člověk</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W25</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W26</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W27</w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W28</w.rf>
   <form>ohánět</form>
   <lemma>ohánět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W30</w.rf>
   <form>panikařit</form>
   <lemma>panikařit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s2W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p9s3">
  <m id="m-pardubicky49547.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W2</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W3</w.rf>
   <form>chvíli</form>
   <lemma>chvíle</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W4</w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W5</w.rf>
   <form>neútočí</form>
   <lemma>útočit_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W7</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W8</w.rf>
   <form>hledají</form>
   <lemma>hledat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W9</w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W10</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W12</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W13</w.rf>
   <form>založily</form>
   <lemma>založit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W14</w.rf>
   <form>nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W15</w.rf>
   <form>roj</form>
   <lemma>roj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W17</w.rf>
   <form>lidem</form>
   <lemma>člověk</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W18</w.rf>
   <form>neublíží</form>
   <lemma>ublížit_:W</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s3W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p9s4">
  <m id="m-pardubicky49547.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W1</w.rf>
   <form>Včelí</form>
   <lemma>včelí</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W2</w.rf>
   <form>roj</form>
   <lemma>roj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W4</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W5</w.rf>
   <form>hroznu</form>
   <lemma>hrozen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W6</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W8</w.rf>
   <form>stromě</form>
   <lemma>strom</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W9</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W11</w.rf>
   <form>jiném</form>
   <lemma>jiný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W12</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W13</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W14</w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W15</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W16</w.rf>
   <form>dní</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W17</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W18</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W19</w.rf>
   <form>pár</form>
   <lemma>pár-2</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W20</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W21</w.rf>
   <form>odlétne</form>
   <lemma>odlétnout_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s4W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49547.txt-001-p9s5">
  <m id="m-pardubicky49547.txt-001-p9s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s5W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s5W2</w.rf>
   <form>Česku</form>
   <lemma>Česko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s5W3</w.rf>
   <form>neexistují</form>
   <lemma>existovat_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s5W4</w.rf>
   <form>útočné</form>
   <lemma>útočný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s5W5</w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky49547.txt-001-p9s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49547.txt-001-p9s5W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
