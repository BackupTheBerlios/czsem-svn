<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky49733.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky49733.txt-001-p1s1">
  <m id="m-pardubicky49733.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W2</w.rf>
   <form>areálu</form>
   <lemma>areál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W3</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W4</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W6</w.rf>
   <form>soutěží</form>
   <lemma>soutěžit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W8</w.rf>
   <form>disciplíně</form>
   <lemma>disciplína</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W9</w.rf>
   <form>požárního</form>
   <lemma>požární</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W10</w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W14</w.rf>
   <form>výstupu</form>
   <lemma>výstup</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W16</w.rf>
   <form>cvičnou</form>
   <lemma>cvičný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W17</w.rf>
   <form>věž</form>
   <lemma>věž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W18</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W19</w.rf>
   <form>hákového</form>
   <lemma>hákový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W20</w.rf>
   <form>žebříku</form>
   <lemma>žebřík</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p1s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49733.txt-001-p2s1">
  <m id="m-pardubicky49733.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W1</w.rf>
   <form>Zároveň</form>
   <lemma>zároveň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W2</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W3</w.rf>
   <form>srdečně</form>
   <lemma>srdečně_^(př._pozdrav,_člověk)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W4</w.rf>
   <form>zváni</form>
   <lemma>zvát</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W5</w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W6</w.rf>
   <form>zájemci</form>
   <lemma>zájemce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W8</w.rf>
   <form>řad</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W9</w.rf>
   <form>dospělých</form>
   <lemma>dospělý-2</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W10</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W11</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W12</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W13</w.rf>
   <form>prohlídce</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W14</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W16</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W18</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W19</w.rf>
   <form>stanici</form>
   <lemma>stanice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W21</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W22</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W23</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W24</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W25</w.rf>
   <form>uskuteční</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W26</w.rf>
   <form>Den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W27</w.rf>
   <form>otevřených</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W28</w.rf>
   <form>dveří</form>
   <lemma>dveře</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p2s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49733.txt-001-p3s1">
  <m id="m-pardubicky49733.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W2</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W3</w.rf>
   <form>Orlická</form>
   <lemma>Orlický_;G</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W4</w.rf>
   <form>věž</form>
   <lemma>věž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W5</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W7</w.rf>
   <form>Den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W8</w.rf>
   <form>otevřených</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W9</w.rf>
   <form>dveří</form>
   <lemma>dveře</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W10</w.rf>
   <form>začíná</form>
   <lemma>začínat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W12</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W13</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p3s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky49733.txt-001-p4s1">
  <m id="m-pardubicky49733.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p4s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p4s1W2</w.rf>
   <form>setkání</form>
   <lemma>setkání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p4s1W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p4s1W4</w.rf>
   <form>Vámi</form>
   <lemma>ty</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p4s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky49733.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky49733.txt-001-p4s1W6</w.rf>
   <form>těší</form>
   <lemma>těšit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
 </s>
</mdata>
