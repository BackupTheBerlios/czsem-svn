<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky47791.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky47791.txt-001-p1s1">
  <m id="m-pardubicky47791.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W1</w.rf>
   <form>Padesát</form>
   <lemma>padesát`50</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W2</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W4</w.rf>
   <form>řad</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W5</w.rf>
   <form>profesionálů</form>
   <lemma>profesionál</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W7</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W9</w.rf>
   <form>dobrovolníků</form>
   <lemma>dobrovolník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W11</w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W12</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W13</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W16</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W17</w.rf>
   <form>sjelo</form>
   <lemma>sjet</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W19</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W20</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W21</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W23</w.rf>
   <form>přesněji</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W24</w.rf>
   <form>řečeno</form>
   <lemma>říci</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W27</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W28</w.rf>
   <form>chatě</form>
   <lemma>chata</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W29</w.rf>
   <form>Hvězda</form>
   <lemma>hvězda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W30</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W31</w.rf>
   <form>Andrlův</form>
   <lemma>Andrlův</lemma>
   <tag>AUIS4M---------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W32</w.rf>
   <form>Chlum</form>
   <lemma>Chlum_;G_;S</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s1W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p1s2">
  <m id="m-pardubicky47791.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W1</w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W3</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W4</w.rf>
   <form>konal</form>
   <lemma>konat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W5</w.rf>
   <form>nultý</form>
   <lemma>nultý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W6</w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W7</w.rf>
   <form>nejnáročnější</form>
   <lemma>náročný</lemma>
   <tag>AAFS2----3A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W8</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W9</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W12</w.rf>
   <form>nejtvrdší</form>
   <lemma>tvrdý</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W13</w.rf>
   <form>hasič</form>
   <lemma>hasič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W14</w.rf>
   <form>přežívá</form>
   <lemma>přežívat_:T_^(*3t)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p1s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p2s1">
  <m id="m-pardubicky47791.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W1</w.rf>
   <form>Účastníci</form>
   <lemma>účastník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W2</w.rf>
   <form>nejnáročnější</form>
   <lemma>náročný</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W3</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W4</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W5</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W6</w.rf>
   <form>startu</form>
   <lemma>start</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W7</w.rf>
   <form>uchopit</form>
   <lemma>uchopit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W8</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W9</w.rf>
   <form>nezavodněná</form>
   <lemma>zavodněný_^(*3it)</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W10</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W11</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W12</w.rf>
   <form>B</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W13</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W14</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W16</w.rf>
   <form>proudnicemi</form>
   <lemma>proudnice</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W18</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W19</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W20</w.rf>
   <form>rozvinout</form>
   <lemma>rozvinout_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W22</w.rf>
   <form>vzdálenost</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W23</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W24</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W26</w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W27</w.rf>
   <form>proudnice</form>
   <lemma>proudnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W28</w.rf>
   <form>odložit</form>
   <lemma>odložit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W29</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W30</w.rf>
   <form>metu</form>
   <lemma>meta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p2s2">
  <m id="m-pardubicky47791.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W1</w.rf>
   <form>Obouručním</form>
   <lemma>obouruční</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W2</w.rf>
   <form>šestikilovým</form>
   <lemma>šestikilový</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W3</w.rf>
   <form>kladivem</form>
   <lemma>kladivo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W4</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W5</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W6</w.rf>
   <form>úderů</form>
   <lemma>úder</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W8</w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W10</w.rf>
   <form>hammer</form>
   <lemma>hammer</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W11</w.rf>
   <form>boxu</form>
   <lemma>box</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W12</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W13</w.rf>
   <form>střídavě</form>
   <lemma>střídavě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W14</w.rf>
   <form>nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W16</w.rf>
   <form>dolů</form>
   <lemma>dolů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p2s3">
  <m id="m-pardubicky47791.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W2</w.rf>
   <form>překonali</form>
   <lemma>překonat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W3</w.rf>
   <form>dvoumetrovou</form>
   <lemma>dvoumetrový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W4</w.rf>
   <form>bariéru</form>
   <lemma>bariéra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W6</w.rf>
   <form>transportovali</form>
   <lemma>transportovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W7</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W8</w.rf>
   <form>čtyřicetimetrové</form>
   <lemma>čtyřicetimetrový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W9</w.rf>
   <form>dráze</form>
   <lemma>dráha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W10</w.rf>
   <form>80</form>
   <lemma>80</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W11</w.rf>
   <form>kg</form>
   <lemma>kg-1`kilogram_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W12</w.rf>
   <form>těžkou</form>
   <lemma>těžký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W13</w.rf>
   <form>figurínu</form>
   <lemma>figurína</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W14</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W15</w.rf>
   <form>úchopem</form>
   <lemma>úchop</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W16</w.rf>
   <form>obouruč</form>
   <lemma>obouruč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W17</w.rf>
   <form>zezadu</form>
   <lemma>zezadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W20</w.rf>
   <form>tzv.</form>
   <lemma>takzvaný_:B_,x</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W21</w.rf>
   <form>Raitekův</form>
   <lemma>Raitekův</lemma>
   <tag>AUIS1M---------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W22</w.rf>
   <form>úchop</form>
   <lemma>úchop</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W23</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p2s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p2s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p3s1">
  <m id="m-pardubicky47791.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W2</w.rf>
   <form>dalším</form>
   <lemma>další</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W3</w.rf>
   <form>stanovišti</form>
   <lemma>stanoviště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W4</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W6</w.rf>
   <form>uchopit</form>
   <lemma>uchopit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W7</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W8</w.rf>
   <form>20kg</form>
   <lemma>20kg</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W9</w.rf>
   <form>barely</form>
   <lemma>barel</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W11</w.rf>
   <form>přenést</form>
   <lemma>přenést</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W12</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W14</w.rf>
   <form>vzdálenost</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W15</w.rf>
   <form>20m</form>
   <lemma>20m</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W17</w.rf>
   <form>vyznačeného</form>
   <lemma>vyznačený_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W18</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p3s2">
  <m id="m-pardubicky47791.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W2</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W3</w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W4</w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W5</w.rf>
   <form>málo</form>
   <lemma>málo-1_^(málo_+_2._p.,_málo_peněz)</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W7</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W8</w.rf>
   <form>nakonec</form>
   <lemma>nakonec</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W9</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W10</w.rf>
   <form>vyběhnout</form>
   <lemma>vyběhnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W11</w.rf>
   <form>183</form>
   <lemma>183</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W12</w.rf>
   <form>schodů</form>
   <lemma>schod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W13</w.rf>
   <form>rozhledny</form>
   <lemma>rozhledna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W14</w.rf>
   <form>Andrlův</form>
   <lemma>Andrlův</lemma>
   <tag>AUIS4M---------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W15</w.rf>
   <form>Chlum</form>
   <lemma>Chlum_;G_;S</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W17</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W18</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W19</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W20</w.rf>
   <form>představu</form>
   <lemma>představa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W21</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W22</w.rf>
   <form>dvanácté</form>
   <lemma>dvanáctý</lemma>
   <tag>CrNS4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W23</w.rf>
   <form>nadzemní</form>
   <lemma>nadzemní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W24</w.rf>
   <form>podlaží</form>
   <lemma>podlaží</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W26</w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W27</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W28</w.rf>
   <form>nacházel</form>
   <lemma>nacházet_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W29</w.rf>
   <form>cíl</form>
   <lemma>cíl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W30</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W31</w.rf>
   <form>náročné</form>
   <lemma>náročný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W32</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p3s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p3s2W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p4s1">
  <m id="m-pardubicky47791.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W1</w.rf>
   <form>Všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W2</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W3</w.rf>
   <form>zmíněné</form>
   <lemma>zmíněný_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W4</w.rf>
   <form>disciplíny</form>
   <lemma>disciplína</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W5</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W7</w.rf>
   <form>provést</form>
   <lemma>provést</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W9</w.rf>
   <form>těžkém</form>
   <lemma>těžký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W10</w.rf>
   <form>zásahové</form>
   <lemma>zásahový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W11</w.rf>
   <form>obleku</form>
   <lemma>oblek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W13</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W14</w.rf>
   <form>dýchacím</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W15</w.rf>
   <form>přístrojem</form>
   <lemma>přístroj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W17</w.rf>
   <form>zádech</form>
   <lemma>záda</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W19</w.rf>
   <form>maskou</form>
   <lemma>maska</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W21</w.rf>
   <form>obličeji</form>
   <lemma>obličej</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p4s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p5s1">
  <m id="m-pardubicky47791.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W3</w.rf>
   <form>pojata</form>
   <lemma>pojmout</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W4</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W5</w.rf>
   <form>modifikace</form>
   <lemma>modifikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W6</w.rf>
   <form>disciplín</form>
   <lemma>disciplína</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W7</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W9</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W12</w.rf>
   <form>simulaci</form>
   <lemma>simulace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W13</w.rf>
   <form>zásahové</form>
   <lemma>zásahový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W14</w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W16</w.rf>
   <form>ochranném</form>
   <lemma>ochranný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W17</w.rf>
   <form>oděvu</form>
   <lemma>oděv</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W18</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W19</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W20</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W21</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W22</w.rf>
   <form>izolačního</form>
   <lemma>izolační</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W23</w.rf>
   <form>vzduchového</form>
   <lemma>vzduchový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W24</w.rf>
   <form>dýchacího</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W25</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p5s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p6s1">
  <m id="m-pardubicky47791.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W2</w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W3</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W4</w.rf>
   <form>nejlepší</form>
   <lemma>dobrý</lemma>
   <tag>AAFP1----3A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W6</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W7</w.rf>
   <form>nejtvrdší</form>
   <lemma>tvrdý</lemma>
   <tag>AAFP1----3A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W8</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p6s1W9</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p7s1">
  <m id="m-pardubicky47791.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W1</w.rf>
   <form>Kategorie</form>
   <lemma>kategorie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W2</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W5</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W6</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W7</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W9</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W12</w.rf>
   <form>Zdeněk</form>
   <lemma>Zdeněk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W13</w.rf>
   <form>Koutník</form>
   <lemma>Koutník_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W16</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W17</w.rf>
   <form>Praha2</form>
   <lemma>Praha2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W19</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W22</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W23</w.rf>
   <form>Teslík</form>
   <lemma>Teslík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W26</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W27</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W28</w.rf>
   <form>kraje3</form>
   <lemma>kraje3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W30</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W31</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W32</w.rf>
   <form>Štěpán</form>
   <lemma>Štěpán_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W33</w.rf>
   <form>Heger</form>
   <lemma>Heger_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W34</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W35</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W36</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W37</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W38</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W39</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W40</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W41</w.rf>
   <form>ÚO</form>
   <lemma>ÚO</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p7s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p7s1W42</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p8s1">
  <m id="m-pardubicky47791.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W1</w.rf>
   <form>Kategorie</form>
   <lemma>kategorie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W2</w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W4</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W5</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W6</w.rf>
   <form>let1</form>
   <lemma>let1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W8</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W11</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W12</w.rf>
   <form>Čermák</form>
   <lemma>Čermák_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W15</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W16</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W17</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W20</w.rf>
   <form>ÚO</form>
   <lemma>Úo</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W21</w.rf>
   <form>Svitavy2</form>
   <lemma>Svitavy2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W23</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W24</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W26</w.rf>
   <form>Vladimír</form>
   <lemma>Vladimír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W27</w.rf>
   <form>Vysocký</form>
   <lemma>Vysocký_;S</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W28</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W29</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W30</w.rf>
   <form>HZS</form>
   <lemma>HZS-1_:B_;K_^(Hasičský_záchranný_sbor)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W31</w.rf>
   <form>Moravskoslezského</form>
   <lemma>moravskoslezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p8s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p8s1W32</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky47791.txt-001-p9s1">
  <m id="m-pardubicky47791.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W1</w.rf>
   <form>Kategorie</form>
   <lemma>kategorie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W2</w.rf>
   <form>dobrovolných</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W5</w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W6</w.rf>
   <form>let1</form>
   <lemma>let1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W8</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W11</w.rf>
   <form>Lukáš</form>
   <lemma>Lukáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W12</w.rf>
   <form>Novák</form>
   <lemma>Novák_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W15</w.rf>
   <form>SDH</form>
   <lemma>Sdh</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W16</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W17</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W18</w.rf>
   <form>Orlicí2</form>
   <lemma>Orlicí2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W20</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W23</w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W24</w.rf>
   <form>Mikulecký</form>
   <lemma>Mikulecký_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W27</w.rf>
   <form>SDH</form>
   <lemma>SDH</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W28</w.rf>
   <form>Sloupnice3</form>
   <lemma>Sloupnice3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W30</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W31</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W32</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W33</w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W34</w.rf>
   <form>Bauer</form>
   <lemma>Bauer_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W35</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W36</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W37</w.rf>
   <form>SDH</form>
   <lemma>SDH</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-pardubicky47791.txt-001-p9s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47791.txt-001-p9s1W38</w.rf>
   <form>Sloupnice</form>
   <lemma>Sloupnice_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
</mdata>
