<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky47719.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky47719.txt-001-p1s1">
  <m id="m-pardubicky47719.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W1</w.rf>
   <form>Nejlépe</form>
   <lemma>dobře</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W2</w.rf>
   <form>fyzicky</form>
   <lemma>fyzicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W3</w.rf>
   <form>vybavení</form>
   <lemma>vybavený_^(*3it)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W7</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W8</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W10</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W11</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W13</w.rf>
   <form>chaty</form>
   <lemma>chata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W14</w.rf>
   <form>Hvězda</form>
   <lemma>hvězda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W16</w.rf>
   <form>Andrlově</form>
   <lemma>Andrlův</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W17</w.rf>
   <form>Chlumu</form>
   <lemma>Chlum_;G_;S</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W19</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W20</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W21</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W22</w.rf>
   <form>přesvědčí</form>
   <lemma>přesvědčit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W24</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W25</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W26</w.rf>
   <form>hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W27</w.rf>
   <form>lidských</form>
   <lemma>lidský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W28</w.rf>
   <form>možností</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p1s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47719.txt-001-p2s1">
  <m id="m-pardubicky47719.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W1</w.rf>
   <form>Účastníci</form>
   <lemma>účastník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W2</w.rf>
   <form>nejnáročnější</form>
   <lemma>náročný</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W3</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W4</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W5</w.rf>
   <form>startu</form>
   <lemma>start</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W6</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W8</w.rf>
   <form>9.45</form>
   <form_change>num_normalization</form_change>
   <lemma>9.45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W9</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W11</w.rf>
   <form>uchopí</form>
   <lemma>uchopit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W12</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W13</w.rf>
   <form>nezavodněná</form>
   <lemma>zavodněný_^(*3it)</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W14</w.rf>
   <form>vedení</form>
   <lemma>vedení</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W15</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W16</w.rf>
   <form>B</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W17</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W18</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W19</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W20</w.rf>
   <form>proudnicemi</form>
   <lemma>proudnice</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W22</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W23</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W24</w.rf>
   <form>rozvinou</form>
   <lemma>rozvinout_:T_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W25</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W26</w.rf>
   <form>vzdálenost</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W27</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W28</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W30</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W31</w.rf>
   <form>proudnice</form>
   <lemma>proudnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W32</w.rf>
   <form>odloží</form>
   <lemma>odložit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W33</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W34</w.rf>
   <form>metu</form>
   <lemma>meta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W35</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W36</w.rf>
   <form>obouručním</form>
   <lemma>obouruční</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W37</w.rf>
   <form>kladivem</form>
   <lemma>kladivo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W38</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W39</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W40</w.rf>
   <form>kg</form>
   <lemma>kg-1`kilogram_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W41</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W42</w.rf>
   <form>provedou</form>
   <lemma>provést</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W43</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W44</w.rf>
   <form>úderů</form>
   <lemma>úder</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W45</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W46</w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W47</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W48</w.rf>
   <form>hammer</form>
   <lemma>hammer</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W49</w.rf>
   <form>boxu</form>
   <lemma>box</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W50</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W51</w.rf>
   <form>střídavě</form>
   <lemma>střídavě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W52</w.rf>
   <form>nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W53</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W54</w.rf>
   <form>dolů</form>
   <lemma>dolů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s1W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s1W55</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47719.txt-001-p2s2">
  <m id="m-pardubicky47719.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W2</w.rf>
   <form>překonají</form>
   <lemma>překonat_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W3</w.rf>
   <form>dvoumetrovou</form>
   <lemma>dvoumetrový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W4</w.rf>
   <form>bariéru</form>
   <lemma>bariéra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W6</w.rf>
   <form>transportují</form>
   <lemma>transportovat_:T_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W7</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W8</w.rf>
   <form>čtyřicetimetrové</form>
   <lemma>čtyřicetimetrový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W9</w.rf>
   <form>dráze</form>
   <lemma>dráha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W10</w.rf>
   <form>80</form>
   <lemma>80</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W11</w.rf>
   <form>kg</form>
   <lemma>kg-1`kilogram_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W12</w.rf>
   <form>těžkou</form>
   <lemma>těžký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W13</w.rf>
   <form>figurínu</form>
   <lemma>figurína</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W14</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W15</w.rf>
   <form>úchopem</form>
   <lemma>úchop</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W16</w.rf>
   <form>obouruč</form>
   <lemma>obouruč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W17</w.rf>
   <form>zezadu</form>
   <lemma>zezadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W20</w.rf>
   <form>tzv.</form>
   <lemma>takzvaný_:B_,x</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W21</w.rf>
   <form>Raitekův</form>
   <lemma>Raitekův</lemma>
   <tag>AUIS1M---------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W22</w.rf>
   <form>úchop</form>
   <lemma>úchop</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W23</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47719.txt-001-p2s3">
  <m id="m-pardubicky47719.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W2</w.rf>
   <form>dalším</form>
   <lemma>další</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W3</w.rf>
   <form>stanovišti</form>
   <lemma>stanoviště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W4</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W6</w.rf>
   <form>uchopit</form>
   <lemma>uchopit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W7</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W8</w.rf>
   <form>20kg</form>
   <lemma>20kg</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W9</w.rf>
   <form>barely</form>
   <lemma>barel</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W11</w.rf>
   <form>přenést</form>
   <lemma>přenést</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W12</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W14</w.rf>
   <form>vzdálenost</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W15</w.rf>
   <form>20m</form>
   <lemma>20m</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W17</w.rf>
   <form>vyznačeného</form>
   <lemma>vyznačený_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W18</w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s3W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47719.txt-001-p2s4">
  <m id="m-pardubicky47719.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W2</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W3</w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W4</w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W5</w.rf>
   <form>málo</form>
   <lemma>málo-1_^(málo_+_2._p.,_málo_peněz)</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W7</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W8</w.rf>
   <form>nakonec</form>
   <lemma>nakonec</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W9</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W10</w.rf>
   <form>vyběhnout</form>
   <lemma>vyběhnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W11</w.rf>
   <form>183</form>
   <lemma>183</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W12</w.rf>
   <form>schodů</form>
   <lemma>schod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W13</w.rf>
   <form>rozhledny</form>
   <lemma>rozhledna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W14</w.rf>
   <form>Andrlův</form>
   <lemma>Andrlův</lemma>
   <tag>AUIS4M---------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W15</w.rf>
   <form>Chlum</form>
   <lemma>Chlum_;G_;S</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W16</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W17</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W18</w.rf>
   <form>12.NP</form>
   <lemma>12.NP</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W19</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W21</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W22</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W23</w.rf>
   <form>nachází</form>
   <lemma>nacházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W24</w.rf>
   <form>cíl</form>
   <lemma>cíl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W25</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W26</w.rf>
   <form>náročné</form>
   <lemma>náročný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W27</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p2s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p2s4W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47719.txt-001-p3s1">
  <m id="m-pardubicky47719.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W1</w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W2</w.rf>
   <form>vše</form>
   <lemma>všechen</lemma>
   <tag>PLNS1---------1</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W4</w.rf>
   <form>těžkém</form>
   <lemma>těžký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W5</w.rf>
   <form>zásahové</form>
   <lemma>zásahový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W6</w.rf>
   <form>obleku</form>
   <lemma>oblek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W8</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W9</w.rf>
   <form>dýchacím</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W10</w.rf>
   <form>přístrojem</form>
   <lemma>přístroj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W12</w.rf>
   <form>zádech</form>
   <lemma>záda</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W14</w.rf>
   <form>maskou</form>
   <lemma>maska</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W16</w.rf>
   <form>obličeji</form>
   <lemma>obličej</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p3s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47719.txt-001-p4s1">
  <m id="m-pardubicky47719.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W1</w.rf>
   <form>Soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W3</w.rf>
   <form>pojata</form>
   <lemma>pojmout</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W4</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W5</w.rf>
   <form>modifikace</form>
   <lemma>modifikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W6</w.rf>
   <form>disciplín</form>
   <lemma>disciplína</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W7</w.rf>
   <form>TFA</form>
   <lemma>Tfa</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W9</w.rf>
   <form>jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W12</w.rf>
   <form>simulaci</form>
   <lemma>simulace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W13</w.rf>
   <form>zásahové</form>
   <lemma>zásahový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W14</w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W16</w.rf>
   <form>ochranném</form>
   <lemma>ochranný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W17</w.rf>
   <form>oděvu</form>
   <lemma>oděv</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W18</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W19</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W20</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W21</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W22</w.rf>
   <form>izolačního</form>
   <lemma>izolační</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W23</w.rf>
   <form>vzduchového</form>
   <lemma>vzduchový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W24</w.rf>
   <form>dýchacího</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W25</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W26</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p4s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47719.txt-001-p5s1">
  <m id="m-pardubicky47719.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W1</w.rf>
   <form>Trať</form>
   <lemma>trať</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W3</w.rf>
   <form>postavena</form>
   <lemma>postavit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W4</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W5</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClMS4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W6</w.rf>
   <form>soutěžícího</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGMS4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W8</w.rf>
   <form>soutěžící</form>
   <lemma>soutěžící_^(*3it)</lemma>
   <tag>AGMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W9</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W10</w.rf>
   <form>startovat</form>
   <lemma>startovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W11</w.rf>
   <form>postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W13</w.rf>
   <form>pětiminutových</form>
   <lemma>pětiminutový</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W14</w.rf>
   <form>intervalech</form>
   <lemma>interval</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p5s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47719.txt-001-p6s1">
  <m id="m-pardubicky47719.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W1</w.rf>
   <form>Přijďte</form>
   <lemma>přijít</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W3</w.rf>
   <form>podívat</form>
   <lemma>podívat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W5</w.rf>
   <form>povzbudit</form>
   <lemma>povzbudit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W6</w.rf>
   <form>záchranáře</form>
   <lemma>záchranář</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W8</w.rf>
   <form>nejtěžší</form>
   <lemma>těžký</lemma>
   <tag>AAFS6----3A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W9</w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47719.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47719.txt-001-p6s1W10</w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
