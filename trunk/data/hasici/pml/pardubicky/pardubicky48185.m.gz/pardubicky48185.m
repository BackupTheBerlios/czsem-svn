<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky48185.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky48185.txt-001-p1s1">
  <m id="m-pardubicky48185.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W4</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W5</w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W7</w.rf>
   <form>odpad</form>
   <lemma>odpad</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W8</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W9</w.rf>
   <form>Prachovic</form>
   <lemma>Prachovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W11</w.rf>
   <form>Chrudimsku</form>
   <lemma>Chrudimsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p1s2">
  <m id="m-pardubicky48185.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W2</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W3</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W5</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W7</w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W8</w.rf>
   <form>hala</form>
   <lemma>hala</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W10</w.rf>
   <form>rozměrech</form>
   <lemma>rozměr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W11</w.rf>
   <form>20x12x12</form>
   <lemma>20x12x12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W12</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W14</w.rf>
   <form>plamenech</form>
   <lemma>plamen</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p1s3">
  <m id="m-pardubicky48185.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W1</w.rf>
   <form>Velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W2</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W5</w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W6</w.rf>
   <form>nechal</form>
   <lemma>nechat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W7</w.rf>
   <form>přivolat</form>
   <lemma>přivolat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W8</w.rf>
   <form>dobrovolné</form>
   <lemma>dobrovolný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W9</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p1s4">
  <m id="m-pardubicky48185.txt-001-p1s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W1</w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W2</w.rf>
   <form>plameny</form>
   <lemma>plamen</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W3</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W4</w.rf>
   <form>bojovalo</form>
   <lemma>bojovat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W5</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W6</w.rf>
   <form>devět</form>
   <lemma>devět`9</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W7</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W8</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p1s5">
  <m id="m-pardubicky48185.txt-001-p1s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W2</w.rf>
   <form>dostupných</form>
   <lemma>dostupný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W3</w.rf>
   <form>informací</form>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W6</w.rf>
   <form>hale</form>
   <lemma>hala</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W7</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W8</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W9</w.rf>
   <form>sto</form>
   <lemma>sto-2`100</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W10</w.rf>
   <form>tun</form>
   <lemma>tuna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W11</w.rf>
   <form>komunálního</form>
   <lemma>komunální</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W12</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s5W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p1s6">
  <m id="m-pardubicky48185.txt-001-p1s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W2</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W3</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W4</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W5</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W6</w.rf>
   <form>použít</form>
   <lemma>použít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W7</w.rf>
   <form>dýchací</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W8</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W10</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W12</w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W13</w.rf>
   <form>vycházel</form>
   <lemma>vycházet_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W14</w.rf>
   <form>hustý</form>
   <lemma>hustý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W15</w.rf>
   <form>černý</form>
   <lemma>černý-1_^(barva)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W16</w.rf>
   <form>dým</form>
   <lemma>dým</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W19</w.rf>
   <form>ovzduší</form>
   <lemma>ovzduší</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W20</w.rf>
   <form>unikaly</form>
   <lemma>unikat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W21</w.rf>
   <form>jedovaté</form>
   <lemma>jedovatý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W22</w.rf>
   <form>látky</form>
   <lemma>látka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s6W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p1s7">
  <m id="m-pardubicky48185.txt-001-p1s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W4</w.rf>
   <form>povolán</form>
   <lemma>povolat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W5</w.rf>
   <form>pracovník</form>
   <lemma>pracovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W6</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W7</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W9</w.rf>
   <form>Chrudimi</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W11</w.rf>
   <form>dostavila</form>
   <lemma>dostavit_:W_^(se)_(na_dané_místo)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W13</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W14</w.rf>
   <form>Inspekce</form>
   <lemma>inspekce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W15</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W16</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W17</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W18</w.rf>
   <form>Hradce</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W19</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p1s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p1s7W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p2s1">
  <m id="m-pardubicky48185.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W1</w.rf>
   <form>Hasičům</form>
   <lemma>hasič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W3</w.rf>
   <form>podařilo</form>
   <lemma>podařit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W4</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W5</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W6</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W7</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W9</w.rf>
   <form>16.05</form>
   <form_change>num_normalization</form_change>
   <lemma>16.05</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W10</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W13</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W14</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W15</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W16</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W18</w.rf>
   <form>18.30</form>
   <form_change>num_normalization</form_change>
   <lemma>18.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W19</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W20</w.rf>
   <form>podílelo</form>
   <lemma>podílet_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W21</w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W22</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W23</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s1W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p2s2">
  <m id="m-pardubicky48185.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W2</w.rf>
   <form>musejí</form>
   <lemma>muset</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W3</w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W4</w.rf>
   <form>pracovat</form>
   <lemma>pracovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W5</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W6</w.rf>
   <form>opatrně</form>
   <lemma>opatrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W8</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W9</w.rf>
   <form>kovová</form>
   <lemma>kovový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W10</w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W13</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W14</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W15</w.rf>
   <form>hala</form>
   <lemma>hala</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W16</w.rf>
   <form>vyrobena</form>
   <lemma>vyrobit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W18</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W19</w.rf>
   <form>požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W20</w.rf>
   <form>natolik</form>
   <lemma>natolik</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W21</w.rf>
   <form>poničena</form>
   <lemma>poničit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W23</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W24</w.rf>
   <form>hrozí</form>
   <lemma>hrozit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W25</w.rf>
   <form>její</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSZS1FS3-------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W26</w.rf>
   <form>zřícení</form>
   <lemma>zřícení_^(*4tit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p2s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p2s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p3s1">
  <m id="m-pardubicky48185.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W4</w.rf>
   <form>zničeny</form>
   <lemma>zničit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W5</w.rf>
   <form>stroje</form>
   <lemma>stroj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W7</w.rf>
   <form>drcení</form>
   <lemma>drcení_^(*4tit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W8</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W10</w.rf>
   <form>veškeré</form>
   <lemma>veškerý</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W11</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p3s2">
  <m id="m-pardubicky48185.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W1</w.rf>
   <form>Velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W2</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W3</w.rf>
   <form>nechal</form>
   <lemma>nechat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W4</w.rf>
   <form>zřídit</form>
   <lemma>zřídit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W5</w.rf>
   <form>kyvadlovou</form>
   <lemma>kyvadlový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W6</w.rf>
   <form>dopravu</form>
   <lemma>doprava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W7</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W9</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W10</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p3s3">
  <m id="m-pardubicky48185.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W1</w.rf>
   <form>Kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W2</w.rf>
   <form>kyvadlové</form>
   <lemma>kyvadlový</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W3</w.rf>
   <form>dopravě</form>
   <lemma>doprava</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W4</w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W5</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W6</w.rf>
   <form>uzavřena</form>
   <lemma>uzavřít</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W7</w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W9</w.rf>
   <form>Vápenného</form>
   <lemma>vápenný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W10</w.rf>
   <form>Podolu</form>
   <lemma>Podol_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W12</w.rf>
   <form>Prachovic</form>
   <lemma>Prachovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p3s4">
  <m id="m-pardubicky48185.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W2</w.rf>
   <form>současné</form>
   <lemma>současný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W3</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W4</w.rf>
   <form>vyváží</form>
   <lemma>vyvážet_:T_^(zboží_přes_hranice)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W5</w.rf>
   <form>bagr</form>
   <lemma>bagr</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W6</w.rf>
   <form>odpadky</form>
   <lemma>odpadek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W8</w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W11</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W12</w.rf>
   <form>řádně</form>
   <lemma>řádně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W13</w.rf>
   <form>prolévají</form>
   <lemma>prolévat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W14</w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W16</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W17</w.rf>
   <form>nedošlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W18</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W19</w.rf>
   <form>opětovnému</form>
   <lemma>opětovný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W20</w.rf>
   <form>rozhoření</form>
   <lemma>rozhoření_^(*2t)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p3s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p3s4W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p4s1">
  <m id="m-pardubicky48185.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W1</w.rf>
   <form>Hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W2</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W3</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W4</w.rf>
   <form>likvidovat</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W5</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W6</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W7</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W9</w.rf>
   <form>zítřejších</form>
   <lemma>zítřejší</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W10</w.rf>
   <form>ranních</form>
   <lemma>ranní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W11</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s1W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p4s2">
  <m id="m-pardubicky48185.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s2W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s2W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s2W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s2W5</w.rf>
   <form>předmětem</form>
   <lemma>předmět</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s2W6</w.rf>
   <form>dalšího</form>
   <lemma>další</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s2W7</w.rf>
   <form>vyšetřování</form>
   <lemma>vyšetřování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48185.txt-001-p4s3">
  <m id="m-pardubicky48185.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W3</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W4</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W6</w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W7</w.rf>
   <form>milionů</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W8</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48185.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48185.txt-001-p4s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
