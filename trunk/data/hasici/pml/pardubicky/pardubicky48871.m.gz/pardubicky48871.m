<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky48871.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky48871.txt-001-p1s1">
  <m id="m-pardubicky48871.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p1s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p1s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p1s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p1s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p1s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p1s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p1s1W7</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p2s1">
  <m id="m-pardubicky48871.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W7</w.rf>
   <form>11.20</form>
   <form_change>num_normalization</form_change>
   <lemma>11.20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W12</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W13</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W14</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W15</w.rf>
   <form>Vendolí</form>
   <lemma>Vendolí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p2s2">
  <m id="m-pardubicky48871.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W4</w.rf>
   <form>nehodu</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W5</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W6</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W7</w.rf>
   <form>Seat</form>
   <lemma>Seat-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W8</w.rf>
   <form>Toledo</form>
   <lemma>Toledo-2_;R_^(vozidlo)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W10</w.rf>
   <form>Toyota</form>
   <lemma>Toyota-3_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W11</w.rf>
   <form>Yaris</form>
   <lemma>Yaris</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p2s3">
  <m id="m-pardubicky48871.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s3W1</w.rf>
   <form>Záchranná</form>
   <lemma>záchranný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s3W2</w.rf>
   <form>služba</form>
   <lemma>služba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s3W3</w.rf>
   <form>odvezla</form>
   <lemma>odvézt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s3W4</w.rf>
   <form>zraněné</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s3W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s3W6</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p2s4">
  <m id="m-pardubicky48871.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W2</w.rf>
   <form>pomohli</form>
   <lemma>pomoci</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W3</w.rf>
   <form>naložit</form>
   <lemma>naložit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W4</w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W6</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W7</w.rf>
   <form>odtahové</form>
   <lemma>odtahový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W8</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W10</w.rf>
   <form>druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W11</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W12</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W13</w.rf>
   <form>jeřábu</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W14</w.rf>
   <form>vyprostili</form>
   <lemma>vyprostit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p2s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p3s1">
  <m id="m-pardubicky48871.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W2</w.rf>
   <form>21.13</form>
   <form_change>num_normalization</form_change>
   <lemma>21.13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W3</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W4</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W5</w.rf>
   <form>svitavští</form>
   <lemma>svitavský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W7</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W8</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W9</w.rf>
   <form>nehodě</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W10</w.rf>
   <form>automobilu</form>
   <lemma>automobil</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W12</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W13</w.rf>
   <form>skončil</form>
   <lemma>skončit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W15</w.rf>
   <form>Třebařově</form>
   <lemma>Třebařov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W17</w.rf>
   <form>potoce</form>
   <lemma>potok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W20</w.rf>
   <form>střeše</form>
   <lemma>střecha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s1W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p3s2">
  <m id="m-pardubicky48871.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W1</w.rf>
   <form>Osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W3</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W4</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W5</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W6</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W7</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W8</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W9</w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W10</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p3s3">
  <m id="m-pardubicky48871.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W2</w.rf>
   <form>vytáhli</form>
   <lemma>vytáhnout</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W3</w.rf>
   <form>vozidlo</form>
   <lemma>vozidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W5</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W7</w.rf>
   <form>postavili</form>
   <lemma>postavit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W8</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W9</w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W11</w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p3s4">
  <m id="m-pardubicky48871.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s4W1</w.rf>
   <form>Uniklé</form>
   <lemma>uniklý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s4W2</w.rf>
   <form>provozní</form>
   <lemma>provozní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s4W3</w.rf>
   <form>náplně</form>
   <lemma>náplň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s4W4</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s4W5</w.rf>
   <form>zasypány</form>
   <lemma>zasypat_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s4W6</w.rf>
   <form>sorbentem</form>
   <lemma>sorbent</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p3s5">
  <m id="m-pardubicky48871.txt-001-p3s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W1</w.rf>
   <form>Odstraňování</form>
   <lemma>odstraňování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W2</w.rf>
   <form>následků</form>
   <lemma>následek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W3</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W4</w.rf>
   <form>trvalo</form>
   <lemma>trvat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W5</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W7</w.rf>
   <form>23.08</form>
   <form_change>num_normalization</form_change>
   <lemma>23.08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p3s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p3s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p4s1">
  <m id="m-pardubicky48871.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W2</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W7</w.rf>
   <form>9.36</form>
   <form_change>num_normalization</form_change>
   <lemma>9.36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W12</w.rf>
   <form>Poličky</form>
   <lemma>polička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W14</w.rf>
   <form>Svitav</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W15</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W16</w.rf>
   <form>kolize</form>
   <lemma>kolize</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W17</w.rf>
   <form>kamionu</form>
   <lemma>kamión</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W19</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W20</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W21</w.rf>
   <form>jízdu</form>
   <lemma>jízda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W22</w.rf>
   <form>skončil</form>
   <lemma>skončit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W23</w.rf>
   <form>poblíž</form>
   <lemma>poblíž-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W24</w.rf>
   <form>železniční</form>
   <lemma>železniční_,a</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W25</w.rf>
   <form>tratě</form>
   <lemma>trať</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W26</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W27</w.rf>
   <form>Borové</form>
   <lemma>bórový-2_;H</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p4s2">
  <m id="m-pardubicky48871.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W1</w.rf>
   <form>Kamion</form>
   <lemma>kamión</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W3</w.rf>
   <form>kterému</form>
   <lemma>který</lemma>
   <tag>P4ZS3----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W5</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W6</w.rf>
   <form>kolizi</form>
   <lemma>kolize</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W7</w.rf>
   <form>protrhla</form>
   <lemma>protrhnout_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W8</w.rf>
   <form>nádrž</form>
   <lemma>nádrž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W10</w.rf>
   <form>ohrožoval</form>
   <lemma>ohrožovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W11</w.rf>
   <form>železniční</form>
   <lemma>železniční_,a</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W12</w.rf>
   <form>trať</form>
   <lemma>trať</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p4s3">
  <m id="m-pardubicky48871.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W2</w.rf>
   <form>zabránili</form>
   <lemma>zabránit_:W_^(někomu_v_něčem)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W3</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W4</w.rf>
   <form>nafty</form>
   <lemma>nafta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W6</w.rf>
   <form>postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W7</w.rf>
   <form>odčerpali</form>
   <lemma>odčerpat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W8</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W9</w.rf>
   <form>400</form>
   <lemma>400</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W10</w.rf>
   <form>l</form>
   <lemma>l-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W11</w.rf>
   <form>nafty</form>
   <lemma>nafta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W13</w.rf>
   <form>nádrže</form>
   <lemma>nádrž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W14</w.rf>
   <form>kamionu</form>
   <lemma>kamión</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p4s4">
  <m id="m-pardubicky48871.txt-001-p4s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W4</w.rf>
   <form>přivolán</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W6</w.rf>
   <form>hasičský</form>
   <lemma>hasičský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W7</w.rf>
   <form>jeřáb</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W9</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W10</w.rf>
   <form>pomohl</form>
   <lemma>pomoci</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W11</w.rf>
   <form>vyprostit</form>
   <lemma>vyprostit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W12</w.rf>
   <form>kamion</form>
   <lemma>kamión</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p4s5">
  <m id="m-pardubicky48871.txt-001-p4s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W1</w.rf>
   <form>Odstraňování</form>
   <lemma>odstraňování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W2</w.rf>
   <form>následků</form>
   <lemma>následek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W3</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W4</w.rf>
   <form>trvalo</form>
   <lemma>trvat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W5</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W7</w.rf>
   <form>14.58</form>
   <form_change>num_normalization</form_change>
   <lemma>14.58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p4s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p4s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p5s1">
  <m id="m-pardubicky48871.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p5s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p5s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p5s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p5s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p5s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p5s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p5s1W7</w.rf>
   <form>Chrudim</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p6s1">
  <m id="m-pardubicky48871.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W7</w.rf>
   <form>14.48</form>
   <form_change>num_normalization</form_change>
   <lemma>14.48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W12</w.rf>
   <form>Hlinska</form>
   <lemma>Hlinsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W13</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W14</w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W15</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W16</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W17</w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p6s2">
  <m id="m-pardubicky48871.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W1</w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W2</w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W5</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W6</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W8</w.rf>
   <form>péči</form>
   <lemma>péče</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W9</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W10</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W11</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p6s3">
  <m id="m-pardubicky48871.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W2</w.rf>
   <form>zajistili</form>
   <lemma>zajistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W3</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W4</w.rf>
   <form>nehody</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W6</w.rf>
   <form>zabezpečili</form>
   <lemma>zabezpečit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W7</w.rf>
   <form>vozidla</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W8</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W9</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W11</w.rf>
   <form>zamezili</form>
   <lemma>zamezit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W12</w.rf>
   <form>úniku</form>
   <lemma>únik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W13</w.rf>
   <form>provozních</form>
   <lemma>provozní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W14</w.rf>
   <form>náplní</form>
   <lemma>náplň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p6s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p6s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p7s1">
  <m id="m-pardubicky48871.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W2</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W7</w.rf>
   <form>7.45</form>
   <form_change>num_normalization</form_change>
   <lemma>7.45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W9</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W10</w.rf>
   <form>nasavrčtí</form>
   <lemma>nasavrcký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W11</w.rf>
   <form>dobrovolní</form>
   <lemma>dobrovolný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W12</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W13</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W15</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W16</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W17</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W18</w.rf>
   <form>komunikaci</form>
   <lemma>komunikace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W20</w.rf>
   <form>Nasavrkách</form>
   <lemma>Nasavrky_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W22</w.rf>
   <form>tvořil</form>
   <lemma>tvořit_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W23</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W24</w.rf>
   <form>překážku</form>
   <lemma>překážka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W25</w.rf>
   <form>silničního</form>
   <lemma>silniční</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W26</w.rf>
   <form>provozu</form>
   <lemma>provoz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p7s2">
  <m id="m-pardubicky48871.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W2</w.rf>
   <form>7.59</form>
   <form_change>num_normalization</form_change>
   <lemma>7.59</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W3</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W4</w.rf>
   <form>odstraňovali</form>
   <lemma>odstraňovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W5</w.rf>
   <form>hlinečtí</form>
   <lemma>hlinecký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W7</w.rf>
   <form>strom</form>
   <lemma>strom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W9</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W10</w.rf>
   <form>spadl</form>
   <lemma>spadnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W12</w.rf>
   <form>vozovku</form>
   <lemma>vozovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W14</w.rf>
   <form>Trhové</form>
   <lemma>trhový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W15</w.rf>
   <form>Kamenici</form>
   <lemma>Kamenica_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p7s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p8s1">
  <m id="m-pardubicky48871.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W2</w.rf>
   <form>17.59</form>
   <form_change>num_normalization</form_change>
   <lemma>17.59</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W3</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W4</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W5</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W6</w.rf>
   <form>přivoláni</form>
   <lemma>přivolat_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W8</w.rf>
   <form>bytovce</form>
   <lemma>bytovka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W10</w.rf>
   <form>Chrudimi</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W12</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W13</w.rf>
   <form>mělo</form>
   <lemma>mít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W14</w.rf>
   <form>dojít</form>
   <lemma>dojít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W15</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W16</w.rf>
   <form>výbuchu</form>
   <lemma>výbuch</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W17</w.rf>
   <form>televize</form>
   <lemma>televize</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p8s2">
  <m id="m-pardubicky48871.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W2</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W4</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W5</w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W7</w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W8</w.rf>
   <form>průzkum</form>
   <lemma>průzkum</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W10</w.rf>
   <form>zjistili</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W12</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W13</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W14</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W15</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W16</w.rf>
   <form>technickou</form>
   <lemma>technický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W17</w.rf>
   <form>závadu</form>
   <lemma>závada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W19</w.rf>
   <form>televizoru</form>
   <lemma>televizor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W21</w.rf>
   <form>následný</form>
   <lemma>následný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W22</w.rf>
   <form>výbuch</form>
   <lemma>výbuch</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p8s3">
  <m id="m-pardubicky48871.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s3W1</w.rf>
   <form>Silně</form>
   <lemma>silně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s3W2</w.rf>
   <form>zakouřený</form>
   <lemma>zakouřený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s3W3</w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s3W4</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s3W5</w.rf>
   <form>odvětrali</form>
   <lemma>odvětrat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p8s4">
  <m id="m-pardubicky48871.txt-001-p8s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W1</w.rf>
   <form>Majitel</form>
   <lemma>majitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W2</w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W4</w.rf>
   <form>intoxikován</form>
   <lemma>intoxikovat_:T</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W5</w.rf>
   <form>zplodinami</form>
   <lemma>zplodina</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W6</w.rf>
   <form>hoření</form>
   <lemma>hoření_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W8</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W9</w.rf>
   <form>předán</form>
   <lemma>předat-1_:T_,a_^(příst)</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W11</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W12</w.rf>
   <form>zdravotnické</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W13</w.rf>
   <form>záchranné</form>
   <lemma>záchranný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W14</w.rf>
   <form>službě</form>
   <lemma>služba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p8s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p8s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p9s1">
  <m id="m-pardubicky48871.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W5</w.rf>
   <form>územní</form>
   <lemma>územní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W6</w.rf>
   <form>odbor</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W7</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W8</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p9s1W9</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p10s1">
  <m id="m-pardubicky48871.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W2</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W7</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W12</w.rf>
   <form>Lanškrouna</form>
   <lemma>Lanškroun_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W14</w.rf>
   <form>Tatenic</form>
   <lemma>Tatenice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W15</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W16</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W17</w.rf>
   <form>skládky</form>
   <lemma>skládka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p10s2">
  <m id="m-pardubicky48871.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W1</w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W3</w.rf>
   <form>rozhořela</form>
   <lemma>rozhořet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W5</w.rf>
   <form>Tatenicích</form>
   <lemma>Tatenice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W7</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W10</w.rf>
   <form>rozlohu</form>
   <lemma>rozloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W11</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W12</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W13</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W14</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W15</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p10s3">
  <m id="m-pardubicky48871.txt-001-p10s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s3W1</w.rf>
   <form>Požár</form>
   <lemma>Požár-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s3W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s3W3</w.rf>
   <form>zlikvidovali</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s3W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s3W5</w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s3W6</w.rf>
   <form>nevznikla</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VpQW---XR-NA--1</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p10s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p10s3W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p11s1">
  <m id="m-pardubicky48871.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W2</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W7</w.rf>
   <form>17.57</form>
   <form_change>num_normalization</form_change>
   <lemma>17.57</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W9</w.rf>
   <form>zasahovaly</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W10</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W11</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W12</w.rf>
   <form>hasičské</form>
   <lemma>hasičský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W13</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W14</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W15</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W16</w.rf>
   <form>kolny</form>
   <lemma>kolna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W18</w.rf>
   <form>jež</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJFS1----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W19</w.rf>
   <form>přísluší</form>
   <lemma>příslušet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W20</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W21</w.rf>
   <form>bytovému</form>
   <lemma>bytový</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W22</w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W23</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W24</w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W26</w.rf>
   <form>Chocni</form>
   <lemma>Choceň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p11s2">
  <m id="m-pardubicky48871.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W1</w.rf>
   <form>Požár</form>
   <lemma>Požár-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W3</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W4</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W5</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W7</w.rf>
   <form>18.56</form>
   <form_change>num_normalization</form_change>
   <lemma>18.56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W10</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W11</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W13</w.rf>
   <form>19.19</form>
   <form_change>num_normalization</form_change>
   <lemma>19.19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W14</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p11s3">
  <m id="m-pardubicky48871.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W1</w.rf>
   <form>Škoda</form>
   <lemma>Škoda-1_;K</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W3</w.rf>
   <form>předběžně</form>
   <lemma>předběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W4</w.rf>
   <form>vyčíslena</form>
   <lemma>vyčíslit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W6</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W7</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W8</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p11s4">
  <m id="m-pardubicky48871.txt-001-p11s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W1</w.rf>
   <form>Příčina</form>
   <lemma>příčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W2</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W3</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W5</w.rf>
   <form>předmětem</form>
   <lemma>předmět</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W6</w.rf>
   <form>dalšího</form>
   <lemma>další</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W7</w.rf>
   <form>vyšetřování</form>
   <lemma>vyšetřování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W9</w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W11</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W12</w.rf>
   <form>jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W13</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W14</w.rf>
   <form>nedbalost</form>
   <lemma>nedbalost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W15</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W16</w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W17</w.rf>
   <form>otevřeného</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W18</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W19</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W20</w.rf>
   <form>neznámé</form>
   <lemma>známý-2_^(co_[ne]známe)</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W21</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p11s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p11s4W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p12s1">
  <m id="m-pardubicky48871.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W2</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W4</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W5</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W7</w.rf>
   <form>0.43</form>
   <form_change>num_normalization</form_change>
   <lemma>0.43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W9</w.rf>
   <form>zasahovali</form>
   <lemma>zasahovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W10</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W12</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W13</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W14</w.rf>
   <form>Orlicí</form>
   <lemma>Orlice_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W16</w.rf>
   <form>Českých</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W17</w.rf>
   <form>drah</form>
   <lemma>dráha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W18</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W19</w.rf>
   <form>Třebová</form>
   <lemma>Třebová_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W20</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W21</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W22</w.rf>
   <form>bývalé</form>
   <lemma>bývalý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W23</w.rf>
   <form>Primony</form>
   <lemma>Primona_;K</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W25</w.rf>
   <form>České</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W26</w.rf>
   <form>Třebové</form>
   <lemma>Třebová_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s1W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p12s2">
  <m id="m-pardubicky48871.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W4</w.rf>
   <form>opuštěný</form>
   <lemma>opuštěný_^(*5stit)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W5</w.rf>
   <form>objekt</form>
   <lemma>objekt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W6</w.rf>
   <form>určený</form>
   <lemma>určený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W8</w.rf>
   <form>demolici</form>
   <lemma>demolice</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p12s3">
  <m id="m-pardubicky48871.txt-001-p12s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s3W1</w.rf>
   <form>Požár</form>
   <lemma>požár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s3W3</w.rf>
   <form>beze</form>
   <lemma>bez-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s3W4</w.rf>
   <form>škody</form>
   <lemma>škoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p12s4">
  <m id="m-pardubicky48871.txt-001-p12s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s4W2</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s4W3</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s4W4</w.rf>
   <form>nalezeno</form>
   <lemma>naleznout</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s4W5</w.rf>
   <form>zapálené</form>
   <lemma>zapálený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s4W6</w.rf>
   <form>klubko</form>
   <lemma>klubko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s4W7</w.rf>
   <form>kabelů</form>
   <lemma>kabel</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p12s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p12s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p13s1">
  <m id="m-pardubicky48871.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p13s1W1</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p13s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p13s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p13s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p13s1W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p13s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p13s1W5</w.rf>
   <form>stanice</form>
   <lemma>stanice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p13s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p13s1W6</w.rf>
   <form>Přelouč</form>
   <lemma>Přelouč_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p14s1">
  <m id="m-pardubicky48871.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W2</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W3</w.rf>
   <form>skládky</form>
   <lemma>skládka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W5</w.rf>
   <form>Zdechovic</form>
   <lemma>Zdechovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W6</w.rf>
   <form>vyjíždělo</form>
   <lemma>vyjíždět_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W7</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W9</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W10</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W12</w.rf>
   <form>18.28</form>
   <form_change>num_normalization</form_change>
   <lemma>18.28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W13</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W14</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W15</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W16</w.rf>
   <form>hasičských</form>
   <lemma>hasičský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W17</w.rf>
   <form>jednotek</form>
   <lemma>jednotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p14s2">
  <m id="m-pardubicky48871.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W1</w.rf>
   <form>Jednalo</form>
   <lemma>jednat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W4</w.rf>
   <form>rozlohu</form>
   <lemma>rozloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W5</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W6</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W7</w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W8</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W9</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p14s3">
  <m id="m-pardubicky48871.txt-001-p14s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W2</w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W3</w.rf>
   <form>použít</form>
   <lemma>použít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W4</w.rf>
   <form>dýchací</form>
   <lemma>dýchací_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W5</w.rf>
   <form>přístroje</form>
   <lemma>přístroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W8</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W9</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W11</w.rf>
   <form>podíleli</form>
   <lemma>podílet_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W12</w.rf>
   <form>společně</form>
   <lemma>společně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W13</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W14</w.rf>
   <form>zaměstnanci</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W15</w.rf>
   <form>skládky</form>
   <lemma>skládka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s3W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48871.txt-001-p14s4">
  <m id="m-pardubicky48871.txt-001-p14s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W1</w.rf>
   <form>Požár</form>
   <lemma>Požár-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W2</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W3</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W4</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W5</w.rf>
   <form>kontrolu</form>
   <lemma>kontrola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W7</w.rf>
   <form>19.54</form>
   <form_change>num_normalization</form_change>
   <lemma>19.54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W8</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W10</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W11</w.rf>
   <form>zlikvidován</form>
   <lemma>zlikvidovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W12</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W14</w.rf>
   <form>20.45</form>
   <form_change>num_normalization</form_change>
   <lemma>20.45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W15</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48871.txt-001-p14s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48871.txt-001-p14s4W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
