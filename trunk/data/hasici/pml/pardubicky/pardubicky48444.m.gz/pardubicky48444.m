<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky48444.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky48444.txt-001-p1s1">
  <m id="m-pardubicky48444.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W2</w.rf>
   <form>Vybrali</form>
   <lemma>vybrat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W3</w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W4</w.rf>
   <form>praktické</form>
   <lemma>praktický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W5</w.rf>
   <form>provedení</form>
   <lemma>provedení_^(*5ést)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W6</w.rf>
   <form>záchranných</form>
   <lemma>záchranný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W7</w.rf>
   <form>prací</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W8</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W9</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W11</w.rf>
   <form>jeřábového</form>
   <lemma>jeřábový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W12</w.rf>
   <form>tělesa</form>
   <lemma>těleso</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W14</w.rf>
   <form>vybrali</form>
   <lemma>vybrat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W15</w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W16</w.rf>
   <form>reálnou</form>
   <lemma>reálný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W17</w.rf>
   <form>situaci</form>
   <lemma>situace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W19</w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W20</w.rf>
   <form>lezci</form>
   <lemma>lezec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W21</w.rf>
   <form>řešili</form>
   <lemma>řešit_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W22</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W23</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W24</w.rf>
   <form>prvně</form>
   <lemma>prvně</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W26</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W27</w.rf>
   <form>řekl</form>
   <lemma>říci_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W28</w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W29</w.rf>
   <form>lezecké</form>
   <lemma>lezecký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W30</w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W31</w.rf>
   <form>chrudimských</form>
   <lemma>chrudimský</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W32</w.rf>
   <form>hasičů</form>
   <lemma>hasič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W33</w.rf>
   <form>nprap</form>
   <lemma>nadpraporčík_:B</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s1W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p1s2">
  <m id="m-pardubicky48444.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s2W1</w.rf>
   <form>Radek</form>
   <lemma>Radek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s2W2</w.rf>
   <form>Svoboda</form>
   <lemma>Svoboda_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s2W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s2W4</w.rf>
   <form>DiS</form>
   <lemma>Dis_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p1s2W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p2s1">
  <m id="m-pardubicky48444.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W1</w.rf>
   <form>Situace</form>
   <lemma>situace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W3</w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W4</w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W5</w.rf>
   <form>hasiči-lezci</form>
   <lemma>hasiči-lezci</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W6</w.rf>
   <form>řešit</form>
   <lemma>řešit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W8</w.rf>
   <form>vypadala</form>
   <lemma>vypadat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W9</w.rf>
   <form>takto</form>
   <lemma>takto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W11</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W12</w.rf>
   <form>provádění</form>
   <lemma>provádění_^(*2t)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W13</w.rf>
   <form>revizních</form>
   <lemma>revizní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W14</w.rf>
   <form>prací</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W16</w.rf>
   <form>rameni</form>
   <lemma>rameno</lemma>
   <tag>NNNS6-----A---2</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W17</w.rf>
   <form>jeřábu</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W18</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W19</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W20</w.rf>
   <form>mozkové</form>
   <lemma>mozkový</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W21</w.rf>
   <form>příhodě</form>
   <lemma>příhoda</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W22</w.rf>
   <form>jeřábníka</form>
   <lemma>jeřábník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W24</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W25</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W26</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W27</w.rf>
   <form>horní</form>
   <lemma>horní-1_^(vrchní)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W28</w.rf>
   <form>ovládací</form>
   <lemma>ovládací_^(*2t)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W29</w.rf>
   <form>kabině</form>
   <lemma>kabina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W30</w.rf>
   <form>jeřábu</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s1W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p2s2">
  <m id="m-pardubicky48444.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s2W1</w.rf>
   <form>Přitom</form>
   <lemma>přitom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s2W2</w.rf>
   <form>tělem</form>
   <lemma>tělo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s2W3</w.rf>
   <form>zavadil</form>
   <lemma>zavadit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s2W4</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s2W5</w.rf>
   <form>ovládací</form>
   <lemma>ovládací_^(*2t)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s2W6</w.rf>
   <form>prvky</form>
   <lemma>prvek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s2W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p2s3">
  <m id="m-pardubicky48444.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s3W1</w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s3W2</w.rf>
   <form>provedl</form>
   <lemma>provést</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s3W3</w.rf>
   <form>nečekaný</form>
   <lemma>čekaný_^(*2t)</lemma>
   <tag>AAIS1----1N----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s3W4</w.rf>
   <form>trhavý</form>
   <lemma>trhavý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s3W5</w.rf>
   <form>pohyb</form>
   <lemma>pohyb</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s3W6</w.rf>
   <form>ramenem</form>
   <lemma>rameno</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s3W7</w.rf>
   <form>jeřábu</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p2s4">
  <m id="m-pardubicky48444.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W1</w.rf>
   <form>Revizní</form>
   <lemma>revizní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W2</w.rf>
   <form>technik</form>
   <lemma>technik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W3</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W4</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W5</w.rf>
   <form>pohybem</form>
   <lemma>pohyb</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W6</w.rf>
   <form>shozen</form>
   <lemma>shodit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W8</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W9</w.rf>
   <form>pádu</form>
   <lemma>pád</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W10</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W11</w.rf>
   <form>zachycen</form>
   <lemma>zachytit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W12</w.rf>
   <form>jistícím</form>
   <lemma>jistící_^(*3it)</lemma>
   <tag>AGIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W13</w.rf>
   <form>řetězcem</form>
   <lemma>řetězec</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W14</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W15</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W16</w.rf>
   <form>m</form>
   <lemma>m-1`metr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W17</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W18</w.rf>
   <form>konstrukcí</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s4W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p2s5">
  <m id="m-pardubicky48444.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W1</w.rf>
   <form>Přivolaní</form>
   <lemma>přivolaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W2</w.rf>
   <form>hasiči-lezci</form>
   <lemma>hasiči-lezci</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W4</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W5</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W6</w.rf>
   <form>příjezdu</form>
   <lemma>příjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W8</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W9</w.rf>
   <form>simulované</form>
   <lemma>simulovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W10</w.rf>
   <form>události</form>
   <lemma>událost_,a_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W11</w.rf>
   <form>vystrojili</form>
   <lemma>vystrojit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W13</w.rf>
   <form>vyzbrojili</form>
   <lemma>vyzbrojit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W14</w.rf>
   <form>materiálem</form>
   <lemma>materiál</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W16</w.rf>
   <form>velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W17</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W18</w.rf>
   <form>stanovil</form>
   <lemma>stanovit_:W_^(určit)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W19</w.rf>
   <form>postup</form>
   <lemma>postup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W20</w.rf>
   <form>záchrany</form>
   <lemma>záchrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W21</w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W22</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p2s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p2s5W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p3s1">
  <m id="m-pardubicky48444.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W2</w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W3</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W5</w.rf>
   <form>věnovala</form>
   <lemma>věnovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W6</w.rf>
   <form>záchraně</form>
   <lemma>záchrana</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W7</w.rf>
   <form>jeřábníka</form>
   <lemma>jeřábník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W9</w.rf>
   <form>horní</form>
   <lemma>horní-1_^(vrchní)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W10</w.rf>
   <form>kabiny</form>
   <lemma>kabina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W12</w.rf>
   <form>druhá</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W13</w.rf>
   <form>pokračovala</form>
   <lemma>pokračovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W15</w.rf>
   <form>rameno</form>
   <lemma>rameno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W16</w.rf>
   <form>jeřábu</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W17</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W18</w.rf>
   <form>reviznímu</form>
   <lemma>revizní</lemma>
   <tag>AAMS3----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W19</w.rf>
   <form>technikovi</form>
   <lemma>technik</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W21</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W22</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W23</w.rf>
   <form>pádu</form>
   <lemma>pád</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W24</w.rf>
   <form>nehybně</form>
   <lemma>hybně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W25</w.rf>
   <form>visel</form>
   <lemma>viset_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W27</w.rf>
   <form>laně</form>
   <lemma>laň</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s1W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p3s2">
  <m id="m-pardubicky48444.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W1</w.rf>
   <form>První</form>
   <lemma>první</lemma>
   <tag>CrMP1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W2</w.rf>
   <form>lezci</form>
   <lemma>lezec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W4</w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6-X7----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W5</w.rf>
   <form>nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W6</w.rf>
   <form>přinesli</form>
   <lemma>přinést</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W7</w.rf>
   <form>křísící</form>
   <lemma>křísící_^(*3it)</lemma>
   <tag>AGIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W8</w.rf>
   <form>přístroj</form>
   <lemma>přístroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W9</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W10</w.rf>
   <form>OXY</form>
   <lemma>OXY</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W11</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W13</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W14</w.rf>
   <form>poskytli</form>
   <lemma>poskytnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W15</w.rf>
   <form>kyslík</form>
   <lemma>kyslík</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W16</w.rf>
   <form>obsluze</form>
   <lemma>obsluha</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W17</w.rf>
   <form>jeřábu</form>
   <lemma>jeřáb-2_^(strom)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W18</w.rf>
   <form>postiženého</form>
   <lemma>postižený_^(*4hnout)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W19</w.rf>
   <form>mozkovou</form>
   <lemma>mozkový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W20</w.rf>
   <form>příhodou</form>
   <lemma>příhoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W21</w.rf>
   <form>projevující</form>
   <lemma>projevující_^(*5ovat)</lemma>
   <tag>AGFS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W22</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W24</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W25</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W26</w.rf>
   <form>ochrnutím</form>
   <lemma>ochrnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W27</w.rf>
   <form>levé</form>
   <lemma>levý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W28</w.rf>
   <form>poloviny</form>
   <lemma>polovina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W29</w.rf>
   <form>těla</form>
   <lemma>tělo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W31</w.rf>
   <form>disartrií</form>
   <lemma>disartrií</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W33</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W34</w.rf>
   <form>popisuje</form>
   <lemma>popisovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W35</w.rf>
   <form>zásah</form>
   <lemma>zásah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W36</w.rf>
   <form>Radek</form>
   <lemma>Radek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W37</w.rf>
   <form>Svoboda</form>
   <lemma>Svoboda_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s2W38</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p3s3">
  <m id="m-pardubicky48444.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W2</w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W3</w.rf>
   <form>kabince</form>
   <lemma>kabinka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W4</w.rf>
   <form>ovládacího</form>
   <lemma>ovládací_^(*2t)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W5</w.rf>
   <form>stanoviště</form>
   <lemma>stanoviště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W6</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W7</w.rf>
   <form>postiženému</form>
   <lemma>postižený_^(*4hnout)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W8</w.rf>
   <form>nasazen</form>
   <lemma>nasadit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W9</w.rf>
   <form>záchranný</form>
   <lemma>záchranný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W10</w.rf>
   <form>trojúhelník</form>
   <lemma>trojúhelník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W12</w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W13</w.rf>
   <form>kladkostroje</form>
   <lemma>kladkostroj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W14</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W15</w.rf>
   <form>vytažen</form>
   <lemma>vytáhnout</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W16</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W17</w.rf>
   <form>kabinku</form>
   <lemma>kabinka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W19</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W20</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W21</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W22</w.rf>
   <form>připravena</form>
   <lemma>připravit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W23</w.rf>
   <form>nosítka</form>
   <lemma>nosítka</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W24</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W25</w.rf>
   <form>nichž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9XP2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W26</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W27</w.rf>
   <form>zraněný</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W28</w.rf>
   <form>přeložen</form>
   <lemma>přeložit-1_:W_^(přemístit)</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W30</w.rf>
   <form>transportován</form>
   <lemma>transportovat_:T_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W31</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W32</w.rf>
   <form>zem</form>
   <lemma>země</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p3s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p3s3W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p4s1">
  <m id="m-pardubicky48444.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W1</w.rf>
   <form>Lezci</form>
   <lemma>lezec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W2</w.rf>
   <form>druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W3</w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W5</w.rf>
   <form>slanili</form>
   <lemma>slanit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W7</w.rf>
   <form>dalšímu</form>
   <lemma>další</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W8</w.rf>
   <form>zraněnému</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W10</w.rf>
   <form>pádem</form>
   <lemma>pád</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W11</w.rf>
   <form>postiženému</form>
   <lemma>postižený_^(*4hnout)</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W12</w.rf>
   <form>reviznímu</form>
   <lemma>revizní</lemma>
   <tag>AAMS3----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W13</w.rf>
   <form>technikovi</form>
   <lemma>technik</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W16</w.rf>
   <form>nasadili</form>
   <lemma>nasadit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W17</w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W18</w.rf>
   <form>krční</form>
   <lemma>krční</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W19</w.rf>
   <form>límec</form>
   <lemma>límec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s1W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p4s2">
  <m id="m-pardubicky48444.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W1</w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W3</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W4</w.rf>
   <form>lezci</form>
   <lemma>lezec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W5</w.rf>
   <form>eliminovali</form>
   <lemma>eliminovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W6</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W7</w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W8</w.rf>
   <form>poškození</form>
   <lemma>poškození_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W9</w.rf>
   <form>páteře</form>
   <lemma>páteř</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p4s3">
  <m id="m-pardubicky48444.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W1</w.rf>
   <form>Zraněný</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W3</w.rf>
   <form>uložen</form>
   <lemma>uložit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W5</w.rf>
   <form>nosítek</form>
   <lemma>nosítka</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W7</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W8</w.rf>
   <form>spuštěn</form>
   <lemma>spustit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W9</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W10</w.rf>
   <form>záchranářem</form>
   <lemma>záchranář</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W12</w.rf>
   <form>zem</form>
   <lemma>země</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p4s3W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p5s1">
  <m id="m-pardubicky48444.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W2</w.rf>
   <form>Časový</form>
   <lemma>časový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W3</w.rf>
   <form>limit</form>
   <lemma>limit-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W4</w.rf>
   <form>lezci</form>
   <lemma>lezec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W5</w.rf>
   <form>splnili</form>
   <lemma>splnit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W7</w.rf>
   <form>základním</form>
   <lemma>základní</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W8</w.rf>
   <form>hodnotícím</form>
   <lemma>hodnotící_^(*3it)</lemma>
   <tag>AGNS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W9</w.rf>
   <form>kritériem</form>
   <lemma>kritérium</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W10</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W11</w.rf>
   <form>zvolení</form>
   <lemma>zvolení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W12</w.rf>
   <form>vhodného</form>
   <lemma>vhodný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W13</w.rf>
   <form>postupu</form>
   <lemma>postup</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W14</w.rf>
   <form>záchrany</form>
   <lemma>záchrana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W15</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W16</w.rf>
   <form>dodržení</form>
   <lemma>dodržení_^(*2t)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W17</w.rf>
   <form>bezpečnosti</form>
   <lemma>bezpečnost-1_^(*5ý-1)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W18</w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W20</w.rf>
   <form>samostatná</form>
   <lemma>samostatný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W21</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W22</w.rf>
   <form>lezců</form>
   <lemma>lezec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s1W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p5s2">
  <m id="m-pardubicky48444.txt-001-p5s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W1</w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W2</w.rf>
   <form>prokázali</form>
   <lemma>prokázat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W3</w.rf>
   <form>individuální</form>
   <lemma>individuální</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W4</w.rf>
   <form>schopnosti</form>
   <lemma>schopnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W5</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W6</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W7</w.rf>
   <form>lezeckou</form>
   <lemma>lezecký</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W8</w.rf>
   <form>technikou</form>
   <lemma>technika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W10</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W11</w.rf>
   <form>vhodně</form>
   <lemma>vhodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W12</w.rf>
   <form>aplikovali</form>
   <lemma>aplikovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W13</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W14</w.rf>
   <form>týmové</form>
   <lemma>týmový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W15</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W17</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W18</w.rf>
   <form>uvedl</form>
   <lemma>uvést</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W19</w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W20</w.rf>
   <form>lezecké</form>
   <lemma>lezecký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W21</w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W23</w.rf>
   <form>dodal</form>
   <lemma>dodat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W25</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W26</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W27</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W28</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W29</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W30</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W31</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W32</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W33</w.rf>
   <form>objeveny</form>
   <lemma>objevit_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W34</w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZIP1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W35</w.rf>
   <form>nedostatky</form>
   <lemma>nedostatek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W37</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W38</w.rf>
   <form>nichž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9XP2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W39</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W40</w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W41</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W42</w.rf>
   <form>vzít</form>
   <lemma>vzít_^(př._sebrat_něco;_brát_ohled,_zřetel,...)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W43</w.rf>
   <form>ponaučení</form>
   <lemma>ponaučení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s2W44</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p5s3">
  <m id="m-pardubicky48444.txt-001-p5s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W1</w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W3</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W4</w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDNP1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W5</w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W6</w.rf>
   <form>provádějí</form>
   <lemma>provádět_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W8</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W10</w.rf>
   <form>odhalily</form>
   <lemma>odhalit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W11</w.rf>
   <form>chyby</form>
   <lemma>chyba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W13</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W14</w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4XP3----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W15</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W16</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W17</w.rf>
   <form>skutečném</form>
   <lemma>skutečný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W18</w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W19</w.rf>
   <form>nemělo</form>
   <lemma>mít</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W20</w.rf>
   <form>docházet</form>
   <lemma>docházet_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p5s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p5s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p6s1">
  <m id="m-pardubicky48444.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W1</w.rf>
   <form>Lezecká</form>
   <lemma>lezecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W2</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W3</w.rf>
   <form>HZS</form>
   <lemma>HZS-2_:B_;K_^(Horská_záchranná_služba)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W4</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W5</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W6</w.rf>
   <form>územního</form>
   <lemma>územní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W7</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W8</w.rf>
   <form>Chrudim</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W9</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W10</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W12</w.rf>
   <form>členů</form>
   <lemma>člen</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W13</w.rf>
   <form>rozdělených</form>
   <lemma>rozdělený_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W14</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W15</w.rf>
   <form>čtyřech</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W17</w.rf>
   <form>směnu</form>
   <lemma>směna-1_^(výměna_za_něco)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p6s2">
  <m id="m-pardubicky48444.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W1</w.rf>
   <form>Složení</form>
   <lemma>složení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W2</w.rf>
   <form>lezecké</form>
   <lemma>lezecký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W3</w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W5</w.rf>
   <form>široké</form>
   <lemma>široký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W6</w.rf>
   <form>spektrum</form>
   <lemma>spektrum</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W7</w.rf>
   <form>klasických</form>
   <lemma>klasický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W8</w.rf>
   <form>služebních</form>
   <lemma>služební_^(poměr,byt,zbraň,...)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W9</w.rf>
   <form>funkcí</form>
   <lemma>funkce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W12</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W13</w.rf>
   <form>hasiče</form>
   <lemma>hasič</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W14</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W15</w.rf>
   <form>velitele</form>
   <lemma>velitel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W16</w.rf>
   <form>čety</form>
   <lemma>četa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W17</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W18</w.rf>
   <form>techniků</form>
   <lemma>technik</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W19</w.rf>
   <form>chemické</form>
   <lemma>chemický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W21</w.rf>
   <form>spojové</form>
   <lemma>spojový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W22</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky48444.txt-001-p6s3">
  <m id="m-pardubicky48444.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W1</w.rf>
   <form>Mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W3</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W4</w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W6</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W7</w.rf>
   <form>členové</form>
   <lemma>člen</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W8</w.rf>
   <form>posttraumatického</form>
   <lemma>posttraumatický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W9</w.rf>
   <form>týmu</form>
   <lemma>tým</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W11</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W12</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W13</w.rf>
   <form>zdravotničtí</form>
   <lemma>zdravotnický</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W14</w.rf>
   <form>záchranáři</form>
   <lemma>záchranář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky48444.txt-001-p6s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky48444.txt-001-p6s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
