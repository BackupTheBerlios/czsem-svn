<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pardubicky47551.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-pardubicky47551.txt-001-p1s1">
  <m id="m-pardubicky47551.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W1</w.rf>
   <form>Hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W2</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W3</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W4</w.rf>
   <form>zaznamenávají</form>
   <lemma>zaznamenávat_:T_^(*4at)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W5</w.rf>
   <form>nárůst</form>
   <lemma>nárůst</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W6</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W7</w.rf>
   <form>lesů</form>
   <lemma>les</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W9</w.rf>
   <form>porostů</form>
   <lemma>porost</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W11</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W12</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W13</w.rf>
   <form>kontejnerů</form>
   <lemma>kontejner</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W15</w.rf>
   <form>odpadkových</form>
   <lemma>odpadkový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W16</w.rf>
   <form>košů</form>
   <lemma>koš</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p1s2">
  <m id="m-pardubicky47551.txt-001-p1s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W1</w.rf>
   <form>Společným</form>
   <lemma>společný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W2</w.rf>
   <form>jmenovatelem</form>
   <lemma>jmenovatel</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W3</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W4</w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W5</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W8</w.rf>
   <form>většině</form>
   <lemma>většina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W9</w.rf>
   <form>případů</form>
   <lemma>případ</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W10</w.rf>
   <form>nedbalost</form>
   <lemma>nedbalost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W11</w.rf>
   <form>občanů</form>
   <lemma>občan</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s2W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p1s3">
  <m id="m-pardubicky47551.txt-001-p1s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W1</w.rf>
   <form>Jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W2</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W3</w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W4</w.rf>
   <form>duben</form>
   <lemma>duben</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W5</w.rf>
   <form>likvidovali</form>
   <lemma>likvidovat_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W6</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W7</w.rf>
   <form>57</form>
   <lemma>57</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W8</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W10</w.rf>
   <form>přírodním</form>
   <lemma>přírodní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W11</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p1s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p1s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p2s1">
  <m id="m-pardubicky47551.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W1</w.rf>
   <form>Chceme</form>
   <lemma>chtít</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W2</w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W3</w.rf>
   <form>upozornit</form>
   <lemma>upozornit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W5</w.rf>
   <form>základní</form>
   <lemma>základní_,s</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W6</w.rf>
   <form>povinnosti</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W7</w.rf>
   <form>fyzických</form>
   <lemma>fyzický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W8</w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W10</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W11</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W12</w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W13</w.rf>
   <form>občan</form>
   <lemma>občan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W14</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W15</w.rf>
   <form>počínat</form>
   <lemma>počínat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W16</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W17</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W19</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W20</w.rf>
   <form>nedocházelo</form>
   <lemma>docházet_:T</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W21</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W22</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W23</w.rf>
   <form>požárů</form>
   <lemma>požár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W24</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W25</w.rf>
   <form>manipulaci</form>
   <lemma>manipulace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W26</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W27</w.rf>
   <form>otevřeným</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W28</w.rf>
   <form>ohněm</form>
   <lemma>oheň</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W29</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W30</w.rf>
   <form>jiným</form>
   <lemma>jiný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W31</w.rf>
   <form>zdrojem</form>
   <lemma>zdroj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W32</w.rf>
   <form>zapálení</form>
   <lemma>zapálení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p2s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p2s1W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p3s1">
  <m id="m-pardubicky47551.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W1</w.rf>
   <form>Dalšími</form>
   <lemma>další</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W2</w.rf>
   <form>významnými</form>
   <lemma>významný</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W3</w.rf>
   <form>příčinami</form>
   <lemma>příčina</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W4</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W5</w.rf>
   <form>vypalování</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W6</w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W8</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W9</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W10</w.rf>
   <form>rostlinného</form>
   <lemma>rostlinný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W11</w.rf>
   <form>charakteru</form>
   <lemma>charakter</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W13</w.rf>
   <form>zapalování</form>
   <lemma>zapalování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W14</w.rf>
   <form>ohňů</form>
   <lemma>oheň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W16</w.rf>
   <form>přírodě</form>
   <lemma>příroda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s1W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p3s2">
  <m id="m-pardubicky47551.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W1</w.rf>
   <form>Vypalování</form>
   <lemma>vypalování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W2</w.rf>
   <form>porostu</form>
   <lemma>porost</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W4</w.rf>
   <form>zakázáno</form>
   <lemma>zakázat</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W5</w.rf>
   <form>zákonem</form>
   <lemma>zákon</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W7</w.rf>
   <form>požární</form>
   <lemma>požární</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W8</w.rf>
   <form>ochraně</form>
   <lemma>ochrana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p3s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p4s1">
  <m id="m-pardubicky47551.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W1</w.rf>
   <form>Pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W2</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W4</w.rf>
   <form>zapalování</form>
   <lemma>zapalování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W5</w.rf>
   <form>ohňů</form>
   <lemma>oheň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W7</w.rf>
   <form>přírodě</form>
   <lemma>příroda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W8</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W10</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W11</w.rf>
   <form>zvýšeného</form>
   <lemma>zvýšený_^(*3it)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W12</w.rf>
   <form>sucha</form>
   <lemma>sucho</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W13</w.rf>
   <form>rizikovou</form>
   <lemma>rizikový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W14</w.rf>
   <form>aktivitou</form>
   <lemma>aktivita</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W16</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W17</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W18</w.rf>
   <form>provádět</form>
   <lemma>provádět_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W19</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W20</w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W22</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W23</w.rf>
   <form>nemůže</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W24</w.rf>
   <form>dojít</form>
   <lemma>dojít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W25</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W26</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W28</w.rf>
   <form>šíření</form>
   <lemma>šíření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W29</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p4s2">
  <m id="m-pardubicky47551.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W1</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W2</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W3</w.rf>
   <form>zamezující</form>
   <lemma>zamezující_^(*5ovat)</lemma>
   <tag>AGIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W4</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W6</w.rf>
   <form>šíření</form>
   <lemma>šíření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W7</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W8</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W9</w.rf>
   <form>odpovědná</form>
   <lemma>odpovědný_^(kdo_za_něco_odpovídá)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W10</w.rf>
   <form>fyzická</form>
   <lemma>fyzický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W11</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W12</w.rf>
   <form>právnická</form>
   <lemma>právnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W13</w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W15</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W16</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W17</w.rf>
   <form>provádí</form>
   <lemma>provádět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p4s3">
  <m id="m-pardubicky47551.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W1</w.rf>
   <form>Právnická</form>
   <lemma>právnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W2</w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W4</w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W5</w.rf>
   <form>povinna</form>
   <lemma>povinný</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W6</w.rf>
   <form>ohlásit</form>
   <lemma>ohlásit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W7</w.rf>
   <form>pálení</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W8</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W9</w.rf>
   <form>stanovených</form>
   <lemma>stanovený_^(určit)_(*3it)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W10</w.rf>
   <form>opatření</form>
   <lemma>opatření_^(*3it)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W11</w.rf>
   <form>Hasičskému</form>
   <lemma>hasičský</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W12</w.rf>
   <form>záchrannému</form>
   <lemma>záchranný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W13</w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W14</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p4s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p5s1">
  <m id="m-pardubicky47551.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W1</w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W2</w.rf>
   <form>fyzická</form>
   <lemma>fyzický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W3</w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W5</w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W7</w.rf>
   <form>pálením</form>
   <lemma>pálení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W8</w.rf>
   <form>odpadu</form>
   <lemma>odpad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W9</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W10</w.rf>
   <form>zakládáním</form>
   <lemma>zakládání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W11</w.rf>
   <form>ohňů</form>
   <lemma>oheň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W13</w.rf>
   <form>přírodě</form>
   <lemma>příroda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W14</w.rf>
   <form>způsobí</form>
   <lemma>způsobit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W15</w.rf>
   <form>požár</form>
   <lemma>požár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W17</w.rf>
   <form>dopouští</form>
   <lemma>dopouštět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W19</w.rf>
   <form>přestupku</form>
   <lemma>přestupek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W21</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W22</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W23</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W24</w.rf>
   <form>uložit</form>
   <lemma>uložit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W25</w.rf>
   <form>pokutu</form>
   <lemma>pokuta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W26</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W27</w.rf>
   <form>výše</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W28</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W29</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W30</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W32</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W33</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W34</w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W35</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W36</w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W37</w.rf>
   <form>požárem</form>
   <lemma>požár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W38</w.rf>
   <form>nezpůsobí</form>
   <lemma>způsobit_:W</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W39</w.rf>
   <form>následek</form>
   <lemma>následek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W40</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W41</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W42</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W43</w.rf>
   <form>povahu</form>
   <lemma>povaha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W44</w.rf>
   <form>trestného</form>
   <lemma>trestný_^(čin)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W45</w.rf>
   <form>činu</form>
   <lemma>čin</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W47</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p5s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p5s1W48</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p6s1">
  <m id="m-pardubicky47551.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p6s1W1</w.rf>
   <form>Hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p6s1W2</w.rf>
   <form>zásady</form>
   <lemma>zásada</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p6s1W3</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p6s1W4</w.rf>
   <form>rozdělávání</form>
   <lemma>rozdělávání_^(*5at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p6s1W5</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p6s1W6</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p7s1">
  <m id="m-pardubicky47551.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W1</w.rf>
   <form>Nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W2</w.rf>
   <form>zapalování</form>
   <lemma>zapalování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W3</w.rf>
   <form>ohňů</form>
   <lemma>oheň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W5</w.rf>
   <form>přírodě</form>
   <lemma>příroda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W7</w.rf>
   <form>zvláště</form>
   <lemma>zvláště</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W8</w.rf>
   <form>vysoké</form>
   <lemma>vysoká_^(zvěř)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W10</w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W11</w.rf>
   <form>filipojakubské</form>
   <lemma>filipojakubský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W12</w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s1W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-pardubicky47551.txt-001-p7s2">
  <m id="m-pardubicky47551.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W2</w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W4</w.rf>
   <form>varováním</form>
   <lemma>varování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W5</w.rf>
   <form>Českého</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W6</w.rf>
   <form>hydrometeorologického</form>
   <lemma>hydrometeorologický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W7</w.rf>
   <form>ústavu</form>
   <lemma>ústav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W8</w.rf>
   <form>hasiči</form>
   <lemma>hasič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W9</w.rf>
   <form>Pardubického</form>
   <lemma>pardubický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W10</w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W11</w.rf>
   <form>nedoporučují</form>
   <lemma>doporučovat_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W12</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W13</w.rf>
   <form>blížícím</form>
   <lemma>blížící_^(*3it)</lemma>
   <tag>AGIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W15</w.rf>
   <form>svátkem</form>
   <lemma>svátek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W16</w.rf>
   <form>čarodějnic</form>
   <lemma>čarodějnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W17</w.rf>
   <form>zapalovat</form>
   <lemma>zapalovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W18</w.rf>
   <form>jakékoliv</form>
   <lemma>jakýkoliv</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W19</w.rf>
   <form>ohně</form>
   <lemma>oheň</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W21</w.rf>
   <form>přírodním</form>
   <lemma>přírodní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W22</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-pardubicky47551.txt-001-p7s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-pardubicky47551.txt-001-p7s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
