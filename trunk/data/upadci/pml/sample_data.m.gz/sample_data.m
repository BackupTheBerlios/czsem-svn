<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample_data.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="tagger-b"></annotation_info>
 </meta>
 <s id="m-sample_data.txt-001-p1s1">
  <m id="m-sample_data.txt-001-p1s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W1</w.rf>
   <form>Krajský</form>
   <lemma>krajský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W2</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W4</w.rf>
   <form>Ostravě</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W6</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W7</w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W8</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W9</w.rf>
   <form>Magdy</form>
   <lemma>Magda_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W10</w.rf>
   <form>Ochmanové</form>
   <lemma>Ochmanová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W12</w.rf>
   <form>bytem</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W13</w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W15</w.rf>
   <form>Engelmullerova</form>
   <lemma>Engelmullerova</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W16</w.rf>
   <form>3031</form>
   <lemma>3031</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W17</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W18</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W20</w.rf>
   <form>IČ</form>
   <lemma>Ič</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W21</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W22</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W23</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W24</w.rf>
   <form>09</form>
   <lemma>09</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W25</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W27</w.rf>
   <form>uvědomuje</form>
   <lemma>uvědomovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W28</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W29</w.rf>
   <form>věřitele</form>
   <lemma>věřitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W31</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W33</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W34</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W35</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W36</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W37</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W38</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W39</w.rf>
   <form>16.4</form>
   <form_change>num_normalization</form_change>
   <lemma>16.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W40</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W41</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W42</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W43</w.rf>
   <form>konečnou</form>
   <lemma>konečný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W44</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W45</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W46</w.rf>
   <form>zpeněžení</form>
   <lemma>zpeněžení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W47</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W48</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W49</w.rf>
   <form>vyúčtování</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W50</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W51</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W52</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W53</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p1s1W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p1s1W54</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p2s1">
  <m id="m-sample_data.txt-001-p2s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s1W2</w.rf>
   <form>podepsaného</form>
   <lemma>podepsaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s1W4</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s1W5</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s1W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p2s2">
  <m id="m-sample_data.txt-001-p2s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W1</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W3</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W5</w.rf>
   <form>95-260-262</form>
   <lemma>95-260-262</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W8</w.rf>
   <form>29.02</form>
   <form_change>num_normalization</form_change>
   <lemma>29.02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W10</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W13</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W14</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W16</w.rf>
   <form>05</form>
   <lemma>05</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W18</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W19</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W20</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W21</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W22</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W23</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W24</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W25</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p2s3">
  <m id="m-sample_data.txt-001-p2s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W1</w.rf>
   <form>Správkyně</form>
   <lemma>správkyně_^(*4ce)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W5</w.rf>
   <form>Zuzana</form>
   <lemma>Zuzana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W6</w.rf>
   <form>Zlatohlávková</form>
   <lemma>zlatohlávkový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W8</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W9</w.rf>
   <form>sídlem</form>
   <lemma>sídlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W10</w.rf>
   <form>Riegrovo</form>
   <lemma>Riegrův_;S_^(*2)</lemma>
   <tag>AUNS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W11</w.rf>
   <form>nám.</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W12</w.rf>
   <form>1493</form>
   <lemma>1493</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W14</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W15</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W17</w.rf>
   <form>oznámila</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W18</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W19</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W20</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W22</w.rf>
   <form>06</form>
   <lemma>06</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W24</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W26</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W27</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W28</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W29</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W30</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s3W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p2s4">
  <m id="m-sample_data.txt-001-p2s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p2s5">
  <m id="m-sample_data.txt-001-p2s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W11</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W13</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W14</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W15</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W16</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W18</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W20</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W21</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W22</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p2s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p2s5W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p3s1">
  <m id="m-sample_data.txt-001-p3s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p3s2">
  <m id="m-sample_data.txt-001-p3s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W1</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W3</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W5</w.rf>
   <form>95-278</form>
   <lemma>95-278</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W8</w.rf>
   <form>21.6</form>
   <form_change>num_normalization</form_change>
   <lemma>21.6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W10</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W13</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W14</w.rf>
   <form>22.9</form>
   <form_change>num_normalization</form_change>
   <lemma>22.9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W16</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W18</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W19</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W20</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W21</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W23</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p3s3">
  <m id="m-sample_data.txt-001-p3s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W5</w.rf>
   <form>Eliška</form>
   <lemma>Eliška_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W6</w.rf>
   <form>Francová</form>
   <lemma>Francová_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W8</w.rf>
   <form>Hořická</form>
   <lemma>hořický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W9</w.rf>
   <form>974</form>
   <lemma>974</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W11</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W12</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W13</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W14</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W16</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W17</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W18</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W19</w.rf>
   <form>5.3</form>
   <form_change>num_normalization</form_change>
   <lemma>5.3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W21</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W23</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W24</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W25</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W26</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W27</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s3W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p3s4">
  <m id="m-sample_data.txt-001-p3s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p3s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p3s4W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p4s1">
  <m id="m-sample_data.txt-001-p4s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p4s2">
  <m id="m-sample_data.txt-001-p4s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W1</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W3</w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W5</w.rf>
   <form>95-992</form>
   <lemma>95-992</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W8</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W10</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W12</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W14</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W15</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W16</w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W18</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W20</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W22</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W23</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W24</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W25</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W27</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p4s3">
  <m id="m-sample_data.txt-001-p4s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W5</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W6</w.rf>
   <form>Poláček</form>
   <lemma>Poláček_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W8</w.rf>
   <form>Nám.</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W9</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W10</w.rf>
   <form>53</form>
   <lemma>53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W12</w.rf>
   <form>530</form>
   <lemma>530</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W13</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W14</w.rf>
   <form>Pardubice</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W16</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W17</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W18</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W19</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W21</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W23</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W25</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W26</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W27</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W28</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W29</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p4s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p4s3W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p5s1">
  <m id="m-sample_data.txt-001-p5s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p5s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p5s1W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s1">
  <m id="m-sample_data.txt-001-p6s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W8</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W9</w.rf>
   <form>14.07</form>
   <form_change>num_normalization</form_change>
   <lemma>14.07</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W11</w.rf>
   <form>1995</form>
   <lemma>1995</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W13</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W14</w.rf>
   <form>j</form>
   <lemma>j-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s2">
  <m id="m-sample_data.txt-001-p6s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W1</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W3</w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W5</w.rf>
   <form>95-81</form>
   <lemma>95-81</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W8</w.rf>
   <form>prohlášen</form>
   <lemma>prohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W9</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W11</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W12</w.rf>
   <form>dlužníka</form>
   <lemma>dlužník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W13</w.rf>
   <form>Průmstav</form>
   <lemma>Průmstav_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W15</w.rf>
   <form>spol</form>
   <lemma>společnost_:B</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W18</w.rf>
   <form>r.</form>
   <lemma>ručení_:B</lemma>
   <tag>NNNS7-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W19</w.rf>
   <form>o</form>
   <lemma>omezený_:B</lemma>
   <tag>AANS7----1A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W22</w.rf>
   <form>IČ</form>
   <lemma>Ič</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W23</w.rf>
   <form>46506683</form>
   <lemma>46506683</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W25</w.rf>
   <form>Masarykovo</form>
   <lemma>Masarykův_;S_^(*2)</lemma>
   <tag>AUNS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W26</w.rf>
   <form>nám.</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W27</w.rf>
   <form>1544</form>
   <lemma>1544</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W29</w.rf>
   <form>530</form>
   <lemma>530</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W30</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W31</w.rf>
   <form>Pardubice</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s2W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s3">
  <m id="m-sample_data.txt-001-p6s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W1</w.rf>
   <form>Správcem</form>
   <lemma>správce</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W5</w.rf>
   <form>ustaven</form>
   <lemma>ustavit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W6</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W7</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W8</w.rf>
   <form>Poláček</form>
   <lemma>Poláček_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W10</w.rf>
   <form>Nám.</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W11</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W12</w.rf>
   <form>53</form>
   <lemma>53</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W14</w.rf>
   <form>530</form>
   <lemma>530</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W15</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W16</w.rf>
   <form>Pardubice</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s4">
  <m id="m-sample_data.txt-001-p6s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W2</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W4</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W6</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W7</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W8</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W9</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W10</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W11</w.rf>
   <form>konečnou</form>
   <lemma>konečný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W12</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W13</w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W15</w.rf>
   <form>vyúčtováním</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W16</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W18</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W19</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s4W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s5">
  <m id="m-sample_data.txt-001-p6s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W2</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W4</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W6</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W7</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W8</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W9</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W10</w.rf>
   <form>dodatek</form>
   <lemma>dodatek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W11</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W12</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W13</w.rf>
   <form>zprávě</form>
   <lemma>zpráva</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s5W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s6">
  <m id="m-sample_data.txt-001-p6s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W1</w.rf>
   <form>Konečná</form>
   <lemma>konečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W2</w.rf>
   <form>zpráva</form>
   <lemma>zpráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W4</w.rf>
   <form>projednána</form>
   <lemma>projednat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W5</w.rf>
   <form>postupem</form>
   <lemma>postup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W6</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W7</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W9</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W10</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W11</w.rf>
   <form>zák</form>
   <lemma>zákon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W13</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W14</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W16</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s6W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s7">
  <m id="m-sample_data.txt-001-p6s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W4</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W6</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W8</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W10</w.rf>
   <form>č.j</form>
   <lemma>č.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s7W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s8">
  <m id="m-sample_data.txt-001-p6s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W1</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W3</w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W5</w.rf>
   <form>95-924</form>
   <lemma>95-924</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W7</w.rf>
   <form>jež</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJNS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W8</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W9</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W10</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W12</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W14</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W16</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W17</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W18</w.rf>
   <form>konečná</form>
   <lemma>konečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W19</w.rf>
   <form>zpráva</form>
   <lemma>zpráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W21</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W22</w.rf>
   <form>vyúčtování</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W23</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W24</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W26</w.rf>
   <form>hotových</form>
   <lemma>hotový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W27</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W29</w.rf>
   <form>schválena</form>
   <lemma>schválit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W30</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W31</w.rf>
   <form>předloženého</form>
   <lemma>předložený_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W32</w.rf>
   <form>dodatku</form>
   <lemma>dodatek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s8W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s8W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s9">
  <m id="m-sample_data.txt-001-p6s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W1</w.rf>
   <form>Návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W2</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W3</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W4</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W5</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W6</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W8</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W10</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W12</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s9W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s10">
  <m id="m-sample_data.txt-001-p6s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W1</w.rf>
   <form>Rozdělení</form>
   <lemma>rozdělení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W2</w.rf>
   <form>výtěžku</form>
   <lemma>výtěžek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W3</w.rf>
   <form>získaného</form>
   <lemma>získaný_^(*2t)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W4</w.rf>
   <form>zpeněžením</form>
   <lemma>zpeněžení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W5</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W6</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W7</w.rf>
   <form>vychází</form>
   <lemma>vycházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W9</w.rf>
   <form>údajů</form>
   <lemma>údaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W10</w.rf>
   <form>obsažených</form>
   <lemma>obsažený_^(*5áhnout)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W11</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W12</w.rf>
   <form>schválené</form>
   <lemma>schválený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W13</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W14</w.rf>
   <form>zprávě</form>
   <lemma>zpráva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W16</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W17</w.rf>
   <form>provedeno</form>
   <lemma>provést</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W19</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W20</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W21</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W23</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W24</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W26</w.rf>
   <form>32</form>
   <lemma>32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W27</w.rf>
   <form>zák</form>
   <lemma>zákon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W29</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W30</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W31</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W32</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s10W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s10W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s11">
  <m id="m-sample_data.txt-001-p6s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W2</w.rf>
   <form>odečtení</form>
   <lemma>odečtení_^(*4íst)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W3</w.rf>
   <form>nákladů</form>
   <lemma>náklad</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W4</w.rf>
   <form>spojených</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W5</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W6</w.rf>
   <form>správou</form>
   <lemma>správa</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W8</w.rf>
   <form>údržbou</form>
   <lemma>údržba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W9</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W10</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W12</w.rf>
   <form>přiznání</form>
   <lemma>přiznání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W13</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W14</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W16</w.rf>
   <form>nároku</form>
   <lemma>nárok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W17</w.rf>
   <form>odděleného</form>
   <lemma>oddělený_^(*3it)</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W18</w.rf>
   <form>věřitele</form>
   <lemma>věřitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W20</w.rf>
   <form>vyměření</form>
   <lemma>vyměření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W21</w.rf>
   <form>soudního</form>
   <lemma>soudní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W22</w.rf>
   <form>poplatku</form>
   <lemma>poplatek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W24</w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W25</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W26</w.rf>
   <form>rozdělení</form>
   <lemma>rozdělení_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W27</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W28</w.rf>
   <form>věřitele</form>
   <lemma>věřitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W29</w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W31</w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W32</w.rf>
   <form>částka</form>
   <lemma>částka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W33</w.rf>
   <form>15921636.70</form>
   <form_change>num_normalization</form_change>
   <lemma>15921636.70</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W34</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W35</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W36</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W37</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W38</w.rf>
   <form>rozdělena</form>
   <lemma>rozdělit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W39</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W40</w.rf>
   <form>poměru</form>
   <lemma>poměr_^(vztah_mezi_2_věcmi/lidmi)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W41</w.rf>
   <form>14927871</form>
   <form_change>num_normalization</form_change>
   <lemma>14927871</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W42</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W43</w.rf>
   <form>zjištěných</form>
   <lemma>zjištěný_^(*5stit)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W44</w.rf>
   <form>pohledávek</form>
   <lemma>pohledávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s11W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s11W45</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p6s12">
  <m id="m-sample_data.txt-001-p6s12W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s12W1</w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s12W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s12W2</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s12W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s12W3</w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s12W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s12W4</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s12W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s12W5</w.rf>
   <form>podstata</form>
   <lemma>podstata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s12W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s12W6</w.rf>
   <form>vyčerpána</form>
   <lemma>vyčerpat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p6s12W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p6s12W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p7s1">
  <m id="m-sample_data.txt-001-p7s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p7s2">
  <m id="m-sample_data.txt-001-p7s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W1</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W3</w.rf>
   <form>160</form>
   <lemma>160</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W5</w.rf>
   <form>94-664</form>
   <lemma>94-664</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W8</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W10</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W12</w.rf>
   <form>2003</form>
   <lemma>2003</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W14</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W15</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W16</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W18</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W20</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W22</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W23</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W24</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W25</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W27</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p7s3">
  <m id="m-sample_data.txt-001-p7s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W1</w.rf>
   <form>Správkyně</form>
   <lemma>správkyně_^(*4ce)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W5</w.rf>
   <form>Zuzana</form>
   <lemma>Zuzana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W6</w.rf>
   <form>Zlatohlávková</form>
   <lemma>zlatohlávkový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W8</w.rf>
   <form>Riegrovo</form>
   <lemma>Riegrův_;S_^(*2)</lemma>
   <tag>AUNS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W9</w.rf>
   <form>nám.</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W10</w.rf>
   <form>1493</form>
   <lemma>1493</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W12</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W13</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W14</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W15</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W17</w.rf>
   <form>oznámila</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W18</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W19</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W20</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W22</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W24</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W26</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W27</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W28</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W29</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W30</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s3W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p7s4">
  <m id="m-sample_data.txt-001-p7s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p7s5">
  <m id="m-sample_data.txt-001-p7s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W1</w.rf>
   <form>Správkyni</form>
   <lemma>správkyně_^(*4ce)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p7s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p7s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p8s1">
  <m id="m-sample_data.txt-001-p8s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p8s2">
  <m id="m-sample_data.txt-001-p8s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W2</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W3</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W4</w.rf>
   <form>93-2465-2477</form>
   <lemma>93-2465-2477</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W5</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W6</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W7</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W9</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W11</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W12</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W13</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W14</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W15</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W17</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W19</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W20</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W21</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W22</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W23</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W24</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W25</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W26</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s2W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p8s3">
  <m id="m-sample_data.txt-001-p8s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W5</w.rf>
   <form>Pavel</form>
   <lemma>Pavel-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W6</w.rf>
   <form>Moník</form>
   <lemma>Moník_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W8</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W9</w.rf>
   <form>sídlem</form>
   <lemma>sídlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W10</w.rf>
   <form>Střelecká</form>
   <lemma>střelecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W11</w.rf>
   <form>672</form>
   <lemma>672</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W13</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W14</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W15</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W16</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W18</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W19</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W20</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W21</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W23</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W25</w.rf>
   <form>2003</form>
   <lemma>2003</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W27</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W28</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W29</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W30</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W31</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s3W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p8s4">
  <m id="m-sample_data.txt-001-p8s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p8s5">
  <m id="m-sample_data.txt-001-p8s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p8s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p8s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p9s1">
  <m id="m-sample_data.txt-001-p9s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W2</w.rf>
   <form>12.7</form>
   <form_change>num_normalization</form_change>
   <lemma>12.7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W4</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W5</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W6</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W7</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W8</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W9</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W11</w.rf>
   <form>označené</form>
   <lemma>označený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W12</w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W13</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W14</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W15</w.rf>
   <form>30.5</form>
   <form_change>num_normalization</form_change>
   <lemma>30.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W17</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p9s2">
  <m id="m-sample_data.txt-001-p9s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W2</w.rf>
   <form>13.7</form>
   <form_change>num_normalization</form_change>
   <lemma>13.7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W4</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W5</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W6</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W7</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W9</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W10</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W11</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W12</w.rf>
   <form>splnil</form>
   <lemma>splnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p9s3">
  <m id="m-sample_data.txt-001-p9s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W2</w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W3</w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W4</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W5</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W6</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W7</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W8</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W9</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W10</w.rf>
   <form>písm.b</form>
   <lemma>písm.b</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W11</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W13</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W14</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W16</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W17</w.rf>
   <form>z.k.v</form>
   <lemma>z.k.v</lemma>
   <tag>AUMS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W19</w.rf>
   <form>rozhodl</form>
   <lemma>rozhodnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W20</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W22</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W23</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W24</w.rf>
   <form>uvedeno</form>
   <lemma>uvést</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W25</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W26</w.rf>
   <form>výroku</form>
   <lemma>výrok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s3W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p9s4">
  <m id="m-sample_data.txt-001-p9s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W2</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W3</w.rf>
   <form>povinnosti</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W4</w.rf>
   <form>uvedené</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W6</w.rf>
   <form>bodu</form>
   <lemma>bod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W7</w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W9</w.rf>
   <form>výroku</form>
   <lemma>výrok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W10</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W11</w.rf>
   <form>zprostí</form>
   <lemma>zprostit_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W12</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W13</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W14</w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p9s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p9s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p10s1">
  <m id="m-sample_data.txt-001-p10s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p10s2">
  <m id="m-sample_data.txt-001-p10s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W1</w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W3</w.rf>
   <form>1028</form>
   <lemma>1028</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W5</w.rf>
   <form>94-233</form>
   <lemma>94-233</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W8</w.rf>
   <form>30.10</form>
   <form_change>num_normalization</form_change>
   <lemma>30.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W10</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W13</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W14</w.rf>
   <form>30.11</form>
   <form_change>num_normalization</form_change>
   <lemma>30.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W16</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W18</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W19</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W20</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W21</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W23</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p10s3">
  <m id="m-sample_data.txt-001-p10s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W4</w.rf>
   <form>Ing.</form>
   <lemma>Ing-1_:B_,x_^(inženýr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W5</w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W6</w.rf>
   <form>Hýbl</form>
   <lemma>Hýbl_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W8</w.rf>
   <form>tř</form>
   <lemma>třída_:B</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p10s4">
  <m id="m-sample_data.txt-001-p10s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W1</w.rf>
   <form>ČSA</form>
   <lemma>ČSA-1_:B_;K_^(Čs./České_aerolinie)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W2</w.rf>
   <form>383</form>
   <lemma>383</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W4</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W5</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W6</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W7</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W9</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W10</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W12</w.rf>
   <form>7.12</form>
   <form_change>num_normalization</form_change>
   <lemma>7.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W14</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W16</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W17</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W18</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W19</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W20</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s4W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p10s5">
  <m id="m-sample_data.txt-001-p10s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s5W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s5W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p10s6">
  <m id="m-sample_data.txt-001-p10s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p10s6W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p10s6W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p11s1">
  <m id="m-sample_data.txt-001-p11s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p11s2">
  <m id="m-sample_data.txt-001-p11s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W1</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W3</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W5</w.rf>
   <form>95-1124</form>
   <lemma>95-1124</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W8</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W10</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W12</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W14</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W15</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W16</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W18</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W20</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W22</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W23</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W24</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W25</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W27</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p11s3">
  <m id="m-sample_data.txt-001-p11s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W5</w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W6</w.rf>
   <form>Koubík</form>
   <lemma>Koubík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W8</w.rf>
   <form>Letců</form>
   <lemma>letec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W9</w.rf>
   <form>1005</form>
   <lemma>1005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W11</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W12</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W13</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W14</w.rf>
   <form>Králové</form>
   <lemma>Králové_;G_^(Dvůr_Králové)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W15</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W17</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W18</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W19</w.rf>
   <form>podáním</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W20</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W21</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W22</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W24</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W26</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W28</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W29</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W30</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W31</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W32</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s3W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p11s4">
  <m id="m-sample_data.txt-001-p11s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p11s5">
  <m id="m-sample_data.txt-001-p11s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p11s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p11s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s1">
  <m id="m-sample_data.txt-001-p12s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W8</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W9</w.rf>
   <form>29.3</form>
   <form_change>num_normalization</form_change>
   <lemma>29.3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W11</w.rf>
   <form>1996</form>
   <lemma>1996</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W13</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W14</w.rf>
   <form>j</form>
   <lemma>j-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s2">
  <m id="m-sample_data.txt-001-p12s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W1</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W3</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W5</w.rf>
   <form>95-151</form>
   <lemma>95-151</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W8</w.rf>
   <form>prohlášen</form>
   <lemma>prohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W9</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W11</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W12</w.rf>
   <form>dlužníka</form>
   <lemma>dlužník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W13</w.rf>
   <form>Zemědělské</form>
   <lemma>zemědělský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W14</w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W15</w.rf>
   <form>Smržov</form>
   <lemma>Smržov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W17</w.rf>
   <form>likvidaci</form>
   <lemma>likvidace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W19</w.rf>
   <form>IČ</form>
   <lemma>Ič</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W20</w.rf>
   <form>00123951</form>
   <lemma>00123951</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W22</w.rf>
   <form>503</form>
   <lemma>503</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W23</w.rf>
   <form>03</form>
   <lemma>03</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W24</w.rf>
   <form>Smiřice</form>
   <lemma>Smiřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W26</w.rf>
   <form>správcem</form>
   <lemma>správce</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W27</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W28</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W29</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W30</w.rf>
   <form>ustaven</form>
   <lemma>ustavit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W31</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W32</w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W33</w.rf>
   <form>Koubík</form>
   <lemma>Koubík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W34</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W35</w.rf>
   <form>Letců</form>
   <lemma>letec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W36</w.rf>
   <form>1005</form>
   <lemma>1005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W37</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W38</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W39</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W40</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W41</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W42</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s2W43</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s3">
  <m id="m-sample_data.txt-001-p12s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W1</w.rf>
   <form>Podáním</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W2</w.rf>
   <form>doručeným</form>
   <lemma>doručený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W4</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W5</w.rf>
   <form>17.4</form>
   <form_change>num_normalization</form_change>
   <lemma>17.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W7</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W8</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W9</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W10</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W11</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W12</w.rf>
   <form>konečnou</form>
   <lemma>konečný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W13</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W14</w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W16</w.rf>
   <form>vyúčtováním</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W17</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W19</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W20</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s4">
  <m id="m-sample_data.txt-001-p12s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W1</w.rf>
   <form>Konečná</form>
   <lemma>konečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W2</w.rf>
   <form>zpráva</form>
   <lemma>zpráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W4</w.rf>
   <form>projednána</form>
   <lemma>projednat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W5</w.rf>
   <form>postupem</form>
   <lemma>postup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W6</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W7</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W9</w.rf>
   <form>§29</form>
   <lemma>§29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W10</w.rf>
   <form>zák</form>
   <lemma>zákon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W12</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W13</w.rf>
   <form>328</form>
   <lemma>328</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W14</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W15</w.rf>
   <form>1991</form>
   <lemma>1991</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W16</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W19</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W20</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W22</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W24</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W25</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W26</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W27</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W28</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W29</w.rf>
   <form>ZKV</form>
   <lemma>Zkv</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W30</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s4W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s5">
  <m id="m-sample_data.txt-001-p12s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W4</w.rf>
   <form>13.12</form>
   <form_change>num_normalization</form_change>
   <lemma>13.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W6</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W8</w.rf>
   <form>č.j</form>
   <lemma>č.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s6">
  <m id="m-sample_data.txt-001-p12s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W1</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W3</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W5</w.rf>
   <form>95-1018</form>
   <lemma>95-1018</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W7</w.rf>
   <form>jež</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJNS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W8</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W9</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W10</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W12</w.rf>
   <form>4.8</form>
   <form_change>num_normalization</form_change>
   <lemma>4.8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W14</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W15</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W16</w.rf>
   <form>konečná</form>
   <lemma>konečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W17</w.rf>
   <form>zpráva</form>
   <lemma>zpráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W19</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W20</w.rf>
   <form>vyúčtování</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W21</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W22</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W24</w.rf>
   <form>hotových</form>
   <lemma>hotový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W25</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W27</w.rf>
   <form>schválena</form>
   <lemma>schválit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s6W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s6W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s7">
  <m id="m-sample_data.txt-001-p12s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W1</w.rf>
   <form>Soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W2</w.rf>
   <form>vyměřil</form>
   <lemma>vyměřit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W3</w.rf>
   <form>soudní</form>
   <lemma>soudní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W4</w.rf>
   <form>poplatek</form>
   <lemma>poplatek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W5</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W6</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W7</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W9</w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W10</w.rf>
   <form>64551</form>
   <form_change>num_normalization</form_change>
   <lemma>64551</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W14</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W15</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W16</w.rf>
   <form>položky</form>
   <lemma>položka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W17</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W18</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W22</w.rf>
   <form>sazebníku</form>
   <lemma>sazebník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W23</w.rf>
   <form>soudních</form>
   <lemma>soudní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W24</w.rf>
   <form>poplatků</form>
   <lemma>poplatek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W26</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W27</w.rf>
   <form>tvoří</form>
   <lemma>tvořit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W28</w.rf>
   <form>přílohu</form>
   <lemma>příloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W29</w.rf>
   <form>zák</form>
   <lemma>zákon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W31</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W32</w.rf>
   <form>549</form>
   <lemma>549</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W33</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W34</w.rf>
   <form>1991</form>
   <lemma>1991</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W35</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W37</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W38</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W39</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W40</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W41</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W42</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W43</w.rf>
   <form>uložil</form>
   <lemma>uložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W44</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W45</w.rf>
   <form>zaplatit</form>
   <lemma>zaplatit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W46</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W47</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W48</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W49</w.rf>
   <form>dnů</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W50</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W51</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W52</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W53</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W54</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W55</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s7W56-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s7W56</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s8">
  <m id="m-sample_data.txt-001-p12s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W1</w.rf>
   <form>Návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W2</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W3</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W4</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W5</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W6</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W8</w.rf>
   <form>22.12</form>
   <form_change>num_normalization</form_change>
   <lemma>22.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W10</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s8W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s9">
  <m id="m-sample_data.txt-001-p12s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W1</w.rf>
   <form>Rozdělení</form>
   <lemma>rozdělení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W2</w.rf>
   <form>výtěžku</form>
   <lemma>výtěžek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W3</w.rf>
   <form>získaného</form>
   <lemma>získaný_^(*2t)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W4</w.rf>
   <form>zpeněžením</form>
   <lemma>zpeněžení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W5</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W6</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W7</w.rf>
   <form>vychází</form>
   <lemma>vycházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W9</w.rf>
   <form>údajů</form>
   <lemma>údaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W10</w.rf>
   <form>obsažených</form>
   <lemma>obsažený_^(*5áhnout)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W11</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W12</w.rf>
   <form>schválené</form>
   <lemma>schválený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W13</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W14</w.rf>
   <form>zprávě</form>
   <lemma>zpráva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W16</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W17</w.rf>
   <form>provedeno</form>
   <lemma>provést</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W19</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W20</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W21</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W23</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W24</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W26</w.rf>
   <form>32</form>
   <lemma>32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W27</w.rf>
   <form>ZKV</form>
   <lemma>ZKV</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s9W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s9W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s10">
  <m id="m-sample_data.txt-001-p12s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W2</w.rf>
   <form>konkurzním</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W3</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W5</w.rf>
   <form>zpeněženo</form>
   <lemma>zpeněžit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W6</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W7</w.rf>
   <form>6455005.95</form>
   <form_change>num_normalization</form_change>
   <lemma>6455005.95</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W8</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s10W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s11">
  <m id="m-sample_data.txt-001-p12s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W1</w.rf>
   <form>Připočtena</form>
   <lemma>připočíst</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W3</w.rf>
   <form>částka</form>
   <lemma>částka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W4</w.rf>
   <form>247068</form>
   <form_change>num_normalization</form_change>
   <lemma>247068</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W8</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W9</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W10</w.rf>
   <form>přirostlé</form>
   <lemma>přirostlý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W11</w.rf>
   <form>úroky</form>
   <lemma>úrok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W13</w.rf>
   <form>běžném</form>
   <lemma>běžný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W14</w.rf>
   <form>účtu</form>
   <lemma>účet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W16</w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W17</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W18</w.rf>
   <form>předložení</form>
   <lemma>předložení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W19</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W20</w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W21</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W22</w.rf>
   <form>předložení</form>
   <lemma>předložení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W23</w.rf>
   <form>návrhu</form>
   <lemma>návrh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W25</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W26</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s11W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s11W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s12">
  <m id="m-sample_data.txt-001-p12s12W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W1</w.rf>
   <form>Celkové</form>
   <lemma>celkový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W2</w.rf>
   <form>výdaje</form>
   <lemma>výdaj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W4</w.rf>
   <form>vyplacené</form>
   <lemma>vyplacený_^(*4tit)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W5</w.rf>
   <form>nároky</form>
   <lemma>nárok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W6</w.rf>
   <form>věřitelů</form>
   <lemma>věřitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W8</w.rf>
   <form>oddělené</form>
   <lemma>oddělený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W9</w.rf>
   <form>uspokojení</form>
   <lemma>uspokojení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W10</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W11</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W12</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W13</w.rf>
   <form>ZKV</form>
   <lemma>Zkv</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W14</w.rf>
   <form>469826.91</form>
   <form_change>num_normalization</form_change>
   <lemma>469826.91</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W15</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W17</w.rf>
   <form>pohledávky</form>
   <lemma>pohledávka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W18</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W19</w.rf>
   <form>podstatou</form>
   <lemma>podstata</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W20</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W21</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W22</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W23</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W24</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W25</w.rf>
   <form>ZKV</form>
   <lemma>Zkv</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W26</w.rf>
   <form>3132102.23</form>
   <form_change>num_normalization</form_change>
   <lemma>3132102.23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W27</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W29</w.rf>
   <form>pracovní</form>
   <lemma>pracovní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W30</w.rf>
   <form>nároky</form>
   <lemma>nárok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W31</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W32</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W33</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W34</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W35</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W36</w.rf>
   <form>ZKV</form>
   <lemma>Zkv</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W37</w.rf>
   <form>606380</form>
   <form_change>num_normalization</form_change>
   <lemma>606380</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W38</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W39</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W40</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W41</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W42</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W43</w.rf>
   <form>činily</form>
   <lemma>činit_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W44</w.rf>
   <form>částku</form>
   <lemma>částka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W45</w.rf>
   <form>4208309</form>
   <form_change>num_normalization</form_change>
   <lemma>4208309</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W46</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W47</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W48</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W49</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s12W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s12W50</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s13">
  <m id="m-sample_data.txt-001-p12s13W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W1</w.rf>
   <form>Mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W2</w.rf>
   <form>věřitele</form>
   <lemma>věřitel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W4</w.rf>
   <form>rozdělena</form>
   <lemma>rozdělit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W5</w.rf>
   <form>částka</form>
   <lemma>částka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W6</w.rf>
   <form>2182145.81</form>
   <form_change>num_normalization</form_change>
   <lemma>2182145.81</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W7</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W8</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W10</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W11</w.rf>
   <form>věřitelé</form>
   <lemma>věřitel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W12</w.rf>
   <form>pohledávek</form>
   <lemma>pohledávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W13</w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W15</w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W16</w.rf>
   <form>obdrží</form>
   <lemma>obdržet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W17</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W18</w.rf>
   <form>263496</form>
   <form_change>num_normalization</form_change>
   <lemma>263496</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W22</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W24</w.rf>
   <form>tj.</form>
   <lemma>tj-1_:B_^(to_je/jest)</lemma>
   <tag>J^------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W25</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W26</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W27</w.rf>
   <form>zjištěných</form>
   <lemma>zjištěný_^(*5stit)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W28</w.rf>
   <form>pohledávek</form>
   <lemma>pohledávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W30</w.rf>
   <form>věřitelé</form>
   <lemma>věřitel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W31</w.rf>
   <form>pohledávek</form>
   <lemma>pohledávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W32</w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W34</w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W35</w.rf>
   <form>obdrží</form>
   <lemma>obdržet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W36</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W37</w.rf>
   <form>1918649.81</form>
   <form_change>num_normalization</form_change>
   <lemma>1918649.81</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W38</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W39</w.rf>
   <form>tj.</form>
   <lemma>tj-1_:B_^(to_je/jest)</lemma>
   <tag>J^------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W40</w.rf>
   <form>41160767</form>
   <form_change>num_normalization</form_change>
   <lemma>41160767</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W41</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W42</w.rf>
   <form>zjištěných</form>
   <lemma>zjištěný_^(*5stit)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W43</w.rf>
   <form>pohledávek</form>
   <lemma>pohledávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s13W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s13W44</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s14">
  <m id="m-sample_data.txt-001-p12s14W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s14W1</w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s14W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s14W2</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s14W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s14W3</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s14W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s14W4</w.rf>
   <form>podstata</form>
   <lemma>podstata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s14W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s14W5</w.rf>
   <form>vyčerpána</form>
   <lemma>vyčerpat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s14W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s14W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s15">
  <m id="m-sample_data.txt-001-p12s15W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W5</w.rf>
   <form>ukládá</form>
   <lemma>ukládat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W6</w.rf>
   <form>uložit</form>
   <lemma>uložit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W8</w.rf>
   <form>soudní</form>
   <lemma>soudní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W9</w.rf>
   <form>úschovy</form>
   <lemma>úschova</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W10</w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W11</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W12</w.rf>
   <form>místně</form>
   <lemma>místně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W13</w.rf>
   <form>příslušného</form>
   <lemma>příslušný_^(*2et)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W14</w.rf>
   <form>okresního</form>
   <lemma>okresní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W15</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W16</w.rf>
   <form>částku</form>
   <lemma>částka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W18</w.rf>
   <form>připadající</form>
   <lemma>připadající_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W20</w.rf>
   <form>zemřelého</form>
   <lemma>zemřelý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W21</w.rf>
   <form>věřitele</form>
   <lemma>věřitel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s15W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s15W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s16">
  <m id="m-sample_data.txt-001-p12s16W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W1</w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W2</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W3</w.rf>
   <form>značnému</form>
   <lemma>značný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W4</w.rf>
   <form>počtu</form>
   <lemma>počet</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W5</w.rf>
   <form>úmrtí</form>
   <lemma>úmrtí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W6</w.rf>
   <form>věřitelů</form>
   <lemma>věřitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W8</w.rf>
   <form>přičemž</form>
   <lemma>přičemž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W9</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W10</w.rf>
   <form>zjištěné</form>
   <lemma>zjištěný_^(*5stit)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W11</w.rf>
   <form>pohledávky</form>
   <lemma>pohledávka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W12</w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W13</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W14</w.rf>
   <form>předmětem</form>
   <lemma>předmět</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W15</w.rf>
   <form>dědického</form>
   <lemma>dědický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W16</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W18</w.rf>
   <form>ukládá</form>
   <lemma>ukládat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W19</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W21</w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W22</w.rf>
   <form>svého</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W23</w.rf>
   <form>dohledu</form>
   <lemma>dohled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W24</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W25</w.rf>
   <form>uložit</form>
   <lemma>uložit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W26</w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W27</w.rf>
   <form>částky</form>
   <lemma>částka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W28</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W29</w.rf>
   <form>soudních</form>
   <lemma>soudní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W30</w.rf>
   <form>úschov</form>
   <lemma>úschova</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W31</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W32</w.rf>
   <form>příslušných</form>
   <lemma>příslušný_^(*2et)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W33</w.rf>
   <form>okresních</form>
   <lemma>okresní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W34</w.rf>
   <form>soudů</form>
   <lemma>soud</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s16W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s16W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p12s17">
  <m id="m-sample_data.txt-001-p12s17W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W2</w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W3</w.rf>
   <form>urychlení</form>
   <lemma>urychlení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W4</w.rf>
   <form>výplaty</form>
   <lemma>výplata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W5</w.rf>
   <form>věřitelů</form>
   <lemma>věřitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W7</w.rf>
   <form>vyzývá</form>
   <lemma>vyzývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W8</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W9</w.rf>
   <form>věřitele</form>
   <lemma>věřitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W10</w.rf>
   <form>uvedené</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W11</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W12</w.rf>
   <form>výroku</form>
   <lemma>výrok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W13</w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W16</w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W19</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W20</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W21</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W22</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W23</w.rf>
   <form>sdělili</form>
   <lemma>sdělit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W24</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8NS4---------1</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W25</w.rf>
   <form>bankovní</form>
   <lemma>bankovní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W26</w.rf>
   <form>spojení</form>
   <lemma>spojení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W28</w.rf>
   <form>případně</form>
   <lemma>případně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W29</w.rf>
   <form>adresu</form>
   <lemma>adresa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W30</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W31</w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W32</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W33</w.rf>
   <form>přináležející</form>
   <lemma>přináležející_^(*4t)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W34</w.rf>
   <form>částky</form>
   <lemma>částka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W35</w.rf>
   <form>poukázat</form>
   <lemma>poukázat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p12s17W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p12s17W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p13s1">
  <m id="m-sample_data.txt-001-p13s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s1W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s1W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s1W4</w.rf>
   <form>29.1</form>
   <form_change>num_normalization</form_change>
   <lemma>29.1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s1W6</w.rf>
   <form>2003</form>
   <lemma>2003</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s1W7</w.rf>
   <form>č.j</form>
   <lemma>č.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p13s2">
  <m id="m-sample_data.txt-001-p13s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W1</w.rf>
   <form>126</form>
   <lemma>126</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W3</w.rf>
   <form>72</form>
   <lemma>72</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W5</w.rf>
   <form>97-411</form>
   <lemma>97-411</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W7</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W8</w.rf>
   <form>konkurs</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W10</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W11</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W13</w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W14</w.rf>
   <form>úmrtí</form>
   <lemma>úmrtí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W15</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s2W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p13s3">
  <m id="m-sample_data.txt-001-p13s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W1</w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W2</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W3</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W4</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W5</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W6</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W7</w.rf>
   <form>29.3</form>
   <form_change>num_normalization</form_change>
   <lemma>29.3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W9</w.rf>
   <form>2003</form>
   <lemma>2003</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p13s4">
  <m id="m-sample_data.txt-001-p13s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W1</w.rf>
   <form>Soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W2</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W3</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W4</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W5</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W7</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W8</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W9</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W10</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W11</w.rf>
   <form>z</form>
   <lemma>z-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W13</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W14</w.rf>
   <form>328</form>
   <lemma>328</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W15</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W16</w.rf>
   <form>1999</form>
   <lemma>1999</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W17</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W19</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W20</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W21</w.rf>
   <form>pozdějších</form>
   <lemma>pozdní-1_^(v_krátkém_čase,_následující_o_něco_později)</lemma>
   <tag>AAIP2----2A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W22</w.rf>
   <form>předpisů</form>
   <lemma>předpis</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W23</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W24</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W25</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W26</w.rf>
   <form>konkursu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W28</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W30</w.rf>
   <form>zprostil</form>
   <lemma>zprostit_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W31</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W32</w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p13s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p13s4W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p14s1">
  <m id="m-sample_data.txt-001-p14s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p14s2">
  <m id="m-sample_data.txt-001-p14s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W1</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W3</w.rf>
   <form>48</form>
   <lemma>48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W5</w.rf>
   <form>95-169</form>
   <lemma>95-169</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W8</w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W10</w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W12</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W14</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W15</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W16</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W18</w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W20</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W22</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W23</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W24</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W25</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W27</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p14s3">
  <m id="m-sample_data.txt-001-p14s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W5</w.rf>
   <form>Pavel</form>
   <lemma>Pavel-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W6</w.rf>
   <form>Barinka</form>
   <lemma>Barinka</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W8</w.rf>
   <form>Soudní</form>
   <lemma>soudní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W9</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W11</w.rf>
   <form>568</form>
   <lemma>568</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W12</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W13</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W15</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W16</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W17</w.rf>
   <form>dopisem</form>
   <lemma>dopis</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W18</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W19</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W20</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W22</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W24</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W26</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W27</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W28</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W29</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W30</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s3W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p14s4">
  <m id="m-sample_data.txt-001-p14s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p14s5">
  <m id="m-sample_data.txt-001-p14s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p14s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p14s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p15s1">
  <m id="m-sample_data.txt-001-p15s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W2</w.rf>
   <form>1.9</form>
   <form_change>num_normalization</form_change>
   <lemma>1.9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W4</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W5</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W6</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W7</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W8</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W9</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W11</w.rf>
   <form>označené</form>
   <lemma>označený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W12</w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W13</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W14</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W15</w.rf>
   <form>21.7</form>
   <form_change>num_normalization</form_change>
   <lemma>21.7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W17</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s1W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p15s2">
  <m id="m-sample_data.txt-001-p15s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W2</w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W3</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W4</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W5</w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W6</w.rf>
   <form>přiznávány</form>
   <lemma>přiznávat_:T_^(*4at)</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W7</w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W8</w.rf>
   <form>částky</form>
   <lemma>částka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W9</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W10</w.rf>
   <form>uspokojení</form>
   <lemma>uspokojení_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W11</w.rf>
   <form>věřitelů</form>
   <lemma>věřitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W13</w.rf>
   <form>neboť</form>
   <lemma>neboť</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W14</w.rf>
   <form>výtěžek</form>
   <lemma>výtěžek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W15</w.rf>
   <form>konkursní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W16</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W17</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W18</w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W19</w.rf>
   <form>vyčerpán</form>
   <lemma>vyčerpat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W20</w.rf>
   <form>uspokojením</form>
   <lemma>uspokojení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W21</w.rf>
   <form>pohledávek</form>
   <lemma>pohledávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W22</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W23</w.rf>
   <form>podstatou</form>
   <lemma>podstata</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W25</w.rf>
   <form>t.j</form>
   <lemma>t.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W27</w.rf>
   <form>hotových</form>
   <lemma>hotový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W28</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W29</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W31</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W32</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W33</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W34</w.rf>
   <form>zaplacením</form>
   <lemma>zaplacení_^(*4tit)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W35</w.rf>
   <form>soudního</form>
   <lemma>soudní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W36</w.rf>
   <form>poplatku</form>
   <lemma>poplatek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s2W37</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p15s3">
  <m id="m-sample_data.txt-001-p15s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W2</w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W3</w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W4</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W5</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W6</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W7</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W8</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W9</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W10</w.rf>
   <form>písm.b</form>
   <lemma>písm.b</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W11</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W13</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W14</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W16</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W17</w.rf>
   <form>z.k.v</form>
   <lemma>z.k.v</lemma>
   <tag>AUMS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W19</w.rf>
   <form>rozhodl</form>
   <lemma>rozhodnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W20</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W22</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W23</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W24</w.rf>
   <form>uvedeno</form>
   <lemma>uvést</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W25</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W26</w.rf>
   <form>výroku</form>
   <lemma>výrok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s3W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p15s4">
  <m id="m-sample_data.txt-001-p15s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W2</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W3</w.rf>
   <form>povinnosti</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W4</w.rf>
   <form>uvedené</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W6</w.rf>
   <form>bodu</form>
   <lemma>bod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W7</w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W9</w.rf>
   <form>výroku</form>
   <lemma>výrok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W10</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W11</w.rf>
   <form>zprostí</form>
   <lemma>zprostit_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W12</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W13</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W14</w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p15s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p15s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p16s1">
  <m id="m-sample_data.txt-001-p16s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s1W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s1W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s1W4</w.rf>
   <form>24.2</form>
   <form_change>num_normalization</form_change>
   <lemma>24.2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s1W6</w.rf>
   <form>1999</form>
   <lemma>1999</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s1W7</w.rf>
   <form>č.j</form>
   <lemma>č.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p16s2">
  <m id="m-sample_data.txt-001-p16s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W1</w.rf>
   <form>126</form>
   <lemma>126</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W3</w.rf>
   <form>72</form>
   <lemma>72</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W5</w.rf>
   <form>97-161</form>
   <lemma>97-161</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W6</w.rf>
   <form>Krajský</form>
   <lemma>krajský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W7</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W9</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W10</w.rf>
   <form>prohlásil</form>
   <lemma>prohlásit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W11</w.rf>
   <form>konkurs</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W13</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W14</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p16s3">
  <m id="m-sample_data.txt-001-p16s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W1</w.rf>
   <form>Správcem</form>
   <lemma>správce</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W2</w.rf>
   <form>konkursní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W5</w.rf>
   <form>ustanovena</form>
   <lemma>ustanovit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W6</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W7</w.rf>
   <form>Jana</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W8</w.rf>
   <form>Sedláčková</form>
   <lemma>Sedláčková_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W10</w.rf>
   <form>advokátka</form>
   <lemma>advokátka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W11</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W12</w.rf>
   <form>sídlem</form>
   <lemma>sídlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W14</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p16s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p16s3W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p17s1">
  <m id="m-sample_data.txt-001-p17s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W1</w.rf>
   <form>Správkyně</form>
   <lemma>správkyně_^(*4ce)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W2</w.rf>
   <form>konkursní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W4</w.rf>
   <form>předložila</form>
   <lemma>předložit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W5</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W6</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W7</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W8</w.rf>
   <form>dosavadních</form>
   <lemma>dosavadní</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W9</w.rf>
   <form>výsledcích</form>
   <lemma>výsledek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W10</w.rf>
   <form>konkursu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W12</w.rf>
   <form>vyúčtování</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W13</w.rf>
   <form>hotových</form>
   <lemma>hotový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W14</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W16</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W17</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W18</w.rf>
   <form>konkursní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W19</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W20</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W21</w.rf>
   <form>11.10</form>
   <form_change>num_normalization</form_change>
   <lemma>11.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W23</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W24</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W25</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W26</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W27</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W28</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W29</w.rf>
   <form>ZKV</form>
   <lemma>ZKV</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s1W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p17s2">
  <m id="m-sample_data.txt-001-p17s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W1</w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W2</w.rf>
   <form>zpráva</form>
   <lemma>zpráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W5</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W6</w.rf>
   <form>sdělení</form>
   <lemma>sdělení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W7</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W8</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W9</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W10</w.rf>
   <form>16.10</form>
   <form_change>num_normalization</form_change>
   <lemma>16.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W12</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W13</w.rf>
   <form>vyvěšena</form>
   <lemma>vyvěsit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W15</w.rf>
   <form>úřední</form>
   <lemma>úřední</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W16</w.rf>
   <form>desce</form>
   <lemma>deska</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W17</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W18</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W19</w.rf>
   <form>30.10</form>
   <form_change>num_normalization</form_change>
   <lemma>30.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W21</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s2W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p17s3">
  <m id="m-sample_data.txt-001-p17s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W1</w.rf>
   <form>Jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W2</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W3</w.rf>
   <form>zprávě</form>
   <lemma>zpráva</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W4</w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W5</w.rf>
   <form>podány</form>
   <lemma>podat_:W_^(něco_[někomu]_[někam])</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W7</w.rf>
   <form>zákonné</form>
   <lemma>zákonný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W8</w.rf>
   <form>lhůtě</form>
   <lemma>lhůta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W9</w.rf>
   <form>námitky</form>
   <lemma>námitka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W11</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W12</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W13</w.rf>
   <form>přezkoumal</form>
   <lemma>přezkoumat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W15</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W16</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W20</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W22</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W24</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W25</w.rf>
   <form>ZKV</form>
   <lemma>ZKV</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W27</w.rf>
   <form>usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W28</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W29</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W30</w.rf>
   <form>20.11</form>
   <form_change>num_normalization</form_change>
   <lemma>20.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W32</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W33</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W34</w.rf>
   <form>schválil</form>
   <lemma>schválit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s3W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s3W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p17s4">
  <m id="m-sample_data.txt-001-p17s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W2</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W3</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W5</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W7</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W9</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W10</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W11</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W12</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W13</w.rf>
   <form>ZKV</form>
   <lemma>ZKV</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W15</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W16</w.rf>
   <form>schválení</form>
   <lemma>schválení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W17</w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W18</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W19</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W20</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W21</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W22</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W23</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W24</w.rf>
   <form>21.1</form>
   <form_change>num_normalization</form_change>
   <lemma>21.1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W26</w.rf>
   <form>2003</form>
   <lemma>2003</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W27</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W28</w.rf>
   <form>konkurs</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W29</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W30</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W31</w.rf>
   <form>důvodu</form>
   <lemma>důvod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W32</w.rf>
   <form>úmrtí</form>
   <lemma>úmrtí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W33</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s4W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p17s5">
  <m id="m-sample_data.txt-001-p17s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W2</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W3</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W4</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W5</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W7</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W8</w.rf>
   <form>spis</form>
   <lemma>spis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W9</w.rf>
   <form>postoupen</form>
   <lemma>postoupit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W10</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W12</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W13</w.rf>
   <form>projednává</form>
   <lemma>projednávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W14</w.rf>
   <form>dědictví</form>
   <lemma>dědictví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p17s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p17s5W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s1">
  <m id="m-sample_data.txt-001-p18s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W1</w.rf>
   <form>Dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W2</w.rf>
   <form>24.2</form>
   <form_change>num_normalization</form_change>
   <lemma>24.2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W4</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W5</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W6</w.rf>
   <form>prohlášen</form>
   <lemma>prohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W7</w.rf>
   <form>konkurs</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W9</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W10</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s1W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s2">
  <m id="m-sample_data.txt-001-p18s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W1</w.rf>
   <form>Podáním</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W2</w.rf>
   <form>10.10</form>
   <form_change>num_normalization</form_change>
   <lemma>10.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W4</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W5</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W6</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W7</w.rf>
   <form>9.10</form>
   <form_change>num_normalization</form_change>
   <lemma>9.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W9</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W10</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W11</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W12</w.rf>
   <form>sděleno</form>
   <lemma>sdělit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W14</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W15</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W16</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W17</w.rf>
   <form>2.7</form>
   <form_change>num_normalization</form_change>
   <lemma>2.7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W19</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W20</w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s2W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s3">
  <m id="m-sample_data.txt-001-p18s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W1</w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W3</w.rf>
   <form>doloženo</form>
   <lemma>doložit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W4</w.rf>
   <form>úmrtním</form>
   <lemma>úmrtní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W5</w.rf>
   <form>listem</form>
   <lemma>list</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W6</w.rf>
   <form>vydaným</form>
   <lemma>vydaný-1_^(emitovat:_cenné_papíry,_knihu,_zvuk,...)_(*4t-1)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W7</w.rf>
   <form>Úřadem</form>
   <lemma>úřad</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W8</w.rf>
   <form>městské</form>
   <lemma>městský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W9</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W10</w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W12</w.rf>
   <form>Brno</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W14</w.rf>
   <form>střed</form>
   <lemma>střed</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W15</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W16</w.rf>
   <form>15.7</form>
   <form_change>num_normalization</form_change>
   <lemma>15.7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s3W18</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s4">
  <m id="m-sample_data.txt-001-p18s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W1</w.rf>
   <form>Dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W2</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W3</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W4</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W5</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W6</w.rf>
   <form>ZKV</form>
   <lemma>ZKV</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W8</w.rf>
   <form>jestliže</form>
   <lemma>jestliže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W9</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W10</w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W12</w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W13</w.rf>
   <form>konkursu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W15</w.rf>
   <form>podá</form>
   <lemma>podat_:W_^(něco_[někomu]_[někam])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W16</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W17</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W18</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W19</w.rf>
   <form>dosavadních</form>
   <lemma>dosavadní</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W20</w.rf>
   <form>výsledcích</form>
   <lemma>výsledek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W21</w.rf>
   <form>konkursu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W23</w.rf>
   <form>předloží</form>
   <lemma>předložit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W24</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W25</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s4W26</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s5">
  <m id="m-sample_data.txt-001-p18s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W1</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W2</w.rf>
   <form>vyhotovení</form>
   <lemma>vyhotovení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W3</w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W5</w.rf>
   <form>postupuje</form>
   <lemma>postupovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W6</w.rf>
   <form>přiměřeně</form>
   <lemma>přiměřeně_^(*3it)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W7</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W8</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W9</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W10</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W11</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W13</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s5W14</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s6">
  <m id="m-sample_data.txt-001-p18s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W1</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W2</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W3</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W4</w.rf>
   <form>vstupují</form>
   <lemma>vstupovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W5</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W6</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W7</w.rf>
   <form>dědici</form>
   <lemma>dědice_^(zdrobnělina_k_děd)_(*3ík)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W10</w.rf>
   <form>není-li</form>
   <lemma>není-li</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W11</w.rf>
   <form>jich</form>
   <lemma>on-1</lemma>
   <tag>PPXP2--3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W13</w.rf>
   <form>stát</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s6W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s7">
  <m id="m-sample_data.txt-001-p18s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W2</w.rf>
   <form>schválení</form>
   <lemma>schválení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W3</w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W4</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W5</w.rf>
   <form>zruší</form>
   <lemma>zrušit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W6</w.rf>
   <form>konkurs</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W8</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W9</w.rf>
   <form>postoupí</form>
   <lemma>postoupit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W10</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W12</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W13</w.rf>
   <form>projednává</form>
   <lemma>projednávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W14</w.rf>
   <form>dědictví</form>
   <lemma>dědictví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s7W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s8">
  <m id="m-sample_data.txt-001-p18s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W2</w.rf>
   <form>konkursní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W4</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W5</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W6</w.rf>
   <form>10.10</form>
   <form_change>num_normalization</form_change>
   <lemma>10.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W8</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W9</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W10</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W11</w.rf>
   <form>specifikovanou</form>
   <lemma>specifikovaný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W12</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s8W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s9">
  <m id="m-sample_data.txt-001-p18s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s9W1</w.rf>
   <form>Soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s9W2</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s9W3</w.rf>
   <form>přezkoumal</form>
   <lemma>přezkoumat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s9W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s9W5</w.rf>
   <form>nezjistil</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s9W6</w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWYP4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s9W7</w.rf>
   <form>nedostatky</form>
   <lemma>nedostatek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s9W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s10">
  <m id="m-sample_data.txt-001-p18s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W1</w.rf>
   <form>Proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W2</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W3</w.rf>
   <form>zprávě</form>
   <lemma>zpráva</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W5</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W8</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W9</w.rf>
   <form>sdělení</form>
   <lemma>sdělení_^(*3it)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W10</w.rf>
   <form>účastníkům</form>
   <lemma>účastník</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W11</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W12</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W13</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W14</w.rf>
   <form>16.10</form>
   <form_change>num_normalization</form_change>
   <lemma>16.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W16</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W17</w.rf>
   <form>vyvěšena</form>
   <lemma>vyvěsit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W18</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W19</w.rf>
   <form>30.10</form>
   <form_change>num_normalization</form_change>
   <lemma>30.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W21</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W23</w.rf>
   <form>úřední</form>
   <lemma>úřední</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W24</w.rf>
   <form>desku</form>
   <lemma>deska</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W25</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W26</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W28</w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W30</w.rf>
   <form>pracoviště</form>
   <lemma>pracoviště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W31</w.rf>
   <form>Husova</form>
   <lemma>Husův_;S_^(*2)</lemma>
   <tag>AUNP1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W32</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W33</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W34</w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W35</w.rf>
   <form>podány</form>
   <lemma>podat_:W_^(něco_[někomu]_[někam])</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W36</w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W37</w.rf>
   <form>námitky</form>
   <lemma>námitka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s10W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s10W38</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p18s11">
  <m id="m-sample_data.txt-001-p18s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s11W1</w.rf>
   <form>Soud</form>
   <lemma>soud</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s11W2</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s11W3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s11W4</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s11W5</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s11W6</w.rf>
   <form>uvedeného</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s11W7</w.rf>
   <form>schválil</form>
   <lemma>schválit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p18s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p18s11W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s1">
  <m id="m-sample_data.txt-001-p19s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W8</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W9</w.rf>
   <form>14.08</form>
   <form_change>num_normalization</form_change>
   <lemma>14.08</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W11</w.rf>
   <form>1995</form>
   <lemma>1995</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W13</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W14</w.rf>
   <form>j</form>
   <lemma>j-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s1W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s2">
  <m id="m-sample_data.txt-001-p19s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W1</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W3</w.rf>
   <form>48</form>
   <lemma>48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W5</w.rf>
   <form>95-50</form>
   <lemma>95-50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W7</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W8</w.rf>
   <form>prohlášen</form>
   <lemma>prohlásit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W9</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W11</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W12</w.rf>
   <form>dlužníka</form>
   <lemma>dlužník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W13</w.rf>
   <form>KONA</form>
   <lemma>Kona_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W14</w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W16</w.rf>
   <form>ručením</form>
   <lemma>ručení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W17</w.rf>
   <form>omezeným</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W19</w.rf>
   <form>IČ</form>
   <lemma>Ič</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W20</w.rf>
   <form>15030270</form>
   <lemma>15030270</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W22</w.rf>
   <form>Žižkova</form>
   <lemma>Žižkov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W23</w.rf>
   <form>738</form>
   <lemma>738</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W24</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W25</w.rf>
   <form>IV</form>
   <lemma>IV-3`4</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W27</w.rf>
   <form>566</form>
   <lemma>566</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W28</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W29</w.rf>
   <form>Vysoké</form>
   <lemma>Vysoký-1_;K</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W30</w.rf>
   <form>Mýto</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W31</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W32</w.rf>
   <form>správcem</form>
   <lemma>správce</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W33</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W34</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W35</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W36</w.rf>
   <form>ustaven</form>
   <lemma>ustavit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W37</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W38</w.rf>
   <form>Pavel</form>
   <lemma>Pavel-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W39</w.rf>
   <form>Barinka</form>
   <lemma>Barina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W40</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W41</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W42</w.rf>
   <form>sídlem</form>
   <lemma>sídlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W43</w.rf>
   <form>Soudní</form>
   <lemma>soudní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W44</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W45</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W46</w.rf>
   <form>568</form>
   <lemma>568</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W47</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W48</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s2W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s2W49</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s3">
  <m id="m-sample_data.txt-001-p19s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W7</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W8</w.rf>
   <form>č.j</form>
   <lemma>č.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s3W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s4">
  <m id="m-sample_data.txt-001-p19s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W1</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W3</w.rf>
   <form>48</form>
   <lemma>48</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W5</w.rf>
   <form>95-158</form>
   <lemma>95-158</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W8</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W10</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W12</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W14</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W15</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W16</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W18</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W20</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W22</w.rf>
   <form>schválil</form>
   <lemma>schválit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W23</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W24</w.rf>
   <form>konečnou</form>
   <lemma>konečný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W25</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W26</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W27</w.rf>
   <form>zpeněžování</form>
   <lemma>zpeněžování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W28</w.rf>
   <form>majetku</form>
   <lemma>majetek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W29</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W30</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W31</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W32</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W33</w.rf>
   <form>vyúčtování</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W34</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W35</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W36</w.rf>
   <form>hotových</form>
   <lemma>hotový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W37</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W38</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W39</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W40</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s4W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s4W41</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s5">
  <m id="m-sample_data.txt-001-p19s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W1</w.rf>
   <form>Zpeněžením</form>
   <lemma>zpeněžení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W4</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W5</w.rf>
   <form>získáno</form>
   <lemma>získat_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W6</w.rf>
   <form>548080</form>
   <form_change>num_normalization</form_change>
   <lemma>548080</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W10</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W12</w.rf>
   <form>ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W13</w.rf>
   <form>příjmy</form>
   <lemma>příjem</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W14</w.rf>
   <form>činily</form>
   <lemma>činit_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W15</w.rf>
   <form>částku</form>
   <lemma>částka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W16</w.rf>
   <form>4148</form>
   <form_change>num_normalization</form_change>
   <lemma>4148</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W20</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W22</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W23</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W24</w.rf>
   <form>podstata</form>
   <lemma>podstata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W25</w.rf>
   <form>představuje</form>
   <lemma>představovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W26</w.rf>
   <form>částku</form>
   <lemma>částka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W27</w.rf>
   <form>552228</form>
   <form_change>num_normalization</form_change>
   <lemma>552228</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W29</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W30</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W31</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s6">
  <m id="m-sample_data.txt-001-p19s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W1</w.rf>
   <form>Dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W2</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W3</w.rf>
   <form>vyměřil</form>
   <lemma>vyměřit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W4</w.rf>
   <form>soudní</form>
   <lemma>soudní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W5</w.rf>
   <form>poplatek</form>
   <lemma>poplatek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W6</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W7</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W8</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W9</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W10</w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W11</w.rf>
   <form>5522</form>
   <form_change>num_normalization</form_change>
   <lemma>5522</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W15</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W16</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W17</w.rf>
   <form>položky</form>
   <lemma>položka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W18</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W19</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W22</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W23</w.rf>
   <form>sazebníku</form>
   <lemma>sazebník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W24</w.rf>
   <form>soudních</form>
   <lemma>soudní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W25</w.rf>
   <form>poplatků</form>
   <lemma>poplatek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W27</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W28</w.rf>
   <form>tvoří</form>
   <lemma>tvořit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W29</w.rf>
   <form>přílohu</form>
   <lemma>příloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W30</w.rf>
   <form>zák</form>
   <lemma>zákon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W32</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W33</w.rf>
   <form>549</form>
   <lemma>549</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W34</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W35</w.rf>
   <form>1991</form>
   <lemma>1991</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W36</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W37</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W38</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W39</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W40</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W41</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W42</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W43</w.rf>
   <form>novelou</form>
   <lemma>novela</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W44</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W45</w.rf>
   <form>uložil</form>
   <lemma>uložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W46</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W47</w.rf>
   <form>zaplatit</form>
   <lemma>zaplatit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W48</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W49</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W50</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W51</w.rf>
   <form>dnů</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W52</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W53</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W54</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W55</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W56-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W56</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W57-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W57</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s6W58-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s6W58</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s7">
  <m id="m-sample_data.txt-001-p19s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W2</w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W3</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W4</w.rf>
   <form>vynaložil</form>
   <lemma>vynaložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W5</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W6</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W7</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W9</w.rf>
   <form>náklady</form>
   <lemma>náklad</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W10</w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W11</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W12</w.rf>
   <form>správou</form>
   <lemma>správa</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W14</w.rf>
   <form>údržbou</form>
   <lemma>údržba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W15</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W16</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W17</w.rf>
   <form>částku</form>
   <lemma>částka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W18</w.rf>
   <form>411522</form>
   <form_change>num_normalization</form_change>
   <lemma>411522</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W21</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W22</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W23</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W24</w.rf>
   <form>daně</form>
   <lemma>daň_^(peněžní/naturální_dávka)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W26</w.rf>
   <form>poplatky</form>
   <lemma>poplatek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W28</w.rf>
   <form>účetnictví</form>
   <lemma>účetnictví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W30</w.rf>
   <form>archivaci</form>
   <lemma>archivace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W32</w.rf>
   <form>atd</form>
   <lemma>atd-1_:B_,x_^(a_tak_dále)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W34</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W35</w.rf>
   <form>blížeji</form>
   <lemma>blízko-1</lemma>
   <tag>Dg-------2A---2</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W36</w.rf>
   <form>specifikované</form>
   <lemma>specifikovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W37</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W38</w.rf>
   <form>schválené</form>
   <lemma>schválený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W39</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W40</w.rf>
   <form>zprávě</form>
   <lemma>zpráva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W41</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W42</w.rf>
   <form>č.l</form>
   <lemma>č.l</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s7W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s7W43</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s8">
  <m id="m-sample_data.txt-001-p19s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W1</w.rf>
   <form>141</form>
   <lemma>141</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W2</w.rf>
   <form>konkurzního</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W3</w.rf>
   <form>spisu</form>
   <lemma>spis</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W4</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W5</w.rf>
   <form>bodem</form>
   <lemma>bod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W6</w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W8</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s8W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s9">
  <m id="m-sample_data.txt-001-p19s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W2</w.rf>
   <form>odečtení</form>
   <lemma>odečtení_^(*4íst)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W5</w.rf>
   <form>nákladů</form>
   <lemma>náklad</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W6</w.rf>
   <form>spojených</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W7</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W8</w.rf>
   <form>správou</form>
   <lemma>správa</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W10</w.rf>
   <form>údržbou</form>
   <lemma>údržba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W11</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W12</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W14</w.rf>
   <form>přiznání</form>
   <lemma>přiznání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W15</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W16</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W17</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W18</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W20</w.rf>
   <form>vyměření</form>
   <lemma>vyměření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W21</w.rf>
   <form>soudního</form>
   <lemma>soudní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W22</w.rf>
   <form>poplatku</form>
   <lemma>poplatek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W24</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W25</w.rf>
   <form>ukládá</form>
   <lemma>ukládat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W26</w.rf>
   <form>výrok</form>
   <lemma>výrok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W27</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W29</w.rf>
   <form>nezůstaly</form>
   <lemma>zůstat</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W30</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W31</w.rf>
   <form>uspokojení</form>
   <lemma>uspokojení_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W32</w.rf>
   <form>věřitelů</form>
   <lemma>věřitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W33</w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W35</w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W36</w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWYP4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W37</w.rf>
   <form>finanční</form>
   <lemma>finanční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W38</w.rf>
   <form>prostředky</form>
   <lemma>prostředek-1_^(střed)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s9W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s9W39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p19s10">
  <m id="m-sample_data.txt-001-p19s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W1</w.rf>
   <form>Věřitelé</form>
   <lemma>věřitel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W2</w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W4</w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W5</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W6</w.rf>
   <form>nebudou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-NA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W7</w.rf>
   <form>uspokojeni</form>
   <lemma>uspokojit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W8</w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p19s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p19s10W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p20s1">
  <m id="m-sample_data.txt-001-p20s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s1W2</w.rf>
   <form>podepsaného</form>
   <lemma>podepsaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s1W4</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s1W5</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s1W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p20s2">
  <m id="m-sample_data.txt-001-p20s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W2</w.rf>
   <form>1026</form>
   <lemma>1026</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W3</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W4</w.rf>
   <form>94-</form>
   <lemma>94-</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W5</w.rf>
   <form>344-345</form>
   <lemma>344-345</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W8</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W10</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W12</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W14</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W15</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W16</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W18</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W20</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W22</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W23</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W24</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W25</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W27</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p20s3">
  <m id="m-sample_data.txt-001-p20s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W1</w.rf>
   <form>Správkyně</form>
   <lemma>správkyně_^(*4ce)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W5</w.rf>
   <form>Alena</form>
   <lemma>Alena_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W6</w.rf>
   <form>Brychtová</form>
   <lemma>Brychtová_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W8</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W9</w.rf>
   <form>sídlem</form>
   <lemma>sídlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W10</w.rf>
   <form>Veverkova</form>
   <lemma>Veverkův_;S_^(*2a)</lemma>
   <tag>AUIS2M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W11</w.rf>
   <form>1343</form>
   <lemma>1343</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W13</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W14</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W16</w.rf>
   <form>oznámila</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W17</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W18</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W19</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W21</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W23</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W25</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W26</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W27</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W28</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W29</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s3W30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p20s4">
  <m id="m-sample_data.txt-001-p20s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p20s5">
  <m id="m-sample_data.txt-001-p20s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p20s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p20s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p21s1">
  <m id="m-sample_data.txt-001-p21s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p21s2">
  <m id="m-sample_data.txt-001-p21s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W1</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W3</w.rf>
   <form>54</form>
   <lemma>54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W5</w.rf>
   <form>93</form>
   <lemma>93</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W8</w.rf>
   <form>22.1</form>
   <form_change>num_normalization</form_change>
   <lemma>22.1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W10</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W13</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W14</w.rf>
   <form>22.2</form>
   <form_change>num_normalization</form_change>
   <lemma>22.2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W16</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W18</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W19</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W20</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W21</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W23</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p21s3">
  <m id="m-sample_data.txt-001-p21s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W5</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W6</w.rf>
   <form>Štangl</form>
   <lemma>Štangl_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W8</w.rf>
   <form>Bratří</form>
   <lemma>bratr</lemma>
   <tag>NNMP2-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W9</w.rf>
   <form>Škorpilů</form>
   <lemma>škorpil</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W10</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W11</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W12</w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W14</w.rf>
   <form>556</form>
   <lemma>556</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W15</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W16</w.rf>
   <form>Vysoké</form>
   <lemma>Vysoký-1_;K</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W17</w.rf>
   <form>Mýto</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W19</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W20</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W21</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W22</w.rf>
   <form>11.4</form>
   <form_change>num_normalization</form_change>
   <lemma>11.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W24</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W26</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W27</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W28</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W29</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W30</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s3W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s3W31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p21s4">
  <m id="m-sample_data.txt-001-p21s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p21s5">
  <m id="m-sample_data.txt-001-p21s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p21s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p21s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p22s1">
  <m id="m-sample_data.txt-001-p22s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W1</w.rf>
   <form>Věřitel</form>
   <lemma>věřitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W2</w.rf>
   <form>Česká</form>
   <lemma>Český-1_;G_^(používá_se_i_pro_jména_org.,_výrobků_atd.)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W3</w.rf>
   <form>konsolidační</form>
   <lemma>konsolidační</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W4</w.rf>
   <form>agentura</form>
   <lemma>agentura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W5</w.rf>
   <form>podáním</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W8</w.rf>
   <form>4.8</form>
   <form_change>num_normalization</form_change>
   <lemma>4.8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W10</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W11</w.rf>
   <form>navrhl</form>
   <lemma>navrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W12</w.rf>
   <form>záměnu</form>
   <lemma>záměna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W13</w.rf>
   <form>účastníků</form>
   <lemma>účastník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W15</w.rf>
   <form>straně</form>
   <lemma>strana-1_^(v_prostoru)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W16</w.rf>
   <form>věřitele</form>
   <lemma>věřitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W18</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W20</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W21</w.rf>
   <form>svoji</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W22</w.rf>
   <form>přihlášenou</form>
   <lemma>přihlášený_^(*4sit)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W23</w.rf>
   <form>pohledávku</form>
   <lemma>pohledávka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W24</w.rf>
   <form>postoupil</form>
   <lemma>postoupit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W25</w.rf>
   <form>věřiteli</form>
   <lemma>věřitel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W26</w.rf>
   <form>CALDERSHOT</form>
   <lemma>CALDERSHOT</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W27</w.rf>
   <form>FINANCE</form>
   <lemma>finance</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W28</w.rf>
   <form>LTD</form>
   <lemma>Ltd_:B_,t</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W31</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W32</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W33</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W34</w.rf>
   <form>přechodu</form>
   <lemma>přechod</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W35</w.rf>
   <form>práv</form>
   <lemma>právo_^(právo_na_něco;_také_jako_obor)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s1W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s1W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p22s2">
  <m id="m-sample_data.txt-001-p22s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s2W1</w.rf>
   <form>Nový</form>
   <lemma>nový</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s2W2</w.rf>
   <form>věřitel</form>
   <lemma>věřitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s2W3</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s2W4</w.rf>
   <form>záměnou</form>
   <lemma>záměna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s2W5</w.rf>
   <form>souhlasil</form>
   <lemma>souhlasit_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s2W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p22s3">
  <m id="m-sample_data.txt-001-p22s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W1</w.rf>
   <form>Právní</form>
   <lemma>právní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W2</w.rf>
   <form>účinky</form>
   <lemma>účinek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W3</w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W4</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W5</w.rf>
   <form>podáním</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W6</w.rf>
   <form>přihlášky</form>
   <lemma>přihláška</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W7</w.rf>
   <form>pohledávek</form>
   <lemma>pohledávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W8</w.rf>
   <form>zůstávají</form>
   <lemma>zůstávat_:T_^(*4at)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W9</w.rf>
   <form>zachovány</form>
   <lemma>zachovat_:T_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p22s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p22s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p23s1">
  <m id="m-sample_data.txt-001-p23s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s1W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s1W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s1W4</w.rf>
   <form>24.10</form>
   <form_change>num_normalization</form_change>
   <lemma>24.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s1W6</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s1W7</w.rf>
   <form>čj</form>
   <lemma>čj-1_:B_^(číslo_jednací)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s1W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p23s2">
  <m id="m-sample_data.txt-001-p23s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W1</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W3</w.rf>
   <form>84</form>
   <lemma>84</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W5</w.rf>
   <form>97-316</form>
   <lemma>97-316</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W7</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W8</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W9</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W10</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W12</w.rf>
   <form>11.12</form>
   <form_change>num_normalization</form_change>
   <lemma>11.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W14</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W16</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W17</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W18</w.rf>
   <form>konkurs</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W20</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W21</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W22</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W23</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W24</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W25</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s2W26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p23s3">
  <m id="m-sample_data.txt-001-p23s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W1</w.rf>
   <form>Zároveň</form>
   <lemma>zároveň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W3</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W4</w.rf>
   <form>uloženo</form>
   <lemma>uložit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W6</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W8</w.rf>
   <form>3O-ti</form>
   <lemma>3O-ti</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W9</w.rf>
   <form>dnů</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W10</w.rf>
   <form>ode</form>
   <lemma>od-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W13</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W14</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W15</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W16</w.rf>
   <form>uzavřel</form>
   <lemma>uzavřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W17</w.rf>
   <form>účetní</form>
   <lemma>účetní-1_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W18</w.rf>
   <form>knihy</form>
   <lemma>kniha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W20</w.rf>
   <form>sestavil</form>
   <lemma>sestavit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W21</w.rf>
   <form>účetní</form>
   <lemma>účetní-1_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W22</w.rf>
   <form>závěrku</form>
   <lemma>závěrka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W23</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p23s4">
  <m id="m-sample_data.txt-001-p23s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W2</w.rf>
   <form>podání</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W3</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W4</w.rf>
   <form>doručené</form>
   <lemma>doručený_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W5</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W6</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W7</w.rf>
   <form>28.11</form>
   <form_change>num_normalization</form_change>
   <lemma>28.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W9</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W10</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W11</w.rf>
   <form>zjistil</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W13</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W15</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W17</w.rf>
   <form>shora</form>
   <lemma>shora</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W18</w.rf>
   <form>citovaným</form>
   <lemma>citovaný_^(*2t)</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W19</w.rf>
   <form>usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W20</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W21</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W22</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W23</w.rf>
   <form>splnil</form>
   <lemma>splnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s4W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p23s5">
  <m id="m-sample_data.txt-001-p23s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W1</w.rf>
   <form>Soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W2</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W3</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W5</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W7</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W9</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W10</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W11</w.rf>
   <form>odst.4</form>
   <lemma>odst.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W12</w.rf>
   <form>ZKV</form>
   <lemma>ZKV</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W14</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W15</w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W16</w.rf>
   <form>zprostil</form>
   <lemma>zprostit_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p23s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p23s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p24s1">
  <m id="m-sample_data.txt-001-p24s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p24s2">
  <m id="m-sample_data.txt-001-p24s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W1</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W3</w.rf>
   <form>1020</form>
   <lemma>1020</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W5</w.rf>
   <form>94-197</form>
   <lemma>94-197</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W8</w.rf>
   <form>7.1</form>
   <form_change>num_normalization</form_change>
   <lemma>7.1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W10</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W13</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W14</w.rf>
   <form>7.2</form>
   <form_change>num_normalization</form_change>
   <lemma>7.2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W16</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W18</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W19</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W20</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W21</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W23</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p24s3">
  <m id="m-sample_data.txt-001-p24s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s3W4</w.rf>
   <form>Mgr</form>
   <lemma>Mgr-1_:B_,x_^(magistr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p24s4">
  <m id="m-sample_data.txt-001-p24s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W1</w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W2</w.rf>
   <form>Janata</form>
   <lemma>Janata_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W4</w.rf>
   <form>Valdštejnská</form>
   <lemma>valdštejnský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W5</w.rf>
   <form>41</form>
   <lemma>41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W7</w.rf>
   <form>514</form>
   <lemma>514</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W8</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W9</w.rf>
   <form>Jilemnice</form>
   <lemma>Jilemnice_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W11</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W12</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W13</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W14</w.rf>
   <form>4.3</form>
   <form_change>num_normalization</form_change>
   <lemma>4.3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W16</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W18</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W19</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W20</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W21</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W22</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s4W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p24s5">
  <m id="m-sample_data.txt-001-p24s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s5W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s5W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p24s6">
  <m id="m-sample_data.txt-001-p24s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p24s6W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p24s6W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p25s1">
  <m id="m-sample_data.txt-001-p25s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p25s2">
  <m id="m-sample_data.txt-001-p25s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W2</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W3</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W4</w.rf>
   <form>94-193</form>
   <lemma>94-193</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W5</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W6</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W7</w.rf>
   <form>7.5</form>
   <form_change>num_normalization</form_change>
   <lemma>7.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W9</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W10</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W11</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W12</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W13</w.rf>
   <form>7.6</form>
   <form_change>num_normalization</form_change>
   <lemma>7.6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W15</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W16</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W17</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W18</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W19</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W20</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W21</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W22</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s2W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p25s3">
  <m id="m-sample_data.txt-001-p25s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W5</w.rf>
   <form>Drahomír</form>
   <lemma>Drahomír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W6</w.rf>
   <form>Růčka</form>
   <lemma>Růček_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W8</w.rf>
   <form>Máchova</form>
   <lemma>Máchův_;S_^(*2a)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W9</w.rf>
   <form>187</form>
   <lemma>187</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W11</w.rf>
   <form>550</form>
   <lemma>550</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W12</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W13</w.rf>
   <form>Broumov</form>
   <lemma>Broumov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W15</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W16</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W17</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W18</w.rf>
   <form>3.9</form>
   <form_change>num_normalization</form_change>
   <lemma>3.9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W20</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W22</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W23</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W24</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W25</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W26</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s3W27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p25s4">
  <m id="m-sample_data.txt-001-p25s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p25s5">
  <m id="m-sample_data.txt-001-p25s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p25s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p25s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s1">
  <m id="m-sample_data.txt-001-p26s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W1</w.rf>
   <form>Krajský</form>
   <lemma>krajský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W2</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W4</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W5</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W6</w.rf>
   <form>usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W7</w.rf>
   <form>vydaným</form>
   <lemma>vydaný-1_^(emitovat:_cenné_papíry,_knihu,_zvuk,...)_(*4t-1)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W8</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W9</w.rf>
   <form>13.9</form>
   <form_change>num_normalization</form_change>
   <lemma>13.9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W11</w.rf>
   <form>1995</form>
   <lemma>1995</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W12</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W13</w.rf>
   <form>čj</form>
   <lemma>čj-1_:B_^(číslo_jednací)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s1W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s1W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s2">
  <m id="m-sample_data.txt-001-p26s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W1</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W3</w.rf>
   <form>1018</form>
   <lemma>1018</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W5</w.rf>
   <form>94-106</form>
   <lemma>94-106</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W6</w.rf>
   <form>prohlásil</form>
   <lemma>prohlásit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W7</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W9</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W10</w.rf>
   <form>dlužníka</form>
   <lemma>dlužník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W11</w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W12</w.rf>
   <form>Plecháček</form>
   <lemma>plecháček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W14</w.rf>
   <form>r</form>
   <lemma>rok_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W16</w.rf>
   <form>č</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W18</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W19</w.rf>
   <form>560610</form>
   <lemma>560610</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W20</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W21</w.rf>
   <form>0049</form>
   <lemma>0049</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W23</w.rf>
   <form>IČ</form>
   <lemma>Ič</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W24</w.rf>
   <form>13183311</form>
   <lemma>13183311</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W26</w.rf>
   <form>Čapkova</form>
   <lemma>Čapkův_;S_^(*3ek)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W27</w.rf>
   <form>182</form>
   <lemma>182</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W29</w.rf>
   <form>533</form>
   <lemma>533</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W30</w.rf>
   <form>54</form>
   <lemma>54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W31</w.rf>
   <form>Pardubice-Rybitví</form>
   <lemma>Pardubice-Rybitev</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s2W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s2W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s3">
  <m id="m-sample_data.txt-001-p26s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W1</w.rf>
   <form>Správcem</form>
   <lemma>správce</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W5</w.rf>
   <form>ustaven</form>
   <lemma>ustavit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W6</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W7</w.rf>
   <form>Dušan</form>
   <lemma>Dušan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W8</w.rf>
   <form>Diviš</form>
   <lemma>Diviš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W10</w.rf>
   <form>Ulrichovo</form>
   <lemma>Ulrichův_;S_^(*2)</lemma>
   <tag>AUNS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W11</w.rf>
   <form>nám.</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W12</w.rf>
   <form>737</form>
   <lemma>737</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W14</w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W15</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W16</w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W17</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s3W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s4">
  <m id="m-sample_data.txt-001-p26s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W1</w.rf>
   <form>Podáním</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W2</w.rf>
   <form>doručeným</form>
   <lemma>doručený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W4</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W5</w.rf>
   <form>31.7</form>
   <form_change>num_normalization</form_change>
   <lemma>31.7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W7</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W8</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W9</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W10</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W11</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W12</w.rf>
   <form>konečnou</form>
   <lemma>konečný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W13</w.rf>
   <form>zprávu</form>
   <lemma>zpráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W14</w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W16</w.rf>
   <form>vyúčtováním</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W17</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W18</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W20</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s4W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s5">
  <m id="m-sample_data.txt-001-p26s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W1</w.rf>
   <form>Konečná</form>
   <lemma>konečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W2</w.rf>
   <form>zpráva</form>
   <lemma>zpráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W4</w.rf>
   <form>projednána</form>
   <lemma>projednat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W5</w.rf>
   <form>postupem</form>
   <lemma>postup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W6</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W7</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W9</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W10</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W11</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W12</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W13</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W15</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W17</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W18</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W19</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s5W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s6">
  <m id="m-sample_data.txt-001-p26s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W8</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W9</w.rf>
   <form>10.10</form>
   <form_change>num_normalization</form_change>
   <lemma>10.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W11</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W13</w.rf>
   <form>č.j</form>
   <lemma>č.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s6W14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s7">
  <m id="m-sample_data.txt-001-p26s7W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W1</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W3</w.rf>
   <form>1018</form>
   <lemma>1018</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W5</w.rf>
   <form>94-771</form>
   <lemma>94-771</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W7</w.rf>
   <form>jež</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJNS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W8</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W9</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W10</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W12</w.rf>
   <form>8.11</form>
   <form_change>num_normalization</form_change>
   <lemma>8.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W14</w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W16</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W17</w.rf>
   <form>konečná</form>
   <lemma>konečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W18</w.rf>
   <form>zpráva</form>
   <lemma>zpráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W20</w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W21</w.rf>
   <form>vyúčtování</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W22</w.rf>
   <form>odměny</form>
   <lemma>odměna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W23</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W25</w.rf>
   <form>hotových</form>
   <lemma>hotový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W26</w.rf>
   <form>výdajů</form>
   <lemma>výdaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W28</w.rf>
   <form>schválena</form>
   <lemma>schválit</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s7W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s7W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s8">
  <m id="m-sample_data.txt-001-p26s8W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W1</w.rf>
   <form>Soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W2</w.rf>
   <form>vyměřil</form>
   <lemma>vyměřit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W3</w.rf>
   <form>soudní</form>
   <lemma>soudní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W4</w.rf>
   <form>poplatek</form>
   <lemma>poplatek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W5</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W6</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W7</w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W9</w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W10</w.rf>
   <form>44559</form>
   <form_change>num_normalization</form_change>
   <lemma>44559</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W14</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W15</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W16</w.rf>
   <form>položky</form>
   <lemma>položka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W17</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W18</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W22</w.rf>
   <form>sazebníku</form>
   <lemma>sazebník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W23</w.rf>
   <form>soudních</form>
   <lemma>soudní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W24</w.rf>
   <form>poplatků</form>
   <lemma>poplatek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W26</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W27</w.rf>
   <form>tvoří</form>
   <lemma>tvořit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W28</w.rf>
   <form>přílohu</form>
   <lemma>příloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W29</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W30</w.rf>
   <form>č.</form>
   <lemma>č-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W31</w.rf>
   <form>549</form>
   <lemma>549</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W32</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W33</w.rf>
   <form>1991</form>
   <lemma>1991</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W34</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W36</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W37</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W38</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W39</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W40</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W41</w.rf>
   <form>31.12</form>
   <form_change>num_normalization</form_change>
   <lemma>31.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W42</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W43</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W44</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W45</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W46</w.rf>
   <form>uložil</form>
   <lemma>uložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W47</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W48-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W48</w.rf>
   <form>zaplatit</form>
   <lemma>zaplatit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W49-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W49</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W50-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W50</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W51-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W51</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W52-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W52</w.rf>
   <form>dnů</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W53-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W53</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W54-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W54</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W55-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W55</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W56-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W56</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W57-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W57</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W58-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W58</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s8W59-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s8W59</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s9">
  <m id="m-sample_data.txt-001-p26s9W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W1</w.rf>
   <form>Návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W2</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W3</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W4</w.rf>
   <form>předložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W5</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W6</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W8</w.rf>
   <form>26.2</form>
   <form_change>num_normalization</form_change>
   <lemma>26.2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W10</w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s9W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s9W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s10">
  <m id="m-sample_data.txt-001-p26s10W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W1</w.rf>
   <form>Rozdělení</form>
   <lemma>rozdělení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W2</w.rf>
   <form>výtěžku</form>
   <lemma>výtěžek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W3</w.rf>
   <form>získaného</form>
   <lemma>získaný_^(*2t)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W4</w.rf>
   <form>zpeněžením</form>
   <lemma>zpeněžení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W5</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W6</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W7</w.rf>
   <form>vychází</form>
   <lemma>vycházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W9</w.rf>
   <form>údajů</form>
   <lemma>údaj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W10</w.rf>
   <form>obsažených</form>
   <lemma>obsažený_^(*5áhnout)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W11</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W12</w.rf>
   <form>schválené</form>
   <lemma>schválený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W13</w.rf>
   <form>konečné</form>
   <lemma>konečný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W14</w.rf>
   <form>zprávě</form>
   <lemma>zpráva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W16</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W17</w.rf>
   <form>provedeno</form>
   <lemma>provést</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W19</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W20</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W21</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W23</w.rf>
   <form>§§</form>
   <lemma>§§</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W24</w.rf>
   <form>31</form>
   <lemma>31</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W26</w.rf>
   <form>32</form>
   <lemma>32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W27</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W28</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W29</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W31</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s10W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s10W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s11">
  <m id="m-sample_data.txt-001-p26s11W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W2</w.rf>
   <form>celkových</form>
   <lemma>celkový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W3</w.rf>
   <form>příjmů</form>
   <lemma>příjem</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W4</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W5</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W7</w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W8</w.rf>
   <form>4456739</form>
   <form_change>num_normalization</form_change>
   <lemma>4456739</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W12</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W13</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W15</w.rf>
   <form>odměnu</form>
   <lemma>odměna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W16</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W17</w.rf>
   <form>použito</form>
   <lemma>použít</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W18</w.rf>
   <form>757540.80</form>
   <form_change>num_normalization</form_change>
   <lemma>757540.80</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W19</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W22</w.rf>
   <form>hotové</form>
   <lemma>hotový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W23</w.rf>
   <form>výdaje</form>
   <lemma>výdaj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W24</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W25</w.rf>
   <form>částka</form>
   <lemma>částka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W26</w.rf>
   <form>228654</form>
   <form_change>num_normalization</form_change>
   <lemma>228654</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W27</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W28</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W29</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W30</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W32</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W33</w.rf>
   <form>náklady</form>
   <lemma>náklad</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W34</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W35</w.rf>
   <form>správu</form>
   <lemma>správa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W36</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W37-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W37</w.rf>
   <form>údržbu</form>
   <lemma>údržba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W38-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W38</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W39-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W39</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W40-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W40</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W41-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W41</w.rf>
   <form>vynaloženo</form>
   <lemma>vynaložit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W42-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W42</w.rf>
   <form>1109306</form>
   <form_change>num_normalization</form_change>
   <lemma>1109306</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W43-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W43</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W44-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W44</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W45-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W45</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W46-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W46</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s11W47-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s11W47</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s12">
  <m id="m-sample_data.txt-001-p26s12W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W1</w.rf>
   <form>Soudní</form>
   <lemma>soudní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W2</w.rf>
   <form>poplatek</form>
   <lemma>poplatek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W3</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W4</w.rf>
   <form>činí</form>
   <lemma>činit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W5</w.rf>
   <form>44559</form>
   <form_change>num_normalization</form_change>
   <lemma>44559</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W9</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W11</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W12</w.rf>
   <form>rezervu</form>
   <lemma>rezerva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W14</w.rf>
   <form>úkony</form>
   <lemma>úkon</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W15</w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W16</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W17</w.rf>
   <form>ukončením</form>
   <lemma>ukončení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W18</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W19</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W20</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W21</w.rf>
   <form>ponechává</form>
   <lemma>ponechávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W22</w.rf>
   <form>částku</form>
   <lemma>částka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W23</w.rf>
   <form>4700</form>
   <form_change>num_normalization</form_change>
   <lemma>4700</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W27</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s12W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s12W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s13">
  <m id="m-sample_data.txt-001-p26s13W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W1</w.rf>
   <form>Mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W2</w.rf>
   <form>věřitele</form>
   <lemma>věřitel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W4</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W5</w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W6</w.rf>
   <form>rozdělena</form>
   <lemma>rozdělit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W7</w.rf>
   <form>částka</form>
   <lemma>částka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W8</w.rf>
   <form>966474.60</form>
   <form_change>num_normalization</form_change>
   <lemma>966474.60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W9</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s13W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s13W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p26s14">
  <m id="m-sample_data.txt-001-p26s14W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s14W1</w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s14W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s14W2</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s14W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s14W3</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s14W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s14W4</w.rf>
   <form>podstata</form>
   <lemma>podstata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s14W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s14W5</w.rf>
   <form>vyčerpána</form>
   <lemma>vyčerpat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p26s14W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p26s14W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p27s1">
  <m id="m-sample_data.txt-001-p27s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p27s2">
  <m id="m-sample_data.txt-001-p27s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W1</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W3</w.rf>
   <form>1034</form>
   <lemma>1034</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W5</w.rf>
   <form>94-339</form>
   <lemma>94-339</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W8</w.rf>
   <form>26.9</form>
   <form_change>num_normalization</form_change>
   <lemma>26.9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W10</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W13</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W14</w.rf>
   <form>27.10</form>
   <form_change>num_normalization</form_change>
   <lemma>27.10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W16</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W18</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W19</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W20</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W21</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W23</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p27s3">
  <m id="m-sample_data.txt-001-p27s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s3W4</w.rf>
   <form>Mgr</form>
   <lemma>Mgr-1_:B_,x_^(magistr)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s3W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p27s4">
  <m id="m-sample_data.txt-001-p27s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W1</w.rf>
   <form>Aleš</form>
   <lemma>Aleš-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W2</w.rf>
   <form>Velc</form>
   <lemma>Velc_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W4</w.rf>
   <form>Smetanovo</form>
   <lemma>Smetanův_;S_^(*2a)</lemma>
   <tag>AUNS1M---------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W5</w.rf>
   <form>nám.</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W6</w.rf>
   <form>126</form>
   <lemma>126</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W8</w.rf>
   <form>570</form>
   <lemma>570</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W9</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W10</w.rf>
   <form>Litomyšl</form>
   <lemma>Litomyšl_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W12</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W13</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W14</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W15</w.rf>
   <form>9.8</form>
   <form_change>num_normalization</form_change>
   <lemma>9.8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W17</w.rf>
   <form>2001</form>
   <lemma>2001</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W19</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W20</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W21</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W22</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W23</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s4W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p27s5">
  <m id="m-sample_data.txt-001-p27s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s5W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s5W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p27s6">
  <m id="m-sample_data.txt-001-p27s6W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p27s6W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p27s6W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p28s1">
  <m id="m-sample_data.txt-001-p28s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W4</w.rf>
   <form>24.2</form>
   <form_change>num_normalization</form_change>
   <lemma>24.2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W6</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W8</w.rf>
   <form>č.j</form>
   <lemma>č.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p28s2">
  <m id="m-sample_data.txt-001-p28s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W1</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W3</w.rf>
   <form>46</form>
   <lemma>46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W5</w.rf>
   <form>97-322</form>
   <lemma>97-322</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W7</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W8</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W9</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W10</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W12</w.rf>
   <form>4.5</form>
   <form_change>num_normalization</form_change>
   <lemma>4.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W14</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W15</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W16</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W17</w.rf>
   <form>konkurs</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W19</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W20</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W21</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W22</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W23</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W24</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p28s3">
  <m id="m-sample_data.txt-001-p28s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W1</w.rf>
   <form>Zároveň</form>
   <lemma>zároveň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W3</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W4</w.rf>
   <form>uloženo</form>
   <lemma>uložit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W6</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W8</w.rf>
   <form>30-ti</form>
   <lemma>30-ti</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W9</w.rf>
   <form>dnů</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W10</w.rf>
   <form>ode</form>
   <lemma>od-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W13</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W14</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W15</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W16</w.rf>
   <form>uzavřel</form>
   <lemma>uzavřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W17</w.rf>
   <form>účetní</form>
   <lemma>účetní-1_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W18</w.rf>
   <form>knihy</form>
   <lemma>kniha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W20</w.rf>
   <form>sestavil</form>
   <lemma>sestavit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W21</w.rf>
   <form>účetní</form>
   <lemma>účetní-1_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W22</w.rf>
   <form>závěrku</form>
   <lemma>závěrka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W23</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p28s4">
  <m id="m-sample_data.txt-001-p28s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W2</w.rf>
   <form>podání</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W3</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W4</w.rf>
   <form>doručeného</form>
   <lemma>doručený_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W5</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W6</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W7</w.rf>
   <form>8.6</form>
   <form_change>num_normalization</form_change>
   <lemma>8.6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W9</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W10</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W11</w.rf>
   <form>zjistil</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W13</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W15</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W17</w.rf>
   <form>shora</form>
   <lemma>shora</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W18</w.rf>
   <form>citovaným</form>
   <lemma>citovaný_^(*2t)</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W19</w.rf>
   <form>usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W20</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W21</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W22</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W23</w.rf>
   <form>splnil</form>
   <lemma>splnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s4W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p28s5">
  <m id="m-sample_data.txt-001-p28s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W1</w.rf>
   <form>Soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W2</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W3</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W5</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W7</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W9</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W10</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W11</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W12</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W13</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W14</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W15</w.rf>
   <form>konkursu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W17</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W19</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W20</w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W21</w.rf>
   <form>zprostil</form>
   <lemma>zprostit_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p28s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p28s5W22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p29s1">
  <m id="m-sample_data.txt-001-p29s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s1W2</w.rf>
   <form>podepsaného</form>
   <lemma>podepsaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s1W4</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s1W5</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s1W6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p29s2">
  <m id="m-sample_data.txt-001-p29s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W2</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W3</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W4</w.rf>
   <form>93</form>
   <lemma>93</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W5</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W6</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W7</w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W9</w.rf>
   <form>04</form>
   <lemma>04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W11</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W12</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W13</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W14</w.rf>
   <form>moc</form>
   <lemma>moc-2_^(mnoho_něčeho_[se_subst._v_gen.])</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W15</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W16</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W18</w.rf>
   <form>06</form>
   <lemma>06</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W20</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W22</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W23</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W24</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W25</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W27</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s2W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s2W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p29s3">
  <m id="m-sample_data.txt-001-p29s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W5</w.rf>
   <form>Antonín</form>
   <lemma>Antonín_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W6</w.rf>
   <form>Zelinka</form>
   <lemma>Zelinka_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W7</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W8</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W9</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W11</w.rf>
   <form>06</form>
   <lemma>06</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W13</w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W14</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W16</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W17</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W18</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W19</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W20</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s3W21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p29s4">
  <m id="m-sample_data.txt-001-p29s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p29s5">
  <m id="m-sample_data.txt-001-p29s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W11</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W13</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W14</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W15</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W16</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W18</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W20</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W21</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W22</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p29s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p29s5W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p30s1">
  <m id="m-sample_data.txt-001-p30s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W2</w.rf>
   <form>Krajského</form>
   <lemma>krajský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W3</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W5</w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W6</w.rf>
   <form>Králové</form>
   <lemma>Králová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W7</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W8</w.rf>
   <form>j</form>
   <lemma>jako_:B</lemma>
   <tag>J,------------8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p30s2">
  <m id="m-sample_data.txt-001-p30s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W1</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W3</w.rf>
   <form>153</form>
   <lemma>153</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W5</w.rf>
   <form>94-436</form>
   <lemma>94-436</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W7</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W8</w.rf>
   <form>9.4</form>
   <form_change>num_normalization</form_change>
   <lemma>9.4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W10</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W13</w.rf>
   <form>moc</form>
   <lemma>moc-3_^(velmi,_ve_spojení_s_adj.,_př._moc_hezká)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W14</w.rf>
   <form>10.5</form>
   <form_change>num_normalization</form_change>
   <lemma>10.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W16</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W18</w.rf>
   <form>rozvrhl</form>
   <lemma>rozvrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W19</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W20</w.rf>
   <form>zpeněžený</form>
   <lemma>zpeněžený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W21</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W22</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W23</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s2W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p30s3">
  <m id="m-sample_data.txt-001-p30s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W1</w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W4</w.rf>
   <form>JUDr.</form>
   <lemma>JUDr-1_:B_,x_^(doktor_práv)</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W5</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W6</w.rf>
   <form>Carda</form>
   <lemma>Carda_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W8</w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W9</w.rf>
   <form>věží</form>
   <lemma>věž</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W10</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W12</w.rf>
   <form>568</form>
   <lemma>568</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W13</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W14</w.rf>
   <form>Svitavy</form>
   <lemma>Svitava_;G_^(řeka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W16</w.rf>
   <form>oznámil</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W17</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W18</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W19</w.rf>
   <form>10.6</form>
   <form_change>num_normalization</form_change>
   <lemma>10.6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W21</w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W23</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W24</w.rf>
   <form>rozvrhové</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W25</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W26</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W27</w.rf>
   <form>splněno</form>
   <lemma>splnit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s3W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s3W28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p30s4">
  <m id="m-sample_data.txt-001-p30s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W2</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W3</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W4</w.rf>
   <form>uvedených</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W5</w.rf>
   <form>skutečností</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W6</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W7</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W8</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W9</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W10</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W12</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W13</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W14</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W15</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W16</w.rf>
   <form>písm</form>
   <lemma>písmeno_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W18</w.rf>
   <form>b</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W19</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W20</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W25</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W26</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W27</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W28</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W30</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W31</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W32</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W33-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W33</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W34-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W34</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W35-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W35</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s4W36-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s4W36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p30s5">
  <m id="m-sample_data.txt-001-p30s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W1</w.rf>
   <form>Správci</form>
   <lemma>správce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W2</w.rf>
   <form>konkurzní</form>
   <lemma>konkursní-1_^(týkající_se_soutěže)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W3</w.rf>
   <form>podstaty</form>
   <lemma>podstata</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W5</w.rf>
   <form>uložena</form>
   <lemma>uložit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W6</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W7</w.rf>
   <form>dle</form>
   <lemma>dle</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W8</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W10</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W11</w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W12</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W13</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W14</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W15</w.rf>
   <form>přihlédnutím</form>
   <lemma>přihlédnutí_^(*3out)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W16</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W17</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W19</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W20</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W21</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W22</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W23</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W24</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W25</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W27</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W28</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W29</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W30-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W30</w.rf>
   <form>platném</form>
   <lemma>platný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W31-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W31</w.rf>
   <form>znění</form>
   <lemma>znění_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p30s5W32-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p30s5W32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p31s1">
  <m id="m-sample_data.txt-001-p31s1W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W1</w.rf>
   <form>Usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s1W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s1W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W3</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s1W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W4</w.rf>
   <form>4.11</form>
   <form_change>num_normalization</form_change>
   <lemma>4.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s1W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s1W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W6</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s1W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s1W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W8</w.rf>
   <form>č.j</form>
   <lemma>č.j</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s1W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s1W9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p31s2">
  <m id="m-sample_data.txt-001-p31s2W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W1</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W2</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W3</w.rf>
   <form>38</form>
   <lemma>38</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W5</w.rf>
   <form>97-228</form>
   <lemma>97-228</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W7</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W8</w.rf>
   <form>nabylo</form>
   <lemma>nabýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W9</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W10</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W12</w.rf>
   <form>30.12</form>
   <form_change>num_normalization</form_change>
   <lemma>30.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W14</w.rf>
   <form>2004</form>
   <lemma>2004</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W15</w.rf>
   <form>zrušil</form>
   <lemma>zrušit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W16</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W17</w.rf>
   <form>konkurz</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W19</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W20</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W21</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W22</w.rf>
   <form>splnění</form>
   <lemma>splnění_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W23</w.rf>
   <form>rozvrhového</form>
   <lemma>rozvrhový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W24</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s2W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s2W25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p31s3">
  <m id="m-sample_data.txt-001-p31s3W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W1</w.rf>
   <form>Zároveň</form>
   <lemma>zároveň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W3</w.rf>
   <form>správci</form>
   <lemma>správce</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W4</w.rf>
   <form>uloženo</form>
   <lemma>uložit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W6</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W8</w.rf>
   <form>30-ti</form>
   <lemma>30-ti</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W9</w.rf>
   <form>dnů</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W10</w.rf>
   <form>ode</form>
   <lemma>od-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W11</w.rf>
   <form>dne</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W12</w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W13</w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W14</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W15</w.rf>
   <form>usnesení</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W16</w.rf>
   <form>uzavřel</form>
   <lemma>uzavřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W17</w.rf>
   <form>účetní</form>
   <lemma>účetní-1_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W18</w.rf>
   <form>knihy</form>
   <lemma>kniha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W20</w.rf>
   <form>sestavil</form>
   <lemma>sestavit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W21</w.rf>
   <form>účetní</form>
   <lemma>účetní-1_,a</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W22</w.rf>
   <form>závěrku</form>
   <lemma>závěrka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W23</w.rf>
   <form>úpadce</form>
   <lemma>úpadce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s3W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s3W24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p31s4">
  <m id="m-sample_data.txt-001-p31s4W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W2</w.rf>
   <form>podání</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W3</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W4</w.rf>
   <form>doručeného</form>
   <lemma>doručený_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W5</w.rf>
   <form>soudu</form>
   <lemma>soud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W6</w.rf>
   <form>1.03</form>
   <form_change>num_normalization</form_change>
   <lemma>1.03</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W8</w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W9</w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W10</w.rf>
   <form>zjistil</form>
   <lemma>zjistit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W12</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W14</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W15</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W16</w.rf>
   <form>shora</form>
   <lemma>shora</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W17</w.rf>
   <form>citovaným</form>
   <lemma>citovaný_^(*2t)</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W18</w.rf>
   <form>usnesením</form>
   <lemma>usnesení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W19</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W20</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W21</w.rf>
   <form>povinnost</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W22</w.rf>
   <form>splnil</form>
   <lemma>splnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s4W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s4W23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-sample_data.txt-001-p31s5">
  <m id="m-sample_data.txt-001-p31s5W1-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W1</w.rf>
   <form>Soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W2-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W2</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W3-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W3</w.rf>
   <form>postupoval</form>
   <lemma>postupovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W4-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W5-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W5</w.rf>
   <form>souladu</form>
   <lemma>soulad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W6-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W7-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W7</w.rf>
   <form>ust</form>
   <lemma>ustanovení_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W8-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W9-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W9</w.rf>
   <form>§</form>
   <lemma>paragraf</lemma>
   <tag>NNIXX-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W10-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W10</w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W11-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W11</w.rf>
   <form>odst.</form>
   <lemma>odstavec_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W12-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W12</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W13-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W13</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W14-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W14</w.rf>
   <form>č.</form>
   <lemma>číslo_:B</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W15-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W15</w.rf>
   <form>328</form>
   <lemma>328</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W16-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W16</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W17-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W17</w.rf>
   <form>1991</form>
   <lemma>1991</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W18-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W18</w.rf>
   <form>Sb</form>
   <lemma>Sb-1_:B_;j_^(Sbírka,_např._zákonů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W19-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W20-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W21-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W22-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W22</w.rf>
   <form>konkurzu</form>
   <lemma>konkurs-1_^(soutěž)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W23-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W24-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W24</w.rf>
   <form>vyrovnání</form>
   <lemma>vyrovnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W25-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W26-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W26</w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W27-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W27</w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W28-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W28</w.rf>
   <form>zprostil</form>
   <lemma>zprostit_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-sample_data.txt-001-p31s5W29-Tb">
   <src.rf>tagger-b</src.rf>
   <w.rf>w#w-sample_data.txt-001-p31s5W29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
